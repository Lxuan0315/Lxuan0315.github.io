
/**变量/常量/字符串注释
 * a                      变量为主菜单选项变量
 * jinbi                  变量为已获得的Win豆数量
 * qiandaocishu           变量为判断今日是否签到
 * b                      变量为判断是否结束主菜单循环
 * a+[数字]和a+[字母]      变量为开启Scanner的变量
 * num+[数字]             变量为计算器变量
 * jieguo                 变量为计算器计算的结果
 * x                      变量为识别WI农场选项
 * z                      变量为判断是否结束WI农场主菜单循环
 * shijian                变量为WI农场判断种子成熟变量
 * q                      变量为电源选项判断
 */

import java.util.Scanner;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class Winllx {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("系统正在启动，请稍候...");
            try {
                Thread.sleep(2000); // 等待
            } catch (InterruptedException e) {
                System.out.println("线程错误");
            }
            int a = 0;
            int b = 0;
            int z = 0;
            int za = 0;
            int q = 0;
            while (b != 4) {// 重复执行主菜单
                System.out.println("                菜单 ");
                System.out.println("1.Winllx的图标             2.弹出Winllx分窗口");
                System.out.println("3.计算器                   4打开虚拟键盘");
                System.out.println("5.暂无                     6.Winllx便笺");
                System.out.println("0.退出");
                System.out.println("请输入序号(数字):");
                a = scanner.nextInt();

                // 选项1
                switch (a) {
                    case 1:
                        System.out.println("正在显示介绍...");
                        Winllx5.Winllx5();
                        break;
                    case 2:// 选项2 打开Winllx分窗口
                        new Winllx1();
                        System.out.println("已弹出窗口...");
                        break;

                    case 3:// 选项3
                        System.out.println("1.四则运算          2.面积计算");
                        Scanner a3 = new Scanner(System.in);
                        za = scanner.nextInt();

                        if (za == 1) { // 四则运算
                            System.out.println("计算器可计算整数/小数的加法(+)减法(-)乘法(*)除法(/)");
                            Scanner num = new Scanner(System.in);
                            System.out.println("请输入第一个运算数字：");
                            double num1 = num.nextDouble();
                            System.out.println("请输入需要的运算符（+ - * /）");
                            char num2 = num.next().charAt(0);
                            System.out.println("请输入第二个运算数字：");
                            double num3 = num.nextDouble();
                            double jieguo;
                            if (num2 == '+') {
                                jieguo = num1 + num3;
                                System.out.println(num1 + "+" + num3 + "=" + jieguo);
                            } else if (num2 == '-') {
                                jieguo = num1 + num3;
                                System.out.println(num1 + "-" + num3 + "=" + jieguo);
                            } else if (num2 == '*') {
                                jieguo = num1 * num3;
                                System.out.println(num1 + "*" + num3 + "=" + jieguo);
                            } else if (num2 == '/') {
                                jieguo = num1 / num3;
                                System.out.println(num1 + "/" + num3 + "=" + jieguo);
                            } else {
                                System.out.println("错误,无法计算");
                            }
                        } else if (za == 2) { //

                        }

                        System.out.println("请按任意键回车继续");
                        Scanner a1 = new Scanner(System.in);
                        String aa = a1.next();
                        break;

                    case 4:// 选项4 虚拟键盘
                        System.out.println("暂时未开发");
                        System.out.println("请输入任意字符 回车继续");
                        Scanner a9 = new Scanner(System.in);
                        String ab = a9.next();
                        break;

                    case 6:
                        Winllx3.Winllx3();
                        System.out.println("便笺已启动");
                        break;

                    case 0:// 选项0 退出系统
                        System.out.println("已退出Winllx系统");
                        b = 4;
                        break;

                    default:
                        System.out.println("无此服务，请重新输入");
                        System.out.println("请按任意键回车继续");
                        Scanner a2 = new Scanner(System.in);
                        String ac = a2.next();
                }
            }
        }
    }
}

class Winllx1 extends JFrame { // 创建父窗口类

    public Winllx1() {

        Container container = getContentPane(); // 获得窗体容器
        container.setLayout(null); // 容器使用null布局
        JTextArea ta = new JTextArea(20, 50);
        JScrollPane sp = new JScrollPane(ta);
        JButton bl = new JButton("打开新窗口"); // 定义一个按钮
        bl.setBounds(10, 10, 100, 21); // 定义按钮在容器中的坐标和大小
        bl.addActionListener(new ActionListener() { // 为按钮添加点击事件
            public void actionPerformed(ActionEvent e) { // 创建MyJdialog对话框
                MyJDialog dialog = new MyJDialog(Winllx1.this);
                dialog.setVisible(true);
            }
        });
        container.add(bl);
        container.setBackground(Color.WHITE); // 设置颜色蓝色
        setSize(200, 200);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String args[]) {
        System.out.println("请输入登录密码：");
        try (Scanner scanner = new Scanner(System.in)) {
            int psw = scanner.nextInt();
            int s = 0;
            while (s <= 3) {
                s++;
                if (psw == 20120315) {
                    System.out.print("密码正确，系统已启动");
                    new Winllx1();

                    break;
                } else {
                    System.out.println("密码错误");
                    int psw3 = 3 - s;
                    System.out.println("请再次输入登录密码，你还有" + psw3 + "次机会");
                }
                if (s > 2) {
                    System.out.println("账号冻结");
                    break;
                }
                psw = scanner.nextInt();
            }
        }

    }

}

class MyJDialog extends JDialog { // 创建自定义窗体

    public MyJDialog(Winllx1 frame) {// 实例化一个JDialog类对象，指定对话框的父窗体和窗体标题和类型
        super(frame, "Winllx", true);
        Container container = getContentPane(); // 创建一个容器
        container.add(new JLabel("欢迎使用Winllx！")); // 在容器中添加标签
        setBounds(120, 120, 100, 100); // 设置对话框窗体在桌面显示的坐标和大小.
        container.setLayout(null); // 容器使用null布局
        JTextArea ta = new JTextArea(20, 50);
        JScrollPane sp = new JScrollPane(ta);
        JButton bl = new JButton("打开新窗口"); // 定义一个按钮
        bl.setBounds(10, 10, 100, 21); // 定义按钮在容器中的坐标和大小
    }
}

class Winllx3 {
    static void Winllx3() {

        JFrame f = new JFrame("Winllx便签");
        f.setSize(400, 300);
        f.setLocation(200, 200);

        f.setLayout(new FlowLayout());

        JLabel l = new JLabel("输入区：");

        JTextArea ta = new JTextArea();
        ta.setPreferredSize(new Dimension(200, 150));
        // 设置自动换行
        ta.setLineWrap(true);
        f.add(l);
        f.add(ta);

        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        f.setVisible(true);
    }
}

class Winllx5 {
    static void Winllx5() {

        JFrame f = new JFrame("Winllx简介");
        f.setSize(400, 300);
        f.setLocation(580, 200);
        f.setLayout(null);

        JLabel l = new JLabel();

        // 根据图片创建ImageIcon对象
        ImageIcon i = new ImageIcon("E:/java/winllxOS/系统/2.0/Winllx图标.png");
        // 设置ImageIcon
        l.setIcon(i);
        // label的大小设置为ImageIcon,否则显示不完整
        l.setBounds(50, 50, i.getIconWidth(), i.getIconHeight());

        f.add(l);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        f.setVisible(true);
    }
}
