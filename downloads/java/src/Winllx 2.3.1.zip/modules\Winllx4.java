package modules;

import app.Winllx;
import ui.*;
import utils.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

// ==================== 子模块：文件管理 ====================
public class Winllx4 {

    private JFrame frame;
    private JTree dirTree;
    private JTable fileTable;
    private DefaultTableModel tableModel;
    private JTextField pathField;
    private JLabel statusLabel;
    private File currentDir;
    private File clipboardFile;
    private boolean clipboardIsCut = false;
    private java.util.List<File> selectedFiles = new java.util.ArrayList<>();

    private static final String[] COLUMN_NAMES = {"名称", "大小", "类型", "修改时间"};
    private static final File[] QUICK_PATHS = {
        new File(System.getProperty("user.home")),
        new File(System.getProperty("user.home") + "/Desktop"),
        new File(System.getProperty("user.home") + "/Downloads"),
        new File(System.getProperty("user.home") + "/Documents")
    };
    private static final String[] QUICK_NAMES = {"主页", "桌面", "下载", "文档"};

    public Winllx4() {
        currentDir = new File(System.getProperty("user.home"));
        initUI();
        refreshFileTable();
    }

    private void initUI() {
        frame = WinllxIcon.createFrame("文件管理");
        frame.setSize(1000, 700);
        frame.setMinimumSize(new Dimension(600, 400));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout(5, 5));
        frame.getContentPane().setBackground(Winllx.getMainBackgroundColor());

        // ===== 顶部工具栏 =====
        JPanel topPanel = new JPanel(new BorderLayout(5, 5));
        topPanel.setBackground(Winllx.getMainBackgroundColor());
        topPanel.setBorder(BorderFactory.createEmptyBorder(8, 10, 5, 10));

        // 地址栏
        JPanel pathPanel = new JPanel(new BorderLayout(5, 0));
        pathPanel.setBackground(Winllx.getMainBackgroundColor());
        pathPanel.setOpaque(false);

        JLabel pathLabel = new JLabel("路径:");
        pathLabel.setForeground(new Color(180, 180, 200));
        pathLabel.setFont(new Font("微软雅黑", Font.BOLD, 12));
        pathPanel.add(pathLabel, BorderLayout.WEST);

        pathField = new JTextField();
        pathField.setFont(new Font("微软雅黑", Font.PLAIN, 13));
        pathField.setBackground(Winllx.getMainBackgroundColor().darker().darker());
        pathField.setForeground(new Color(220, 220, 240));
        pathField.setCaretColor(new Color(0, 200, 255));
        pathField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Winllx.getMainBackgroundColor().darker().darker()),
                BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        pathField.addActionListener(e -> navigateToPath(pathField.getText().trim()));
        pathPanel.add(pathField, BorderLayout.CENTER);

        // 导航按钮
        JPanel navBtnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        navBtnPanel.setBackground(Winllx.getMainBackgroundColor().darker());
        navBtnPanel.setOpaque(false);

        GlassButton backBtn = GlassButton.createButton("← 返回");
        backBtn.setPreferredSize(new Dimension(90, 32));
        backBtn.addActionListener(e -> goBack());

        GlassButton upBtn = GlassButton.createButton("↑ 上级");
        upBtn.setPreferredSize(new Dimension(90, 32));
        upBtn.addActionListener(e -> goUp());

        GlassButton homeBtn = GlassButton.createButton("🏠 主页");
        homeBtn.setPreferredSize(new Dimension(90, 32));
        homeBtn.addActionListener(e -> navigateTo(QUICK_PATHS[0]));

        GlassButton refreshBtn = GlassButton.createButton("⟳ 刷新");
        refreshBtn.setPreferredSize(new Dimension(90, 32));
        refreshBtn.addActionListener(e -> refreshAll());

        navBtnPanel.add(backBtn);
        navBtnPanel.add(upBtn);
        navBtnPanel.add(homeBtn);
        navBtnPanel.add(refreshBtn);

        topPanel.add(navBtnPanel, BorderLayout.NORTH);
        topPanel.add(pathPanel, BorderLayout.CENTER);

        // 快捷路径按钮
        JPanel quickPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        quickPanel.setBackground(Winllx.getMainBackgroundColor().darker());
        quickPanel.setOpaque(false);
        quickPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));

        for (int i = 0; i < QUICK_PATHS.length; i++) {
            final File path = QUICK_PATHS[i];
            GlassButton btn = GlassButton.createButton(QUICK_NAMES[i]);
            btn.setPreferredSize(new Dimension(80, 28));
            btn.addActionListener(e -> navigateTo(path));
            quickPanel.add(btn);
        }

        // 搜索框
        JTextField searchField = new JTextField(15);
        searchField.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        searchField.setBackground(Winllx.getMainBackgroundColor().darker().darker());
        searchField.setForeground(new Color(220, 220, 240));
        searchField.setCaretColor(new Color(0, 200, 255));
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Winllx.getMainBackgroundColor().darker().darker()),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));
        searchField.setToolTipText("输入关键词搜索当前目录...");
        searchField.addActionListener(e -> {
            String keyword = searchField.getText().trim();
            if (!keyword.isEmpty()) {
                searchFiles(keyword);
            } else {
                refreshFileTable();
            }
        });

        JLabel searchLabel = new JLabel("🔍");
        searchLabel.setForeground(new Color(180, 180, 200));
        quickPanel.add(Box.createHorizontalStrut(20));
        quickPanel.add(searchLabel);
        quickPanel.add(searchField);

        topPanel.add(quickPanel, BorderLayout.SOUTH);
        frame.add(topPanel, BorderLayout.NORTH);

        // ===== 中间主区域：左右分割 =====
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(220);
        splitPane.setOneTouchExpandable(true);
        splitPane.setBackground(Winllx.getMainBackgroundColor().darker());

        // 左侧目录树
        dirTree = createDirectoryTree();
        JScrollPane treeScroll = new JScrollPane(dirTree);
        treeScroll.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(55, 55, 75)),
                "目录", javax.swing.border.TitledBorder.LEFT,
                javax.swing.border.TitledBorder.TOP,
                new Font("微软雅黑", Font.BOLD, 12), new Color(150, 150, 180)
        ));
        treeScroll.setBackground(Winllx.getMainBackgroundColor().darker().darker());
        splitPane.setLeftComponent(treeScroll);

        // 右侧文件表格
        tableModel = new DefaultTableModel(COLUMN_NAMES, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return String.class;
            }
        };
        fileTable = new JTable(tableModel);
        fileTable.setFont(new Font("微软雅黑", Font.PLAIN, 13));
        fileTable.setRowHeight(28);
        fileTable.setGridColor(new Color(45, 45, 60));
        fileTable.setBackground(Winllx.getMainBackgroundColor().darker().darker());
        fileTable.setForeground(new Color(210, 210, 230));
        fileTable.setSelectionBackground(new Color(50, 80, 120));
        fileTable.setSelectionForeground(Color.WHITE);
        fileTable.setShowGrid(false);
        fileTable.setIntercellSpacing(new Dimension(0, 0));
        fileTable.setFillsViewportHeight(true);

        // 表头样式
        fileTable.getTableHeader().setFont(new Font("微软雅黑", Font.BOLD, 12));
        fileTable.getTableHeader().setBackground(Winllx.getMainBackgroundColor().darker().darker());
        fileTable.getTableHeader().setForeground(new Color(180, 180, 200));
        fileTable.getTableHeader().setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Winllx.getMainBackgroundColor().darker().darker()));

        // 列宽
        fileTable.getColumnModel().getColumn(0).setPreferredWidth(300);
        fileTable.getColumnModel().getColumn(1).setPreferredWidth(100);
        fileTable.getColumnModel().getColumn(2).setPreferredWidth(100);
        fileTable.getColumnModel().getColumn(3).setPreferredWidth(180);

        // 双击打开
        fileTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && SwingUtilities.isLeftMouseButton(e)) {
                    openSelectedFile();
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    int row = fileTable.rowAtPoint(e.getPoint());
                    if (row >= 0) {
                        fileTable.setRowSelectionInterval(row, row);
                        showFileContextMenu(e.getX(), e.getY());
                    }
                }
            }
        });

        JScrollPane tableScroll = new JScrollPane(fileTable);
        tableScroll.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(55, 55, 75)),
                "文件列表", javax.swing.border.TitledBorder.LEFT,
                javax.swing.border.TitledBorder.TOP,
                new Font("微软雅黑", Font.BOLD, 12), new Color(150, 150, 180)
        ));
        tableScroll.setBackground(Winllx.getMainBackgroundColor().darker().darker());
        splitPane.setRightComponent(tableScroll);

        frame.add(splitPane, BorderLayout.CENTER);

        // ===== 底部操作栏 =====
        JPanel bottomPanel = new JPanel(new BorderLayout(5, 5));
        bottomPanel.setBackground(Winllx.getMainBackgroundColor().darker());
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 8, 10));

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        actionPanel.setBackground(Winllx.getMainBackgroundColor().darker());
        actionPanel.setOpaque(false);

        GlassButton newFolderBtn = GlassButton.createButton("📁 新建文件夹");
        newFolderBtn.setPreferredSize(new Dimension(130, 32));
        newFolderBtn.addActionListener(e -> createNewFolder());

        GlassButton newFileBtn = GlassButton.createButton("📄 新建文件");
        newFileBtn.setPreferredSize(new Dimension(110, 32));
        newFileBtn.addActionListener(e -> createNewFile());

        GlassButton renameBtn = GlassButton.createButton("✏️ 重命名");
        renameBtn.setPreferredSize(new Dimension(100, 32));
        renameBtn.addActionListener(e -> renameSelected());

        GlassButton deleteBtn = GlassButton.createButton("🗑️ 删除");
        deleteBtn.setPreferredSize(new Dimension(90, 32));
        deleteBtn.addActionListener(e -> deleteSelected());

        GlassButton copyBtn = GlassButton.createButton("📋 复制");
        copyBtn.setPreferredSize(new Dimension(90, 32));
        copyBtn.addActionListener(e -> copySelected());

        GlassButton pasteBtn = GlassButton.createButton("📌 粘贴");
        pasteBtn.setPreferredSize(new Dimension(90, 32));
        pasteBtn.addActionListener(e -> pasteClipboard());

        GlassButton previewBtn = GlassButton.createButton("👁️ 预览");
        previewBtn.setPreferredSize(new Dimension(90, 32));
        previewBtn.addActionListener(e -> previewSelected());

        actionPanel.add(newFolderBtn);
        actionPanel.add(newFileBtn);
        actionPanel.add(renameBtn);
        actionPanel.add(deleteBtn);
        actionPanel.add(copyBtn);
        actionPanel.add(pasteBtn);
        actionPanel.add(previewBtn);

        statusLabel = new JLabel("就绪");
        statusLabel.setForeground(new Color(150, 150, 170));
        statusLabel.setFont(new Font("微软雅黑", Font.PLAIN, 12));

        bottomPanel.add(actionPanel, BorderLayout.CENTER);
        bottomPanel.add(statusLabel, BorderLayout.SOUTH);

        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }

    // ==================== 目录树 ====================
    private JTree createDirectoryTree() {
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Computer");

        File[] roots = File.listRoots();
        for (File r : roots) {
            DefaultMutableTreeNode node = new DefaultMutableTreeNode(new FileNode(r));
            root.add(node);
            addDummyChild(node);
        }

        DefaultTreeModel treeModel = new DefaultTreeModel(root);
        JTree tree = new JTree(treeModel);
        tree.setRootVisible(true);
        tree.setShowsRootHandles(true);
        tree.setCellRenderer(new FileTreeCellRenderer());
        tree.setBackground(Winllx.getMainBackgroundColor().darker().darker());
        tree.setForeground(new Color(210, 210, 230));
        tree.setFont(new Font("微软雅黑", Font.PLAIN, 13));
        tree.setRowHeight(24);

        tree.addTreeExpansionListener(new javax.swing.event.TreeExpansionListener() {
            @Override
            public void treeExpanded(javax.swing.event.TreeExpansionEvent event) {
                TreePath path = event.getPath();
                DefaultMutableTreeNode node = (DefaultMutableTreeNode) path.getLastPathComponent();
                if (node.getChildCount() == 1 && ((DefaultMutableTreeNode) node.getFirstChild()).getUserObject().equals("loading...")) {
                    node.removeAllChildren();
                    FileNode fn = (FileNode) node.getUserObject();
                    File dir = fn.file;
                    File[] children = dir.listFiles();
                    if (children != null) {
                        java.util.Arrays.sort(children);
                        for (File child : children) {
                            if (child.isDirectory()) {
                                DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(new FileNode(child));
                                node.add(childNode);
                                addDummyChild(childNode);
                            }
                        }
                    }
                    treeModel.nodeStructureChanged(node);
                }
            }

            @Override
            public void treeCollapsed(javax.swing.event.TreeExpansionEvent event) {
            }
        });

        tree.addTreeSelectionListener(e -> {
            TreePath path = e.getPath();
            if (path != null) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode) path.getLastPathComponent();
                Object obj = node.getUserObject();
                if (obj instanceof FileNode) {
                    FileNode fn = (FileNode) obj;
                    if (fn.file.isDirectory()) {
                        navigateTo(fn.file);
                    }
                }
            }
        });

        return tree;
    }

    private void addDummyChild(DefaultMutableTreeNode parent) {
        parent.add(new DefaultMutableTreeNode("loading..."));
    }

    // ==================== 文件表格操作 ====================
    private void refreshFileTable() {
        tableModel.setRowCount(0);
        selectedFiles.clear();

        if (currentDir == null || !currentDir.exists() || !currentDir.isDirectory()) {
            statusLabel.setText("无效的目录");
            return;
        }

        pathField.setText(currentDir.getAbsolutePath());

        File[] files = currentDir.listFiles();
        if (files == null) {
            statusLabel.setText("无法访问该目录");
            return;
        }

        java.util.Arrays.sort(files, (a, b) -> {
            if (a.isDirectory() && !b.isDirectory()) {
                return -1;
            }
            if (!a.isDirectory() && b.isDirectory()) {
                return 1;
            }
            return a.getName().compareToIgnoreCase(b.getName());
        });

        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        for (File f : files) {
            String name = f.getName();
            if (name.isEmpty()) {
                name = f.getAbsolutePath();
            }

            String size;
            if (f.isDirectory()) {
                size = "<文件夹>";
            } else {
                size = formatFileSize(f.length());
            }

            String type = f.isDirectory() ? "文件夹" : getFileExtension(f.getName());
            String date = sdf.format(new java.util.Date(f.lastModified()));

            tableModel.addRow(new Object[]{name, size, type, date});
        }

        statusLabel.setText("共 " + files.length + " 个项目 | 当前目录: " + currentDir.getAbsolutePath());
    }

    private void searchFiles(String keyword) {
        tableModel.setRowCount(0);
        if (currentDir == null || !currentDir.exists()) {
            return;
        }

        File[] files = currentDir.listFiles();
        if (files == null) {
            return;
        }

        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        int count = 0;

        for (File f : files) {
            if (f.getName().toLowerCase().contains(keyword.toLowerCase())) {
                String name = f.getName();
                if (name.isEmpty()) {
                    name = f.getAbsolutePath();
                }

                String size = f.isDirectory() ? "<文件夹>" : formatFileSize(f.length());
                String type = f.isDirectory() ? "文件夹" : getFileExtension(f.getName());
                String date = sdf.format(new java.util.Date(f.lastModified()));

                tableModel.addRow(new Object[]{name, size, type, date});
                count++;
            }
        }

        statusLabel.setText("搜索 \"" + keyword + "\" 找到 " + count + " 个结果");
    }

    // ==================== 导航 ====================
    private void navigateTo(File dir) {
        if (dir != null && dir.exists() && dir.isDirectory()) {
            currentDir = dir;
            refreshFileTable();
        }
    }

    private void navigateToPath(String path) {
        File dir = new File(path);
        if (dir.exists() && dir.isDirectory()) {
            navigateTo(dir);
        } else {
            JOptionPane.showMessageDialog(frame, "路径不存在或不是目录: " + path, "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void goBack() {
        refreshFileTable();
    }

    private void goUp() {
        File parent = currentDir.getParentFile();
        if (parent != null) {
            navigateTo(parent);
        }
    }

    private void refreshAll() {
        refreshFileTable();
        DefaultTreeModel model = (DefaultTreeModel) dirTree.getModel();
        model.reload();
    }

    // ==================== 文件操作 ====================
    private File getSelectedFile() {
        int row = fileTable.getSelectedRow();
        if (row < 0) {
            return null;
        }
        String name = (String) tableModel.getValueAt(row, 0);
        return new File(currentDir, name);
    }

    private void openSelectedFile() {
        File file = getSelectedFile();
        if (file == null) {
            return;
        }

        if (file.isDirectory()) {
            navigateTo(file);
        } else {
            previewSelected();
        }
    }

    private void createNewFolder() {
        String name = JOptionPane.showInputDialog(frame, "输入新文件夹名称:", "新建文件夹");
        if (name == null || name.trim().isEmpty()) {
            return;
        }

        File newDir = new File(currentDir, name.trim());
        if (newDir.exists()) {
            JOptionPane.showMessageDialog(frame, "该名称已存在", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (newDir.mkdirs()) {
            refreshFileTable();
            statusLabel.setText("已创建文件夹: " + name);
        } else {
            JOptionPane.showMessageDialog(frame, "创建文件夹失败", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void createNewFile() {
        String name = JOptionPane.showInputDialog(frame, "输入新文件名称 (含扩展名):", "新建文件.txt");
        if (name == null || name.trim().isEmpty()) {
            return;
        }

        File newFile = new File(currentDir, name.trim());
        if (newFile.exists()) {
            JOptionPane.showMessageDialog(frame, "该文件已存在", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            if (newFile.createNewFile()) {
                refreshFileTable();
                statusLabel.setText("已创建文件: " + name);
            } else {
                JOptionPane.showMessageDialog(frame, "创建文件失败", "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "创建文件失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void renameSelected() {
        File file = getSelectedFile();
        if (file == null) {
            JOptionPane.showMessageDialog(frame, "请先选择一个文件或文件夹", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String newName = JOptionPane.showInputDialog(frame, "输入新名称:", file.getName());
        if (newName == null || newName.trim().isEmpty()) {
            return;
        }

        File dest = new File(currentDir, newName.trim());
        if (dest.exists() && !dest.equals(file)) {
            JOptionPane.showMessageDialog(frame, "目标名称已存在", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (file.renameTo(dest)) {
            refreshFileTable();
            statusLabel.setText("已重命名为: " + newName);
        } else {
            JOptionPane.showMessageDialog(frame, "重命名失败", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteSelected() {
        File file = getSelectedFile();
        if (file == null) {
            JOptionPane.showMessageDialog(frame, "请先选择一个文件或文件夹", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(frame,
                "确定要删除 \"" + file.getName() + "\" 吗?\n此操作不可恢复!",
                "确认删除", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        boolean success;
        if (file.isDirectory()) {
            success = deleteDirectory(file);
        } else {
            success = file.delete();
        }

        if (success) {
            refreshFileTable();
            statusLabel.setText("已删除: " + file.getName());
        } else {
            JOptionPane.showMessageDialog(frame, "删除失败，可能没有权限", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean deleteDirectory(File dir) {
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) {
                    deleteDirectory(f);
                } else {
                    f.delete();
                }
            }
        }
        return dir.delete();
    }

    private void copySelected() {
        File file = getSelectedFile();
        if (file == null) {
            JOptionPane.showMessageDialog(frame, "请先选择一个文件或文件夹", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }
        clipboardFile = file;
        clipboardIsCut = false;
        statusLabel.setText("已复制: " + file.getName());
    }

    private void pasteClipboard() {
        if (clipboardFile == null) {
            JOptionPane.showMessageDialog(frame, "剪贴板为空，请先复制或剪切", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        File dest = new File(currentDir, clipboardFile.getName());
        if (dest.exists()) {
            int confirm = JOptionPane.showConfirmDialog(frame,
                    "目标位置已存在同名文件，是否覆盖?",
                    "确认覆盖", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }
        }

        try {
            if (clipboardFile.isDirectory()) {
                copyDirectory(clipboardFile, dest);
            } else {
                copyFile(clipboardFile, dest);
            }

            if (clipboardIsCut) {
                if (clipboardFile.isDirectory()) {
                    deleteDirectory(clipboardFile);
                } else {
                    clipboardFile.delete();
                }
                clipboardFile = null;
            }

            refreshFileTable();
            statusLabel.setText("已粘贴: " + dest.getName());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "粘贴失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void copyFile(File source, File dest) throws Exception {
        try (java.io.FileInputStream fis = new java.io.FileInputStream(source); java.io.FileOutputStream fos = new java.io.FileOutputStream(dest)) {
            byte[] buffer = new byte[8192];
            int len;
            while ((len = fis.read(buffer)) > 0) {
                fos.write(buffer, 0, len);
            }
        }
    }

    private void copyDirectory(File source, File dest) throws Exception {
        if (!dest.mkdirs()) {
            throw new Exception("无法创建目标目录");
        }
        File[] files = source.listFiles();
        if (files != null) {
            for (File f : files) {
                File newDest = new File(dest, f.getName());
                if (f.isDirectory()) {
                    copyDirectory(f, newDest);
                } else {
                    copyFile(f, newDest);
                }
            }
        }
    }

    // ==================== 预览 ====================
    private void previewSelected() {
        File file = getSelectedFile();
        if (file == null) {
            JOptionPane.showMessageDialog(frame, "请先选择一个文件", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (file.isDirectory()) {
            navigateTo(file);
            return;
        }

        JDialog previewDialog = new JDialog(frame, "预览 - " + file.getName(), true);
        previewDialog.setSize(700, 500);
        previewDialog.setLocationRelativeTo(frame);
        previewDialog.setLayout(new BorderLayout(5, 5));
        previewDialog.getContentPane().setBackground(Winllx.getMainBackgroundColor().darker());

        // 文件信息面板
        JPanel infoPanel = new JPanel(new GridLayout(0, 2, 10, 5));
        infoPanel.setBackground(Winllx.getMainBackgroundColor().darker().darker());
        infoPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        addInfoRow(infoPanel, "文件名:", file.getName());
        addInfoRow(infoPanel, "路径:", file.getParent());
        addInfoRow(infoPanel, "大小:", formatFileSize(file.length()));
        addInfoRow(infoPanel, "类型:", getFileExtension(file.getName()));
        addInfoRow(infoPanel, "修改时间:", sdf.format(new java.util.Date(file.lastModified())));
        addInfoRow(infoPanel, "是否可读:", file.canRead() ? "是" : "否");
        addInfoRow(infoPanel, "是否可写:", file.canWrite() ? "是" : "否");

        previewDialog.add(infoPanel, BorderLayout.NORTH);

        // 内容预览
        if (isTextFile(file)) {
            JTextArea textArea = new JTextArea();
            textArea.setFont(new Font("微软雅黑", Font.PLAIN, 13));
            textArea.setBackground(Winllx.getMainBackgroundColor().darker().darker());
            textArea.setForeground(new Color(210, 210, 230));
            textArea.setCaretColor(new Color(0, 200, 255));
            textArea.setEditable(false);
            textArea.setLineWrap(true);
            textArea.setWrapStyleWord(true);

            try {
                String content = readFileContent(file, 50000);
                textArea.setText(content);
                if (content.length() >= 50000) {
                    textArea.append("\n\n[文件过大，仅显示前50KB内容]");
                }
            } catch (Exception ex) {
                textArea.setText("无法读取文件内容: " + ex.getMessage());
            }

            JScrollPane scroll = new JScrollPane(textArea);
            scroll.setBorder(BorderFactory.createTitledBorder(
                    BorderFactory.createLineBorder(new Color(55, 55, 75)),
                    "文件内容", javax.swing.border.TitledBorder.LEFT,
                    javax.swing.border.TitledBorder.TOP,
                    new Font("微软雅黑", Font.BOLD, 12), new Color(150, 150, 180)
            ));
            previewDialog.add(scroll, BorderLayout.CENTER);
        } else if (isImageFile(file)) {
            JLabel imgLabel = new JLabel("正在加载图片...", SwingConstants.CENTER);
            imgLabel.setForeground(new Color(180, 180, 200));
            imgLabel.setBackground(Winllx.getMainBackgroundColor().darker().darker());
            imgLabel.setOpaque(true);

            SwingUtilities.invokeLater(() -> {
                try {
                    ImageIcon icon = new ImageIcon(file.getAbsolutePath());
                    Image img = icon.getImage();
                    int w = img.getWidth(null);
                    int h = img.getHeight(null);
                    if (w > 0 && h > 0) {
                        int maxW = 650, maxH = 380;
                        if (w > maxW || h > maxH) {
                            double scale = Math.min((double) maxW / w, (double) maxH / h);
                            w = (int) (w * scale);
                            h = (int) (h * scale);
                            img = img.getScaledInstance(w, h, Image.SCALE_SMOOTH);
                            icon = new ImageIcon(img);
                        }
                        imgLabel.setIcon(icon);
                        imgLabel.setText("");
                    } else {
                        imgLabel.setText("无法加载图片");
                    }
                } catch (Exception ex) {
                    imgLabel.setText("图片加载失败: " + ex.getMessage());
                }
            });

            JScrollPane scroll = new JScrollPane(imgLabel);
            scroll.setBorder(BorderFactory.createTitledBorder(
                    BorderFactory.createLineBorder(new Color(55, 55, 75)),
                    "图片预览", javax.swing.border.TitledBorder.LEFT,
                    javax.swing.border.TitledBorder.TOP,
                    new Font("微软雅黑", Font.BOLD, 12), new Color(150, 150, 180)
            ));
            previewDialog.add(scroll, BorderLayout.CENTER);
        } else {
            JLabel label = new JLabel("此文件类型暂不支持预览", SwingConstants.CENTER);
            label.setFont(new Font("微软雅黑", Font.PLAIN, 16));
            label.setForeground(new Color(150, 150, 170));
            label.setBackground(Winllx.getMainBackgroundColor().darker().darker());
            label.setOpaque(true);
            previewDialog.add(label, BorderLayout.CENTER);
        }

        // 底部按钮
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        btnPanel.setBackground(Winllx.getMainBackgroundColor().darker());

        GlassButton openBtn = GlassButton.createButton("用系统打开");
        openBtn.setPreferredSize(new Dimension(120, 32));
        openBtn.addActionListener(e -> {
            try {
                Desktop.getDesktop().open(file);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(previewDialog, "打开失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        });

        GlassButton closeBtn = GlassButton.createButton("关闭");
        closeBtn.setPreferredSize(new Dimension(80, 32));
        closeBtn.addActionListener(e -> previewDialog.dispose());

        btnPanel.add(openBtn);
        btnPanel.add(closeBtn);
        previewDialog.add(btnPanel, BorderLayout.SOUTH);

        previewDialog.setVisible(true);
    }

    private void addInfoRow(JPanel panel, String label, String value) {
        JLabel l = new JLabel(label);
        l.setFont(new Font("微软雅黑", Font.BOLD, 12));
        l.setForeground(new Color(150, 150, 180));
        panel.add(l);

        JLabel v = new JLabel(value);
        v.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        v.setForeground(new Color(210, 210, 230));
        panel.add(v);
    }

    // ==================== 右键菜单 ====================
    private void showFileContextMenu(int x, int y) {
        JPopupMenu menu = new JPopupMenu();
        menu.setBackground(Winllx.getMainBackgroundColor().darker().darker());

        JMenuItem openItem = new JMenuItem("打开");
        openItem.addActionListener(e -> openSelectedFile());
        menu.add(openItem);

        JMenuItem previewItem = new JMenuItem("预览");
        previewItem.addActionListener(e -> previewSelected());
        menu.add(previewItem);

        menu.addSeparator();

        JMenuItem copyItem = new JMenuItem("复制");
        copyItem.addActionListener(e -> copySelected());
        menu.add(copyItem);

        JMenuItem pasteItem = new JMenuItem("粘贴");
        pasteItem.addActionListener(e -> pasteClipboard());
        menu.add(pasteItem);

        menu.addSeparator();

        JMenuItem renameItem = new JMenuItem("重命名");
        renameItem.addActionListener(e -> renameSelected());
        menu.add(renameItem);

        JMenuItem deleteItem = new JMenuItem("删除");
        deleteItem.addActionListener(e -> deleteSelected());
        menu.add(deleteItem);

        menu.addSeparator();

        JMenuItem propItem = new JMenuItem("属性");
        propItem.addActionListener(e -> showProperties());
        menu.add(propItem);

        menu.show(fileTable, x, y);
    }

    private void showProperties() {
        File file = getSelectedFile();
        if (file == null) {
            return;
        }

        JDialog dialog = new JDialog(frame, "属性 - " + file.getName(), true);
        dialog.setSize(400, 350);
        dialog.setLocationRelativeTo(frame);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.getContentPane().setBackground(Winllx.getMainBackgroundColor().darker());

        JPanel panel = new JPanel(new GridLayout(0, 2, 10, 8));
        panel.setBackground(Winllx.getMainBackgroundColor().darker().darker());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        addInfoRow(panel, "名称:", file.getName());
        addInfoRow(panel, "路径:", file.getAbsolutePath());
        addInfoRow(panel, "大小:", file.isDirectory() ? "<文件夹>" : formatFileSize(file.length()));
        addInfoRow(panel, "类型:", file.isDirectory() ? "文件夹" : getFileExtension(file.getName()));
        addInfoRow(panel, "创建时间:", "N/A");
        addInfoRow(panel, "修改时间:", sdf.format(new java.util.Date(file.lastModified())));
        addInfoRow(panel, "可读:", file.canRead() ? "是" : "否");
        addInfoRow(panel, "可写:", file.canWrite() ? "是" : "否");
        addInfoRow(panel, "隐藏:", file.isHidden() ? "是" : "否");

        dialog.add(panel, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(Winllx.getMainBackgroundColor().darker());
        GlassButton okBtn = GlassButton.createButton("确定");
        okBtn.setPreferredSize(new Dimension(80, 32));
        okBtn.addActionListener(e -> dialog.dispose());
        btnPanel.add(okBtn);
        dialog.add(btnPanel, BorderLayout.SOUTH);

        dialog.setVisible(true);
    }

    // ==================== 工具方法 ====================
    private String formatFileSize(long size) {
        if (size < 1024) {
            return size + " B";
        }
        if (size < 1024 * 1024) {
            return String.format("%.1f KB", size / 1024.0);
        }
        if (size < 1024 * 1024 * 1024) {
            return String.format("%.1f MB", size / (1024.0 * 1024));
        }
        return String.format("%.2f GB", size / (1024.0 * 1024 * 1024));
    }

    private String getFileExtension(String name) {
        int dot = name.lastIndexOf('.');
        if (dot > 0 && dot < name.length() - 1) {
            return name.substring(dot + 1).toUpperCase() + " 文件";
        }
        return "未知类型";
    }

    private boolean isTextFile(File file) {
        String name = file.getName().toLowerCase();
        String[] textExts = {".txt", ".java", ".md", ".json", ".xml", ".html", ".css", ".js",
            ".py", ".c", ".cpp", ".h", ".log", ".ini", ".conf", ".properties",
            ".csv", ".bat", ".sh", ".yml", ".yaml", ".gradle", ".kt", ".rs"};
        for (String ext : textExts) {
            if (name.endsWith(ext)) {
                return true;
            }
        }
        return false;
    }

    private boolean isImageFile(File file) {
        String name = file.getName().toLowerCase();
        String[] imgExts = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".ico"};
        for (String ext : imgExts) {
            if (name.endsWith(ext)) {
                return true;
            }
        }
        return false;
    }

    private String readFileContent(File file, int maxBytes) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (java.io.FileInputStream fis = new java.io.FileInputStream(file)) {
            byte[] buffer = new byte[Math.min(maxBytes, 8192)];
            int total = 0;
            int len;
            while (total < maxBytes && (len = fis.read(buffer)) > 0) {
                int toRead = Math.min(len, maxBytes - total);
                sb.append(new String(buffer, 0, toRead, java.nio.charset.Charset.defaultCharset()));
                total += toRead;
            }
        }
        return sb.toString();
    }

    // ==================== 树节点渲染器 ====================
    private static class FileNode {

        File file;

        FileNode(File file) {
            this.file = file;
        }

        @Override
        public String toString() {
            String name = file.getName();
            if (name.isEmpty()) {
                return file.getAbsolutePath();
            }
            return name;
        }
    }

    private static class FileTreeCellRenderer extends DefaultTreeCellRenderer {

        @Override
        public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel,
                boolean expanded, boolean leaf, int row, boolean hasFocus) {
            super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
            if (value instanceof DefaultMutableTreeNode) {
                Object obj = ((DefaultMutableTreeNode) value).getUserObject();
                if (obj instanceof FileNode) {
                    FileNode fn = (FileNode) obj;
                    if (fn.file.isDirectory()) {
                        setIcon(expanded ? UIManager.getIcon("Tree.openIcon") : UIManager.getIcon("Tree.closedIcon"));
                    } else {
                        setIcon(UIManager.getIcon("Tree.leafIcon"));
                    }
                }
            }
            setBackgroundNonSelectionColor(Winllx.getMainBackgroundColor().darker().darker());
            setBackgroundSelectionColor(new Color(50, 80, 120));
            setForeground(new Color(210, 210, 230));
            return this;
        }
    }
}
