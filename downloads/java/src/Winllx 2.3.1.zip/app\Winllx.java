package app;

import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.Point;
import java.awt.PopupMenu;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Robot;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.Window;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.InputMismatchException;
import java.util.Properties;
import java.util.Scanner;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import ui.GlassFrame;

import ui.*;
import utils.*;
import modules.*;

public class Winllx {
    private static String APP_TITLE = "Winllx";
    private static final Color DEFAULT_BG = Color.WHITE;
    private static final String TRAY_ICON_PATH = "C:/Users/86132/Desktop/java.png";
    private static final String SETTINGS_FILE = System.getProperty("user.dir") + "/Winllx/app_settings.properties";
    private static final int[][] MIND_GROUPS = new int[][]{{1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31}, {2, 3, 6, 7, 10, 11, 14, 15, 18, 19, 22, 23, 26, 27, 30, 31}, {4, 5, 6, 7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31}, {8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29, 30, 31}, {16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31}};
    private static final int[] MIND_WEIGHTS = new int[]{1, 2, 4, 8, 16};
    private static boolean trayEnabled = true;
    private static TrayIcon trayIcon;
    private static JFrame mainFrame;
    private static BufferedImage backgroundImage = null;
    private static String bgImagePath = null;
    
    private static final int GRID_CELL_WIDTH = 120;
    private static final int GRID_CELL_HEIGHT = 100;
    private static final int GRID_PADDING_X = 50;
    private static final int GRID_PADDING_Y = 120;
    private static GridLayoutManager gridManager;
    private static JPanel gridOverlay;
    private static Timer resizeTimer;
    
    private static DraggableButton noteBtn;
    private static DraggableButton calcBtn;
    private static DraggableButton fileBtn;
    private static DraggableButton mindBtn;
    private static DraggableButton sysMonBtn;
    private static DraggableButton boardBtn;
    private static DraggableButton clockBtn;
    private static DraggableButton weatherBtn;
    private static DraggableButton minimizeBtn;
    private static DraggableButton settingsBtn;
    private static DraggableButton exitBtn;
    
    private static JLabel timeLabel;
    private static JLabel dateLabel;

    public static void main(String[] stringArray) {
        LangManager.init();
        Loading loading = new Loading();
        loading.show();
        WinllxIcon.init();
        Winllx.initMainWindow();
        SwingUtilities.invokeLater(() -> {
            Winllx.buildDesktopUI();
            Winllx.applySavedTextColor(Winllx.loadTextColor());
            Winllx.initSystemTray();
            loading.close();
        });
    }

    public static void setMainVisible(boolean bl) {
        if (mainFrame != null) {
            mainFrame.setVisible(bl);
        }
    }

    public static Color getMainBackgroundColor() {
        if (mainFrame != null) {
            return mainFrame.getContentPane().getBackground();
        }
        return DEFAULT_BG;
    }

    private static BackgroundPanel getBackgroundPanel() {
        if (mainFrame != null && mainFrame.getContentPane() instanceof BackgroundPanel) {
            return (BackgroundPanel) mainFrame.getContentPane();
        }
        return null;
    }

    private static void initMainWindow() {
        APP_TITLE = LangManager.getString("app.title");
        mainFrame = new JFrame(APP_TITLE);
        Color color = Winllx.loadBackgroundColor();
        BackgroundPanel bgPanel = new BackgroundPanel();
        bgPanel.setBackground(color);
        mainFrame.setContentPane(bgPanel);
        mainFrame.setExtendedState(6);
        mainFrame.setLayout(null);
        mainFrame.setDefaultCloseOperation(3);
        WinllxIcon.applyToFrame(mainFrame);
        Winllx.loadBackgroundImageSettings();
        GlassFrame.setMainFrame(mainFrame);
        GlassFrame.setGlassEnabled(Winllx.loadGlassWindows());
        gridOverlay = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (gridManager != null) {
                    Graphics2D g2d = (Graphics2D) g.create();
                    gridManager.drawGrid(g2d);
                    g2d.dispose();
                }
            }
        };
        gridOverlay.setOpaque(false);
        gridOverlay.setBounds(0, 0, 9999, 9999);
        mainFrame.add(gridOverlay);
        mainFrame.setVisible(true);
        mainFrame.addComponentListener(new ComponentAdapter(){

            @Override
            public void componentResized(ComponentEvent componentEvent) {
                if (resizeTimer != null && resizeTimer.isRunning()) {
                    resizeTimer.stop();
                }
                resizeTimer = new Timer(50, e -> {
                    Winllx.updateLayout();
                    ((Timer) e.getSource()).stop();
                });
                resizeTimer.setRepeats(false);
                resizeTimer.start();
            }

            @Override
            public void componentShown(ComponentEvent componentEvent) {
                Winllx.updateLayout();
            }
        });
    }

    private static void applySavedTextColor(Color color) {
        for (Component component : mainFrame.getContentPane().getComponents()) {
            if (component instanceof JLabel) {
                ((JLabel)component).setForeground(color);
                continue;
            }
            if (component instanceof GlassButton) {
                ((GlassButton)component).setTextColor(color);
                continue;
            }
            if (!(component instanceof AbstractButton)) continue;
            ((AbstractButton)component).setForeground(color);
        }
        mainFrame.repaint();
    }

    private static void buildDesktopUI() {
        Winllx.initGridManager();
        Winllx.addDesktopLabels();
        Winllx.addDesktopButtons();
        Winllx.updateLayout();
    }

    private static void initGridManager() {
        gridManager = new GridLayoutManager(
                mainFrame.getContentPane().getWidth(),
                mainFrame.getContentPane().getHeight(),
                GRID_CELL_WIDTH, GRID_CELL_HEIGHT,
                GRID_PADDING_X, GRID_PADDING_Y
        );
        gridManager.setGridAlpha(Winllx.loadGridAlpha());
    }

    private static void addDesktopLabels() {
        timeLabel = new JLabel();
        timeLabel.setFont(new Font("Microsoft YaHei", 1, 36));
        dateLabel = new JLabel();
        dateLabel.setFont(new Font("Microsoft YaHei", 0, 14));
        Winllx.addToMain(timeLabel, dateLabel);
        Winllx.updateDateTime();
        Timer timer = new Timer(1000, actionEvent -> Winllx.updateDateTime());
        timer.start();
        Winllx.updateLayout();
    }

    private static void updateDateTime() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm");
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("MM\u6708dd\u65e5 EEEE");
        timeLabel.setText(simpleDateFormat.format(calendar.getTime()));
        dateLabel.setText(simpleDateFormat2.format(calendar.getTime()));
    }

    private static void updateLayout() {
        int n;
        FontMetrics fontMetrics;
        int n3 = mainFrame.getContentPane().getWidth();
        int n4 = mainFrame.getContentPane().getHeight();
        
        if (gridManager != null) {
            gridManager.setContainerSize(n3, n4);
        }
        if (gridOverlay != null) {
            gridOverlay.setBounds(0, 0, n3, n4);
        }

        if (timeLabel != null) {
            fontMetrics = timeLabel.getFontMetrics(timeLabel.getFont());
            n = fontMetrics.stringWidth(timeLabel.getText());
            timeLabel.setBounds((n3 - n) / 2, 10, n + 20, 50);
        }
        if (dateLabel != null) {
            fontMetrics = dateLabel.getFontMetrics(dateLabel.getFont());
            n = fontMetrics.stringWidth(dateLabel.getText());
            dateLabel.setBounds((n3 - n) / 2, 50, n + 20, 30);
        }

        DraggableButton[] allButtons = {noteBtn, calcBtn, fileBtn, mindBtn, sysMonBtn,
                                         boardBtn, clockBtn, weatherBtn, settingsBtn, exitBtn, minimizeBtn};

        int buttonsPerRow = Math.max(1, (n3 - GRID_PADDING_X * 2) / GRID_CELL_WIDTH);

        for (int i = 0; i < allButtons.length; i++) {
            if (allButtons[i] == null) continue;

            if (!allButtons[i].isDragging()) {
                int gx = allButtons[i].getGridX();
                int gy = allButtons[i].getGridY();

                if (gx < 0 || gy < 0) {
                    gx = i % buttonsPerRow;
                    gy = i / buttonsPerRow;
                    allButtons[i].setGridPosition(gx, gy);
                }

                Rectangle oldBounds = allButtons[i].getBounds();
                Point pos = gridManager.getGridPosition(gx, gy);
                allButtons[i].setBounds(pos.x, pos.y, GRID_CELL_WIDTH, GRID_CELL_HEIGHT);
                allButtons[i].setGridManager(gridManager);
                mainFrame.repaint(oldBounds.x, oldBounds.y, oldBounds.width, oldBounds.height);
                Rectangle newBounds = allButtons[i].getBounds();
                mainFrame.repaint(newBounds.x, newBounds.y, newBounds.width, newBounds.height);
            }
        }

        mainFrame.repaint();
    }

    private static void addDesktopButtons() {
        noteBtn = Winllx.createDraggableButton(LangManager.getString("module.note"), 80, 80, actionEvent -> new Winllx2());
        calcBtn = Winllx.createDraggableButton(LangManager.getString("module.calc"), 80, 80, actionEvent -> new Winllx3());
        fileBtn = Winllx.createDraggableButton(LangManager.getString("module.file"), 80, 80, actionEvent -> new Winllx4());
        mindBtn = Winllx.createDraggableButton(LangManager.getString("module.mind"), 80, 80, actionEvent -> Winllx.launchMindReading());
        sysMonBtn = Winllx.createDraggableButton(LangManager.getString("module.sysmon"), 80, 80, actionEvent -> new WinllxSysMon());
        boardBtn = Winllx.createDraggableButton(LangManager.getString("module.board"), 80, 80, actionEvent -> new Winllx7());
        clockBtn = Winllx.createDraggableButton(LangManager.getString("module.clock"), 80, 80, actionEvent -> SwingUtilities.invokeLater(() -> new Winllx5().setVisible(true)));
        weatherBtn = Winllx.createDraggableButton(LangManager.getString("module.weather"), 80, 80, actionEvent -> new WinllxWeather());
        settingsBtn = Winllx.createDraggableButton(LangManager.getString("btn.settings"), 80, 80, actionEvent -> Winllx.openSettings());
        exitBtn = Winllx.createDraggableButton(LangManager.getString("btn.exit"), 80, 80, actionEvent -> new Winllx0());
        minimizeBtn = Winllx.createDraggableButton(LangManager.getString("btn.minimize"), 80, 80, actionEvent -> Winllx.setMainVisible(false));

        Winllx.addToMain(noteBtn, calcBtn, fileBtn, mindBtn, sysMonBtn, boardBtn, 
                         clockBtn, weatherBtn, settingsBtn, exitBtn, minimizeBtn);

        DraggableButton[] all = {noteBtn, calcBtn, fileBtn, mindBtn, sysMonBtn, 
                                  boardBtn, clockBtn, weatherBtn, settingsBtn, exitBtn, minimizeBtn};
        for (DraggableButton btn : all) {
            btn.setOnCollisionCheck((gx, gy) -> {
                for (DraggableButton other : all) {
                    if (other != btn && other != null 
                        && other.getGridX() >= 0 && other.getGridY() >= 0
                        && other.getGridX() == gx && other.getGridY() == gy) {
                        return true;
                    }
                }
                return false;
            });
        }
    }

    private static JLabel createLabel(String string, int n, int n2, int n3, int n4, float f) {
        JLabel jLabel = new JLabel(string);
        jLabel.setBounds(n, n2, n3, n4);
        if (f > 0.0f) {
            jLabel.setFont(jLabel.getFont().deriveFont(f));
        }
        return jLabel;
    }

    private static DraggableButton createDraggableButton(String string, int width, int height, ActionListener actionListener) {
        DraggableButton button = new DraggableButton(string, width, height);
        button.setBounds(0, 0, width, height);
        if (actionListener != null) {
            button.addActionListener(actionListener);
        }
        return button;
    }

    private static void addToMain(JComponent ... jComponentArray) {
        for (JComponent jComponent : jComponentArray) {
            mainFrame.add(jComponent);
        }
    }

    private static void launchMindReading() {
        Winllx.setMainVisible(false);
        JOptionPane.showMessageDialog(null, LangManager.getString("msg.start.success"));
        System.out.println(LangManager.getString("mind.welcome"));
        System.out.println(LangManager.getString("mind.choose"));
        System.out.println(LangManager.getString("mind.warning"));
        System.out.println(LangManager.getString("mind.press.enter"));
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();
        int n = 0;
        for (int i = 0; i < MIND_GROUPS.length; ++i) {
            System.out.println(LangManager.getString("mind.group.ask"));
            if (!Winllx.askGroup(scanner, MIND_GROUPS[i])) continue;
            n += MIND_WEIGHTS[i];
        }
        JOptionPane.showMessageDialog(null, String.format(LangManager.getString("mind.result"), n));
        Winllx.setMainVisible(true);
    }

    private static boolean askGroup(Scanner scanner, int[] nArray) {
        System.out.print(LangManager.getString("mind.group.label"));
        for (int n : nArray) {
            System.out.print(n + " ");
        }
        System.out.println("\n" + LangManager.getString("mind.group.prompt"));
        try {
            return scanner.nextInt() == 1;
        }
        catch (InputMismatchException inputMismatchException) {
            scanner.next();
            System.out.println(LangManager.getString("mind.input.invalid"));
            return false;
        }
    }

    private static void openSettings() {
        JFrame jFrame = WinllxIcon.createFrame(LangManager.getString("app.settings.title"));
        jFrame.setSize(380, 600);
        jFrame.setMinimumSize(new Dimension(300, 350));
        Point settingsPos = Winllx.loadSettingsPosition();
        jFrame.setLocation(settingsPos.x, settingsPos.y);

        Color bgColor = Winllx.getMainBackgroundColor().darker();
        int prefW = 340;
        int ctrlH = 72;

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(bgColor);
        content.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // === Language Section ===
        JLabel jLabel = new JLabel(LangManager.getString("setting.language"));
        jLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(jLabel);
        String[] stringArray = new String[]{LangManager.getString("lang.zh"), LangManager.getString("lang.zh_tw"), LangManager.getString("lang.en")};
        GlassSegmentedControl glassSegmentedControl = new GlassSegmentedControl(stringArray);
        styleSegmented(glassSegmentedControl, prefW, ctrlH);
        String string2 = LangManager.getCurrentLang();
        int n2 = string2.equals("zh_tw") ? 1 : (string2.equals("en") ? 2 : 0);
        glassSegmentedControl.setSelectedIndex(n2);
        glassSegmentedControl.addSelectionListener((n, string) -> {
            String lang = n == 0 ? "zh" : (n == 1 ? "zh_tw" : "en");
            LangManager.setLanguage(lang);
            JOptionPane.showMessageDialog(jFrame, LangManager.getString("msg.lang.changed"), LangManager.getString("dialog.tip"), 1);
        });
        content.add(glassSegmentedControl);
        content.add(Box.createVerticalStrut(10));

        // === Theme Section ===
        JLabel jLabel2 = new JLabel(LangManager.getString("setting.theme"));
        jLabel2.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(jLabel2);
        String[] stringArray2 = new String[]{LangManager.getString("setting.theme.white"), LangManager.getString("setting.theme.black"), LangManager.getString("setting.theme.custom"), LangManager.getString("setting.theme.image")};
        GlassSegmentedControl glassSegmentedControl2 = new GlassSegmentedControl(stringArray2);
        styleSegmented(glassSegmentedControl2, prefW, ctrlH);
        BackgroundPanel mainBgPanel = getBackgroundPanel();
        int n3;
        if (mainBgPanel != null && mainBgPanel.hasBackgroundImage()) {
            n3 = 3;
        } else {
            Color bgColorCheck = mainFrame.getContentPane().getBackground();
            if (bgColorCheck.equals(Color.BLACK)) {
                n3 = 1;
            } else if (!bgColorCheck.equals(Color.WHITE)) {
                n3 = 2;
            } else {
                n3 = 0;
            }
        }
        glassSegmentedControl2.setSelectedIndex(n3);
        int[] prevTheme = {n3};
        content.add(glassSegmentedControl2);
        content.add(Box.createVerticalStrut(10));

        // === Background Image Section ===
        JLabel bgImageLabel = new JLabel(LangManager.getString("setting.bg.image"));
        bgImageLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(bgImageLabel);

        GlassButton selectImgBtn = GlassButton.createButton(
                LangManager.getString("setting.bg.image.select"), 110, 36);
        GlassButton removeImgBtn = GlassButton.createButton(
                LangManager.getString("setting.bg.image.remove"), 110, 36);
        removeImgBtn.setVisible(backgroundImage != null);

        JPanel thumbPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                g2d.setColor(mainFrame.getContentPane().getBackground());
                g2d.fillRect(0, 0, getWidth(), getHeight());
                if (backgroundImage != null) {
                    int iw = backgroundImage.getWidth();
                    int ih = backgroundImage.getHeight();
                    int pw = getWidth() - 4;
                    int ph = getHeight() - 4;
                    double scale = Math.min((double) pw / iw, (double) ph / ih);
                    int sw = (int) (iw * scale);
                    int sh = (int) (ih * scale);
                    g2d.drawImage(backgroundImage, (pw - sw) / 2 + 2, (ph - sh) / 2 + 2, sw, sh, null);
                } else {
                    g2d.setColor(new Color(150, 150, 150, 120));
                    g2d.setFont(new Font("Microsoft YaHei", Font.PLAIN, 10));
                    FontMetrics fm = g2d.getFontMetrics();
                    String txt = LangManager.getString("msg.image.no.image");
                    g2d.drawString(txt, (getWidth() - fm.stringWidth(txt)) / 2, getHeight() / 2 + 4);
                }
                g2d.setColor(new Color(100, 100, 100));
                g2d.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
                g2d.dispose();
            }
        };
        thumbPanel.setPreferredSize(new Dimension(90, 70));
        thumbPanel.setOpaque(false);

        JPanel imgButtonRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        imgButtonRow.setBackground(bgColor);
        imgButtonRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        imgButtonRow.add(selectImgBtn);
        imgButtonRow.add(removeImgBtn);
        imgButtonRow.add(thumbPanel);
        content.add(imgButtonRow);
        content.add(Box.createVerticalStrut(8));

        // Fit mode
        JLabel fitLabel = new JLabel(LangManager.getString("setting.bg.image.fit"));
        fitLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(fitLabel);
        String[] fitOptions = {
            LangManager.getString("setting.bg.image.fit.fill"),
            LangManager.getString("setting.bg.image.fit.fit"),
            LangManager.getString("setting.bg.image.fit.stretch"),
            LangManager.getString("setting.bg.image.fit.center")
        };
        GlassSegmentedControl fitControl = new GlassSegmentedControl(fitOptions);
        styleSegmented(fitControl, prefW, ctrlH);
        int currentFit = mainBgPanel != null ? mainBgPanel.getFitMode() : 0;
        fitControl.setSelectedIndex(currentFit);
        fitControl.addSelectionListener((n, str) -> {
            if (mainBgPanel != null) {
                mainBgPanel.setFitMode(n);
            }
            Winllx.saveBgImageFitMode(n);
            mainFrame.repaint();
        });
        content.add(fitControl);
        content.add(Box.createVerticalStrut(8));

        // Opacity
        JLabel opacityLabel = new JLabel(LangManager.getString("setting.bg.image.opacity"));
        opacityLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(opacityLabel);
        GlassSlider[] opacitySliderArr = new GlassSlider[1];
        float currentOpacity = mainBgPanel != null ? mainBgPanel.getImageOpacity() : 1.0f;
        int opacityVal = (int) (currentOpacity * 100);
        opacitySliderArr[0] = new GlassSlider();
        opacitySliderArr[0].setValue(opacityVal);
        opacitySliderArr[0].addChangeListener(e -> {
            int v = opacitySliderArr[0].getValue();
            float op = v / 100.0f;
            if (mainBgPanel != null) {
                mainBgPanel.setImageOpacity(op);
            }
            Winllx.saveBgImageOpacity(op);
            mainFrame.repaint();
        });
        opacitySliderArr[0].setPreferredSize(new Dimension(prefW, 50));
        opacitySliderArr[0].setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        opacitySliderArr[0].setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(opacitySliderArr[0]);
        content.add(Box.createVerticalStrut(10));

        // === Button actions ===
        selectImgBtn.addActionListener(actionEvent -> {
            BufferedImage img = Winllx.selectBackgroundImage(jFrame);
            if (img != null) {
                backgroundImage = img;
                if (mainBgPanel != null) {
                    mainBgPanel.setBackgroundImage(img);
                }
                Winllx.saveBgImagePath(bgImagePath);
                Winllx.saveBgMode(3);
                Winllx.syncTextColorForImage(img);
                removeImgBtn.setVisible(true);
                imgButtonRow.revalidate();
                thumbPanel.repaint();
                mainFrame.repaint();
                prevTheme[0] = 3;
            }
        });
        removeImgBtn.addActionListener(actionEvent -> {
            backgroundImage = null;
            bgImagePath = null;
            if (mainBgPanel != null) {
                mainBgPanel.setBackgroundImage(null);
            }
            Winllx.saveBgImagePath("");
            Color bgColor2 = mainFrame.getContentPane().getBackground();
            int revertMode;
            if (bgColor2.equals(Color.BLACK)) revertMode = 1;
            else if (bgColor2.equals(Color.WHITE)) revertMode = 0;
            else revertMode = 2;
            Winllx.saveBgMode(revertMode);
            Winllx.syncTextColor();
            removeImgBtn.setVisible(false);
            imgButtonRow.revalidate();
            thumbPanel.repaint();
            mainFrame.repaint();
            glassSegmentedControl2.setSelectedIndex(revertMode);
            prevTheme[0] = revertMode;
        });

        glassSegmentedControl2.addSelectionListener((n, string) -> {
            if (n == 3) {
                BufferedImage img = Winllx.selectBackgroundImage(jFrame);
                if (img != null) {
                    backgroundImage = img;
                    if (mainBgPanel != null) {
                        mainBgPanel.setBackgroundImage(img);
                    }
                    Winllx.saveBgImagePath(bgImagePath);
                    Winllx.saveBgMode(3);
                    Winllx.syncTextColorForImage(img);
                    removeImgBtn.setVisible(true);
                    imgButtonRow.revalidate();
                    thumbPanel.repaint();
                    mainFrame.repaint();
                    prevTheme[0] = 3;
                } else {
                    glassSegmentedControl2.setSelectedIndex(prevTheme[0]);
                }
            } else if (n == 2) {
                ColorPicker colorPicker = new ColorPicker((Window)jFrame, mainFrame.getContentPane().getBackground());
                colorPicker.addColorListener(selectedColor -> {
                    mainFrame.getContentPane().setBackground(selectedColor);
                    if (mainBgPanel != null) {
                        mainBgPanel.setBackgroundImage(null);
                    }
                    backgroundImage = null;
                    Winllx.saveBackgroundColor(selectedColor);
                    Winllx.saveBgMode(2);
                    Winllx.saveBgImagePath("");
                    Winllx.syncTextColor();
                    removeImgBtn.setVisible(false);
                    imgButtonRow.revalidate();
                    thumbPanel.repaint();
                    mainFrame.repaint();
                });
                colorPicker.setVisible(true);
                prevTheme[0] = 2;
            } else {
                Winllx.applyTheme(n);
                removeImgBtn.setVisible(false);
                imgButtonRow.revalidate();
                thumbPanel.repaint();
                prevTheme[0] = n;
            }
        });

        // === Frosted Glass Section ===
        JLabel glassLabel = new JLabel(LangManager.getString("setting.glass.window"));
        glassLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(glassLabel);
        String[] glassOptions = {LangManager.getString("setting.glass.enable"), LangManager.getString("setting.glass.disable")};
        GlassSegmentedControl glassControl = new GlassSegmentedControl(glassOptions);
        styleSegmented(glassControl, prefW, ctrlH);
        glassControl.setSelectedIndex(Winllx.loadGlassWindows() ? 0 : 1);
        glassControl.addSelectionListener((n, str) -> {
            boolean enabled = (n == 0);
            Winllx.saveGlassWindows(enabled);
            GlassFrame.setGlassEnabled(enabled);
            JOptionPane.showMessageDialog(jFrame,
                    LangManager.getString("msg.glass.changed"),
                    LangManager.getString("dialog.tip"),
                    JOptionPane.INFORMATION_MESSAGE);
        });
        content.add(glassControl);
        content.add(Box.createVerticalStrut(10));

        // === Icon Theme Section ===
        JLabel jLabel3 = new JLabel(LangManager.getString("setting.icon.theme"));
        jLabel3.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(jLabel3);
        String[] stringArray3 = new String[]{LangManager.getString("setting.icon.light"), LangManager.getString("setting.icon.dark")};
        GlassSegmentedControl glassSegmentedControl3 = new GlassSegmentedControl(stringArray3);
        styleSegmented(glassSegmentedControl3, 180, ctrlH);
        glassSegmentedControl3.setSelectedIndex(WinllxIcon.getCurrentTheme());

        JPanel jPanel = new JPanel();
        jPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(100, 100, 100)), LangManager.getString("setting.icon.compare")));
        jPanel.setLayout(new GridLayout(2, 1, 5, 5));
        jPanel.setPreferredSize(new Dimension(130, 110));
        jPanel.setBackground(bgColor);
        JPanel jPanel2 = new JPanel(new BorderLayout());
        jPanel2.setBackground(Color.WHITE);
        jPanel2.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        JLabel jLabel4 = new JLabel();
        jLabel4.setHorizontalAlignment(0);
        Image image = WinllxIcon.getIconImage(0);
        if (image != null) {
            jLabel4.setIcon(new ImageIcon(image.getScaledInstance(32, 32, 4)));
        }
        jPanel2.add((Component)jLabel4, "Center");
        JLabel jLabel5 = new JLabel(LangManager.getString("setting.icon.light"), 0);
        jLabel5.setFont(new Font("\u5fae\u8f6f\u96c5\u9ed1", 0, 10));
        jPanel2.add((Component)jLabel5, "South");
        jPanel.add(jPanel2);
        JPanel jPanel3 = new JPanel(new BorderLayout());
        jPanel3.setBackground(Color.BLACK);
        jPanel3.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        JLabel jLabel6 = new JLabel();
        jLabel6.setHorizontalAlignment(0);
        Image image2 = WinllxIcon.getIconImage(1);
        if (image2 != null) {
            jLabel6.setIcon(new ImageIcon(image2.getScaledInstance(32, 32, 4)));
        }
        jPanel3.add((Component)jLabel6, "Center");
        JLabel jLabel7 = new JLabel(LangManager.getString("setting.icon.dark"), 0);
        jLabel7.setFont(new Font("\u5fae\u8f6f\u96c5\u9ed1", 0, 10));
        jLabel7.setForeground(Color.WHITE);
        jPanel3.add((Component)jLabel7, "South");
        jPanel.add(jPanel3);

        JPanel iconRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        iconRow.setBackground(bgColor);
        iconRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        iconRow.add(glassSegmentedControl3);
        iconRow.add(jPanel);
        content.add(iconRow);

        glassSegmentedControl3.addSelectionListener((n, string) -> {
            WinllxIcon.setTheme(n);
            WinllxIcon.applyToFrame(mainFrame);
            WinllxIcon.applyToFrame(jFrame);
        });

        JLabel iconFailLabel = new JLabel(LangManager.getString("icon.load.fail"));
        iconFailLabel.setForeground(Color.RED);
        iconFailLabel.setFont(new Font("微软雅黑", 0, 12));
        iconFailLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        iconFailLabel.setVisible(WinllxIcon.isAnyIconFailed());
        content.add(iconFailLabel);

        // Test button
        GlassButton glassButton = GlassButton.createButton(LangManager.getString("btn.test"), 180, 40);
        glassButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        glassButton.addActionListener(actionEvent -> {
            JFrame jFrame2 = WinllxIcon.createFrame("\u56fe\u6807\u6d4b\u8bd5\u7a97\u53e3 - " + (WinllxIcon.getCurrentTheme() == 0 ? LangManager.getString("setting.icon.light") : LangManager.getString("setting.icon.dark")));
            jFrame2.setSize(300, 200);
            jFrame2.setLocationRelativeTo(jFrame);
            jFrame2.setLayout(new BorderLayout());
            JLabel label = new JLabel(LangManager.getString("setting.icon.theme") + "\uff1a" + (WinllxIcon.getCurrentTheme() == 0 ? LangManager.getString("setting.icon.light") : LangManager.getString("setting.icon.dark")), 0);
            label.setFont(new Font("\u5fae\u8f6f\u96c5\u9ed1", 1, 16));
            jFrame2.add((Component)label, "Center");
            jFrame2.setDefaultCloseOperation(2);
            jFrame2.setVisible(true);
        });
        JPanel testBtnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 4));
        testBtnRow.setBackground(bgColor);
        testBtnRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        testBtnRow.add(glassButton);
        content.add(testBtnRow);
        content.add(Box.createVerticalStrut(10));

        // === Volume Section ===
        JLabel jLabel8 = new JLabel(LangManager.getString("setting.volume"));
        jLabel8.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(jLabel8);
        GlassSlider[] glassSliderArray = new GlassSlider[1];
        int n4 = Winllx.getSystemVolume();
        glassSliderArray[0] = new GlassSlider();
        glassSliderArray[0].setValue(n4);
        glassSliderArray[0].addChangeListener(changeEvent -> {
            int n = glassSliderArray[0].getValue();
            Winllx.setSystemVolume(n);
        });
        glassSliderArray[0].setPreferredSize(new Dimension(prefW, 50));
        glassSliderArray[0].setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        glassSliderArray[0].setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(glassSliderArray[0]);
        content.add(Box.createVerticalStrut(10));

        // === Grid Section ===
        JLabel jLabel9 = new JLabel(LangManager.getString("setting.grid"));
        jLabel9.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(jLabel9);
        String[] gridOptions = {LangManager.getString("setting.grid.hide"), LangManager.getString("setting.grid.show")};
        GlassSegmentedControl gridSegmented = new GlassSegmentedControl(gridOptions);
        styleSegmented(gridSegmented, prefW, ctrlH);
        int gridAlphaVal = gridManager != null ? gridManager.getGridAlpha() : 0;
        gridSegmented.setSelectedIndex(gridAlphaVal > 0 ? 1 : 0);
        gridSegmented.addSelectionListener((n, string) -> {
            int alpha = n == 0 ? 0 : 100;
            if (gridManager != null) {
                gridManager.setGridAlpha(alpha);
                mainFrame.repaint();
            }
            Winllx.saveGridAlpha(alpha);
        });
        content.add(gridSegmented);
        content.add(Box.createVerticalGlue());

        // === Scroll pane ===
        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getViewport().setBackground(bgColor);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        jFrame.add(scrollPane);

        jFrame.setDefaultCloseOperation(2);
        jFrame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                Winllx.saveSettingsPosition(jFrame.getLocation());
            }
        });
        jFrame.setVisible(true);
    }

    private static void styleSegmented(GlassSegmentedControl control, int prefW, int ctrlH) {
        control.setAlignmentX(Component.LEFT_ALIGNMENT);
        control.setPreferredSize(new Dimension(prefW, ctrlH));
        control.setMaximumSize(new Dimension(Integer.MAX_VALUE, ctrlH));
    }

    private static Color getContrastColor(Color color) {
        if (color == null) {
            return Color.BLACK;
        }
        double d = 0.2126 * (double)color.getRed() + 0.7152 * (double)color.getGreen() + 0.0722 * (double)color.getBlue();
        return d < 128.0 ? Color.WHITE : Color.BLACK;
    }

    private static void updateIconPreview(JLabel jLabel, int n) {
        Image image = WinllxIcon.getIconImage(n);
        if (image != null) {
            Image image2 = image.getScaledInstance(80, 80, 4);
            jLabel.setIcon(new ImageIcon(image2));
        } else {
            jLabel.setIcon(null);
            jLabel.setText(n == 0 ? LangManager.getString("setting.icon.light") : LangManager.getString("setting.icon.dark"));
        }
    }

    private static void syncTextColor() {
        Color color = mainFrame.getContentPane().getBackground();
        Color color2 = Winllx.getContrastColor(color);
        for (Component component : mainFrame.getContentPane().getComponents()) {
            if (component instanceof JLabel) {
                ((JLabel)component).setForeground(color2);
                continue;
            }
            if (component instanceof GlassButton) {
                ((GlassButton)component).setTextColor(color2);
                continue;
            }
            if (!(component instanceof AbstractButton)) continue;
            ((AbstractButton)component).setForeground(color2);
        }
        mainFrame.repaint();
    }

    private static void applyTheme(int n) {
        Color color = switch (n) {
            case 1 -> Color.BLACK;
            case 2 -> Color.BLUE;
            default -> Color.WHITE;
        };
        mainFrame.getContentPane().setBackground(color);
        BackgroundPanel bgPanel = getBackgroundPanel();
        if (bgPanel != null) {
            bgPanel.setBackgroundImage(null);
        }
        backgroundImage = null;
        Winllx.saveBackgroundColor(color);
        Winllx.saveBgMode(n);
        Winllx.saveBgImagePath("");
        Winllx.syncTextColor();
        mainFrame.repaint();
    }

    private static Color loadBackgroundColor() {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                String string = properties.getProperty("bgColor");
                if (string != null && !string.isEmpty()) {
                    return Winllx.hexToColor(string);
                }
            }
        }
        catch (Exception exception) {
        }
        return DEFAULT_BG;
    }

    private static Color loadTextColor() {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                String string = properties.getProperty("textColor");
                if ("white".equalsIgnoreCase(string)) {
                    return Color.WHITE;
                }
            }
        }
        catch (Exception exception) {
        }
        return Color.BLACK;
    }

    private static int loadGridAlpha() {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                String string = properties.getProperty("gridAlpha");
                if (string != null && !string.isEmpty()) {
                    return Math.max(0, Math.min(100, Integer.parseInt(string)));
                }
            }
        }
        catch (Exception exception) {
        }
        return 0;
    }

    private static void saveGridAlpha(int alpha) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            File f = new File(SETTINGS_FILE);
            if (f.exists()) {
                properties.load(new FileInputStream(f));
            }
            properties.setProperty("gridAlpha", String.valueOf(alpha));
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static Point loadSettingsPosition() {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                String x = properties.getProperty("settingsX");
                String y = properties.getProperty("settingsY");
                if (x != null && y != null) {
                    return new Point(Integer.parseInt(x), Integer.parseInt(y));
                }
            }
        }
        catch (Exception exception) {
        }
        return new Point(0, 0);
    }

    private static void saveSettingsPosition(Point pos) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            File f = new File(SETTINGS_FILE);
            if (f.exists()) {
                properties.load(new FileInputStream(f));
            }
            properties.setProperty("settingsX", String.valueOf(pos.x));
            properties.setProperty("settingsY", String.valueOf(pos.y));
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static void saveBackgroundColor(Color color) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            properties.setProperty("bgColor", Winllx.colorToHex(color));
            properties.setProperty("textColor", Winllx.getContrastColor(color) == Color.WHITE ? "white" : "black");
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static String colorToHex(Color color) {
        return String.format("#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
    }

    private static Color hexToColor(String string) {
        if (string.startsWith("#")) {
            string = string.substring(1);
        }
        if (string.length() == 6) {
            int n = Integer.parseInt(string.substring(0, 2), 16);
            int n2 = Integer.parseInt(string.substring(2, 4), 16);
            int n3 = Integer.parseInt(string.substring(4, 6), 16);
            return new Color(n, n2, n3);
        }
        return DEFAULT_BG;
    }

    private static void saveProperty(String key, String value) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            File f = new File(SETTINGS_FILE);
            if (f.exists()) {
                properties.load(new FileInputStream(f));
            }
            properties.setProperty(key, value);
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static String loadProperty(String key) {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                return properties.getProperty(key);
            }
        }
        catch (Exception exception) {
        }
        return null;
    }

    private static void saveBgMode(int mode) {
        saveProperty("bgMode", String.valueOf(mode));
    }

    private static int loadBgMode() {
        String s = loadProperty("bgMode");
        if (s != null && !s.isEmpty()) {
            try { return Integer.parseInt(s); } catch (Exception e) {}
        }
        return 0;
    }

    private static void saveBgImagePath(String path) {
        saveProperty("bgImagePath", path != null ? path : "");
    }

    private static String loadBgImagePath() {
        return loadProperty("bgImagePath");
    }

    private static void saveBgImageOpacity(float opacity) {
        saveProperty("bgImageOpacity", String.valueOf(opacity));
    }

    private static float loadBgImageOpacity() {
        String s = loadProperty("bgImageOpacity");
        if (s != null && !s.isEmpty()) {
            try { return Float.parseFloat(s); } catch (Exception e) {}
        }
        return 1.0f;
    }

    private static void saveBgImageFitMode(int mode) {
        saveProperty("bgImageFitMode", String.valueOf(mode));
    }

    private static void saveGlassWindows(boolean enabled) {
        saveProperty("glassWindows", String.valueOf(enabled));
    }

    private static boolean loadGlassWindows() {
        String s = loadProperty("glassWindows");
        return "true".equalsIgnoreCase(s);
    }

    private static int loadBgImageFitMode() {
        String s = loadProperty("bgImageFitMode");
        if (s != null && !s.isEmpty()) {
            try { return Integer.parseInt(s); } catch (Exception e) {}
        }
        return 0;
    }

    private static void loadBackgroundImageSettings() {
        BackgroundPanel bgPanel = getBackgroundPanel();
        if (bgPanel == null) return;
        bgPanel.setImageOpacity(Winllx.loadBgImageOpacity());
        bgPanel.setFitMode(Winllx.loadBgImageFitMode());
        String path = Winllx.loadBgImagePath();
        if (path != null && !path.isEmpty()) {
            try {
                File imgFile = new File(path);
                if (imgFile.exists()) {
                    BufferedImage img = ImageIO.read(imgFile);
                    if (img != null) {
                        bgPanel.setBackgroundImage(img);
                        backgroundImage = img;
                        bgImagePath = path;
                        Winllx.syncTextColorForImage(img);
                    }
                }
            }
            catch (Exception exception) {
            }
        }
    }

    private static BufferedImage selectBackgroundImage(JFrame parent) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(LangManager.getString("dialog.image.select"));
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "Image Files (jpg, png, gif, bmp, jpeg, wbmp)",
                "jpg", "png", "gif", "bmp", "jpeg", "wbmp");
        fileChooser.setFileFilter(filter);
        int result = fileChooser.showOpenDialog(parent);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                BufferedImage img = ImageIO.read(selectedFile);
                if (img != null) {
                    bgImagePath = selectedFile.getAbsolutePath();
                    return img;
                } else {
                    JOptionPane.showMessageDialog(parent,
                            LangManager.getString("msg.image.load.error"),
                            LangManager.getString("dialog.error"),
                            JOptionPane.ERROR_MESSAGE);
                }
            }
            catch (Exception ex) {
                JOptionPane.showMessageDialog(parent,
                        LangManager.getString("msg.image.load.error"),
                        LangManager.getString("dialog.error"),
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        return null;
    }

    private static Color getAverageColor(BufferedImage image) {
        if (image == null) return Color.GRAY;
        long sumR = 0, sumG = 0, sumB = 0;
        int w = image.getWidth();
        int h = image.getHeight();
        int step = Math.max(1, (int) Math.sqrt(w * h / 10000.0));
        int count = 0;
        for (int y = 0; y < h; y += step) {
            for (int x = 0; x < w; x += step) {
                int rgb = image.getRGB(x, y);
                sumR += (rgb >> 16) & 0xFF;
                sumG += (rgb >> 8) & 0xFF;
                sumB += rgb & 0xFF;
                count++;
            }
        }
        if (count == 0) return Color.GRAY;
        return new Color((int)(sumR / count), (int)(sumG / count), (int)(sumB / count));
    }

    private static void syncTextColorForImage(BufferedImage image) {
        if (image == null) return;
        new Thread(() -> {
            Color avg = Winllx.getAverageColor(image);
            SwingUtilities.invokeLater(() -> syncTextColorForImage(avg));
        }).start();
    }

    private static void syncTextColorForImage(Color avgColor) {
        if (avgColor == null) return;
        Color textColor = Winllx.getContrastColor(avgColor);
        Winllx.applySavedTextColor(textColor);
        saveProperty("textColor", textColor == Color.WHITE ? "white" : "black");
    }

    private static void initSystemTray() {
        if (!trayEnabled || !SystemTray.isSupported()) {
            return;
        }
        SystemTray systemTray = SystemTray.getSystemTray();
        Image image = Toolkit.getDefaultToolkit().getImage(TRAY_ICON_PATH);
        PopupMenu popupMenu = new PopupMenu();
        MenuItem menuItem = new MenuItem(LangManager.getString("tray.open"));
        MenuItem menuItem2 = new MenuItem(LangManager.getString("tray.settings"));
        MenuItem menuItem3 = new MenuItem(LangManager.getString("tray.exit"));
        popupMenu.add(menuItem);
        popupMenu.addSeparator();
        popupMenu.add(menuItem2);
        popupMenu.addSeparator();
        popupMenu.add(menuItem3);
        trayIcon = new TrayIcon(image, APP_TITLE, popupMenu);
        trayIcon.setImageAutoSize(true);
        menuItem.addActionListener(actionEvent -> Winllx.setMainVisible(true));
        menuItem2.addActionListener(actionEvent -> Winllx.openSettings());
        menuItem3.addActionListener(actionEvent -> {
            systemTray.remove(trayIcon);
            System.exit(0);
        });
        trayIcon.addActionListener(actionEvent -> Winllx.setMainVisible(true));
        try {
            systemTray.add(trayIcon);
        }
        catch (AWTException aWTException) {
            System.err.println(LangManager.getString("msg.tray.error"));
        }
    }

    private static void setSystemVolume(int n) {
        Winllx.setSystemVolumeRobot(n);
    }

    private static int getSystemVolume() {
        return 50;
    }

    private static void setSystemVolumeRobot(int n) {
        try {
            int n2;
            Robot robot = new Robot();
            int n3 = Math.max(0, Math.min(100, n));
            for (n2 = 0; n2 < 50; ++n2) {
                robot.keyPress(174);
                robot.keyRelease(174);
                Thread.sleep(5L);
            }
            for (n2 = 0; n2 < n3 / 2; ++n2) {
                robot.keyPress(175);
                robot.keyRelease(175);
                Thread.sleep(5L);
            }
        }
        catch (Exception exception) {
            JOptionPane.showMessageDialog(mainFrame, LangManager.getString("msg.volume.error"), LangManager.getString("dialog.tip"), 2);
        }
    }

    public static void showNotification(String string, String string2) {
        if (trayIcon != null) {
            trayIcon.displayMessage(string, string2, TrayIcon.MessageType.INFO);
        }
    }
}
