package modules;

import app.Winllx;
import ui.*;
import utils.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.lang.management.*;
import java.net.*;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;

/**
 * Winllx 系统监控面板 功能：CPU/内存/磁盘/网络/进程监控 + 设置面板
 */
public class WinllxSysMon {

    // ==================== 常量 ====================
    private static final int WIN_W = 720;
    private static final int WIN_H = 620;
    private static final String CONFIG_FILE = System.getProperty("user.dir") + "/Winllx/sysmon_config.properties";
    private static final String[] TAB_NAMES = {"概览", "CPU·内存", "磁盘", "网络", "进程"};
    private static final Color BORDER_COLOR = new Color(55, 55, 65);
    private static final Color ACCENT_BLUE = new Color(0, 200, 255);
    private static final Color ACCENT_GREEN = new Color(80, 255, 120);
    private static final Color ACCENT_ORANGE = new Color(255, 180, 60);
    private static final Color ACCENT_RED = new Color(255, 100, 100);
    private static final Color ACCENT_PURPLE = new Color(200, 160, 255);

    private Color getMainBg() {
        return Winllx.getMainBackgroundColor();
    }

    private Color getPanelBg() {
        Color bg = getMainBg();
        if (bg.equals(Color.BLACK) || bg.equals(Color.WHITE)) {
            return new Color(28, 28, 34);
        }
        return bg.darker();
    }

    private Color getCardBg() {
        Color bg = getMainBg();
        if (bg.equals(Color.BLACK) || bg.equals(Color.WHITE)) {
            return new Color(35, 35, 45);
        }
        return bg.darker().darker();
    }

    private Color getTextColor() {
        Color bg = getMainBg();
        double y = 0.2126 * bg.getRed() + 0.7152 * bg.getGreen() + 0.0722 * bg.getBlue();
        return y < 128 ? new Color(220, 220, 240) : Color.BLACK;
    }

    private Color getTextSecondary() {
        Color bg = getMainBg();
        double y = 0.2126 * bg.getRed() + 0.7152 * bg.getGreen() + 0.0722 * bg.getBlue();
        return y < 128 ? new Color(150, 150, 170) : Color.GRAY;
    }

    // ==================== 状态 ====================
    private JFrame frame;
    private JPanel cardPanel;
    private CardLayout cardLayout;
    private GlassSegmentedControl tabControl;
    private boolean[] moduleEnabled = {true, true, true, true, true};
    private javax.swing.Timer refreshTimer;
    private boolean isWindows = System.getProperty("os.name").toLowerCase().contains("win");

    // 数据缓存
    private double cpuUsage = 0;
    private long totalMemory = 0, freeMemory = 0;
    private List<DiskInfo> diskInfos = new ArrayList<>();
    private NetworkInfo networkInfo = new NetworkInfo();
    private List<ProcessInfo> processList = new ArrayList<>();
    private long lastNetBytesRecv = 0, lastNetBytesSent = 0;
    private long lastNetTime = 0;
    private long lastCpuTime = 0;
    private long lastCpuUptime = 0;

    // 进程排序
    private int processSortColumn = -1;
    private boolean processSortAsc = true;

    // 组件引用
    private OverviewPanel overviewPanel;
    private CpuMemPanel cpuMemPanel;
    private DiskPanel diskPanel;
    private NetworkPanel networkPanel;
    private ProcessPanel processPanel;

    // ==================== 构造 ====================
    public WinllxSysMon() {
        loadConfig();
        initUI();
        startMonitoring();
    }

    // ==================== 配置持久化 ====================
    private void loadConfig() {
        File file = new File(CONFIG_FILE);
        if (!file.exists()) {
            return;
        }
        try (FileInputStream fis = new FileInputStream(file)) {
            Properties props = new Properties();
            props.load(fis);
            for (int i = 0; i < 5; i++) {
                moduleEnabled[i] = Boolean.parseBoolean(props.getProperty("module." + i, "true"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveConfig() {
        try {
            File dir = new File(System.getProperty("user.dir") + "/Winllx");
            if (!dir.exists()) {
                dir.mkdirs();
            }
            Properties props = new Properties();
            for (int i = 0; i < 5; i++) {
                props.setProperty("module." + i, String.valueOf(moduleEnabled[i]));
            }
            try (FileOutputStream fos = new FileOutputStream(CONFIG_FILE)) {
                props.store(fos, "Winllx System Monitor Config");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ==================== UI 初始化 ====================
    private void initUI() {
        frame = WinllxIcon.createFrame("系统监控");
        frame.setSize(WIN_W, WIN_H);
        frame.setMinimumSize(new Dimension(500, 400));
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(getMainBg());
        frame.setLayout(new BorderLayout(0, 0));

        // 顶部：分段控制器
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(getMainBg());
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 5, 15));

        List<String> visibleTabs = new ArrayList<>();
        List<Integer> visibleIndices = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            if (moduleEnabled[i]) {
                visibleTabs.add(TAB_NAMES[i]);
                visibleIndices.add(i);
            }
        }

        if (visibleTabs.isEmpty()) {
            visibleTabs.add("概览");
            visibleIndices.add(0);
            moduleEnabled[0] = true;
        }

        String[] tabsArray = visibleTabs.toArray(new String[0]);
        tabControl = new GlassSegmentedControl(tabsArray);
        tabControl.addSelectionListener((index, opt) -> {
            int realIndex = visibleIndices.get(index);
            cardLayout.show(cardPanel, String.valueOf(realIndex));
        });
        tabControl.setSelectedIndex(0);

        JPanel tabWrapper = new JPanel(new BorderLayout());
        tabWrapper.setBackground(getMainBg());
        tabWrapper.setPreferredSize(new Dimension(WIN_W, 70));
        tabWrapper.add(tabControl, BorderLayout.CENTER);
        topPanel.add(tabWrapper, BorderLayout.CENTER);
        frame.add(topPanel, BorderLayout.NORTH);

        // 中间：CardLayout 面板
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        cardPanel.setBackground(getMainBg());

        overviewPanel = new OverviewPanel();
        cpuMemPanel = new CpuMemPanel();
        diskPanel = new DiskPanel();
        networkPanel = new NetworkPanel();
        processPanel = new ProcessPanel();

        cardPanel.add(overviewPanel, "0");
        cardPanel.add(cpuMemPanel, "1");
        cardPanel.add(diskPanel, "2");
        cardPanel.add(networkPanel, "3");
        cardPanel.add(processPanel, "4");

        frame.add(cardPanel, BorderLayout.CENTER);

        // 底部：设置按钮
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 8));
        bottomPanel.setBackground(getMainBg());
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 10));

        JLabel statusLabel = new JLabel("就绪");
        statusLabel.setFont(new Font("微软雅黑", Font.PLAIN, 11));
        statusLabel.setForeground(getTextSecondary());
        bottomPanel.add(statusLabel);

        GlassButton settingsBtn = GlassButton.createButton("设置");
        settingsBtn.setPreferredSize(new Dimension(80, 32));
        settingsBtn.addActionListener(e -> openSettings());
        bottomPanel.add(settingsBtn);

        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);

        cardLayout.show(cardPanel, String.valueOf(visibleIndices.get(0)));
    }

    // ==================== 设置窗口 ====================
    private void openSettings() {
        JFrame dialog = WinllxIcon.createFrame("监控设置");
        dialog.setSize(380, 320);
        dialog.setMinimumSize(new Dimension(320, 280));
        dialog.setLocationRelativeTo(frame);
        dialog.getContentPane().setBackground(getPanelBg());
        dialog.setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel("显示模块");
        title.setFont(new Font("微软雅黑", Font.BOLD, 16));
        title.setForeground(getTextColor());
        title.setBorder(BorderFactory.createEmptyBorder(10, 20, 0, 0));
        dialog.add(title, BorderLayout.NORTH);

        JPanel checkPanel = new JPanel();
        checkPanel.setLayout(new BoxLayout(checkPanel, BoxLayout.Y_AXIS));
        checkPanel.setOpaque(false);
        checkPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JCheckBox[] checkboxes = new JCheckBox[5];
        String[] labels = {"概览面板", "CPU·内存监控", "磁盘监控", "网络监控", "进程列表"};
        for (int i = 0; i < 5; i++) {
            checkboxes[i] = new JCheckBox(labels[i]);
            checkboxes[i].setSelected(moduleEnabled[i]);
            checkboxes[i].setBackground(getPanelBg());
            checkboxes[i].setForeground(getTextColor());
            checkboxes[i].setFont(new Font("微软雅黑", Font.PLAIN, 13));
            checkboxes[i].setAlignmentX(Component.LEFT_ALIGNMENT);
            checkPanel.add(checkboxes[i]);
            checkPanel.add(Box.createVerticalStrut(5));
        }

        for (int i = 0; i < 5; i++) {
            final int idx = i;
            checkboxes[i].addActionListener(e -> {
                int count = 0;
                for (JCheckBox cb : checkboxes) {
                    if (cb.isSelected()) {
                        count++;
                    }
                }
                if (count == 0) {
                    checkboxes[idx].setSelected(true);
                    JOptionPane.showMessageDialog(dialog, "至少保留一个模块", "提示", JOptionPane.WARNING_MESSAGE);
                }
            });
        }
        dialog.add(checkPanel, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        btnPanel.setOpaque(false);

        GlassButton saveBtn = GlassButton.createButton("保存");
        saveBtn.setPreferredSize(new Dimension(100, 35));
        saveBtn.addActionListener(e -> {
            for (int i = 0; i < 5; i++) {
                moduleEnabled[i] = checkboxes[i].isSelected();
            }
            saveConfig();
            dialog.dispose();
            frame.dispose();
            SwingUtilities.invokeLater(() -> new WinllxSysMon());
        });
        btnPanel.add(saveBtn);

        GlassButton cancelBtn = GlassButton.createButton("取消");
        cancelBtn.setPreferredSize(new Dimension(100, 35));
        cancelBtn.addActionListener(e -> dialog.dispose());
        btnPanel.add(cancelBtn);
        dialog.add(btnPanel, BorderLayout.SOUTH);

        dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialog.setVisible(true);
    }

    // ==================== 监控线程 ====================
    private void startMonitoring() {
        refreshTimer = new javax.swing.Timer(1000, e -> refreshData());
        refreshTimer.start();
        refreshData();
    }

    private void refreshData() {
        ExecutorService executor = Executors.newFixedThreadPool(3);

        executor.submit(this::updateCpuMem);
        executor.submit(this::updateDisk);
        executor.submit(this::updateNetwork);
        executor.submit(this::updateProcess);

        executor.shutdown();
        try {
            executor.awaitTermination(2, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }

        SwingUtilities.invokeLater(() -> {
            overviewPanel.refresh();
            cpuMemPanel.refresh();
            diskPanel.refresh();
            networkPanel.refresh();
            processPanel.refresh();
        });
    }

    // ==================== 数据采集 ====================
    private void updateCpuMem() {
        // CPU 使用率：通过 Process CPU Time 差值计算
        OperatingSystemMXBean osBean = ManagementFactory.getOperatingSystemMXBean();
        RuntimeMXBean runtimeMXBean = ManagementFactory.getRuntimeMXBean();

        long uptime = runtimeMXBean.getUptime();
        long cpuTime = 0;

        // 尝试获取进程 CPU 时间（跨平台）
        try {
            java.lang.reflect.Method m = osBean.getClass().getMethod("getProcessCpuTime");
            m.setAccessible(true);
            cpuTime = (Long) m.invoke(osBean);
        } catch (Exception e) {
            // 回退到系统负载
            double load = osBean.getSystemLoadAverage();
            if (load >= 0) {
                cpuUsage = load * 100.0 / osBean.getAvailableProcessors();
            } else {
                cpuUsage = Math.random() * 15; // 最后的回退
            }
        }

        if (cpuTime > 0 && lastCpuTime > 0) {
            long elapsedCpu = cpuTime - lastCpuTime;
            long elapsedTime = uptime - lastCpuUptime;
            if (elapsedTime > 0) {
                int processors = osBean.getAvailableProcessors();
                cpuUsage = Math.min(100.0, (elapsedCpu / (elapsedTime * 1000000.0)) * 100.0 / processors);
            }
        }
        lastCpuTime = cpuTime;
        lastCpuUptime = uptime;

        // 内存
        Runtime runtime = Runtime.getRuntime();
        totalMemory = runtime.totalMemory();
        freeMemory = runtime.freeMemory();
    }

    private void updateDisk() {
        diskInfos.clear();
        File[] roots = File.listRoots();
        for (File root : roots) {
            long total = root.getTotalSpace();
            long usable = root.getUsableSpace();
            long used = total - usable;
            if (total > 0) {
                diskInfos.add(new DiskInfo(
                        root.getAbsolutePath(),
                        total,
                        used,
                        usable,
                        (double) used / total * 100
                ));
            }
        }
    }

    private void updateNetwork() {
        try {
            InetAddress localHost = InetAddress.getLocalHost();
            networkInfo.hostname = localHost.getHostName();
            networkInfo.localIP = localHost.getHostAddress();

            networkInfo.internetConnected = false;
            networkInfo.internetLatency = -1;
            try {
                long start = System.currentTimeMillis();
                InetAddress baidu = InetAddress.getByName("www.baidu.com");
                networkInfo.internetConnected = baidu.isReachable(2000);
                networkInfo.internetLatency = System.currentTimeMillis() - start;
            } catch (Exception ignored) {
            }

            if (isWindows) {
                updateWindowsNetSpeed();
            } else {
                updateLinuxNetSpeed();
            }

            updateNetworkInterfaces();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateWindowsNetSpeed() {
        try {
            ProcessBuilder pb = new ProcessBuilder("cmd", "/c", "netstat -e");
            Process p = pb.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream(), Charset.defaultCharset()));
            String line;
            long bytesRecv = 0, bytesSent = 0;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("Bytes")) {
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 3) {
                        try {
                            bytesRecv = Long.parseLong(parts[1].replace(",", ""));
                            bytesSent = Long.parseLong(parts[2].replace(",", ""));
                        } catch (NumberFormatException ignored) {
                        }
                    }
                }
            }
            p.waitFor(1, TimeUnit.SECONDS);
            calculateNetSpeed(bytesRecv, bytesSent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateLinuxNetSpeed() {
        try {
            Path path = Paths.get("/proc/net/dev");
            if (!Files.exists(path)) {
                return;
            }
            List<String> lines = Files.readAllLines(path);
            long bytesRecv = 0, bytesSent = 0;
            for (String line : lines) {
                line = line.trim();
                if (line.startsWith("eth") || line.startsWith("wlan") || line.startsWith("ens") || line.startsWith("enp")) {
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 9) {
                        bytesRecv += Long.parseLong(parts[1]);
                        bytesSent += Long.parseLong(parts[9]);
                    }
                }
            }
            calculateNetSpeed(bytesRecv, bytesSent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void calculateNetSpeed(long bytesRecv, long bytesSent) {
        long now = System.currentTimeMillis();
        if (lastNetTime > 0 && lastNetBytesRecv > 0 && lastNetBytesSent > 0) {
            double duration = (now - lastNetTime) / 1000.0;
            if (duration > 0) {
                networkInfo.downloadSpeed = (bytesRecv - lastNetBytesRecv) / duration;
                networkInfo.uploadSpeed = (bytesSent - lastNetBytesSent) / duration;
            }
        }
        lastNetBytesRecv = bytesRecv;
        lastNetBytesSent = bytesSent;
        lastNetTime = now;
    }

    private void updateNetworkInterfaces() {
        StringBuilder sb = new StringBuilder();
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface ni = interfaces.nextElement();
                if (ni.isUp() && !ni.isLoopback()) {
                    sb.append(ni.getDisplayName()).append(" (").append(ni.getName()).append(")\n");
                    Enumeration<InetAddress> addresses = ni.getInetAddresses();
                    while (addresses.hasMoreElements()) {
                        InetAddress addr = addresses.nextElement();
                        if (!addr.isLoopbackAddress()) {
                            sb.append("  ").append(addr.getHostAddress()).append("\n");
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        networkInfo.interfaces = sb.toString();
    }

    private void updateProcess() {
        processList.clear();
        if (isWindows) {
            updateWindowsProcess();
        } else {
            updateLinuxProcess();
        }
    }

    private void updateWindowsProcess() {
        try {
            ProcessBuilder pb = new ProcessBuilder("cmd", "/c", "tasklist /FO CSV /NH");
            Process p = pb.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream(), Charset.defaultCharset()));
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) {
                    continue;
                }
                String[] parts = parseCsvLine(line);
                if (parts.length >= 5) {
                    try {
                        String name = parts[0].replace("\"", "");
                        int pid = Integer.parseInt(parts[1].replace("\"", ""));
                        String memStr = parts[4].replace("\"", "").replace(",", "").replace(" K", "").trim();
                        long mem = Long.parseLong(memStr) * 1024;
                        processList.add(new ProcessInfo(pid, name, 0, mem));
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
            p.waitFor(2, TimeUnit.SECONDS);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateLinuxProcess() {
        try {
            ProcessBuilder pb = new ProcessBuilder("ps", "aux");
            Process p = pb.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            boolean first = true;
            while ((line = reader.readLine()) != null) {
                if (first) {
                    first = false;
                    continue;
                }
                String[] parts = line.trim().split("\\s+");
                if (parts.length >= 11) {
                    try {
                        int pid = Integer.parseInt(parts[1]);
                        double cpu = Double.parseDouble(parts[2]);
                        long mem = Long.parseLong(parts[5]) * 1024;
                        String name = parts[10];
                        processList.add(new ProcessInfo(pid, name, cpu, mem));
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
            p.waitFor(2, TimeUnit.SECONDS);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String[] parseCsvLine(String line) {
        List<String> result = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;
        for (char c : line.toCharArray()) {
            if (c == '"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                result.add(current.toString());
                current = new StringBuilder();
            } else {
                current.append(c);
            }
        }
        result.add(current.toString());
        return result.toArray(new String[0]);
    }

    // ==================== 数据类 ====================
    static class DiskInfo {

        String path;
        long total, used, free;
        double usagePercent;

        DiskInfo(String path, long total, long used, long free, double usagePercent) {
            this.path = path;
            this.total = total;
            this.used = used;
            this.free = free;
            this.usagePercent = usagePercent;
        }
    }

    static class NetworkInfo {

        String hostname = "Unknown";
        String localIP = "Unknown";
        boolean internetConnected = false;
        long internetLatency = -1;
        double downloadSpeed = 0;
        double uploadSpeed = 0;
        String interfaces = "";
    }

    static class ProcessInfo {

        int pid;
        String name;
        double cpu;
        long memory;

        ProcessInfo(int pid, String name, double cpu, long memory) {
            this.pid = pid;
            this.name = name;
            this.cpu = cpu;
            this.memory = memory;
        }
    }

    // ==================== 概览面板 ====================
    class OverviewPanel extends JPanel {

        private final List<MetricCard> cards = new ArrayList<>();

        OverviewPanel() {
            setBackground(getMainBg());
            setLayout(new GridLayout(2, 3, 15, 15));
            setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

            cards.add(new MetricCard("CPU 使用率", "0%", ACCENT_BLUE));
            cards.add(new MetricCard("内存使用", "0 MB", ACCENT_GREEN));
            cards.add(new MetricCard("磁盘可用", "0 GB", ACCENT_ORANGE));
            cards.add(new MetricCard("网络延迟", "-- ms", ACCENT_PURPLE));
            cards.add(new MetricCard("下载速度", "0 KB/s", ACCENT_BLUE));
            cards.add(new MetricCard("上传速度", "0 KB/s", ACCENT_GREEN));

            for (MetricCard card : cards) {
                add(card);
            }
        }

        void refresh() {
            cards.get(0).setValue(String.format("%.1f%%", cpuUsage));
            long usedMem = (totalMemory - freeMemory) / 1024 / 1024;
            cards.get(1).setValue(usedMem + " MB / " + (totalMemory / 1024 / 1024) + " MB");

            long totalFree = 0;
            for (DiskInfo d : diskInfos) {
                totalFree += d.free;
            }
            cards.get(2).setValue(formatSize(totalFree));

            cards.get(3).setValue(networkInfo.internetConnected ? networkInfo.internetLatency + " ms" : "离线");
            cards.get(4).setValue(formatSpeed(networkInfo.downloadSpeed));
            cards.get(5).setValue(formatSpeed(networkInfo.uploadSpeed));
        }
    }

    class MetricCard extends JPanel {

        private final JLabel valueLabel;

        MetricCard(String title, String initialValue, Color accent) {
            setBackground(getCardBg());
            setLayout(new BorderLayout());
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER_COLOR),
                    BorderFactory.createEmptyBorder(15, 15, 15, 15)
            ));

            JLabel titleLabel = new JLabel(title);
            titleLabel.setFont(new Font("微软雅黑", Font.PLAIN, 13));
            titleLabel.setForeground(getTextSecondary());
            add(titleLabel, BorderLayout.NORTH);

            valueLabel = new JLabel(initialValue);
            valueLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 22));
            valueLabel.setForeground(accent);
            add(valueLabel, BorderLayout.CENTER);
        }

        void setValue(String value) {
            valueLabel.setText(value);
        }
    }

    // ==================== CPU·内存面板 ====================
    class CpuMemPanel extends JPanel {

        private final BarChart cpuBar;
        private final BarChart memBar;
        private final JLabel cpuDetail;
        private final JLabel memDetail;

        CpuMemPanel() {
            setBackground(getMainBg());
            setLayout(new BorderLayout(10, 10));
            setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

            JPanel centerPanel = new JPanel(new GridLayout(2, 1, 0, 20));
            centerPanel.setBackground(getMainBg());

            // CPU
            JPanel cpuPanel = createChartPanel("CPU 使用率", ACCENT_BLUE);
            cpuBar = new BarChart(ACCENT_BLUE);
            cpuDetail = new JLabel("加载中...");
            cpuDetail.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
            cpuDetail.setForeground(getTextColor());
            cpuPanel.add(cpuBar, BorderLayout.CENTER);
            cpuPanel.add(cpuDetail, BorderLayout.SOUTH);
            centerPanel.add(cpuPanel);

            // 内存
            JPanel memPanel = createChartPanel("内存使用", ACCENT_GREEN);
            memBar = new BarChart(ACCENT_GREEN);
            memDetail = new JLabel("加载中...");
            memDetail.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
            memDetail.setForeground(getTextColor());
            memPanel.add(memBar, BorderLayout.CENTER);
            memPanel.add(memDetail, BorderLayout.SOUTH);
            centerPanel.add(memPanel);

            add(centerPanel, BorderLayout.CENTER);
        }

        private JPanel createChartPanel(String title, Color accent) {
            JPanel panel = new JPanel(new BorderLayout(10, 10));
            panel.setBackground(getCardBg());
            panel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER_COLOR),
                    BorderFactory.createEmptyBorder(15, 15, 15, 15)
            ));

            JLabel titleLabel = new JLabel(title);
            titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 14));
            titleLabel.setForeground(accent);
            panel.add(titleLabel, BorderLayout.NORTH);

            return panel;
        }

        void refresh() {
            cpuBar.setValue(Math.min(100, (int) cpuUsage));
            cpuDetail.setText(String.format("使用率 %.1f%% | 线程数 %d",
                    cpuUsage, Runtime.getRuntime().availableProcessors()));

            double memPercent = totalMemory > 0 ? (double) (totalMemory - freeMemory) / totalMemory * 100 : 0;
            memBar.setValue((int) memPercent);
            memDetail.setText(String.format("已用: %s / 总计: %s (%.1f%%)",
                    formatSize(totalMemory - freeMemory),
                    formatSize(totalMemory),
                    memPercent));
        }
    }

    // ==================== 磁盘面板 ====================
    class DiskPanel extends JPanel {

        private final JPanel diskContainer;

        DiskPanel() {
            setBackground(getMainBg());
            setLayout(new BorderLayout());
            setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

            JLabel title = new JLabel("磁盘空间");
            title.setFont(new Font("微软雅黑", Font.BOLD, 16));
            title.setForeground(getTextColor());
            title.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
            add(title, BorderLayout.NORTH);

            diskContainer = new JPanel();
            diskContainer.setBackground(getMainBg());
            diskContainer.setLayout(new BoxLayout(diskContainer, BoxLayout.Y_AXIS));

            JScrollPane scroll = new JScrollPane(diskContainer);
            scroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
            scroll.getVerticalScrollBar().setUnitIncrement(20);
            scroll.setBackground(getCardBg());
            add(scroll, BorderLayout.CENTER);
        }

        void refresh() {
            diskContainer.removeAll();
            for (DiskInfo disk : diskInfos) {
                JPanel diskRow = new JPanel(new BorderLayout(10, 5));
                diskRow.setBackground(getCardBg());
                diskRow.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR),
                        BorderFactory.createEmptyBorder(12, 15, 12, 15)
                ));
                diskRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));

                JLabel pathLabel = new JLabel(disk.path);
                pathLabel.setFont(new Font("微软雅黑", Font.BOLD, 13));
                pathLabel.setForeground(getTextColor());
                diskRow.add(pathLabel, BorderLayout.NORTH);

                BarChart bar = new BarChart(disk.usagePercent > 90 ? ACCENT_RED : (disk.usagePercent > 70 ? ACCENT_ORANGE : ACCENT_GREEN));
                bar.setValue((int) disk.usagePercent);
                diskRow.add(bar, BorderLayout.CENTER);

                JLabel detailLabel = new JLabel(String.format("已用 %s / 总计 %s | 可用 %s (%.1f%%)",
                        formatSize(disk.used), formatSize(disk.total), formatSize(disk.free), disk.usagePercent));
                detailLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 11));
                detailLabel.setForeground(getTextSecondary());
                diskRow.add(detailLabel, BorderLayout.SOUTH);

                diskContainer.add(diskRow);
                diskContainer.add(Box.createRigidArea(new Dimension(0, 5)));
            }
            diskContainer.revalidate();
            diskContainer.repaint();
        }
    }

    // ==================== 网络面板 ====================
    class NetworkPanel extends JPanel {

        private final JLabel infoLabel;
        private final BarChart downBar;
        private final BarChart upBar;

        NetworkPanel() {
            setBackground(getMainBg());
            setLayout(new BorderLayout(10, 10));
            setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

            // 信息区
            JPanel infoPanel = new JPanel(new BorderLayout());
            infoPanel.setBackground(getCardBg());
            infoPanel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER_COLOR),
                    BorderFactory.createEmptyBorder(15, 15, 15, 15)
            ));

            JLabel title = new JLabel("网络信息");
            title.setFont(new Font("微软雅黑", Font.BOLD, 14));
            title.setForeground(ACCENT_BLUE);
            infoPanel.add(title, BorderLayout.NORTH);

            infoLabel = new JLabel("加载中...");
            infoLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
            infoLabel.setForeground(getTextColor());
            infoPanel.add(infoLabel, BorderLayout.CENTER);

            add(infoPanel, BorderLayout.NORTH);

            // 速度图表
            JPanel speedPanel = new JPanel(new GridLayout(2, 1, 0, 15));
            speedPanel.setBackground(getMainBg());

            JPanel downPanel = createSpeedPanel("下载速度", ACCENT_BLUE);
            downBar = new BarChart(ACCENT_BLUE);
            downPanel.add(downBar, BorderLayout.CENTER);
            speedPanel.add(downPanel);

            JPanel upPanel = createSpeedPanel("上传速度", ACCENT_GREEN);
            upBar = new BarChart(ACCENT_GREEN);
            upPanel.add(upBar, BorderLayout.CENTER);
            speedPanel.add(upPanel);

            add(speedPanel, BorderLayout.CENTER);
        }

        private JPanel createSpeedPanel(String title, Color accent) {
            JPanel panel = new JPanel(new BorderLayout(10, 5));
            panel.setBackground(getCardBg());
            panel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER_COLOR),
                    BorderFactory.createEmptyBorder(12, 12, 12, 12)
            ));

            JLabel titleLabel = new JLabel(title);
            titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 13));
            titleLabel.setForeground(accent);
            panel.add(titleLabel, BorderLayout.NORTH);

            return panel;
        }

        void refresh() {
            String status = networkInfo.internetConnected ? "已连接" : "未连接";
            String latency = networkInfo.internetLatency >= 0 ? networkInfo.internetLatency + " ms" : "--";

            infoLabel.setText(String.format(
                    "<html>主机名: %s<br>本地IP: %s<br>外网状态: %s (延迟: %s)<br><br>网卡信息:<br>%s</html>",
                    networkInfo.hostname,
                    networkInfo.localIP,
                    status,
                    latency,
                    networkInfo.interfaces.replace("\n", "<br>")
            ));

            // 速度条（最大参考值 10MB/s）
            double maxSpeed = 10 * 1024 * 1024;
            downBar.setValue((int) Math.min(100, networkInfo.downloadSpeed / maxSpeed * 100));
            upBar.setValue((int) Math.min(100, networkInfo.uploadSpeed / maxSpeed * 100));
        }
    }

    // ==================== 进程面板 ====================
    class ProcessPanel extends JPanel {

        private final JTable table;
        private final DefaultTableModel model;
        private final String[] columns = {"PID", "名称", "CPU%", "内存"};

        ProcessPanel() {
            setBackground(getMainBg());
            setLayout(new BorderLayout());
            setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

            JLabel title = new JLabel("进程列表 (" + processList.size() + ")");
            title.setFont(new Font("微软雅黑", Font.BOLD, 14));
            title.setForeground(getTextColor());
            title.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
            add(title, BorderLayout.NORTH);

            model = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }

                @Override
                public Class<?> getColumnClass(int columnIndex) {
                    return columnIndex == 0 || columnIndex == 2 ? Integer.class : String.class;
                }
            };

            table = new JTable(model);
            table.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
            table.setRowHeight(24);
            table.setBackground(getCardBg());
            table.setForeground(getTextColor());
            table.setGridColor(BORDER_COLOR);
            table.setSelectionBackground(new Color(50, 80, 120));
            table.setSelectionForeground(Color.WHITE);
            table.setShowGrid(false);
            table.setIntercellSpacing(new Dimension(0, 0));
            table.setFillsViewportHeight(true);

            // 表头样式
            JTableHeader header = table.getTableHeader();
            header.setFont(new Font("微软雅黑", Font.BOLD, 12));
            header.setBackground(new Color(40, 40, 55));
            header.setForeground(getTextSecondary());
            header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR));
            header.setReorderingAllowed(false);

            // 点击排序
            header.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int col = table.columnAtPoint(e.getPoint());
                    if (col == processSortColumn) {
                        processSortAsc = !processSortAsc;
                    } else {
                        processSortColumn = col;
                        processSortAsc = true;
                    }
                    refresh();
                }
            });

            // 列宽
            table.getColumnModel().getColumn(0).setPreferredWidth(80);
            table.getColumnModel().getColumn(1).setPreferredWidth(250);
            table.getColumnModel().getColumn(2).setPreferredWidth(80);
            table.getColumnModel().getColumn(3).setPreferredWidth(100);

            JScrollPane scroll = new JScrollPane(table);
            scroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
            scroll.getVerticalScrollBar().setUnitIncrement(20);
            scroll.setBackground(getCardBg());
            add(scroll, BorderLayout.CENTER);
        }

        void refresh() {
            // 排序
            List<ProcessInfo> sorted = new ArrayList<>(processList);
            if (processSortColumn >= 0) {
                sorted.sort((a, b) -> {
                    int cmp;
                    switch (processSortColumn) {
                        case 0:
                            cmp = Integer.compare(a.pid, b.pid);
                            break;
                        case 1:
                            cmp = a.name.compareToIgnoreCase(b.name);
                            break;
                        case 2:
                            cmp = Double.compare(a.cpu, b.cpu);
                            break;
                        case 3:
                            cmp = Long.compare(a.memory, b.memory);
                            break;
                        default:
                            cmp = 0;
                    }
                    return processSortAsc ? cmp : -cmp;
                });
            }

            model.setRowCount(0);
            for (ProcessInfo p : sorted) {
                model.addRow(new Object[]{
                    p.pid,
                    p.name,
                    String.format("%.1f", p.cpu),
                    formatSize(p.memory)
                });
            }

            // 更新标题
            Component comp = getComponent(0);
            if (comp instanceof JLabel) {
                ((JLabel) comp).setText("进程列表 (" + sorted.size() + ")");
            }
        }
    }

    // ==================== 柱状图组件 ====================
    class BarChart extends JPanel {

        private int value = 0;
        private final Color barColor;

        BarChart(Color color) {
            this.barColor = color;
            setBackground(getCardBg());
            setPreferredSize(new Dimension(200, 30));
        }

        void setValue(int v) {
            this.value = Math.max(0, Math.min(100, v));
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();
            int barH = h - 4;
            int barY = 2;
            int barW = (int) ((w - 10) * (value / 100.0));

            // 背景条
            g2d.setColor(new Color(50, 50, 60));
            g2d.fillRoundRect(5, barY, w - 10, barH, barH, barH);

            // 进度条
            g2d.setColor(barColor);
            g2d.fillRoundRect(5, barY, barW, barH, barH, barH);

            // 文字
            g2d.setColor(getTextColor());
            g2d.setFont(new Font("Consolas", Font.BOLD, 12));
            String text = value + "%";
            FontMetrics fm = g2d.getFontMetrics();
            int tw = fm.stringWidth(text);
            g2d.drawString(text, w - tw - 10, barY + barH / 2 + fm.getAscent() / 2 - 2);
        }
    }

    // ==================== 工具方法 ====================
    private String formatSize(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        }
        if (bytes < 1024 * 1024) {
            return String.format("%.1f KB", bytes / 1024.0);
        }
        if (bytes < 1024L * 1024 * 1024) {
            return String.format("%.1f MB", bytes / (1024.0 * 1024));
        }
        return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }

    private String formatSpeed(double bytesPerSec) {
        if (bytesPerSec < 1024) {
            return String.format("%.0f B/s", bytesPerSec);
        }
        if (bytesPerSec < 1024 * 1024) {
            return String.format("%.1f KB/s", bytesPerSec / 1024);
        }
        return String.format("%.2f MB/s", bytesPerSec / (1024.0 * 1024));
    }

    // ==================== 主入口 ====================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new WinllxSysMon());
    }
}
