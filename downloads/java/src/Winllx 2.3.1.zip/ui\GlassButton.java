package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Apple iOS Liquid Glass Button
 * 按钮本体不动，玻璃表面层跟随手指拖动产生液态拉扯扭曲
 * 支持方形和圆形两种样式
 */
public class GlassButton extends JPanel {

    public enum ShapeStyle {
        RECTANGLE,  // 方形/圆角矩形
        CIRCLE      // 圆形
    }

    public interface ButtonClickListener {
        void onClick(GlassButton button);
    }

    private String text;
    private Font font;
    private Color textColor;
    private int buttonWidth, buttonHeight;
    private int borderRadius;
    private ShapeStyle shapeStyle;

    private float mouseX = 0f, mouseY = 0f;
    private float velocityX = 0f, velocityY = 0f;
    private float prevMouseX = 0f, prevMouseY = 0f;

    private boolean isPressed = false;
    private boolean isDragging = false;
    protected boolean wasDragMoved = false;

    private float pressProgress = 0f;
    private float scaleProgress = 0f;
    private float idleScale = 1f;          // 闲置状态的缩放
    private float targetIdleScale = 1f;    // 目标闲置缩放

    private Timer animTimer;
    private ButtonClickListener clickListener;
    private List<ActionListener> actionListeners = new ArrayList<>();  // 支持ActionListener

    private static final float SPRING_K = 0.12f;
    private static final float DAMPING = 0.88f;
    private static final float DEFORM_STRENGTH = 0.045f;
    private static final float PRESS_SCALE = 1.12f;  // 点击时的放大比例

    protected GlassButton(String text, Font font, Color textColor, int width, int height, int borderRadius, ShapeStyle style) {
        this.text = text != null ? text : "";
        this.font = font != null ? font : new Font("Microsoft YaHei", Font.BOLD, 15);
        this.textColor = textColor != null ? textColor : new Color(30, 30, 30);
        this.buttonWidth = width > 0 ? width : 140;
        this.buttonHeight = height > 0 ? height : 48;
        this.shapeStyle = style;
        
        // 圆形模式：borderRadius设为最大值
        if (style == ShapeStyle.CIRCLE) {
            this.borderRadius = Math.min(this.buttonWidth, this.buttonHeight) / 2;
        } else {
            this.borderRadius = borderRadius > 0 ? borderRadius : Math.min(this.buttonWidth, this.buttonHeight) / 2;
        }

        setOpaque(false);
        int ew = (int) (this.buttonWidth * PRESS_SCALE + 40);
        int eh = (int) (this.buttonHeight * PRESS_SCALE + 40);
        setPreferredSize(new Dimension(ew, eh));
        setSize(ew, eh);

        MouseAdapter ma = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                isPressed = true;
                isDragging = true;
                mouseX = e.getX() - buttonWidth / 2f;
                mouseY = e.getY() - buttonHeight / 2f;
                prevMouseX = mouseX;
                prevMouseY = mouseY;
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                isDragging = false;
                isPressed = false;
                // 只有未被拖动过（位置移动）时才触发点击
                if (!wasDragMoved) {
                    if (clickListener != null) {
                        clickListener.onClick(GlassButton.this);
                    }
                    ActionEvent event = new ActionEvent(GlassButton.this, ActionEvent.ACTION_PERFORMED, text);
                    for (ActionListener listener : actionListeners) {
                        listener.actionPerformed(event);
                    }
                }
                wasDragMoved = false;
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                if (isDragging) {
                    float newX = e.getX() - buttonWidth / 2f;
                    float newY = e.getY() - buttonHeight / 2f;
                    velocityX = newX - prevMouseX;
                    velocityY = newY - prevMouseY;
                    mouseX = newX;
                    mouseY = newY;
                    prevMouseX = newX;
                    prevMouseY = newY;
                }
            }
        };

        addMouseListener(ma);
        addMouseMotionListener(ma);

        animTimer = new Timer(16, e -> {
            updatePhysics();
            repaint(0, 0, getExpandedWidth(), getExpandedHeight());
        });
        animTimer.start();
    }

    // ========== 工厂方法 ==========
    
    public static GlassButton createButton(String text) {
        return new GlassButton(text, null, null, 140, 48, 24, ShapeStyle.RECTANGLE);
    }

    public static GlassButton createButton(String text, int width, int height) {
        return new GlassButton(text, null, null, width, height, Math.min(width, height) / 2, ShapeStyle.RECTANGLE);
    }

    public static GlassButton createButton(String text, int width, int height, int borderRadius) {
        return new GlassButton(text, null, null, width, height, borderRadius, ShapeStyle.RECTANGLE);
    }

    public static GlassButton createButton(String text, Font font, Color textColor, int width, int height) {
        return new GlassButton(text, font, textColor, width, height, Math.min(width, height) / 2, ShapeStyle.RECTANGLE);
    }

    public static GlassButton createButton(String text, Font font, Color textColor, int width, int height, int borderRadius) {
        return new GlassButton(text, font, textColor, width, height, borderRadius, ShapeStyle.RECTANGLE);
    }
    
    // 创建圆形按钮
    public static GlassButton createCircleButton(String text, int diameter) {
        return new GlassButton(text, null, null, diameter, diameter, diameter / 2, ShapeStyle.CIRCLE);
    }
    
    public static GlassButton createCircleButton(String text, int diameter, Font font, Color textColor) {
        return new GlassButton(text, font, textColor, diameter, diameter, diameter / 2, ShapeStyle.CIRCLE);
    }

    public void setOnClickListener(ButtonClickListener listener) {
        this.clickListener = listener;
    }
    
    /**
     * 添加ActionListener，兼容原有按钮代码
     */
    public void addActionListener(ActionListener listener) {
        actionListeners.add(listener);
    }
    
    /**
     * 移除ActionListener
     */
    public void removeActionListener(ActionListener listener) {
        actionListeners.remove(listener);
    }
    
    /**
     * 获取按钮文字
     */
    public String getText() {
        return text;
    }
    
    /**
     * 设置按钮文字
     */
    public void setText(String text) {
        this.text = text;
        repaint();
    }

    public void setTextColor(Color color) {
        this.textColor = color;
        repaint();
    }

    private void updatePhysics() {
        // 鼠标位置的弹性回复
        if (!isDragging) {
            mouseX += (-mouseX) * SPRING_K;
            mouseY += (-mouseY) * SPRING_K;
            velocityX *= DAMPING;
            velocityY *= DAMPING;
        }

        // 按压进度动画
        float targetPress = isPressed ? 1f : 0f;
        pressProgress += (targetPress - pressProgress) * 0.18f;
        
        // 缩放动画 - 点击时放大，释放时平滑回弹
        float targetScale = isPressed ? 1f : 0f;
        scaleProgress += (targetScale - scaleProgress) * 0.15f;
        
        // 闲置缩放动画（鼠标悬停时轻微放大）
        idleScale += (targetIdleScale - idleScale) * 0.12f;
    }

    // 扩展绘制区域大小
    private int getExpandedWidth() {
        return (int) (buttonWidth * PRESS_SCALE + 40);
    }

    private int getExpandedHeight() {
        return (int) (buttonHeight * PRESS_SCALE + 40);
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(getExpandedWidth(), getExpandedHeight());
    }

    @Override
    public Dimension getSize() {
        return new Dimension(getExpandedWidth(), getExpandedHeight());
    }
    
    @Override
    public void paint(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        // 清除上一帧残留，防止半透明阴影叠加
        Composite oldComp = g2d.getComposite();
        g2d.setComposite(AlphaComposite.Clear);
        g2d.fillRect(0, 0, getExpandedWidth(), getExpandedHeight());
        g2d.setComposite(oldComp);

        // 取消裁剪
        g2d.setClip(null);

        int w = buttonWidth;
        int h = buttonHeight;
        int cx = getWidth() / 2;
        int cy = getHeight() / 2;
        int arc = borderRadius;

        // 计算当前缩放
        float currentScale = 1f + scaleProgress * (PRESS_SCALE - 1f);

        // ===== 第一层：底层阴影和背景（固定大小） =====
        drawShadow(g2d, w, h, cx, cy, arc);
        drawBase(g2d, w, h, cx, cy, arc);

        // ===== 第二层：上层玻璃效果（可缩放，超出边界） =====
        // 应用缩放变换绘制玻璃层
        g2d.translate(cx, cy);
        g2d.scale(currentScale, currentScale);
        g2d.translate(-cx, -cy);

        drawLiquidGlass(g2d, w, h, cx, cy, arc);
        drawText(g2d, w, h, cx, cy);
    }

    @Override
    protected void paintComponent(Graphics g) {
        // 不在这里绘制，改用paint方法实现分层
    }

    private void drawShadow(Graphics2D g2d, int w, int h, int cx, int cy, int arc) {
        float depth = pressProgress * 3f;
        
        // 计算背景层起始位置（居中）
        int baseX = cx - w / 2;
        int baseY = cy - h / 2;
        
        // 多层阴影，营造深度感
        for (int i = 8; i > 0; i--) {
            float alpha = (0.025f - i * 0.002f) * (1f + pressProgress * 0.4f);
            alpha = Math.max(0, alpha);
            g2d.setColor(new Color(0, 0, 0, (int) (alpha * 255)));
            float spread = i * 2.5f;
            
            if (shapeStyle == ShapeStyle.CIRCLE) {
                g2d.fillOval((int) (baseX - spread), (int) (baseY + 3 + depth + spread * 0.3f), 
                            (int) (w + spread * 2), (int) (h + spread));
            } else {
                g2d.fillRoundRect(
                        (int) (baseX - spread), (int) (baseY + 3 + depth + spread * 0.3f),
                        (int) (w + spread * 2), (int) (h + spread),
                        arc + (int) spread, arc + (int) spread);
            }
        }

        // 主阴影
        g2d.setColor(new Color(0, 0, 0, (int) (25 * (1 + pressProgress * 0.5f))));
        if (shapeStyle == ShapeStyle.CIRCLE) {
            g2d.fillOval(baseX, (int) (baseY + 2 + depth), w, h);
        } else {
            g2d.fillRoundRect(baseX, (int) (baseY + 2 + depth), w, h, arc, arc);
        }
    }

    private void drawBase(Graphics2D g2d, int w, int h, int cx, int cy, int arc) {
        // 计算背景层起始位置（居中）
        int baseX = cx - w / 2;
        int baseY = cy - h / 2;
        
        // 闲置时的淡色填充背景
        float baseAlpha = 0.08f + pressProgress * 0.12f; // 点击时略微增加
        
        // 渐变背景
        GradientPaint basePaint = new GradientPaint(
                baseX, baseY, new Color(255, 255, 255, (int) (baseAlpha * 255 * 1.2f)),
                baseX, baseY + h, new Color(240, 245, 255, (int) (baseAlpha * 255 * 0.8f))
        );
        g2d.setPaint(basePaint);
        
        if (shapeStyle == ShapeStyle.CIRCLE) {
            g2d.fillOval(baseX, baseY, w, h);
        } else {
            g2d.fillRoundRect(baseX, baseY, w, h, arc, arc);
        }

        // 内部高光（闲置时也显示）
        float highlightAlpha = 0.15f + pressProgress * 0.25f;
        RadialGradientPaint innerGlow = new RadialGradientPaint(
                new Point2D.Float(cx, baseY + h * 0.3f),
                Math.min(w, h) * 0.7f,
                new float[]{0f, 0.5f, 1f},
                new Color[]{
                        new Color(255, 255, 255, (int) (highlightAlpha * 255)),
                        new Color(255, 255, 255, (int) (highlightAlpha * 100)),
                        new Color(255, 255, 255, 0)
                }
        );
        g2d.setPaint(innerGlow);
        
        if (shapeStyle == ShapeStyle.CIRCLE) {
            g2d.fillOval(baseX, baseY, w, h);
        } else {
            g2d.fillRoundRect(baseX, baseY, w, h, arc, arc);
        }

        // 边框
        g2d.setColor(new Color(255, 255, 255, (int) (80 * (0.8f + pressProgress * 0.2f))));
        g2d.setStroke(new BasicStroke(1.0f));
        if (shapeStyle == ShapeStyle.CIRCLE) {
            g2d.drawOval(baseX, baseY, w - 1, h - 1);
        } else {
            g2d.drawRoundRect(baseX, baseY, w - 1, h - 1, arc, arc);
        }
    }

    private void drawLiquidGlass(Graphics2D g2d, int w, int h, int cx, int cy, int arc) {
        float velMag = (float) Math.sqrt(velocityX * velocityX + velocityY * velocityY);
        float velDeform = Math.min(velMag * 0.5f, 10f);

        float deformX = mouseX * DEFORM_STRENGTH;
        float deformY = mouseY * DEFORM_STRENGTH;

        if (velMag > 0.1f) {
            deformX += (velocityX / velMag) * velDeform * 0.6f;
            deformY += (velocityY / velMag) * velDeform * 0.6f;
        }

        // 拉伸计算
        float stretchLeft = -mouseX * 0.015f - (velMag > 0.1f && velocityX < 0 ? velDeform * 0.3f : 0);
        float stretchRight = mouseX * 0.015f + (velMag > 0.1f && velocityX > 0 ? velDeform * 0.3f : 0);
        float stretchTop = -mouseY * 0.015f - (velMag > 0.1f && velocityY < 0 ? velDeform * 0.3f : 0);
        float stretchBottom = mouseY * 0.015f + (velMag > 0.1f && velocityY > 0 ? velDeform * 0.3f : 0);

        // 基于中心点计算坐标
        float glassCenterX = cx + deformX * 0.4f;
        float glassCenterY = cy + deformY * 0.4f;

        float left = glassCenterX - w / 2f + stretchLeft;
        float right = glassCenterX + w / 2f + stretchRight;
        float top = glassCenterY - h / 2f + stretchTop;
        float bottom = glassCenterY + h / 2f + stretchBottom;

        float drawW = right - left;
        float drawH = bottom - top;
        
        // 点击时透明效果最大化
        float glassOpacity = 0.02f + pressProgress * 0.15f;

        // 创建玻璃层形状
        Shape glassShape;
        if (shapeStyle == ShapeStyle.CIRCLE) {
            glassShape = new Ellipse2D.Float(left, top, drawW, drawH);
        } else {
            glassShape = new RoundRectangle2D.Float(left, top, drawW, drawH, arc, arc);
        }

        // 玻璃层填充
        GradientPaint glassGrad = new GradientPaint(
                left, top, new Color(255, 255, 255, (int) (glassOpacity * 255)),
                right, bottom, new Color(240, 248, 255, (int) (glassOpacity * 180))
        );
        g2d.setPaint(glassGrad);
        g2d.fill(glassShape);

        // 玻璃边缘发光
        g2d.setColor(new Color(255, 255, 255, (int) (70 * (0.6f + pressProgress * 0.4f))));
        g2d.setStroke(new BasicStroke(1.2f));
        g2d.draw(glassShape);

        // 外发光效果
        if (pressProgress > 0.05f) {
            int glowLayers = (int) (6 * pressProgress);
            for (int i = glowLayers; i > 0; i--) {
                float alpha = 0.012f * (1 - i / (float) glowLayers) * pressProgress;
                if (alpha <= 0) continue;
                g2d.setColor(new Color(200, 220, 255, (int) (alpha * 255)));
                g2d.setStroke(new BasicStroke(i * 3));
                g2d.draw(glassShape);
            }
        }

        drawHighlight(g2d, left, top, drawW, drawH, deformX, deformY, pressProgress);
        drawRefraction(g2d, left, top, drawW, drawH, arc, pressProgress);
    }

    private void drawHighlight(Graphics2D g2d, float x, float y, float w, float h, 
                               float dx, float dy, float press) {
        // 顶部高光
        float highlightY = y + h * 0.15f;
        float highlightW = w * 0.6f;
        float highlightH = h * 0.18f;
        float highlightX = x + w / 2f;

        Ellipse2D.Float highlight = new Ellipse2D.Float(
                highlightX - highlightW / 2, highlightY - highlightH / 2,
                highlightW, highlightH);

        RadialGradientPaint highlightGrad = new RadialGradientPaint(
                new Point2D.Float(highlightX, highlightY - highlightH * 0.15f),
                highlightW / 2,
                new float[]{0f, 0.5f, 1f},
                new Color[]{
                        new Color(255, 255, 255, (int) (110 * (0.7f + press * 0.3f))),
                        new Color(255, 255, 255, (int) (45 * (0.7f + press * 0.3f))),
                        new Color(255, 255, 255, 0)
                }
        );

        g2d.setPaint(highlightGrad);
        g2d.fill(highlight);

        // 顶部细线高光
        g2d.setColor(new Color(255, 255, 255, (int) (180 * (0.5f + press * 0.5f))));
        g2d.setStroke(new BasicStroke(0.9f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        if (shapeStyle == ShapeStyle.CIRCLE) {
            // 圆形的顶部高光弧线
            float arcW = w * 0.85f;
            g2d.drawArc((int) (x + (w - arcW) / 2), (int) y, (int) arcW, (int) (h * 0.4f), 30, 120);
        } else {
            g2d.drawLine((int) (x + 4), (int) (y + 2), (int) (x + w - 4), (int) (y + 2));
        }

        // 底部反光
        g2d.setColor(new Color(255, 255, 255, (int) (25 * (0.6f + press * 0.4f))));
        g2d.setStroke(new BasicStroke(0.6f));
        if (shapeStyle == ShapeStyle.CIRCLE) {
            float arcW = w * 0.7f;
            g2d.drawArc((int) (x + (w - arcW) / 2), (int) (y + h * 0.65f), (int) arcW, (int) (h * 0.3f), 210, 120);
        } else {
            g2d.drawLine((int) (x + 6), (int) (y + h - 2.5f), (int) (x + w - 6), (int) (y + h - 2.5f));
        }
    }
    
    /**
     * 绘制边缘折射弯曲效果
     */
    private void drawRefraction(Graphics2D g2d, float x, float y, float w, float h, 
                                 int arc, float press) {
        if (press < 0.05f) return;
        
        // 边缘折射层
        float refractionAlpha = press * 0.25f;
        
        // 左右边缘折射
        float edgeWidth = Math.min(w, h) * 0.12f;
        
        // 左边缘
        GradientPaint leftRefraction = new GradientPaint(
                x, y, new Color(220, 235, 255, (int) (refractionAlpha * 255 * 0.3f)),
                x + edgeWidth, y, new Color(255, 255, 255, 0)
        );
        g2d.setPaint(leftRefraction);
        if (shapeStyle == ShapeStyle.CIRCLE) {
            g2d.fill(new Ellipse2D.Float(x, y, edgeWidth * 2, h));
        } else {
            g2d.fill(new RoundRectangle2D.Float(x, y, edgeWidth, h, arc, arc));
        }
        
        // 右边缘
        GradientPaint rightRefraction = new GradientPaint(
                x + w - edgeWidth, y, new Color(255, 255, 255, 0),
                x + w, y, new Color(220, 235, 255, (int) (refractionAlpha * 255 * 0.3f))
        );
        g2d.setPaint(rightRefraction);
        if (shapeStyle == ShapeStyle.CIRCLE) {
            g2d.fill(new Ellipse2D.Float(x + w - edgeWidth * 2, y, edgeWidth * 2, h));
        } else {
            g2d.fill(new RoundRectangle2D.Float(x + w - edgeWidth, y, edgeWidth, h, arc, arc));
        }
        
        // 底部边缘折射（模拟玻璃弯曲）
        float bottomRefraction = press * 0.2f;
        GradientPaint bottomGrad = new GradientPaint(
                x, y + h * 0.7f, new Color(200, 220, 255, 0),
                x, y + h, new Color(180, 210, 240, (int) (bottomRefraction * 255))
        );
        g2d.setPaint(bottomGrad);
        if (shapeStyle == ShapeStyle.CIRCLE) {
            g2d.fill(new Ellipse2D.Float(x, y + h * 0.5f, w, h * 0.5f));
        } else {
            g2d.fill(new RoundRectangle2D.Float(x, y + h * 0.7f, w, h * 0.3f, arc, arc));
        }
    }

    private void drawText(Graphics2D g2d, int w, int h, int cx, int cy) {
        g2d.setFont(font);
        FontMetrics fm = g2d.getFontMetrics();

        float textOffsetX = mouseX * 0.06f + velocityX * 0.08f;
        float textOffsetY = mouseY * 0.06f + velocityY * 0.08f;

        int tx = (int) (cx - fm.stringWidth(text) / 2f + textOffsetX);
        int ty = (int) (cy + fm.getAscent() / 2 - 2 + textOffsetY);

        // 文字阴影
        float shadowAlpha = 25 + pressProgress * 15;
        g2d.setColor(new Color(0, 0, 0, (int) shadowAlpha));
        g2d.drawString(text, tx + 1, ty + 1);

        // 主文字
        g2d.setColor(textColor);
        g2d.drawString(text, tx, ty);
    }
    
    @Override
    public void setBounds(int x, int y, int width, int height) {
        super.setBounds(x, y, width, height);
        // 圆形模式自动调整borderRadius
        if (shapeStyle == ShapeStyle.CIRCLE) {
            this.borderRadius = Math.min(width, height) / 2;
        }
    }
}
