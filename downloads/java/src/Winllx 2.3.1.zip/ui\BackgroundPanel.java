package ui;

import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

public class BackgroundPanel extends JPanel {
    public static final int FIT_FILL = 0;
    public static final int FIT_FIT = 1;
    public static final int FIT_STRETCH = 2;
    public static final int FIT_CENTER = 3;

    private BufferedImage backgroundImage;
    private float imageOpacity = 1.0f;
    private int fitMode = FIT_FILL;

    public BackgroundPanel() {
        setOpaque(true);
        setLayout(null);
    }

    public void setBackgroundImage(BufferedImage image) {
        this.backgroundImage = image;
        repaint();
    }

    public BufferedImage getBackgroundImage() {
        return backgroundImage;
    }

    public boolean hasBackgroundImage() {
        return backgroundImage != null;
    }

    public void setImageOpacity(float opacity) {
        this.imageOpacity = Math.max(0f, Math.min(1f, opacity));
        repaint();
    }

    public float getImageOpacity() {
        return imageOpacity;
    }

    public void setFitMode(int mode) {
        this.fitMode = mode;
        repaint();
    }

    public int getFitMode() {
        return fitMode;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);

        g2d.setColor(getBackground());
        g2d.fillRect(0, 0, getWidth(), getHeight());

        if (backgroundImage != null && imageOpacity > 0) {
            Composite oldComp = g2d.getComposite();
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, imageOpacity));

            int pw = getWidth();
            int ph = getHeight();
            int iw = backgroundImage.getWidth();
            int ih = backgroundImage.getHeight();

            switch (fitMode) {
                case FIT_FILL -> {
                    double scale = Math.max((double) pw / iw, (double) ph / ih);
                    int sw = (int) (iw * scale);
                    int sh = (int) (ih * scale);
                    g2d.drawImage(backgroundImage, (pw - sw) / 2, (ph - sh) / 2, sw, sh, null);
                }
                case FIT_FIT -> {
                    double scale = Math.min((double) pw / iw, (double) ph / ih);
                    int sw = (int) (iw * scale);
                    int sh = (int) (ih * scale);
                    g2d.drawImage(backgroundImage, (pw - sw) / 2, (ph - sh) / 2, sw, sh, null);
                }
                case FIT_STRETCH -> g2d.drawImage(backgroundImage, 0, 0, pw, ph, null);
                case FIT_CENTER -> g2d.drawImage(backgroundImage, (pw - iw) / 2, (ph - ih) / 2, null);
            }

            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.25f * imageOpacity));
            GradientPaint topOverlay = new GradientPaint(
                    0, 0, new Color(0, 0, 0, 180),
                    0, Math.min(100, ph * 0.12f), new Color(0, 0, 0, 0)
            );
            g2d.setPaint(topOverlay);
            g2d.fillRect(0, 0, pw, Math.min(100, ph / 8));

            g2d.setComposite(oldComp);
        }

        g2d.dispose();
    }
}
