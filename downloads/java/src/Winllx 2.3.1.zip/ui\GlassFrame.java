package ui;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.util.Arrays;

public class GlassFrame extends JFrame {

    private static boolean glassEnabled = false;
    private static JFrame mainFrameRef = null;

    private BufferedImage backdrop;
    private int backdropOffsetX = 0, backdropOffsetY = 0;
    private boolean dragging = false;
    private boolean maximized = false;
    private Rectangle restoreBounds;
    private Point dragStart;
    private Point windowStart;

    private int hoverButton = -1;
    private int pressedButton = -1;

    private Timer captureTimer;
    private int captureRetries = 0;

    private static final int CORNER_RADIUS = 14;
    private static final int TITLE_BAR_H = 36;
    private static final int BTN_SIZE = 14;
    private static final int BTN_SPACING = 8;
    private static final int BTN_START_X = 12;
    private static final int BTN_START_Y = 11;
    private static final int DRAG_AREA_W = 90;
    private static final int RESIZE_BORDER = 6;

    private int resizeEdge = 0;
    private Point resizeStart;
    private Rectangle resizeStartBounds;

    static final int EDGE_NONE = 0;
    static final int EDGE_TOP = 1;
    static final int EDGE_BOTTOM = 2;
    static final int EDGE_LEFT = 4;
    static final int EDGE_RIGHT = 8;

    public GlassFrame(String title) {
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 0));

        getRootPane().setOpaque(false);
        getLayeredPane().setOpaque(false);

        JPanel glassContent = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                paintFrostedGlass(g2d, getWidth(), getHeight());
                g2d.dispose();
            }
            @Override
            public boolean isOpaque() {
                return true;
            }
        };
        glassContent.setLayout(new BorderLayout());
        glassContent.setBorder(BorderFactory.createEmptyBorder(TITLE_BAR_H, 0, 0, 0));
        super.setContentPane(glassContent);

        JPanel resizeLayer = new JPanel() {
            @Override
            public boolean contains(int x, int y) {
                return getResizeEdgeAt(x, y) != EDGE_NONE;
            }
        };
        resizeLayer.setOpaque(false);
        resizeLayer.setBounds(0, 0, 9999, 9999);
        getLayeredPane().add(resizeLayer, JLayeredPane.PALETTE_LAYER + 1);

        resizeLayer.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                resizeEdge = getResizeEdgeAt(e.getX(), e.getY());
                if (resizeEdge != EDGE_NONE) {
                    resizeStart = new Point(e.getPoint());
                    SwingUtilities.convertPointToScreen(resizeStart, GlassFrame.this);
                    resizeStartBounds = GlassFrame.this.getBounds();
                    if (maximized) {
                        maximized = false;
                        restoreBounds = null;
                    }
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (resizeEdge != EDGE_NONE) {
                    resizeEdge = EDGE_NONE;
                    scheduleCapture();
                }
            }
        });

        resizeLayer.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                int edge = getResizeEdgeAt(e.getX(), e.getY());
                setCursor(getResizeCursor(edge));
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                if (resizeEdge != EDGE_NONE && resizeStart != null && resizeStartBounds != null) {
                    Point p = new Point(e.getPoint());
                    SwingUtilities.convertPointToScreen(p, GlassFrame.this);
                    int dx = p.x - resizeStart.x;
                    int dy = p.y - resizeStart.y;

                    int x = resizeStartBounds.x;
                    int y = resizeStartBounds.y;
                    int w = resizeStartBounds.width;
                    int h = resizeStartBounds.height;

                    if ((resizeEdge & EDGE_LEFT) != 0) {
                        x = resizeStartBounds.x + dx;
                        w = resizeStartBounds.width - dx;
                    }
                    if ((resizeEdge & EDGE_RIGHT) != 0) {
                        w = resizeStartBounds.width + dx;
                    }
                    if ((resizeEdge & EDGE_TOP) != 0) {
                        y = resizeStartBounds.y + dy;
                        h = resizeStartBounds.height - dy;
                    }
                    if ((resizeEdge & EDGE_BOTTOM) != 0) {
                        h = resizeStartBounds.height + dy;
                    }

                    int minW = getMinimumSize() != null ? getMinimumSize().width : 100;
                    int minH = getMinimumSize() != null ? getMinimumSize().height : 100;
                    if (w < minW) { w = minW; if ((resizeEdge & EDGE_LEFT) != 0) x = resizeStartBounds.x + resizeStartBounds.width - minW; }
                    if (h < minH) { h = minH; if ((resizeEdge & EDGE_TOP) != 0) y = resizeStartBounds.y + resizeStartBounds.height - minH; }

                    GlassFrame.this.setBounds(x, y, w, h);
                    updateShape();
                    captureBackdropLive();
                    repaint();
                }
            }
        });

        JPanel titleBarHandler = new JPanel() {
            @Override
            public boolean contains(int x, int y) {
                return y < TITLE_BAR_H;
            }
        };
        titleBarHandler.setOpaque(false);
        titleBarHandler.setBounds(0, 0, 9999, TITLE_BAR_H);
        getLayeredPane().add(titleBarHandler, JLayeredPane.PALETTE_LAYER);

        titleBarHandler.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                int btn = getButtonAt(e.getX(), e.getY());
                pressedButton = btn;
                if (btn < 0) {
                    Point p = new Point(e.getPoint());
                    SwingUtilities.convertPointToScreen(p, GlassFrame.this);
                    dragStart = p;
                    windowStart = GlassFrame.this.getLocation();
                    dragging = true;
                }
                repaint();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                int btn = getButtonAt(e.getX(), e.getY());
                if (btn == pressedButton && btn >= 0) {
                    handleButtonClick(btn);
                }
                pressedButton = -1;
                if (dragging) {
                    dragging = false;
                    scheduleCapture();
                }
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hoverButton = -1;
                repaint();
            }
        });

        titleBarHandler.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                int newHover = getButtonAt(e.getX(), e.getY());
                if (newHover != hoverButton) {
                    hoverButton = newHover;
                    repaint();
                }
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                if (dragging && dragStart != null) {
                    Point p = new Point(e.getPoint());
                    SwingUtilities.convertPointToScreen(p, GlassFrame.this);
                    int nx = windowStart.x + (p.x - dragStart.x);
                    int ny = windowStart.y + (p.y - dragStart.y);
                    if (maximized) {
                        maximized = false;
                        restoreBounds = null;
                    }
                    GlassFrame.this.setLocation(nx, ny);
                    captureBackdropLive();
                    repaint();
                }
            }
        });

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                updateShape();
                scheduleCapture();
            }

            @Override
            public void componentMoved(ComponentEvent e) {
                if (!dragging) scheduleCapture();
            }

            @Override
            public void componentShown(ComponentEvent e) {
                SwingUtilities.invokeLater(() -> {
                    updateShape();
                    captureRetries = 0;
                    scheduleCapture();
                });
            }
        });
    }

    @Override
    public void setContentPane(Container c) {
        if (c instanceof JComponent jc) {
            jc.setOpaque(false);
        }
        JPanel wrapper = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                paintFrostedGlass(g2d, getWidth(), getHeight());
                g2d.dispose();
            }
            @Override
            public boolean isOpaque() {
                return true;
            }
        };
        wrapper.setBorder(BorderFactory.createEmptyBorder(TITLE_BAR_H, 0, 0, 0));
        wrapper.add(c, BorderLayout.CENTER);
        super.setContentPane(wrapper);
        makeContainersTransparent(c);
    }

    @Override
    public void setVisible(boolean b) {
        super.setVisible(b);
        if (b) {
            SwingUtilities.invokeLater(() -> {
                makeContainersTransparent(getContentPane());
                captureRetries = 0;
                scheduleCapture();
            });
        }
    }

    private void makeContainersTransparent(Container c) {
        if (c == null) return;
        for (Component child : c.getComponents()) {
            if (child instanceof JScrollPane sp) {
                sp.setOpaque(false);
                if (sp.getViewport() != null) {
                    sp.getViewport().setOpaque(false);
                    sp.getViewport().setBackground(new Color(0, 0, 0, 0));
                }
            } else if (child instanceof JTabbedPane tp) {
                tp.setOpaque(false);
                tp.setBackground(new Color(0, 0, 0, 0));
            } else if (child instanceof JComponent jc) {
                jc.setOpaque(false);
            }
            if (child instanceof Container cont) {
                makeContainersTransparent(cont);
            }
        }
    }

    @Override
    public void paint(Graphics g) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);

        paintFrostedGlass(g2d, w, h);
        g2d.dispose();

        getRootPane().paint(g);

        Graphics2D g2d2 = (Graphics2D) g.create();
        g2d2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        drawBorder(g2d2, w, h);
        drawTitleBarButtons(g2d2);
        g2d2.dispose();
    }

    public static void setGlassEnabled(boolean enabled) { glassEnabled = enabled; }
    public static boolean isGlassEnabled() { return glassEnabled; }
    public static void setMainFrame(JFrame frame) { mainFrameRef = frame; }

    private void updateShape() {
        int w = getWidth();
        int h = getHeight();
        if (w > 0 && h > 0) {
            setShape(new RoundRectangle2D.Double(0, 0, w, h, CORNER_RADIUS, CORNER_RADIUS));
        }
    }

    private void scheduleCapture() {
        if (captureTimer != null && captureTimer.isRunning()) {
            captureTimer.restart();
        } else {
            int delay = captureRetries == 0 ? 100 : (captureRetries == 1 ? 300 : 600);
            captureTimer = new Timer(delay, e -> {
                captureBackdrop();
                repaint();
                if (backdrop == null && captureRetries < 3) {
                    captureRetries++;
                    scheduleCapture();
                } else {
                    captureRetries = 0;
                }
            });
            captureTimer.setRepeats(false);
            captureTimer.start();
        }
    }

    private void captureBackdrop() {
        captureBackdrop(12, 4);
    }

    private void captureBackdropLive() {
        captureBackdrop(6, 1);
    }

    private void captureBackdrop(int blurRadius, int blurPasses) {
        try {
            if (mainFrameRef == null || !mainFrameRef.isShowing() || !isShowing()) {
                return;
            }
            Point glassLoc = getLocationOnScreen();
            Point mainLoc = mainFrameRef.getLocationOnScreen();

            int relX = glassLoc.x - mainLoc.x;
            int relY = glassLoc.y - mainLoc.y;
            int w = getWidth();
            int h = getHeight();

            int x1 = Math.max(0, relX);
            int y1 = Math.max(0, relY);
            int x2 = Math.min(mainFrameRef.getWidth(), relX + w);
            int y2 = Math.min(mainFrameRef.getHeight(), relY + h);

            if (x2 <= x1 || y2 <= y1) return;

            int cropW = x2 - x1;
            int cropH = y2 - y1;

            Container content = mainFrameRef.getContentPane();
            BufferedImage mainImg = new BufferedImage(cropW, cropH, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = mainImg.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
            g.setColor(content.getBackground());
            g.fillRect(0, 0, cropW, cropH);
            g.translate(-x1, -y1);
            g.setClip(0, 0, mainFrameRef.getWidth(), mainFrameRef.getHeight());

            RepaintManager rm = RepaintManager.currentManager(content);
            boolean db = rm.isDoubleBufferingEnabled();
            rm.setDoubleBufferingEnabled(false);
            content.print(g);
            rm.setDoubleBufferingEnabled(db);

            g.dispose();

            backdrop = blurImage(mainImg, blurRadius, blurPasses);
            backdropOffsetX = x1 - relX;
            backdropOffsetY = y1 - relY;
        } catch (Exception e) {
            backdrop = null;
        }
    }

    private static BufferedImage blurImage(BufferedImage image, int radius, int passes) {
        if (image == null) return null;
        int size = radius * 2 + 1;
        float weight = 1.0f / size;
        float[] kernel = new float[size];
        Arrays.fill(kernel, weight);

        Kernel hKernel = new Kernel(size, 1, kernel);
        Kernel vKernel = new Kernel(1, size, kernel);

        BufferedImage result = image;
        for (int i = 0; i < passes; i++) {
            BufferedImage temp = new BufferedImage(result.getWidth(), result.getHeight(), BufferedImage.TYPE_INT_ARGB);
            ConvolveOp hBlur = new ConvolveOp(hKernel, ConvolveOp.EDGE_NO_OP, null);
            hBlur.filter(result, temp);
            BufferedImage temp2 = new BufferedImage(result.getWidth(), result.getHeight(), BufferedImage.TYPE_INT_ARGB);
            ConvolveOp vBlur = new ConvolveOp(vKernel, ConvolveOp.EDGE_NO_OP, null);
            vBlur.filter(temp, temp2);
            result = temp2;
        }
        return result;
    }

    private void paintFrostedGlass(Graphics2D g2d, int w, int h) {
        if (backdrop != null) {
            g2d.drawImage(backdrop, backdropOffsetX, backdropOffsetY, null);
        } else {
            Color baseColor = (mainFrameRef != null) ? mainFrameRef.getContentPane().getBackground() : new Color(80, 80, 90);
            g2d.setColor(baseColor);
            g2d.fillRect(0, 0, w, h);
        }

        Color baseColor = (mainFrameRef != null) ? mainFrameRef.getContentPane().getBackground() : new Color(120, 120, 130);
        boolean dark = (baseColor.getRed() + baseColor.getGreen() + baseColor.getBlue()) / 3 < 128;
        Color tint = dark ? new Color(255, 255, 255, 30) : new Color(255, 255, 255, 45);
        g2d.setColor(tint);
        g2d.fillRect(0, 0, w, h);

        GradientPaint topGrad = new GradientPaint(
                0, 0, new Color(0, 0, 0, 35),
                0, 50, new Color(0, 0, 0, 0)
        );
        g2d.setPaint(topGrad);
        g2d.fillRect(0, 0, w, 50);
    }

    private void drawBorder(Graphics2D g2d, int w, int h) {
        g2d.setColor(new Color(130, 130, 130, 200));
        g2d.setStroke(new BasicStroke(1.5f));
        g2d.drawRoundRect(0, 0, w - 1, h - 1, CORNER_RADIUS, CORNER_RADIUS);
    }

    private void drawTitleBarButtons(Graphics2D g2d) {
        Color[] colors = {
            new Color(255, 95, 86),
            new Color(255, 189, 46),
            new Color(39, 201, 63)
        };

        for (int i = 0; i < 3; i++) {
            int bx = BTN_START_X + i * (BTN_SIZE + BTN_SPACING);
            boolean hovered = (hoverButton == i);
            boolean pressed = (pressedButton == i && hovered);

            Color baseColor = colors[i];
            if (hovered) {
                g2d.setColor(baseColor);
            } else {
                g2d.setColor(new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), 160));
            }

            int drawX = pressed ? bx + 1 : bx;
            g2d.fillOval(drawX, BTN_START_Y, BTN_SIZE, BTN_SIZE);
            g2d.setColor(new Color(0, 0, 0, 40));
            g2d.drawOval(drawX, BTN_START_Y, BTN_SIZE, BTN_SIZE);

            if (hovered) {
                g2d.setColor(new Color(255, 255, 255, 230));
                g2d.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                int cx = drawX + BTN_SIZE / 2;
                int cy = BTN_START_Y + BTN_SIZE / 2;
                int r = 3;
                switch (i) {
                    case 0 -> {
                        g2d.drawLine(cx - r, cy - r, cx + r, cy + r);
                        g2d.drawLine(cx - r, cy + r, cx + r, cy - r);
                    }
                    case 1 -> g2d.drawLine(cx - r, cy, cx + r, cy);
                    case 2 -> {
                        if (maximized) {
                            g2d.drawRect(cx - r, cy - 2, 5, 5);
                            g2d.drawRect(cx - 2, cy - r, 5, 5);
                        } else {
                            g2d.drawLine(cx - 2, cy + 1, cx, cy - 2);
                            g2d.drawLine(cx, cy - 2, cx + 2, cy + 1);
                        }
                    }
                }
            }
        }

        if (hoverButton < 0 && pressedButton < 0) {
            g2d.setColor(new Color(255, 255, 255, 180));
            g2d.setStroke(new BasicStroke(1.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            for (int i = 0; i < 3; i++) {
                int bx = BTN_START_X + i * (BTN_SIZE + BTN_SPACING);
                int cx = bx + BTN_SIZE / 2;
                int cy = BTN_START_Y + BTN_SIZE / 2;
                int r = 2;
                switch (i) {
                    case 0 -> {
                        g2d.drawLine(cx - r, cy - r, cx + r, cy + r);
                        g2d.drawLine(cx - r, cy + r, cx + r, cy - r);
                    }
                    case 1 -> g2d.drawLine(cx - r, cy, cx + r, cy);
                    case 2 -> {
                        g2d.drawLine(cx - 2, cy + 1, cx, cy - 2);
                        g2d.drawLine(cx, cy - 2, cx + 2, cy + 1);
                    }
                }
            }
        }
    }

    private int getButtonAt(int x, int y) {
        for (int i = 0; i < 3; i++) {
            int bx = BTN_START_X + i * (BTN_SIZE + BTN_SPACING);
            if (x >= bx - 3 && x <= bx + BTN_SIZE + 3 &&
                y >= BTN_START_Y - 3 && y <= BTN_START_Y + BTN_SIZE + 3) {
                return i;
            }
        }
        return -1;
    }

    private void handleButtonClick(int btn) {
        switch (btn) {
            case 0 -> dispose();
            case 1 -> setState(Frame.ICONIFIED);
            case 2 -> {
                if (maximized) {
                    if (restoreBounds != null) setBounds(restoreBounds);
                    maximized = false;
                } else {
                    restoreBounds = getBounds();
                    if (mainFrameRef != null) {
                        setBounds(mainFrameRef.getBounds());
                    } else {
                        setExtendedState(MAXIMIZED_BOTH);
                    }
                    maximized = true;
                }
                scheduleCapture();
            }
        }
    }

    private int getResizeEdgeAt(int x, int y) {
        int w = getWidth();
        int h = getHeight();
        int edge = EDGE_NONE;
        if (x < RESIZE_BORDER) edge |= EDGE_LEFT;
        if (x > w - RESIZE_BORDER) edge |= EDGE_RIGHT;
        if (y < RESIZE_BORDER) edge |= EDGE_TOP;
        if (y > h - RESIZE_BORDER) edge |= EDGE_BOTTOM;
        return edge;
    }

    private Cursor getResizeCursor(int edge) {
        boolean top = (edge & EDGE_TOP) != 0;
        boolean bottom = (edge & EDGE_BOTTOM) != 0;
        boolean left = (edge & EDGE_LEFT) != 0;
        boolean right = (edge & EDGE_RIGHT) != 0;

        if (top && left) return Cursor.getPredefinedCursor(Cursor.NW_RESIZE_CURSOR);
        if (top && right) return Cursor.getPredefinedCursor(Cursor.NE_RESIZE_CURSOR);
        if (bottom && left) return Cursor.getPredefinedCursor(Cursor.SW_RESIZE_CURSOR);
        if (bottom && right) return Cursor.getPredefinedCursor(Cursor.SE_RESIZE_CURSOR);
        if (top) return Cursor.getPredefinedCursor(Cursor.N_RESIZE_CURSOR);
        if (bottom) return Cursor.getPredefinedCursor(Cursor.S_RESIZE_CURSOR);
        if (left) return Cursor.getPredefinedCursor(Cursor.W_RESIZE_CURSOR);
        if (right) return Cursor.getPredefinedCursor(Cursor.E_RESIZE_CURSOR);
        return Cursor.getDefaultCursor();
    }
}
