package modules;

import app.Winllx;
import ui.*;
import utils.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Winllx3 {

    private static final int WIN_W = 270;
    private static final int WIN_H = 480;

    private static final Color COLOR_ACCENT = Color.ORANGE;
    private static final Color COLOR_RESULT = Color.CYAN;
    private static final Color COLOR_DEFAULT = Color.WHITE;

    private static final String[] BTN_LABELS = {
        "C", "%", "⬅", "÷",
        "7", "8", "9", "×",
        "4", "5", "6", "-",
        "1", "2", "3", "+",
        "0", ".", "00", "=",
    };

    private static final String OPS = "+-×÷";
    private JFrame frame;

    public Winllx3() {
        frame = WinllxIcon.createFrame("计算器");
        frame.setSize(WIN_W, WIN_H);
        frame.setMinimumSize(new Dimension(220, 400));
        frame.getContentPane().setBackground(Winllx.getMainBackgroundColor());
        frame.setLayout(new BorderLayout(0, 0));

        JTextArea display = new JTextArea();
        display.setLineWrap(true);
        display.setBackground(Winllx.getMainBackgroundColor());
        display.setFont(new Font("微软雅黑", Font.BOLD, 24));
        display.setMargin(new Insets(10, 10, 10, 10));
        display.setEditable(false);
        JScrollPane displayScroll = new JScrollPane(display);
        displayScroll.setBorder(null);
        displayScroll.setPreferredSize(new Dimension(WIN_W, 60));
        frame.add(displayScroll, BorderLayout.NORTH);

        JPanel btnPanel = new JPanel(new GridBagLayout());
        btnPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(3, 3, 3, 3);

        for (int i = 0; i < BTN_LABELS.length; i++) {
            String label = BTN_LABELS[i];
            int row = i / 4;
            int col = i % 4;
            gbc.gridx = col;
            gbc.gridy = row;

            GlassButton btn = GlassButton.createButton(label);
            btn.setFont(new Font("微软雅黑", Font.BOLD, 16));
            switch (label) {
                case "C" -> btn.setBackground(COLOR_ACCENT);
                case "=" -> btn.setBackground(COLOR_RESULT);
                default -> btn.setBackground(COLOR_DEFAULT);
            }
            btn.setPreferredSize(new Dimension(50, 50));
            btn.addActionListener(e -> handleButton(label, display));
            btnPanel.add(btn, gbc);
        }

        frame.add(btnPanel, BorderLayout.CENTER);

        GlassButton settingsBtn = GlassButton.createButton("设置");
        settingsBtn.setFont(new Font("微软雅黑", Font.BOLD, 14));
        settingsBtn.setBackground(new Color(200, 200, 200));
        settingsBtn.setPreferredSize(new Dimension(WIN_W, 35));
        settingsBtn.addActionListener(e -> openSettings());
        frame.add(settingsBtn, BorderLayout.SOUTH);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }

    private void openSettings() {
        JFrame dialog = WinllxIcon.createFrame("计算器设置");
        dialog.setSize(350, 220);
        dialog.setLocationRelativeTo(frame);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.getContentPane().setBackground(Winllx.getMainBackgroundColor().darker());

        JLabel title = new JLabel("计算器模式");
        title.setFont(new Font("微软雅黑", Font.BOLD, 16));
        title.setForeground(Color.WHITE);
        title.setBorder(BorderFactory.createEmptyBorder(10, 20, 0, 0));
        dialog.add(title, BorderLayout.NORTH);

        String[] modes = {"标准", "科学"};
        GlassSegmentedControl selector = new GlassSegmentedControl(modes);
        selector.setSelectedIndex(0);
        selector.addSelectionListener((index, opt) -> {
            if (index == 1) {
                dialog.dispose();
                frame.dispose();
                new Winllx3Sci();
            }
        });
        JPanel selectorWrap = new JPanel(new FlowLayout(FlowLayout.CENTER));
        selectorWrap.setOpaque(false);
        selectorWrap.add(selector);
        dialog.add(selectorWrap, BorderLayout.CENTER);

        dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialog.setVisible(true);
    }

    private void handleButton(String label, JTextArea display) {
        switch (label) {
            case "C" -> display.setText("");
            case "⬅" -> {
                String t = display.getText();
                if (!t.isEmpty()) {
                    display.setText(t.substring(0, t.length() - 1));
                }
            }
            case "=" -> calculate(display);
            case "%" -> openPercentCalculator();
            case "+", "-", "×", "÷" -> appendOperator(label, display);
            default -> display.setText(display.getText() + label);
        }
    }

    private void appendOperator(String op, JTextArea display) {
        String text = display.getText();
        if (containsOperator(text) && !text.endsWith(OPS)) {
            JOptionPane.showMessageDialog(frame, "你已输入了一个运算符！");
            return;
        }
        if (op.equals("-") && (text.isEmpty() || isLastCharOperator(text))) {
            display.setText(text + "-");
            return;
        }
        display.setText(text + op);
    }

    private boolean containsOperator(String text) {
        if (text.isEmpty()) return false;
        int start = text.startsWith("-") ? 1 : 0;
        for (int i = start; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '-' && i > 0 && OPS.indexOf(text.charAt(i - 1)) >= 0) continue;
            if (OPS.indexOf(c) >= 0) return true;
        }
        return false;
    }

    private boolean isLastCharOperator(String text) {
        if (text.isEmpty()) return false;
        char last = text.charAt(text.length() - 1);
        return OPS.indexOf(last) >= 0;
    }

    private void calculate(JTextArea display) {
        String text = display.getText();
        if (text.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "请输入一个运算符！");
            return;
        }
        int opPos = -1;
        int start = text.startsWith("-") ? 1 : 0;
        for (int i = start; i < text.length(); i++) {
            if (OPS.indexOf(text.charAt(i)) >= 0) {
                opPos = i;
                break;
            }
        }
        if (opPos == -1) {
            JOptionPane.showMessageDialog(frame, "请输入一个运算符！");
            return;
        }
        try {
            double a = Double.parseDouble(text.substring(0, opPos));
            double b = Double.parseDouble(text.substring(opPos + 1));
            char op = text.charAt(opPos);
            double result = switch (op) {
                case '+' -> a + b;
                case '-' -> a - b;
                case '×' -> a * b;
                case '÷' -> b == 0 ? throwDivZero() : a / b;
                default -> 0;
            };
            display.setText(text + "=" + result);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "缺少操作数！\n请重新输入");
            display.setText("");
        }
    }

    private double throwDivZero() {
        JOptionPane.showMessageDialog(frame, "除数不能为0,请重新输入！");
        throw new ArithmeticException();
    }

    private void openPercentCalculator() {
        JFrame pFrame = WinllxIcon.createFrame("百分比专用计算器");
        pFrame.setSize(700, 200);
        pFrame.setMinimumSize(new Dimension(500, 150));
        pFrame.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        pFrame.getContentPane().setBackground(Winllx.getMainBackgroundColor());

        String[][] configs = {
            {"计算百分比值", "输入数值：", "输入百分比：", "value"},
            {"计算百分比增加", "输入数值：", "输入增加百分比：", "increase"},
            {"计算百分比减少", "输入数值：", "输入减少百分比：", "decrease"},
            {"计算百分比占比", "输入部分值：", "输入总值：", "ratio"},
            {"计算百分比变化", "输入旧值：", "输入新值：", "change"}
        };

        for (String[] cfg : configs) {
            GlassButton btn = GlassButton.createButton(cfg[0]);
            btn.setPreferredSize(new Dimension(200, 30));
            btn.addActionListener(e -> openPercentDialog(cfg[0], cfg[1], cfg[2], cfg[3]));
            pFrame.add(btn);
        }

        pFrame.setVisible(true);
    }

    private void openPercentDialog(String title, String label1, String label2, String type) {
        JFrame dialog = WinllxIcon.createFrame(title);
        dialog.setSize(320, 200);
        dialog.setMinimumSize(new Dimension(280, 160));
        dialog.setLayout(new GridBagLayout());
        dialog.getContentPane().setBackground(Winllx.getMainBackgroundColor());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel l1 = new JLabel(label1);
        JTextField t1 = new JTextField(10);
        JLabel l2 = new JLabel(label2);
        JTextField t2 = new JTextField(10);
        GlassButton calc = GlassButton.createButton("计算");

        gbc.gridx = 0; gbc.gridy = 0; dialog.add(l1, gbc);
        gbc.gridx = 1; gbc.gridy = 0; dialog.add(t1, gbc);
        gbc.gridx = 0; gbc.gridy = 1; dialog.add(l2, gbc);
        gbc.gridx = 1; gbc.gridy = 1; dialog.add(t2, gbc);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2; dialog.add(calc, gbc);

        calc.addActionListener(e -> {
            try {
                double n1 = Double.parseDouble(t1.getText());
                double n2 = Double.parseDouble(t2.getText());
                String result = switch (type) {
                    case "value" -> "结果：" + (n1 * n2 / 100);
                    case "increase" -> "结果：" + (n1 + n1 * n2 / 100);
                    case "decrease" -> "结果：" + (n1 - n1 * n2 / 100);
                    case "ratio" -> "结果：" + (n1 / n2 * 100) + "%";
                    case "change" -> "百分比变化：" + ((n1 - n2) / n2 * 100) + "%";
                    default -> "";
                };
                JOptionPane.showMessageDialog(dialog, result);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
            }
        });

        dialog.setVisible(true);
    }
}
