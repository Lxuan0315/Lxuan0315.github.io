package modules;

import utils.*;
import ui.GlassButton;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Properties;
import javax.imageio.ImageIO;

public class Winllx2 {

    private static final String NOTES_DIR = System.getProperty("user.dir") + "/Winllx/notes";
    private static final String NOTES_FILE = NOTES_DIR + "/notes_data.properties";
    private static final String SETTINGS_FILE = NOTES_DIR + "/notes_settings.properties";
    private static final int MAX_TABS = 20;

    private JFrame frame;
    private JTabbedPane tabbedPane;
    private Color textAreaBgColor = Color.WHITE;
    private BufferedImage textAreaBgImage = null;
    private float textAreaBgOpacity = 1.0f;

    public Winllx2() {
        new File(NOTES_DIR).mkdirs();
        loadSettings();

        frame = WinllxIcon.createFrame(LangManager.getString("module.note"));
        frame.setSize(650, 500);
        frame.setMinimumSize(new Dimension(450, 350));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        tabbedPane = new JTabbedPane();
        tabbedPane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);

        loadNotes();

        if (tabbedPane.getTabCount() == 0) {
            addNewTab();
        }

        frame.add(tabbedPane, BorderLayout.CENTER);

        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 8));
        bottomBar.setOpaque(false);

        GlassButton addBtn = GlassButton.createButton(LangManager.getString("btn.add"));
        addBtn.setPreferredSize(new Dimension(50, 32));
        addBtn.setFont(new Font("微软雅黑", Font.BOLD, 14));
        addBtn.addActionListener(e -> addNewTab());
        bottomBar.add(addBtn);

        GlassButton closeBtn = GlassButton.createButton("×");
        closeBtn.setPreferredSize(new Dimension(50, 32));
        closeBtn.setFont(new Font("微软雅黑", Font.BOLD, 14));
        closeBtn.addActionListener(e -> closeCurrentTab());
        bottomBar.add(closeBtn);

        GlassButton clearBtn = GlassButton.createButton(LangManager.getString("btn.clear"));
        clearBtn.setPreferredSize(new Dimension(130, 32));
        clearBtn.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        clearBtn.addActionListener(e -> clearAllNotes());
        bottomBar.add(clearBtn);

        GlassButton saveBtn = GlassButton.createButton(LangManager.getString("note.save"));
        saveBtn.setPreferredSize(new Dimension(70, 32));
        saveBtn.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        saveBtn.addActionListener(e -> {
            saveNotes();
            saveSettings();
            JOptionPane.showMessageDialog(frame, LangManager.getString("note.save.success"));
        });
        bottomBar.add(saveBtn);

        GlassButton settingsBtn = GlassButton.createButton(LangManager.getString("note.settings"));
        settingsBtn.setPreferredSize(new Dimension(90, 32));
        settingsBtn.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        settingsBtn.addActionListener(e -> openSettings());
        bottomBar.add(settingsBtn);

        frame.add(bottomBar, BorderLayout.SOUTH);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                saveNotes();
                saveSettings();
            }
        });
        frame.setVisible(true);
    }

    private JTextArea createTextArea() {
        JTextArea ta = new JTextArea() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

                if (textAreaBgImage != null) {
                    int pw = getWidth();
                    int ph = getHeight();
                    int iw = textAreaBgImage.getWidth();
                    int ih = textAreaBgImage.getHeight();
                    double scale = Math.max((double) pw / iw, (double) ph / ih);
                    int sw = (int) (iw * scale);
                    int sh = (int) (ih * scale);
                    g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, textAreaBgOpacity));
                    g2d.drawImage(textAreaBgImage, (pw - sw) / 2, (ph - sh) / 2, sw, sh, null);
                    g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
                } else {
                    g2d.setColor(textAreaBgColor);
                    g2d.fillRect(0, 0, getWidth(), getHeight());
                }
                g2d.dispose();
                super.paintComponent(g);
            }
        };
        ta.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        ta.setOpaque(false);
        return ta;
    }

    private void addNewTab() {
        if (tabbedPane.getTabCount() >= MAX_TABS) {
            JOptionPane.showMessageDialog(frame,
                    String.format(LangManager.getString("msg.tab.limit"), MAX_TABS),
                    LangManager.getString("dialog.tip"), JOptionPane.WARNING_MESSAGE);
            return;
        }
        int count = tabbedPane.getTabCount() + 1;
        String title = LangManager.getString("module.note") + count;
        JTextArea textArea = createTextArea();
        JScrollPane scroll = new JScrollPane(textArea);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        tabbedPane.addTab(title, scroll);
        tabbedPane.setSelectedIndex(tabbedPane.getTabCount() - 1);
    }

    private void closeCurrentTab() {
        if (tabbedPane.getTabCount() <= 1) {
            JOptionPane.showMessageDialog(frame,
                    LangManager.getString("msg.tab.keepone"),
                    LangManager.getString("dialog.tip"), JOptionPane.WARNING_MESSAGE);
            return;
        }
        int idx = tabbedPane.getSelectedIndex();
        if (idx >= 0) {
            tabbedPane.removeTabAt(idx);
        }
    }

    private void clearAllNotes() {
        int confirm = JOptionPane.showConfirmDialog(frame,
                LangManager.getString("msg.clear.confirm"),
                LangManager.getString("msg.clear.title"),
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) {
            tabbedPane.removeAll();
            addNewTab();
            JOptionPane.showMessageDialog(frame,
                    LangManager.getString("msg.clear.success"),
                    LangManager.getString("dialog.tip"), JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private JTextArea getTextAreaAt(int index) {
        if (index < 0 || index >= tabbedPane.getTabCount()) return null;
        JScrollPane scroll = (JScrollPane) tabbedPane.getComponentAt(index);
        if (scroll != null && scroll.getViewport() != null) {
            return (JTextArea) scroll.getViewport().getView();
        }
        return null;
    }

    private void saveNotes() {
        Properties props = new Properties();
        props.setProperty("tab.count", String.valueOf(tabbedPane.getTabCount()));
        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
            String title = tabbedPane.getTitleAt(i);
            JTextArea ta = getTextAreaAt(i);
            String content = ta != null ? ta.getText() : "";
            props.setProperty("tab." + i + ".title", title);
            props.setProperty("tab." + i + ".content", content.replace("\n", "\\n"));
        }
        try (FileOutputStream fos = new FileOutputStream(NOTES_FILE)) {
            props.store(fos, "Winllx Notes Data");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame,
                    String.format(LangManager.getString("msg.save.error"), e.getMessage()),
                    LangManager.getString("dialog.error"), JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadNotes() {
        File file = new File(NOTES_FILE);
        if (!file.exists()) return;
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(file)) {
            props.load(fis);
            int count = Integer.parseInt(props.getProperty("tab.count", "0"));
            if (count < 0 || count > MAX_TABS) {
                JOptionPane.showMessageDialog(frame,
                        String.format(LangManager.getString("msg.notes.reset"), count),
                        LangManager.getString("dialog.warning"), JOptionPane.WARNING_MESSAGE);
                return;
            }
            for (int i = 0; i < count; i++) {
                String title = props.getProperty("tab." + i + ".title", LangManager.getString("module.note") + (i + 1));
                String content = props.getProperty("tab." + i + ".content", "").replace("\\n", "\n");
                JTextArea ta = createTextArea();
                ta.setText(content);
                JScrollPane scroll = new JScrollPane(ta);
                scroll.setOpaque(false);
                scroll.getViewport().setOpaque(false);
                tabbedPane.addTab(title, scroll);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame,
                    String.format(LangManager.getString("msg.load.error"), e.getMessage()),
                    LangManager.getString("dialog.error"), JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadSettings() {
        File file = new File(SETTINGS_FILE);
        if (!file.exists()) return;
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(file)) {
            props.load(fis);
            String colorHex = props.getProperty("bg.color", "FFFFFF");
            textAreaBgColor = hexToColor(colorHex);
            textAreaBgOpacity = Float.parseFloat(props.getProperty("bg.opacity", "1.0"));
            String imgPath = props.getProperty("bg.image.path", "");
            if (!imgPath.isEmpty()) {
                File imgFile = new File(imgPath);
                if (imgFile.exists()) {
                    textAreaBgImage = ImageIO.read(imgFile);
                }
            }
        } catch (Exception e) {
            textAreaBgColor = Color.WHITE;
        }
    }

    private void saveSettings() {
        Properties props = new Properties();
        File file = new File(SETTINGS_FILE);
        if (file.exists()) {
            try (FileInputStream fis = new FileInputStream(file)) {
                props.load(fis);
            } catch (IOException ignored) {}
        }
        props.setProperty("bg.color", colorToHex(textAreaBgColor));
        props.setProperty("bg.opacity", String.valueOf(textAreaBgOpacity));
        if (textAreaBgImage == null) {
            props.remove("bg.image.path");
        }
        try (FileOutputStream fos = new FileOutputStream(file)) {
            props.store(fos, "Winllx Notes Settings");
        } catch (IOException ignored) {
        }
    }

    private void saveImageProps(String path) {
        Properties props = new Properties();
        File file = new File(SETTINGS_FILE);
        if (file.exists()) {
            try (FileInputStream fis = new FileInputStream(file)) {
                props.load(fis);
            } catch (IOException ignored) {}
        }
        props.setProperty("bg.color", colorToHex(textAreaBgColor));
        props.setProperty("bg.opacity", String.valueOf(textAreaBgOpacity));
        props.setProperty("bg.image.path", path);
        try (FileOutputStream fos = new FileOutputStream(file)) {
            props.store(fos, "Winllx Notes Settings");
        } catch (IOException ignored) {}
    }

    private void removeImageProps() {
        Properties props = new Properties();
        File file = new File(SETTINGS_FILE);
        if (file.exists()) {
            try (FileInputStream fis = new FileInputStream(file)) {
                props.load(fis);
            } catch (IOException ignored) {}
        }
        props.remove("bg.image.path");
        try (FileOutputStream fos = new FileOutputStream(file)) {
            props.store(fos, "Winllx Notes Settings");
        } catch (IOException ignored) {}
    }

    private static String colorToHex(Color c) {
        return String.format("%02X%02X%02X", c.getRed(), c.getGreen(), c.getBlue());
    }

    private static Color hexToColor(String hex) {
        try {
            return new Color(
                    Integer.parseInt(hex.substring(0, 2), 16),
                    Integer.parseInt(hex.substring(2, 4), 16),
                    Integer.parseInt(hex.substring(4, 6), 16)
            );
        } catch (Exception e) {
            return Color.WHITE;
        }
    }

    private void openSettings() {
        JFrame dialog = WinllxIcon.createFrame(LangManager.getString("note.settings"));
        dialog.setSize(480, 520);
        dialog.setMinimumSize(new Dimension(400, 420));
        dialog.setLocationRelativeTo(frame);
        dialog.setLayout(new BorderLayout(15, 15));

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel(LangManager.getString("note.settings.title"));
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 16));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(titleLabel);
        content.add(Box.createVerticalStrut(20));

        // --- 背景颜色行 ---
        JPanel colorRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        colorRow.setOpaque(false);
        colorRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        colorRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));

        JLabel colorLabel = new JLabel(LangManager.getString("note.bg.color"));
        colorLabel.setFont(new Font("微软雅黑", Font.PLAIN, 13));
        colorRow.add(colorLabel);

        JButton colorBtn = new JButton(LangManager.getString("note.select.color"));
        colorBtn.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        colorBtn.setBackground(textAreaBgColor);
        colorBtn.setPreferredSize(new Dimension(110, 32));
        colorBtn.addActionListener(e -> {
            Color chosen = JColorChooser.showDialog(dialog, LangManager.getString("note.select.color"), textAreaBgColor);
            if (chosen != null) {
                textAreaBgColor = chosen;
                textAreaBgImage = null;
                colorBtn.setBackground(chosen);
                refreshAllTextAreas();
            }
        });
        colorRow.add(colorBtn);
        content.add(colorRow);
        content.add(Box.createVerticalStrut(15));

        // --- 背景图片行 ---
        JPanel imgRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        imgRow.setOpaque(false);
        imgRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        imgRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));

        JLabel imgLabel = new JLabel(LangManager.getString("note.bg.image"));
        imgLabel.setFont(new Font("微软雅黑", Font.PLAIN, 13));
        imgRow.add(imgLabel);

        GlassButton selectImgBtn = GlassButton.createButton(LangManager.getString("note.select.img"));
        selectImgBtn.setPreferredSize(new Dimension(100, 32));
        selectImgBtn.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        selectImgBtn.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle(LangManager.getString("dialog.image.select"));
            chooser.setFileFilter(new FileNameExtensionFilter(
                    "Image Files (jpg, png, gif, bmp)", "jpg", "png", "gif", "bmp"));
            if (chooser.showOpenDialog(dialog) == JFileChooser.APPROVE_OPTION) {
                try {
                    BufferedImage img = ImageIO.read(chooser.getSelectedFile());
                    if (img != null) {
                        textAreaBgImage = img;
                        saveImageProps(chooser.getSelectedFile().getAbsolutePath());
                        refreshAllTextAreas();
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog,
                            LangManager.getString("msg.image.load.error"),
                            LangManager.getString("dialog.error"), JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        imgRow.add(selectImgBtn);

        GlassButton removeImgBtn = GlassButton.createButton(LangManager.getString("note.remove.img"));
        removeImgBtn.setPreferredSize(new Dimension(100, 32));
        removeImgBtn.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        removeImgBtn.addActionListener(e -> {
            textAreaBgImage = null;
            removeImageProps();
            refreshAllTextAreas();
        });
        imgRow.add(removeImgBtn);
        content.add(imgRow);
        content.add(Box.createVerticalStrut(15));

        // --- 透明度行 ---
        JPanel opacityRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        opacityRow.setOpaque(false);
        opacityRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        opacityRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 55));

        JLabel opacityLabel = new JLabel(LangManager.getString("note.bg.opacity"));
        opacityLabel.setFont(new Font("微软雅黑", Font.PLAIN, 13));
        opacityRow.add(opacityLabel);

        JSlider opacitySlider = new JSlider(0, 100, (int)(textAreaBgOpacity * 100));
        opacitySlider.setPreferredSize(new Dimension(220, 45));
        opacitySlider.addChangeListener(e -> {
            textAreaBgOpacity = opacitySlider.getValue() / 100f;
            refreshAllTextAreas();
        });
        opacityRow.add(opacitySlider);
        content.add(opacityRow);
        content.add(Box.createVerticalStrut(20));

        // --- 预览 ---
        JLabel previewLabel = new JLabel(LangManager.getString("note.preview"));
        previewLabel.setFont(new Font("微软雅黑", Font.PLAIN, 13));
        previewLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(previewLabel);
        content.add(Box.createVerticalStrut(8));

        JPanel previewPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                if (textAreaBgImage != null) {
                    int pw = getWidth();
                    int ph = getHeight();
                    int iw = textAreaBgImage.getWidth();
                    int ih = textAreaBgImage.getHeight();
                    double scale = Math.max((double) pw / iw, (double) ph / ih);
                    int sw = (int) (iw * scale);
                    int sh = (int) (ih * scale);
                    g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, textAreaBgOpacity));
                    g2d.drawImage(textAreaBgImage, (pw - sw) / 2, (ph - sh) / 2, sw, sh, null);
                } else {
                    g2d.setColor(textAreaBgColor);
                    g2d.fillRect(0, 0, getWidth(), getHeight());
                }
                g2d.dispose();
            }
        };
        previewPanel.setPreferredSize(new Dimension(420, 100));
        previewPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(previewPanel);

        dialog.add(new JScrollPane(content), BorderLayout.CENTER);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 8));
        btnRow.setOpaque(false);

        GlassButton okBtn = GlassButton.createButton(LangManager.getString("btn.ok"));
        okBtn.setPreferredSize(new Dimension(90, 35));
        okBtn.addActionListener(e -> {
            saveSettings();
            saveNotes();
            dialog.dispose();
        });
        btnRow.add(okBtn);

        GlassButton cancelBtn = GlassButton.createButton(LangManager.getString("btn.cancel"));
        cancelBtn.setPreferredSize(new Dimension(90, 35));
        cancelBtn.addActionListener(e -> dialog.dispose());
        btnRow.add(cancelBtn);

        dialog.add(btnRow, BorderLayout.SOUTH);
        dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialog.setVisible(true);
    }

    private void refreshAllTextAreas() {
        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
            JTextArea ta = getTextAreaAt(i);
            if (ta != null) ta.repaint();
        }
    }
}
