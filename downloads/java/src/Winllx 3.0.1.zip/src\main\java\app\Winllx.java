package app;

import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Calendar;
import java.util.Properties;

import javax.imageio.ImageIO;
import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.filechooser.FileNameExtensionFilter;

import modules.AppStoreModule;
import modules.BoardModule;
import modules.BrowserModule;
import modules.CalculatorModule;
import modules.CalendarModule;
import modules.ClipboardModule;
import modules.ClockModule;
import modules.ExitAction;
import modules.FileManagerModule;
import modules.LiquidGlassModule;
import modules.MindReaderModule;
import modules.NotesModule;
import modules.SystemMonitorModule;
import modules.TodoModule;
import modules.WeatherModule;
import ui.BackgroundPanel;
import ui.DraggableButton;
import ui.GlassButton;
import ui.GlassFrame;
import ui.GridLayoutManager;
import ui.LiquidButton;
import ui.SettingsFrame;
import utils.LangManager;
import utils.Loading;
import utils.WinllxIcon;

public class Winllx {
    private static String APP_TITLE = "Winllx";
    private static final Color DEFAULT_BG = Color.WHITE;
    private static final String TRAY_ICON_PATH = "C:/Users/86132/Desktop/java.png";
    private static final String SETTINGS_FILE = System.getProperty("user.dir") + "/Winllx/app_settings.properties";
    private static boolean trayEnabled = true;
    private static TrayIcon trayIcon;
    private static JFrame mainFrame;
    private static BufferedImage backgroundImage = null;
    private static String bgImagePath = null;

    /** 音量缓存快照（snapshot 时立即返回，后台用 SystemVolumeControl.getVolume() 刷新）。 */
    private static volatile int cachedVolume = 50;
    
    private static final int GRID_CELL_WIDTH = 120;
    private static final int GRID_CELL_HEIGHT = 100;
    private static final int GRID_PADDING_X = 50;
    private static final int GRID_PADDING_Y = 120;
    private static GridLayoutManager gridManager;
    private static JPanel gridOverlay;
    private static Timer resizeTimer;
    /** 非最大化（窗口化）时为 true：按钮按流式布局排列，忽略拖拽保存的网格坐标；
     *  最大化时为 false：恢复为固定网格布局，按钮回到各自保存的 gridX/gridY。 */
    private static boolean windowedMode = false;
    
    private static DraggableButton noteBtn;
    private static DraggableButton calcBtn;
    private static DraggableButton fileBtn;
    private static DraggableButton mindBtn;
    private static DraggableButton sysMonBtn;
    private static DraggableButton boardBtn;
    private static DraggableButton clockBtn;
    private static DraggableButton weatherBtn;
    private static DraggableButton minimizeBtn;
    private static DraggableButton settingsBtn;
    private static DraggableButton exitBtn;
    private static DraggableButton glassBtn;
    private static DraggableButton storeBtn;
    private static DraggableButton browserBtn;
    private static DraggableButton todoBtn;
    private static DraggableButton clipBtn;
    private static DraggableButton calendarBtn;
    
    private static JLabel timeLabel;
    private static JLabel dateLabel;

    public static void main(String[] stringArray) {
        LangManager.init();
        Loading loading = new Loading();
        loading.show();

        // 后台预热 JCEF（Chromium 内核初始化耗时较长，尽早开始，用户点击子应用时才秒开）
        new Thread(() -> {
            try {
                System.out.println("[Winllx] 后台预热 JCEF 内核...");
                Class<?> gbp = Class.forName("ui.GlassBrowserPanel");
                java.lang.reflect.Method m = gbp.getMethod("ensureJcef");
                Object result = m.invoke(null);
                System.out.println("[Winllx] JCEF 预热完成: " + result);
            } catch (Throwable t) {
                System.err.println("[Winllx] JCEF 预热失败（不影响主程序）: " + t.getMessage());
            }
        }, "jcef-prewarm").start();

        // 后台刷新系统音量缓存（阻塞 PowerShell 调用不能放 EDT）
        new Thread(() -> { try { ui.SystemVolumeControl.init(); refreshSystemVolumeCache(); } catch (Throwable ignore) {} }, "volume-init").start();

        WinllxIcon.init();
        Winllx.initMainWindow();

        SwingUtilities.invokeLater(() -> {
            Winllx.buildDesktopUI();
            Winllx.applySavedTextColor(Winllx.loadTextColor());
            Winllx.initSystemTray();
            loading.close();
        });
    }

    public static void setMainVisible(boolean bl) {
        if (mainFrame != null) {
            mainFrame.setVisible(bl);
        }
    }

    public static Color getMainBackgroundColor() {
        if (mainFrame != null) {
            return mainFrame.getContentPane().getBackground();
        }
        return DEFAULT_BG;
    }

    private static BackgroundPanel getBackgroundPanel() {
        if (mainFrame != null && mainFrame.getContentPane() instanceof BackgroundPanel) {
            return (BackgroundPanel) mainFrame.getContentPane();
        }
        return null;
    }

    private static void initMainWindow() {
        APP_TITLE = LangManager.getString("app.title");
        mainFrame = new JFrame(APP_TITLE);
        Color color = Winllx.loadBackgroundColor();
        BackgroundPanel bgPanel = new BackgroundPanel();
        bgPanel.setBackground(color);
        mainFrame.setContentPane(bgPanel);
        mainFrame.setExtendedState(6);
        mainFrame.setLayout(null);
        mainFrame.setDefaultCloseOperation(3);
        WinllxIcon.applyToFrame(mainFrame);
        Winllx.loadBackgroundImageSettings();
        GlassFrame.setMainFrame(mainFrame);
        GlassFrame.setGlassEnabled(Winllx.loadGlassWindows());
        gridOverlay = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (gridManager != null) {
                    Graphics2D g2d = (Graphics2D) g.create();
                    gridManager.drawGrid(g2d);
                    g2d.dispose();
                }
            }
        };
        gridOverlay.setOpaque(false);
        gridOverlay.setBounds(0, 0, 9999, 9999);
        mainFrame.add(gridOverlay);
        mainFrame.setVisible(true);
        mainFrame.addComponentListener(new ComponentAdapter(){

            @Override
            public void componentResized(ComponentEvent componentEvent) {
                if (resizeTimer != null && resizeTimer.isRunning()) {
                    resizeTimer.stop();
                }
                resizeTimer = new Timer(50, e -> {
                    Winllx.updateLayout();
                    ((Timer) e.getSource()).stop();
                });
                resizeTimer.setRepeats(false);
                resizeTimer.start();
            }

            @Override
            public void componentShown(ComponentEvent componentEvent) {
                Winllx.updateLayout();
            }
        });
        // 监听主窗口最大化状态切换：最大化保持网格布局，窗口化切换为流式布局
        mainFrame.addWindowStateListener(e -> {
            boolean maximized = (e.getNewState() & Frame.MAXIMIZED_BOTH) != 0;
            boolean wasWindowed = windowedMode;
            windowedMode = !maximized;
            if (wasWindowed != windowedMode) {
                // 状态切换时强制重排（流式模式忽略之前保存的网格坐标）
                Winllx.updateLayout();
            }
        });
    }

    private static void applySavedTextColor(Color color) {
        for (Component component : mainFrame.getContentPane().getComponents()) {
            if (component instanceof JLabel) {
                ((JLabel)component).setForeground(color);
                continue;
            }
            if (component instanceof LiquidButton) {
                component.setForeground(color);
                continue;
            }
            if (component instanceof GlassButton) {
                ((GlassButton)component).setTextColor(color);
                continue;
            }
            if (!(component instanceof AbstractButton)) continue;
            ((AbstractButton)component).setForeground(color);
        }
        mainFrame.repaint();
    }

    private static void buildDesktopUI() {
        Winllx.initGridManager();
        Winllx.addDesktopLabels();
        Winllx.addDesktopButtons();
        Winllx.applyFontsToMain();
        Winllx.updateLayout();
    }

    private static void initGridManager() {
        gridManager = new GridLayoutManager(
                mainFrame.getContentPane().getWidth(),
                mainFrame.getContentPane().getHeight(),
                GRID_CELL_WIDTH, GRID_CELL_HEIGHT,
                GRID_PADDING_X, GRID_PADDING_Y
        );
        gridManager.setGridAlpha(Winllx.loadGridAlpha());
    }

    private static void addDesktopLabels() {
        timeLabel = new JLabel();
        timeLabel.setFont(new Font("Microsoft YaHei", 1, 36));
        dateLabel = new JLabel();
        dateLabel.setFont(new Font("Microsoft YaHei", 0, 14));
        Winllx.addToMain(timeLabel, dateLabel);
        Winllx.updateDateTime();
        Timer timer = new Timer(1000, actionEvent -> Winllx.updateDateTime());
        timer.start();
        Winllx.updateLayout();
    }

    private static void updateDateTime() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm");
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("MM\u6708dd\u65e5 EEEE");
        timeLabel.setText(simpleDateFormat.format(calendar.getTime()));
        dateLabel.setText(simpleDateFormat2.format(calendar.getTime()));
    }

    private static void updateLayout() {
        int n;
        FontMetrics fontMetrics;
        int n3 = mainFrame.getContentPane().getWidth();
        int n4 = mainFrame.getContentPane().getHeight();

        // 同步 DraggableButton 的网格吸附开关：流式模式禁用吸附
        DraggableButton.gridSnapEnabled = !windowedMode;

        if (gridManager != null) {
            gridManager.setContainerSize(n3, n4);
        }
        if (gridOverlay != null) {
            gridOverlay.setBounds(0, 0, n3, n4);
            // 流式模式下隐藏网格叠层（网格只有在固定布局时才有意义）
            gridOverlay.setVisible(!windowedMode);
        }

        // 时间/日期标签始终顶栏居中（两种布局共用）
        if (timeLabel != null) {
            fontMetrics = timeLabel.getFontMetrics(timeLabel.getFont());
            n = fontMetrics.stringWidth(timeLabel.getText());
            timeLabel.setBounds((n3 - n) / 2, 10, n + 20, 50);
        }
        if (dateLabel != null) {
            fontMetrics = dateLabel.getFontMetrics(dateLabel.getFont());
            n = fontMetrics.stringWidth(dateLabel.getText());
            dateLabel.setBounds((n3 - n) / 2, 50, n + 20, 30);
        }

        DraggableButton[] allButtons = {noteBtn, calcBtn, fileBtn, mindBtn, sysMonBtn,
                                         boardBtn, clockBtn, weatherBtn, storeBtn, browserBtn, settingsBtn, exitBtn, minimizeBtn, glassBtn,
                                         todoBtn, clipBtn, calendarBtn};

        if (windowedMode) {
            // ========== 流式布局（非最大化）==========
            // 按钮按索引顺序从左到右、从上到下排列；窗口宽度变化时自动换行。
            // 拖拽仅在最大化网格模式下有意义，流式模式不尊重拖拽位置（也不阻止拖拽，
            // 只是 updateLayout 会立刻按流式规则覆盖回去）。
            int hPadding = 30;                                 // 两侧内边距
            int topOffset = 100;                               // 顶部避开时间/日期标签
            int cellW = 120;
            int cellH = 100;
            int gapX = 16;                                     // 水平间距
            int gapY = 20;                                     // 垂直间距
            int usableW = n3 - hPadding * 2;
            int perRow = Math.max(1, (usableW + gapX) / (cellW + gapX));

            for (int i = 0; i < allButtons.length; i++) {
                if (allButtons[i] == null) continue;
                int row = i / perRow;
                int col = i % perRow;
                int x = hPadding + col * (cellW + gapX);
                int y = topOffset + row * (cellH + gapY);

                // 注意：不要覆盖 gridX/Y——那是用户在最大化网格布局下拖拽保存的位置，
                // 切回最大化时要按那个位置恢复。流式布局只是临时重排视觉位置。
                allButtons[i].setBounds(x, y, cellW, cellH);
            }
        } else {
            // ========== 固定网格布局（最大化） ==========
            int buttonsPerRow = Math.max(1, (n3 - GRID_PADDING_X * 2) / GRID_CELL_WIDTH);

            for (int i = 0; i < allButtons.length; i++) {
                if (allButtons[i] == null) continue;

                if (!allButtons[i].isDragging()) {
                    int gx = allButtons[i].getGridX();
                    int gy = allButtons[i].getGridY();

                    if (gx < 0 || gy < 0) {
                        gx = i % buttonsPerRow;
                        gy = i / buttonsPerRow;
                        allButtons[i].setGridPosition(gx, gy);
                    }

                    Rectangle oldBounds = allButtons[i].getBounds();
                    Point pos = gridManager.getGridPosition(gx, gy);
                    allButtons[i].setBounds(pos.x, pos.y, GRID_CELL_WIDTH, GRID_CELL_HEIGHT);
                    allButtons[i].setGridManager(gridManager);
                    mainFrame.repaint(oldBounds.x, oldBounds.y, oldBounds.width, oldBounds.height);
                    Rectangle newBounds = allButtons[i].getBounds();
                    mainFrame.repaint(newBounds.x, newBounds.y, newBounds.width, newBounds.height);
                }
            }
        }

        mainFrame.repaint();
    }

    private static void addDesktopButtons() {
        noteBtn = Winllx.createDraggableButton(LangManager.getString("module.note"), 80, 80, actionEvent -> new NotesModule());
        calcBtn = Winllx.createDraggableButton(LangManager.getString("module.calc"), 80, 80, actionEvent -> new CalculatorModule());
        fileBtn = Winllx.createDraggableButton(LangManager.getString("module.file"), 80, 80, actionEvent -> new FileManagerModule());
        mindBtn = Winllx.createDraggableButton(LangManager.getString("module.mind"), 80, 80, actionEvent -> new MindReaderModule());
        sysMonBtn = Winllx.createDraggableButton(LangManager.getString("module.sysmon"), 80, 80, actionEvent -> new SystemMonitorModule());
        boardBtn = Winllx.createDraggableButton(LangManager.getString("module.board"), 80, 80, actionEvent -> new BoardModule());
        clockBtn = Winllx.createDraggableButton(LangManager.getString("module.clock"), 80, 80, actionEvent -> new ClockModule());
        weatherBtn = Winllx.createDraggableButton(LangManager.getString("module.weather"), 80, 80, actionEvent -> new WeatherModule());
        storeBtn = Winllx.createDraggableButton(LangManager.getString("module.store"), 80, 80, actionEvent -> new AppStoreModule());
        browserBtn = Winllx.createDraggableButton(LangManager.getString("module.browser"), 80, 80, actionEvent -> new BrowserModule());
        settingsBtn = Winllx.createDraggableButton(LangManager.getString("btn.settings"), 80, 80, actionEvent -> Winllx.openSettings());
        exitBtn = Winllx.createDraggableButton(LangManager.getString("btn.exit"), 80, 80, actionEvent -> new ExitAction());
        minimizeBtn = Winllx.createDraggableButton(LangManager.getString("btn.minimize"), 80, 80, actionEvent -> Winllx.setMainVisible(false));
        glassBtn = Winllx.createDraggableButton("液态玻璃", 80, 80, actionEvent -> new LiquidGlassModule());
        todoBtn = Winllx.createDraggableButton(LangManager.getString("module.todo"), 80, 80, actionEvent -> new TodoModule());
        clipBtn = Winllx.createDraggableButton(LangManager.getString("module.clipboard"), 80, 80, actionEvent -> new ClipboardModule());
        calendarBtn = Winllx.createDraggableButton(LangManager.getString("module.calendar"), 80, 80, actionEvent -> new CalendarModule());

        Winllx.addToMain(noteBtn, calcBtn, fileBtn, mindBtn, sysMonBtn, boardBtn, 
                         clockBtn, weatherBtn, storeBtn, browserBtn, settingsBtn, exitBtn, minimizeBtn, glassBtn,
                         todoBtn, clipBtn, calendarBtn);

        DraggableButton[] all = {noteBtn, calcBtn, fileBtn, mindBtn, sysMonBtn, 
                                  boardBtn, clockBtn, weatherBtn, storeBtn, browserBtn, settingsBtn, exitBtn, minimizeBtn, glassBtn,
                                  todoBtn, clipBtn, calendarBtn};
        for (DraggableButton btn : all) {
            btn.setOnCollisionCheck((gx, gy) -> {
                for (DraggableButton other : all) {
                    if (other != btn && other != null 
                        && other.getGridX() >= 0 && other.getGridY() >= 0
                        && other.getGridX() == gx && other.getGridY() == gy) {
                        return true;
                    }
                }
                return false;
            });
        }
    }

    private static DraggableButton createDraggableButton(String string, int width, int height, ActionListener actionListener) {
        DraggableButton button = new DraggableButton(string, width, height);
        button.setBounds(0, 0, width, height);
        if (actionListener != null) {
            button.addActionListener(actionListener);
        }
        return button;
    }

    private static void addToMain(JComponent ... jComponentArray) {
        for (JComponent jComponent : jComponentArray) {
            mainFrame.add(jComponent);
        }
    }

    private static volatile SettingsFrame settingsFrameRef = null;

    private static void openSettings() {
        // 若已有窗口实例且尚未销毁，直接前置显示；否则新建
        if (settingsFrameRef != null) {
            try {
                java.lang.reflect.Field f = SettingsFrame.class.getDeclaredField("frame");
                f.setAccessible(true);
                JFrame f2 = (JFrame) f.get(settingsFrameRef);
                if (f2 != null && f2.isDisplayable()) {
                    f2.setVisible(true);
                    f2.toFront();
                    return;
                }
            } catch (Throwable ignore) {}
        }

        final SettingsFrame.HostActions actions = new SettingsFrame.HostActions() {
            @Override public void applyLang(String lang) {
                if (lang == null || lang.isEmpty()) return;
                LangManager.setLanguage(lang);
                // 提示由 settings.html 里的 showToast 承担，不再弹 Swing JOptionPane
            }

            @Override public void applyThemeMode(int mode) {
                if (mode == 0 || mode == 1 || mode == 2) {
                    Winllx.applyTheme(mode);
                } else if (mode == 3) {
                    BackgroundPanel bp = getBackgroundPanel();
                    if (bp == null || !bp.hasBackgroundImage()) {
                        BufferedImage img = Winllx.selectBackgroundImage(mainFrame);
                        if (img != null) {
                            backgroundImage = img;
                            bp.setBackgroundImage(img);
                            Winllx.saveBgImagePath(bgImagePath);
                            Winllx.saveBgMode(3);
                            Winllx.syncTextColorForImage(img);
                            mainFrame.repaint();
                        }
                    } else {
                        Winllx.saveBgMode(3);
                    }
                }
            }

            @Override public void applyBgColor(String colorHex) {
                if (colorHex == null || colorHex.isEmpty()) return;
                Color c;
                try { c = Winllx.hexToColor(colorHex); }
                catch (Exception e) { c = Color.WHITE; }
                mainFrame.getContentPane().setBackground(c);
                BackgroundPanel bp = getBackgroundPanel();
                if (bp != null && loadBgMode() != 3) bp.setBackgroundImage(null);
                Winllx.saveBackgroundColor(c);
                Winllx.saveBgMode(2);
                Winllx.syncTextColor();
                mainFrame.repaint();
            }

            @Override public void applyBgImage(File imgFile, String dataUrlPreview) {
                if (imgFile == null) return;
                try {
                    BufferedImage img = ImageIO.read(imgFile);
                    if (img != null) {
                        backgroundImage = img;
                        bgImagePath = imgFile.getAbsolutePath();
                        BackgroundPanel bp = getBackgroundPanel();
                        if (bp != null) bp.setBackgroundImage(img);
                        Winllx.saveBgImagePath(bgImagePath);
                        Winllx.saveBgMode(3);
                        Winllx.syncTextColorForImage(img);
                        mainFrame.repaint();
                    }
                } catch (Exception ex) {
                    System.err.println("[Winllx] 背景图加载失败: " + ex.getMessage());
                    // 错误提示由 settings.html 里的 showToast 承担
                }
            }

            @Override public void clearBgImage() {
                backgroundImage = null;
                bgImagePath = null;
                BackgroundPanel bp = getBackgroundPanel();
                if (bp != null) bp.setBackgroundImage(null);
                Winllx.saveBgImagePath("");
                Color cur = mainFrame.getContentPane().getBackground();
                int mode;
                if (cur.equals(Color.BLACK)) mode = 1;
                else if (cur.equals(Color.WHITE)) mode = 0;
                else mode = 2;
                Winllx.saveBgMode(mode);
                Winllx.syncTextColor();
                mainFrame.repaint();
            }

            @Override public void applyBgFit(int mode) {
                BackgroundPanel bp = getBackgroundPanel();
                if (bp != null) bp.setFitMode(mode);
                Winllx.saveBgImageFitMode(mode);
                mainFrame.repaint();
            }

            @Override public void applyBgOpacity(float opacity) {
                float op = Math.max(0.1f, Math.min(1.0f, opacity));
                BackgroundPanel bp = getBackgroundPanel();
                if (bp != null) bp.setImageOpacity(op);
                Winllx.saveBgImageOpacity(op);
                mainFrame.repaint();
            }

            @Override public void applyIconTheme(int theme) {
                WinllxIcon.setTheme(theme);
                WinllxIcon.applyToFrame(mainFrame);
                Winllx.refreshTrayIcon();  // 托盘图标同步跟随窗口图标主题
            }

            @Override public void showIconThemeTest(int theme) {
                JFrame tf = WinllxIcon.createFrame(
                        "\u56fe\u6807\u6d4b\u8bd5\u7a97\u53e3 - " + (theme == 0
                                ? LangManager.getString("setting.icon.light")
                                : LangManager.getString("setting.icon.dark")));
                tf.setSize(300, 200);
                tf.setLocationRelativeTo(mainFrame);
                tf.setLayout(new BorderLayout());
                JLabel label = new JLabel(
                        LangManager.getString("setting.icon.theme") + "\uff1a" +
                                (theme == 0 ? LangManager.getString("setting.icon.light")
                                        : LangManager.getString("setting.icon.dark")), JLabel.CENTER);
                label.setFont(new Font("微软雅黑", Font.BOLD, 16));
                tf.add(label, BorderLayout.CENTER);
                tf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                tf.setVisible(true);
            }

            @Override public void applyVolume(int volume) { Winllx.setSystemVolume(volume); }

            @Override public void querySystemVolume(java.util.function.IntConsumer onReady) {
                if (onReady == null) return;
                new Thread(() -> {
                    ui.SystemVolumeControl.init();
                    int v = ui.SystemVolumeControl.getVolume();
                    cachedVolume = v;
                    onReady.accept(v);
                }, "query-volume").start();
            }

            @Override public void applyGridShow(boolean show) {
                int alpha = show ? 100 : 0;
                if (gridManager != null) {
                    gridManager.setGridAlpha(alpha);
                    mainFrame.repaint();
                }
                Winllx.saveGridAlpha(alpha);
            }

            @Override public void applyGlassWin(boolean enable) {
                Winllx.saveGlassWindows(enable);
                GlassFrame.setGlassEnabled(enable);
            }

            @Override public void applyTray(boolean enable) {
                Winllx.saveTray(enable);
                Winllx.updateTray(enable);
            }

            @Override public void applyAutoStart(boolean enable) {
                Winllx.applyAutoStart(enable);
            }

            @Override public boolean isAutoStartOn() {
                return Winllx.isAutoStartEnabled();
            }

            @Override public void applyLiquidGlass(String payloadStr) {
                Winllx.applyLiquidGlass(payloadStr);
            }

            @Override public void clearCache() {
                final File cache = new File(System.getProperty("user.dir"), "Winllx/jcef_cache");
                new Thread(() -> {
                    int[] cnt = new int[]{0, 0};
                    Winllx.deleteRecursively(cache, cnt);
                    SwingUtilities.invokeLater(() -> {
                        String msg = LangManager.getString("msg.cache.cleared")
                                + " (" + cnt[0] + " / " + cnt[1] + ")";
                        JOptionPane.showMessageDialog(mainFrame, msg,
                                LangManager.getString("lbl.clearCache"),
                                JOptionPane.INFORMATION_MESSAGE);
                    });
                }, "jcef-cache-clear").start();
            }

            @Override public void clearAllData() {
                new Thread(() -> {
                    File root = new File(System.getProperty("user.dir"), "Winllx");
                    int[] cnt = new int[]{0, 0};
                    // 商店下载安装的应用及其索引缓存
                    Winllx.deleteRecursively(new File(root, "apps"), cnt);
                    // 便笺 / 待办 / 日历 / 浏览器记录等网页数据与 JCEF 缓存
                    Winllx.deleteRecursively(new File(root, "jcef_cache"), cnt);
                    // 便笺附件目录
                    Winllx.deleteRecursively(new File(root, "notes"), cnt);
                    // 全部设置文件
                    for (String name : new String[]{"app_settings.properties", "browser.properties",
                            "github_accel.properties", "icon_settings.properties", "weather_cities.txt"}) {
                        File f = new File(root, name);
                        if (f.exists()) f.delete();
                    }
                    // 不动 Winllx/minecraft：游戏本体、模组与存档不属于 Winllx 的应用数据
                }, "winllx-clear-all").start();
            }

            @Override public void resetAllSettings() {
                try {
                    File dir = new File(SETTINGS_FILE).getParentFile();
                    if (dir != null && !dir.exists()) dir.mkdirs();
                    Properties p = new Properties();
                    p.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings (reset)");
                } catch (Exception ignore) {}
                Winllx.applyTheme(0);
                Winllx.saveGridAlpha(0);
        if (gridManager != null) { gridManager.setGridAlpha(0); mainFrame.repaint(); }
        Winllx.saveGlassWindows(true);
        GlassFrame.setGlassEnabled(true);
        Winllx.saveTray(true);
        Winllx.updateTray(true);
                WinllxIcon.setTheme(0);
                WinllxIcon.applyToFrame(mainFrame);
                BackgroundPanel bp = getBackgroundPanel();
                if (bp != null) {
                    bp.setImageOpacity(1.0f);
                    bp.setFitMode(0);
                    bp.setBackgroundImage(null);
                }
                backgroundImage = null; bgImagePath = null;
                Winllx.saveBgImageOpacity(1.0f);
                Winllx.saveBgImageFitMode(0);
                Winllx.saveBgImagePath("");
                Winllx.saveBgMode(0);
                mainFrame.repaint();
            }

            @Override public File pickBgImageByFileChooser(Component parent) {
                return _pickBgImageReturnFile(parent);
            }

            @Override public String getSettingsSnapshotJson() {
                return Winllx.buildSettingsSnapshotJson();
            }

            @Override public void onCloseSettings(Point location) {
                Winllx.saveSettingsPosition(location);
                // 销毁式：窗口已 dispose（见 SettingsFrame.doClose），下次打开会新建
            }

            @Override public JFrame getMainFrame() { return mainFrame; }
        };

        SwingUtilities.invokeLater(() -> {
            settingsFrameRef = new SettingsFrame(actions);
        });
    }

    /** selectBackgroundImage 语义相同，但返回 File 对象而不是 BufferedImage（供 bridge 持久化路径） */
    private static File _pickBgImageReturnFile(Component parent) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(LangManager.getString("dialog.image.select"));
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "Image Files (jpg, png, gif, bmp, jpeg, wbmp)",
                "jpg", "png", "gif", "bmp", "jpeg", "wbmp");
        fileChooser.setFileFilter(filter);
        int result = fileChooser.showOpenDialog(parent);
        if (result == JFileChooser.APPROVE_OPTION) {
            File f = fileChooser.getSelectedFile();
            try {
                BufferedImage img = ImageIO.read(f);
                if (img != null) { return f; }
                JOptionPane.showMessageDialog(parent,
                        LangManager.getString("msg.image.load.error"),
                        LangManager.getString("dialog.error"), JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(parent,
                        LangManager.getString("msg.image.load.error"),
                        LangManager.getString("dialog.error"), JOptionPane.ERROR_MESSAGE);
            }
        }
        return null;
    }

    /** 生成当前设置的 JSON 快照（settings.html 里 __applySnapshot 消费） */
    private static String buildSettingsSnapshotJson() {
        StringBuilder sb = new StringBuilder();
        sb.append('{');
        sb.append("\"lang\":").append(_q(LangManager.getCurrentLang())).append(',');
        BackgroundPanel bp = getBackgroundPanel();
        int theme;
        if (bp != null && bp.hasBackgroundImage()) theme = 3;
        else {
            Color c = mainFrame.getContentPane().getBackground();
            if (Color.BLACK.equals(c)) theme = 1;
            else if (Color.WHITE.equals(c)) theme = 0;
            else theme = 2;
        }
        sb.append("\"theme\":").append(theme).append(',');
        Color bg = mainFrame.getContentPane().getBackground();
        sb.append("\"bgColor\":").append(_q(colorToHex(bg))).append(',');
        String preview = _bgImageDataUrl();
        sb.append("\"bgImage\":").append(preview == null ? "null" : _q(preview)).append(',');
        sb.append("\"bgImagePath\":").append(bgImagePath == null ? "null" : _q(bgImagePath)).append(',');
        sb.append("\"bgFit\":").append(bp == null ? 0 : bp.getFitMode()).append(',');
        sb.append("\"bgOpacity\":").append(bp == null ? 1.0f : bp.getImageOpacity()).append(',');
        sb.append("\"iconTheme\":").append(WinllxIcon.getCurrentTheme()).append(',');
        sb.append("\"iconLightData\":").append(_q(_iconThumb(0))).append(',');
        sb.append("\"iconDarkData\":").append(_q(_iconThumb(1))).append(',');
        sb.append("\"iconFailed\":").append(WinllxIcon.isAnyIconFailed()).append(',');
        sb.append("\"volume\":").append(getSystemVolume()).append(',');
        int ga = gridManager == null ? 0 : gridManager.getGridAlpha();
        sb.append("\"gridShow\":").append(ga > 0).append(',');
        sb.append("\"glassWin\":").append(loadGlassWindows()).append(',');
        sb.append("\"tray\":").append(loadTray()).append(',');
        sb.append("\"autoStart\":").append(isAutoStartEnabled()).append(',');
        sb.append("\"blurAmount\":").append(lgBlur()).append(',');
        sb.append("\"saturation\":").append(lgSat()).append(',');
        sb.append("\"displacementScale\":").append(lgDisp()).append(',');
        sb.append("\"aberrationIntensity\":").append(lgAber()).append(',');
        sb.append("\"elasticity\":").append(lgElast()).append(',');
        sb.append("\"activationZone\":").append(lgAct()).append(',');
        sb.append("\"activeScale\":").append(lgScale()).append(',');
        sb.append("\"mode\":").append(_q(lgMode())).append(',');
        sb.append("\"overLight\":").append(lgOverLight()).append(',');
        sb.append("\"cornerRadius\":").append(lgRadius()).append(',');
        sb.append("\"version\":").append(_q("Winllx 2.3.1"));
        sb.append('}');
        return sb.toString();
    }

    private static String _q(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder(s.length() + 16);
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '"':  sb.append("\\\""); break;
                case '\r': sb.append("\\r"); break;
                case '\n': sb.append("\\n"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04X", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('"');
        return sb.toString();
    }

    private static String _bgImageDataUrl() {
        if (backgroundImage == null) return null;
        try {
            int maxW = 600;
            int w = backgroundImage.getWidth(), h = backgroundImage.getHeight();
            BufferedImage src = backgroundImage;
            if (w > maxW) {
                int nh = (int) Math.round(h * (maxW * 1.0 / w));
                Image sc = src.getScaledInstance(maxW, nh, Image.SCALE_SMOOTH);
                BufferedImage b2 = new BufferedImage(maxW, nh, BufferedImage.TYPE_INT_RGB);
                Graphics2D g = b2.createGraphics();
                g.drawImage(sc, 0, 0, null);
                g.dispose();
                src = b2;
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ImageIO.write(src, "jpg", bos);
            return "data:image/jpeg;base64," + Base64.getEncoder().encodeToString(bos.toByteArray());
        } catch (Throwable t) { return null; }
    }

    private static String _iconThumb(int theme) {
        try {
            Image img = WinllxIcon.getIconImage(theme);
            if (img == null) return "";
            BufferedImage bi;
            if (img instanceof BufferedImage) bi = (BufferedImage) img;
            else {
                bi = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g = bi.createGraphics();
                g.drawImage(img.getScaledInstance(64, 64, Image.SCALE_SMOOTH), 0, 0, null);
                g.dispose();
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ImageIO.write(bi, "png", bos);
            return "data:image/png;base64," + Base64.getEncoder().encodeToString(bos.toByteArray());
        } catch (Throwable t) { return ""; }
    }

    /* 设置窗口由 SettingsFrame（JCEF + settings/settings.html）承担。 */

    private static Color getContrastColor(Color color) {
        if (color == null) {
            return Color.BLACK;
        }
        double d = 0.2126 * (double)color.getRed() + 0.7152 * (double)color.getGreen() + 0.0722 * (double)color.getBlue();
        return d < 128.0 ? Color.WHITE : Color.BLACK;
    }

    private static void syncTextColor() {
        Color color = mainFrame.getContentPane().getBackground();
        Color color2 = Winllx.getContrastColor(color);
        for (Component component : mainFrame.getContentPane().getComponents()) {
            if (component instanceof JLabel) {
                ((JLabel)component).setForeground(color2);
                continue;
            }
            if (component instanceof LiquidButton) {
                component.setForeground(color2);
                continue;
            }
            if (component instanceof GlassButton) {
                ((GlassButton)component).setTextColor(color2);
                continue;
            }
            if (!(component instanceof AbstractButton)) continue;
            ((AbstractButton)component).setForeground(color2);
        }
        mainFrame.repaint();
    }

    private static void applyTheme(int n) {
        Color color = switch (n) {
            case 1 -> Color.BLACK;
            case 2 -> Color.BLUE;
            default -> Color.WHITE;
        };
        mainFrame.getContentPane().setBackground(color);
        BackgroundPanel bgPanel = getBackgroundPanel();
        if (bgPanel != null) {
            bgPanel.setBackgroundImage(null);
        }
        backgroundImage = null;
        Winllx.saveBackgroundColor(color);
        Winllx.saveBgMode(n);
        Winllx.saveBgImagePath("");
        Winllx.syncTextColor();
        mainFrame.repaint();
    }

    private static Color loadBackgroundColor() {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                String string = properties.getProperty("bgColor");
                if (string != null && !string.isEmpty()) {
                    return Winllx.hexToColor(string);
                }
            }
        }
        catch (Exception exception) {
        }
        return DEFAULT_BG;
    }

    private static Color loadTextColor() {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                String string = properties.getProperty("textColor");
                if ("white".equalsIgnoreCase(string)) {
                    return Color.WHITE;
                }
            }
        }
        catch (Exception exception) {
        }
        return Color.BLACK;
    }

    private static int loadGridAlpha() {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                String string = properties.getProperty("gridAlpha");
                if (string != null && !string.isEmpty()) {
                    return Math.max(0, Math.min(100, Integer.parseInt(string)));
                }
            }
        }
        catch (Exception exception) {
        }
        return 0;
    }

    private static void saveGridAlpha(int alpha) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            File f = new File(SETTINGS_FILE);
            if (f.exists()) {
                properties.load(new FileInputStream(f));
            }
            properties.setProperty("gridAlpha", String.valueOf(alpha));
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static void saveSettingsPosition(Point pos) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            File f = new File(SETTINGS_FILE);
            if (f.exists()) {
                properties.load(new FileInputStream(f));
            }
            properties.setProperty("settingsX", String.valueOf(pos.x));
            properties.setProperty("settingsY", String.valueOf(pos.y));
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static void saveBackgroundColor(Color color) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            properties.setProperty("bgColor", Winllx.colorToHex(color));
            properties.setProperty("textColor", Winllx.getContrastColor(color) == Color.WHITE ? "white" : "black");
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static String colorToHex(Color color) {
        return String.format("#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
    }

    private static Color hexToColor(String string) {
        if (string.startsWith("#")) {
            string = string.substring(1);
        }
        if (string.length() == 6) {
            int n = Integer.parseInt(string.substring(0, 2), 16);
            int n2 = Integer.parseInt(string.substring(2, 4), 16);
            int n3 = Integer.parseInt(string.substring(4, 6), 16);
            return new Color(n, n2, n3);
        }
        return DEFAULT_BG;
    }

    private static void saveProperty(String key, String value) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            File f = new File(SETTINGS_FILE);
            if (f.exists()) {
                properties.load(new FileInputStream(f));
            }
            properties.setProperty(key, value);
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static String loadProperty(String key) {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                return properties.getProperty(key);
            }
        }
        catch (Exception exception) {
        }
        return null;
    }

    private static void saveBgMode(int mode) {
        saveProperty("bgMode", String.valueOf(mode));
    }

    private static int loadBgMode() {
        String s = loadProperty("bgMode");
        if (s != null && !s.isEmpty()) {
            try { return Integer.parseInt(s); } catch (Exception e) {}
        }
        return 0;
    }

    private static void saveBgImagePath(String path) {
        saveProperty("bgImagePath", path != null ? path : "");
    }

    private static String loadBgImagePath() {
        return loadProperty("bgImagePath");
    }

    private static void saveBgImageOpacity(float opacity) {
        saveProperty("bgImageOpacity", String.valueOf(opacity));
    }

    private static float loadBgImageOpacity() {
        String s = loadProperty("bgImageOpacity");
        if (s != null && !s.isEmpty()) {
            try { return Float.parseFloat(s); } catch (Exception e) {}
        }
        return 1.0f;
    }

    private static void saveBgImageFitMode(int mode) {
        saveProperty("bgImageFitMode", String.valueOf(mode));
    }

    private static void saveGlassWindows(boolean enabled) {
        saveProperty("glassWindows", String.valueOf(enabled));
    }

    private static boolean loadGlassWindows() {
        String s = loadProperty("glassWindows");
        // 未保存过该设置时默认开启毛玻璃（只有明确保存过 false 才关闭）
        return s == null || s.trim().isEmpty() || "true".equalsIgnoreCase(s.trim());
    }

    private static void saveTray(boolean enabled) {
        saveProperty("tray", String.valueOf(enabled));
    }

    private static boolean loadTray() {
        String s = loadProperty("tray");
        return s == null || "true".equalsIgnoreCase(s);
    }

    /** 开机自启动（随系统启动自动运行并添加托盘图标） */
    private static void saveAutoStart(boolean enabled) {
        saveProperty("autoStart", String.valueOf(enabled));
    }

    private static boolean loadAutoStart() {
        String s = loadProperty("autoStart");
        return "true".equalsIgnoreCase(s);
    }

    /**
     * 设置开机自启动：写入/删除 HKCU Run 键。
     * 命令使用 javaw 静默启动当前程序（含 classpath），避免弹出控制台窗口。
     */
    private static void applyAutoStart(boolean enable) {
        saveAutoStart(enable);
        try {
            java.util.prefs.Preferences runKey = java.util.prefs.Preferences.userRoot()
                    .node("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
            if (enable) {
                String javaBin = System.getProperty("java.home") + "\\bin\\javaw.exe";
                // 用程序目录作为工作目录，保证开机启动后配置文件/图标/语言文件路径仍然有效
                String dir = System.getProperty("user.dir");
                if (dir == null || dir.trim().isEmpty()) dir = ".";
                // cmd /c start 指定工作目录 + javaw 静默启动，避免控制台窗口弹出
                String cmd = "cmd.exe /c start \"Winllx\" /d \"" + dir + "\" \"" + javaBin
                        + "\" -cp \"" + dir + "\" app.Winllx";
                runKey.put("Winllx", cmd);
                System.out.println("[Winllx] 已开启开机自启动: " + cmd);
            } else {
                runKey.remove("Winllx");
                System.out.println("[Winllx] 已关闭开机自启动");
            }
        } catch (Throwable t) {
            System.err.println("[Winllx] 设置开机自启动失败: " + t.getMessage());
        }
    }

    private static boolean isAutoStartEnabled() {
        try {
            java.util.prefs.Preferences runKey = java.util.prefs.Preferences.userRoot()
                    .node("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
            return runKey.get("Winllx", null) != null;
        } catch (Throwable t) {
            return loadAutoStart();
        }
    }

    // ===== 液态玻璃按钮效果参数（默认值 = 液态玻璃应用 web/glass 里的演示预览，保证按钮与之完全一致）=====
    private static final float LG_BLUR = 0.5f;    // 模糊系数（演示默认，实际 blur=(4+0.5*32)px=20px）
    private static final float LG_SAT = 140f;     // 饱和度（%）
    private static final float LG_DISP = 100f;    // 位移缩放
    private static final float LG_ABER = 2f;      // 色差强度
    private static final float LG_ELAST = 0f;     // 弹性系数
    private static final float LG_ACT = 200f;     // 激活区域（px）
    private static final float LG_SCALE = 0.96f;  // 按下缩放
    private static final String LG_MODE = "standard"; // 折射模式：standard / polar / prominent / shader
    private static final boolean LG_OVERLIGHT = false; // 亮底加深
    private static final float LG_RADIUS = 32f;   // 圆角

    private static float loadLgFloat(String key, float def) {
        String s = loadProperty(key);
        if (s == null || s.isEmpty()) return def;
        try { return Float.parseFloat(s); } catch (Exception e) { return def; }
    }
    private static String loadLgString(String key, String def) {
        String s = loadProperty(key);
        return (s == null || s.isEmpty()) ? def : s;
    }
    private static boolean loadLgBool(String key, boolean def) {
        String s = loadProperty(key);
        return (s == null || s.isEmpty()) ? def : Boolean.parseBoolean(s);
    }
    private static float lgBlur() { return loadLgFloat("lgBlurAmount", LG_BLUR); }
    private static float lgSat() { return loadLgFloat("lgSaturation", LG_SAT); }
    private static float lgDisp() { return loadLgFloat("lgDisplacementScale", LG_DISP); }
    private static float lgAber() { return loadLgFloat("lgAberrationIntensity", LG_ABER); }
    private static float lgElast() { return loadLgFloat("lgElasticity", LG_ELAST); }
    private static float lgAct() { return loadLgFloat("lgActivationZone", LG_ACT); }
    private static float lgScale() { return loadLgFloat("lgActiveScale", LG_SCALE); }
    private static String lgMode() { return loadLgString("lgMode", LG_MODE); }
    private static boolean lgOverLight() { return loadLgBool("lgOverLight", LG_OVERLIGHT); }
    private static float lgRadius() { return loadLgFloat("lgCornerRadius", LG_RADIUS); }

    /** 解析 setLiquidGlass 桥接 payload 并持久化每个参数（缺失的字段保持原值） */
    private static void applyLiquidGlass(String payloadStr) {
        if (payloadStr == null) return;
        Float b = _jsonFloat(payloadStr, "blurAmount");
        if (b != null) saveProperty("lgBlurAmount", String.valueOf(b));
        Float s = _jsonFloat(payloadStr, "saturation");
        if (s != null) saveProperty("lgSaturation", String.valueOf(s));
        Float d = _jsonFloat(payloadStr, "displacementScale");
        if (d != null) saveProperty("lgDisplacementScale", String.valueOf(d));
        Float a = _jsonFloat(payloadStr, "aberrationIntensity");
        if (a != null) saveProperty("lgAberrationIntensity", String.valueOf(a));
        Float e = _jsonFloat(payloadStr, "elasticity");
        if (e != null) saveProperty("lgElasticity", String.valueOf(e));
        Float z = _jsonFloat(payloadStr, "activationZone");
        if (z != null) saveProperty("lgActivationZone", String.valueOf(z));
        Float as = _jsonFloat(payloadStr, "activeScale");
        if (as != null) saveProperty("lgActiveScale", String.valueOf(as));
        Float cr = _jsonFloat(payloadStr, "cornerRadius");
        if (cr != null) saveProperty("lgCornerRadius", String.valueOf(cr));
        String md = _jsonString(payloadStr, "mode");
        if (md != null) saveProperty("lgMode", md);
        Boolean ol = _jsonBool(payloadStr, "overLight");
        if (ol != null) saveProperty("lgOverLight", String.valueOf(ol));

        // 实时推送改动到所有已打开的便笺窗口（便笺 JS 端 applyLiquidGlassParams 接收并更新按钮）
        NotesModule.pushLiquidGlassToAll(payloadStr);
    }

    private static String _jsonString(String json, String key) {
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("\\\"" + key + "\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"");
        java.util.regex.Matcher m = p.matcher(json);
        if (m.find()) return m.group(1);
        return null;
    }

    private static Boolean _jsonBool(String json, String key) {
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("\\\"" + key + "\\\"\\s*:\\s*(true|false)");
        java.util.regex.Matcher m = p.matcher(json);
        if (m.find()) return Boolean.parseBoolean(m.group(1));
        return null;
    }

    private static Float _jsonFloat(String json, String key) {
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("\\\"" + key + "\\\"\\s*:\\s*(\\-?\\d+(\\.\\d+)?)");
        java.util.regex.Matcher m = p.matcher(json);
        if (m.find()) {
            try { return Float.parseFloat(m.group(1)); } catch (Exception ex) { return null; }
        }
        return null;
    }

    /** 根据设置启用/停用系统托盘图标（运行时即时生效） */
    private static void updateTray(boolean enable) {
        trayEnabled = enable;
        if (enable) {
            if (trayIcon == null) initSystemTray();
        } else if (trayIcon != null) {
            try { SystemTray.getSystemTray().remove(trayIcon); } catch (Exception ignore) {}
            trayIcon = null;
        }
    }

    private static int loadBgImageFitMode() {
        String s = loadProperty("bgImageFitMode");
        if (s != null && !s.isEmpty()) {
            try { return Integer.parseInt(s); } catch (Exception e) {}
        }
        return 0;
    }

    // ===== 字体（供 SettingsFrame.HostActions 调用） =====
    private static final String DEFAULT_FONT_FAMILY = "微软雅黑";
    private static final int DEFAULT_FONT_SIZE = 14;

    private static String loadFontFamily() {
        String s = loadProperty("fontFamily");
        return (s == null || s.isEmpty()) ? DEFAULT_FONT_FAMILY : s;
    }
    private static int loadFontSize() {
        String s = loadProperty("fontSize");
        if (s != null && !s.isEmpty()) {
            try { return Math.max(10, Math.min(28, Integer.parseInt(s))); } catch (Exception e) {}
        }
        return DEFAULT_FONT_SIZE;
    }

    /** 将当前保存的字体族/字号应用到主窗口的所有文字组件。 */
    private static void applyFontsToMain() {
        if (mainFrame == null) return;
        String family = loadFontFamily();
        int size = loadFontSize();
        Font labelFont = new Font(family, Font.PLAIN, size);
        Font timeFont = new Font(family, Font.BOLD, 36);
        if (timeLabel != null) timeLabel.setFont(timeFont);
        if (dateLabel != null) dateLabel.setFont(labelFont);
        for (Component c : mainFrame.getContentPane().getComponents()) {
            if (c == timeLabel || c == dateLabel) continue;
            if (c instanceof AbstractButton) c.setFont(labelFont);
            else if (c instanceof JLabel) ((JLabel) c).setFont(labelFont);
        }
        mainFrame.repaint();
        updateLayout();
    }

    /** 递归删除文件/目录；cnt[0]=成功删除数，cnt[1]=总条目数。 */
    private static void deleteRecursively(File f, int[] cnt) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File c : children) deleteRecursively(c, cnt);
        }
        cnt[1]++;
        if (f.delete()) cnt[0]++;
    }

    private static void loadBackgroundImageSettings() {
        BackgroundPanel bgPanel = getBackgroundPanel();
        if (bgPanel == null) return;
        bgPanel.setImageOpacity(Winllx.loadBgImageOpacity());
        bgPanel.setFitMode(Winllx.loadBgImageFitMode());
        final String path = Winllx.loadBgImagePath();
        if (path == null || path.isEmpty()) return;
        // 背景图解码较耗时，放后台线程读取，避免拖慢主窗口启动
        new Thread(() -> {
            try {
                File imgFile = new File(path);
                if (!imgFile.exists()) return;
                final BufferedImage img = ImageIO.read(imgFile);
                if (img == null) return;
                SwingUtilities.invokeLater(() -> {
                    BackgroundPanel bp = getBackgroundPanel();
                    if (bp != null) bp.setBackgroundImage(img);
                    backgroundImage = img;
                    bgImagePath = path;
                    Winllx.syncTextColorForImage(img);
                    if (mainFrame != null) mainFrame.repaint();
                });
            } catch (Exception exception) {
            }
        }, "bg-image-load").start();
    }

    private static BufferedImage selectBackgroundImage(JFrame parent) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(LangManager.getString("dialog.image.select"));
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "Image Files (jpg, png, gif, bmp, jpeg, wbmp)",
                "jpg", "png", "gif", "bmp", "jpeg", "wbmp");
        fileChooser.setFileFilter(filter);
        int result = fileChooser.showOpenDialog(parent);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                BufferedImage img = ImageIO.read(selectedFile);
                if (img != null) {
                    bgImagePath = selectedFile.getAbsolutePath();
                    return img;
                } else {
                    JOptionPane.showMessageDialog(parent,
                            LangManager.getString("msg.image.load.error"),
                            LangManager.getString("dialog.error"),
                            JOptionPane.ERROR_MESSAGE);
                }
            }
            catch (Exception ex) {
                JOptionPane.showMessageDialog(parent,
                        LangManager.getString("msg.image.load.error"),
                        LangManager.getString("dialog.error"),
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        return null;
    }

    private static Color getAverageColor(BufferedImage image) {
        if (image == null) return Color.GRAY;
        long sumR = 0, sumG = 0, sumB = 0;
        int w = image.getWidth();
        int h = image.getHeight();
        int step = Math.max(1, (int) Math.sqrt(w * h / 10000.0));
        int count = 0;
        for (int y = 0; y < h; y += step) {
            for (int x = 0; x < w; x += step) {
                int rgb = image.getRGB(x, y);
                sumR += (rgb >> 16) & 0xFF;
                sumG += (rgb >> 8) & 0xFF;
                sumB += rgb & 0xFF;
                count++;
            }
        }
        if (count == 0) return Color.GRAY;
        return new Color((int)(sumR / count), (int)(sumG / count), (int)(sumB / count));
    }

    private static void syncTextColorForImage(BufferedImage image) {
        if (image == null) return;
        new Thread(() -> {
            Color avg = Winllx.getAverageColor(image);
            SwingUtilities.invokeLater(() -> syncTextColorForImage(avg));
        }).start();
    }

    private static void syncTextColorForImage(Color avgColor) {
        if (avgColor == null) return;
        Color textColor = Winllx.getContrastColor(avgColor);
        Winllx.applySavedTextColor(textColor);
        saveProperty("textColor", textColor == Color.WHITE ? "white" : "black");
    }

    private static void initSystemTray() {
        trayEnabled = loadTray();
        if (!trayEnabled || !SystemTray.isSupported()) {
            return;
        }
        SystemTray systemTray = SystemTray.getSystemTray();

        // 托盘图标 = 主窗口当前图标主题（跟随 设置-图标 主题切换），失败才回退旧图标
        Image image = WinllxIcon.getCurrentIconImage();
        if (image == null) {
            image = Toolkit.getDefaultToolkit().getImage(TRAY_ICON_PATH);
        }

        // 托盘菜单改用 Swing JPopupMenu：AWT 原生 PopupMenu/MenuItem 在 JBR 环境下取不到含中文的字体，
        // 菜单文字会渲染成方块。JPopupMenu 与主界面走同一套字体渲染，中文正常显示。
        final SystemTray finalTray = systemTray;
        final JPopupMenu popupMenu = buildTrayMenu(finalTray);

        trayIcon = new TrayIcon(image, APP_TITLE);
        trayIcon.setImageAutoSize(true);

        trayIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                if (e.isPopupTrigger()) showTrayMenu(popupMenu);
            }

            @Override
            public void mouseReleased(java.awt.event.MouseEvent e) {
                if (e.isPopupTrigger() || e.getButton() == java.awt.event.MouseEvent.BUTTON3) {
                    showTrayMenu(popupMenu);
                }
            }
        });
        trayIcon.addActionListener(actionEvent -> Winllx.setMainVisible(true));
        try {
            systemTray.add(trayIcon);
        }
        catch (AWTException aWTException) {
            System.err.println(LangManager.getString("msg.tray.error"));
        }
    }

    /** 构建托盘 Swing 菜单，字体与主界面一致，避免 AWT 原生菜单中文显示为方块 */
    private static JPopupMenu buildTrayMenu(SystemTray systemTray) {
        Font menuFont = new Font(loadFontFamily(), Font.PLAIN, loadFontSize());
        JPopupMenu menu = new JPopupMenu();
        menu.setFont(menuFont);

        menu.add(createTrayItem(LangManager.getString("tray.open"), menuFont, e -> Winllx.setMainVisible(true)));
        menu.addSeparator();
        menu.add(createTrayItem(LangManager.getString("tray.settings"), menuFont, e -> Winllx.openSettings()));
        menu.addSeparator();
        menu.add(createTrayItem(LangManager.getString("tray.exit"), menuFont, e -> {
            if (trayIcon != null) systemTray.remove(trayIcon);
            // 退出前统一清理 JCEF，确保 jcef_helper.exe 子进程被终止
            try {
                Class<?> gbp = Class.forName("ui.GlassBrowserPanel");
                gbp.getMethod("shutdownJcef").invoke(null);
            } catch (Throwable ignore) {}
            System.exit(0);
        }));
        return menu;
    }

    private static JMenuItem createTrayItem(String text, Font font, ActionListener action) {
        JMenuItem item = new JMenuItem(text);
        item.setFont(font);
        item.addActionListener(action);
        return item;
    }

    /** 在鼠标位置弹出托盘菜单；invoker 设为自身，保证无主窗口时也能显示并在点击别处后收起 */
    private static void showTrayMenu(JPopupMenu menu) {
        if (menu == null) return;
        try {
            java.awt.Point p = java.awt.MouseInfo.getPointerInfo().getLocation();
            menu.setLocation(p);
            menu.setInvoker(menu);
            menu.setVisible(true);
            SwingUtilities.invokeLater(menu::requestFocusInWindow);
        }
        catch (Throwable t) {
            System.err.println("[Winllx] 托盘菜单弹出失败: " + t.getMessage());
        }
    }

    /** 刷新托盘图标（图标主题切换时调用），保持与窗口图标一致 */
    private static void refreshTrayIcon() {
        if (trayIcon == null) return;
        Image image = WinllxIcon.getCurrentIconImage();
        if (image != null) {
            trayIcon.setImage(image);
        }
    }

    private static void setSystemVolume(int n) {
        cachedVolume = Math.max(0, Math.min(100, n));
        ui.SystemVolumeControl.setVolume(cachedVolume);
    }

    private static int getSystemVolume() {
        return cachedVolume;
    }

    /** 后台线程刷新系统音量缓存（不阻塞 EDT）。 */
    public static void refreshSystemVolumeCache() {
        cachedVolume = ui.SystemVolumeControl.getVolume();
    }

    public static void showNotification(String string, String string2) {
        if (trayIcon != null) {
            trayIcon.displayMessage(string, string2, TrayIcon.MessageType.INFO);
        }
    }
}
