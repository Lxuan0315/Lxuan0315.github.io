import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.*;
class Winllx extends JFrame{
	public void GridLayoutPosition(){
		Container c=getContentPane();
		this.setLayout(new GridLayout(7,3,5,5));
		for(int i=1;i<11;i++)
			c.add(new JButton("按钮"+i));
		this.setSize(300,300);
		this.setTitle("1");
		this.setVisible(true);
		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	public static void main(String[] args){
		Winllx winllx=new Winllx();
		winllx.GridLayoutPosition();
		
	}
}