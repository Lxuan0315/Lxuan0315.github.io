import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
//新滑块
class GlassSegmentedControl extends JPanel implements MouseListener, MouseMotionListener {

    public interface SelectionListener {
        void onSelected(int index, String option);
    }

    private final String[] options;
    private int selectedIndex = 0;
    private final List<SelectionListener> listeners = new ArrayList<>();

    private static final int BAR_HEIGHT = 52;
    private static final int BAR_PADDING = 4;
    private static final int SLIDER_HEIGHT = BAR_HEIGHT - BAR_PADDING * 2;
    private static final float SPRING_K = 0.18f;
    private static final float SCALE_SPEED = 0.18f;
    private static final float PRESS_SCALE_MAX = 1.4f;
    private static final float PRESS_SCALE_SPEED = 0.25f;
    private static final float VELOCITY_SMOOTH = 0.3f;
    private static final float LIQUID_DEFORM = 0.4f;

    private float sliderX = -1, targetX = -1;
    private float sliderW = -1, targetW = -1;
    private float glassState = 0f;
    private boolean isDragging = false;
    private boolean isPressed = false;
    private float pressScale = 0f;
    private float prevSliderX = 0f;
    private float velocityX = 0f;
    private float rawVelocityX = 0f;
    private float[] optionCenters;
    private float[] optionWidths;
    private float time = 0;

    private BufferedImage bgBuffer;
    private int[] bgPixels;
    private int bgW, bgH;
    private BufferedImage sliderBuf;
    private int[] sliderPixels;
    private int lastSliderBufW = 0, lastSliderBufH = 0;
    private BufferedImage userBgImage = null;

    private final Font labelFont;
    private int containerX, containerW;

    public GlassSegmentedControl(String[] options) {
        this.options = options != null && options.length > 0
            ? options : new String[]{"Item 1", "Item 2"};
        setOpaque(false);
        labelFont = new Font("Microsoft YaHei", Font.PLAIN, 16);
        addMouseListener(this);
        addMouseMotionListener(this);

        Timer timer = new Timer(16, e -> {
            time += 0.016f;
            updatePhysics();
            repaint();
        });
        timer.start();
    }

    public void setBackgroundImage(BufferedImage image) {
        this.userBgImage = image;
        repaint();
    }

    public void addSelectionListener(SelectionListener l) {
        listeners.add(l);
    }

    public void removeSelectionListener(SelectionListener l) {
        listeners.remove(l);
    }

    // 修改：移除 optionCenters != null 的条件限制，允许延迟设置
    public void setSelectedIndex(int index) {
        if (index >= 0 && index < options.length) {
            selectedIndex = index;
            if (optionCenters != null) {
                targetX = optionCenters[index];
                targetW = optionWidths[index];
            }
        }
    }

    public int getSelectedIndex() {
        return selectedIndex;
    }

    public String getSelectedOption() {
        return options[selectedIndex];
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(400, BAR_HEIGHT + 20);
    }

    @Override
    public Dimension getMinimumSize() {
        return new Dimension(200, BAR_HEIGHT + 10);
    }

    private void updatePhysics() {
        if (!isDragging) {
            float dx = targetX - sliderX;
            if (Math.abs(dx) > 0.5f) sliderX += dx * SPRING_K;
            else sliderX = targetX;

            float dw = targetW - sliderW;
            if (Math.abs(dw) > 0.5f) sliderW += dw * SPRING_K;
            else sliderW = targetW;
        }

        rawVelocityX = sliderX - prevSliderX;
        velocityX += (rawVelocityX - velocityX) * VELOCITY_SMOOTH;
        prevSliderX = sliderX;

        float targetGlass = (isDragging || isPressed) ? 1f : 0f;
        glassState += (targetGlass - glassState) * SCALE_SPEED;

        float targetPress = (isDragging || isPressed) ? 1f : 0f;
        pressScale += (targetPress - pressScale) * PRESS_SCALE_SPEED;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);

        int w = getWidth(), h = getHeight();
        captureBackground(w, h);
        calculatePositions(w, h);
        drawContainer(g2d, w, h);
        drawSlider(g2d);
        drawLabels(g2d);
    }

    private void captureBackground(int w, int h) {
        if (w <= 0 || h <= 0) return;
        if (bgBuffer == null || bgBuffer.getWidth() != w || bgBuffer.getHeight() != h) {
            bgBuffer = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        }
        Graphics2D bgG = bgBuffer.createGraphics();

        if (userBgImage != null) {
            bgG.drawImage(userBgImage, 0, 0, w, h, null);
        } else {
            Component parent = getParent();
            if (parent != null) {
                bgG.setColor(parent.getBackground());
                bgG.fillRect(0, 0, w, h);
                if (parent instanceof JComponent) {
                    JComponent jp = (JComponent) parent;
                    for (Component c : jp.getComponents()) {
                        if (c != this && c.isVisible()) {
                            bgG.translate(c.getX(), c.getY());
                            c.paint(bgG);
                            bgG.translate(-c.getX(), -c.getY());
                        }
                    }
                }
            } else {
                bgG.setColor(getBackground());
                bgG.fillRect(0, 0, w, h);
            }
        }
        bgG.dispose();
        bgPixels = ((DataBufferInt) bgBuffer.getRaster().getDataBuffer()).getData();
        bgW = w; bgH = h;
    }

    private void calculatePositions(int w, int h) {
        int[] textWidths = new int[options.length];
        FontMetrics fm = getFontMetrics(labelFont);
        int totalTextWidth = 0;
        for (int i = 0; i < options.length; i++) {
            textWidths[i] = fm.stringWidth(options[i]) + 32;
            totalTextWidth += textWidths[i];
        }
        containerW = totalTextWidth + BAR_PADDING * 2 + (options.length - 1) * 8;
        containerX = (w - containerW) / 2;

        optionCenters = new float[options.length];
        optionWidths = new float[options.length];
        float currentX = containerX + BAR_PADDING;
        for (int i = 0; i < options.length; i++) {
            optionWidths[i] = textWidths[i];
            optionCenters[i] = currentX + optionWidths[i] / 2f;
            currentX += optionWidths[i] + 8;
        }
        // 修改：初始化时使用 selectedIndex 而不是硬编码 0
        if (sliderX < 0) {
            sliderX = optionCenters[selectedIndex];
            targetX = optionCenters[selectedIndex];
            sliderW = optionWidths[selectedIndex];
            targetW = optionWidths[selectedIndex];
        }
    }

    private void drawContainer(Graphics2D g2d, int w, int h) {
        int barY = (h - BAR_HEIGHT) / 2;
        g2d.setColor(new Color(255, 255, 255, 25));
        g2d.fillRoundRect(containerX, barY, containerW, BAR_HEIGHT, BAR_HEIGHT, BAR_HEIGHT);
        g2d.setColor(new Color(0, 0, 0, 15));
        g2d.setStroke(new BasicStroke(1f));
        g2d.drawRoundRect(containerX, barY, containerW, BAR_HEIGHT, BAR_HEIGHT, BAR_HEIGHT);

        GradientPaint topShadow = new GradientPaint(
            0, barY, new Color(0, 0, 0, 10),
            0, barY + 8, new Color(0, 0, 0, 0)
        );
        g2d.setPaint(topShadow);
        g2d.fillRoundRect(containerX, barY, containerW, 10, BAR_HEIGHT, BAR_HEIGHT);
    }
    private void drawSlider(Graphics2D g2d) {
        int barY = (getHeight() - BAR_HEIGHT) / 2;
        int cy = barY + BAR_HEIGHT / 2;
        int cx = (int) sliderX;

        float scale = 1f + pressScale * (PRESS_SCALE_MAX - 1f);
        float scaledW = sliderW * scale;
        float scaledH = SLIDER_HEIGHT * scale;

        float vel = velocityX * 0.5f;
        float deform = Math.min(Math.abs(vel) * LIQUID_DEFORM, 8f);
        float frontStretch = vel > 0 ? deform : -deform * 0.3f;
        float backStretch = vel < 0 ? -deform : deform * 0.3f;

        int halfW = (int) (scaledW / 2f);
        int halfH = (int) (scaledH / 2f);
        int sx = cx - halfW;
        int sy = cy - halfH;
        int sw = halfW * 2;
        int sh = halfH * 2;
        if (sw <= 0 || sh <= 0) return;

        if (glassState > 0.01f) drawGlassSlider(g2d, sx, sy, sw, sh, halfH, frontStretch, backStretch);

        if (glassState < 0.99f) {
            float solidAlpha = 1f - glassState;
            g2d.setColor(new Color(
                (int) (230 + 25 * (1 - solidAlpha)),
                (int) (230 + 25 * (1 - solidAlpha)),
                (int) (235 + 20 * (1 - solidAlpha)),
                (int) (255 * solidAlpha)
            ));
            drawLiquidShape(g2d, cx, cy, halfW, halfH, frontStretch, backStretch);
        }

        if (glassState > 0.3f) {
            g2d.setColor(new Color(255, 255, 255, (int) (120 * glassState)));
            g2d.setStroke(new BasicStroke(1.5f));
            drawLiquidBorder(g2d, cx, cy, halfW - 1, halfH - 1, frontStretch, backStretch);
            g2d.setColor(new Color(0, 0, 0, (int) (30 * glassState)));
            g2d.setStroke(new BasicStroke(1f));
            drawLiquidBorder(g2d, cx, cy + 1, halfW, halfH - 1, frontStretch, backStretch);
        }

        if (glassState > 0.5f) {
            int glowSize = (int) (6 * glassState);
            for (int i = glowSize; i > 0; i--) {
                float alpha = 0.03f * (1 - i / (float) glowSize) * glassState;
                g2d.setColor(new Color(0, 0, 0, (int) (alpha * 255)));
                g2d.setStroke(new BasicStroke(i * 2));
                drawLiquidBorder(g2d, cx, cy + 2, halfW + i, halfH + i, frontStretch, backStretch);
            }
        }
    }

    private void drawLiquidShape(Graphics2D g2d, int cx, int cy, int halfW, int halfH, float front, float back) {
        int r = halfH * 2;
        int left = cx - halfW + (int) back;
        int right = cx + halfW + (int) front;
        int top = cy - halfH;
        int bottom = cy + halfH;
        g2d.fillRoundRect(left, top, right - left, bottom - top, r, r);
    }

    private void drawLiquidBorder(Graphics2D g2d, int cx, int cy, int halfW, int halfH, float front, float back) {
        int r = halfH * 2;
        int left = cx - halfW + (int) back;
        int right = cx + halfW + (int) front;
        int top = cy - halfH;
        int bottom = cy + halfH;
        g2d.drawRoundRect(left, top, right - left, bottom - top, r, r);
    }

    private void drawGlassSlider(Graphics2D g2d, int sx, int sy, int sw, int sh, int radius, float frontStretch, float backStretch) {
        if (sw <= 0 || sh <= 0) return;

        if (sliderBuf == null || lastSliderBufW != sw || lastSliderBufH != sh) {
            sliderBuf = new BufferedImage(sw, sh, BufferedImage.TYPE_INT_ARGB);
            sliderPixels = ((DataBufferInt) sliderBuf.getRaster().getDataBuffer()).getData();
            lastSliderBufW = sw; lastSliderBufH = sh;
        }

        int r = radius;
        float refraction = 0.3f + glassState * 0.7f;
        float opacity = 0.15f + glassState * 0.15f;

        float velMag = Math.min(Math.abs(velocityX) * 0.3f, 1.5f);
        refraction += velMag * 0.5f;

        for (int py = 0; py < sh; py++) {
            for (int px = 0; px < sw; px++) {
                float normX = px / (float) sw;
                float shapeOffset = backStretch * (1 - normX) + frontStretch * normX;
                float effectivePx = px - shapeOffset;

                float dx = 0, dy = 0;
                if (effectivePx < r) dx = r - effectivePx;
                else if (effectivePx > sw - r) dx = effectivePx - (sw - r);
                else dx = 0;

                if (py < r) dy = r - py;
                else if (py > sh - r) dy = py - (sh - r);
                else dy = 0;

                float dist = 0f;
                boolean inCorner = false;
                if (dx > 0 && dy > 0) {
                    float cdx = (effectivePx < r) ? r - effectivePx : effectivePx - (sw - r);
                    float cdy = (py < r) ? r - py : py - (sh - r);
                    dist = (float) Math.sqrt(cdx * cdx + cdy * cdy);
                    if (dist > r) {
                        sliderPixels[py * sw + px] = 0;
                        continue;
                    }
                    inCorner = true;
                } else if (dx > r || dy > r) {
                    sliderPixels[py * sw + px] = 0;
                    continue;
                }

                float edgeFactor;
                if (inCorner) edgeFactor = dist / r;
                else edgeFactor = Math.max(dx / r, dy / r);

                float dynamicRefraction = refraction + velMag * edgeFactor * 0.5f;
                float offset = edgeFactor * edgeFactor * dynamicRefraction * 3.0f;
                float wave = (float) Math.sin(edgeFactor * 8 - time * 4) * 0.4f * dynamicRefraction;
                offset += wave;

                float dragOffset = velocityX * 0.3f * edgeFactor;
                offset += dragOffset;

                float centerX = sw / 2f, centerY = sh / 2f;
                float dirX = (px - centerX) / (sw / 2f);
                float dirY = (py - centerY) / (sh / 2f);
                float dirLen = (float) Math.sqrt(dirX * dirX + dirY * dirY);
                if (dirLen > 0.001f) { dirX /= dirLen; dirY /= dirLen; }

                int sampleX = (int) (px + dirX * offset);
                int sampleY = (int) (py + dirY * offset);
                sampleX = Math.max(0, Math.min(sw - 1, sampleX));
                sampleY = Math.max(0, Math.min(sh - 1, sampleY));

                int bgPx = sx + sampleX, bgPy = sy + sampleY;
                int color;
                if (bgPx >= 0 && bgPx < bgW && bgPy >= 0 && bgPy < bgH)
                    color = bgPixels[bgPy * bgW + bgPx];
                else
                    color = 0xFFF5F5F7;

                int a = (color >> 24) & 0xFF;
                int rC = (color >> 16) & 0xFF;
                int gC = (color >> 8) & 0xFF;
                int bC = color & 0xFF;

                rC = (int) (rC * (1 - opacity) + 255 * opacity);
                gC = (int) (gC * (1 - opacity) + 255 * opacity);
                bC = (int) (bC * (1 - opacity) + 255 * opacity);

                sliderPixels[py * sw + px] = (0xFF << 24) | (rC << 16) | (gC << 8) | bC;
            }
        }

        int hw = (int) (sw * 0.25), hh = (int) (sh * 0.18);
        int hx = (int) (sw * 0.35), hy = (int) (sh * 0.25);
        for (int y = Math.max(0, hy - hh); y < Math.min(sh, hy + hh); y++) {
            for (int x = Math.max(0, hx - hw); x < Math.min(sw, hx + hw); x++) {
                double ddx = (x - hx) / (double) hw;
                double ddy = (y - hy) / (double) hh;
                double d = Math.sqrt(ddx * ddx + ddy * ddy);
                if (d <= 1.0) {
                    int alpha = (int) ((1.0 - d) * 80 * glassState);
                    int px = sliderPixels[y * sw + x];
                    int rC = Math.min(255, ((px >> 16) & 0xFF) + alpha);
                    int gC = Math.min(255, ((px >> 8) & 0xFF) + alpha);
                    int bC = Math.min(255, (px & 0xFF) + alpha);
                    sliderPixels[y * sw + x] = (0xFF << 24) | (rC << 16) | (gC << 8) | bC;
                }
            }
        }

        g2d.drawImage(sliderBuf, sx, sy, null);
    }
    private void drawLabels(Graphics2D g2d) {
        int barY = (getHeight() - BAR_HEIGHT) / 2;
        int cy = barY + BAR_HEIGHT / 2;

        g2d.setFont(labelFont);
        for (int i = 0; i < options.length; i++) {
            g2d.setColor(new Color(0, 0, 0, 200));
            FontMetrics fm = g2d.getFontMetrics();
            int tw = fm.stringWidth(options[i]);
            int tx = (int) (optionCenters[i] - tw / 2f);
            int ty = cy + fm.getAscent() / 2 - 2;
            g2d.drawString(options[i], tx, ty);
        }

        float scale = 1f + pressScale * (PRESS_SCALE_MAX - 1f);
        float scaledW = sliderW * scale;
        float scaledH = SLIDER_HEIGHT * scale;
        float vel = velocityX * 0.5f;
        float deform = Math.min(Math.abs(vel) * LIQUID_DEFORM, 8f);
        float frontStretch = vel > 0 ? deform : -deform * 0.3f;
        float backStretch = vel < 0 ? -deform : deform * 0.3f;

        int cx = (int) sliderX;
        int halfW = (int) (scaledW / 2f);
        int halfH = (int) (scaledH / 2f);
        int left = cx - halfW + (int) backStretch;
        int right = cx + halfW + (int) frontStretch;
        int top = cy - halfH;
        int bottom = cy + halfH;
        int sw = right - left;
        int sh = bottom - top;
        if (sw <= 0 || sh <= 0) return;

        java.awt.geom.RoundRectangle2D sliderClip = 
            new java.awt.geom.RoundRectangle2D.Float(left, top, sw, sh, halfH * 2, halfH * 2);

        Shape oldClip = g2d.getClip();
        g2d.setClip(sliderClip);

        for (int i = 0; i < options.length; i++) {
            g2d.setColor(new Color(0, 122, 255));
            FontMetrics fm = g2d.getFontMetrics();
            int tw = fm.stringWidth(options[i]);
            int tx = (int) (optionCenters[i] - tw / 2f);
            int ty = cy + fm.getAscent() / 2 - 2;
            g2d.drawString(options[i], tx, ty);
        }

        g2d.setClip(oldClip);
    }

    private void snapToNearest() {
        float minDist = Float.MAX_VALUE;
        int nearest = 0;
        for (int i = 0; i < optionCenters.length; i++) {
            float d = Math.abs(sliderX - optionCenters[i]);
            if (d < minDist) { minDist = d; nearest = i; }
        }
        selectedIndex = nearest;
        targetX = optionCenters[nearest];
        targetW = optionWidths[nearest];
        for (SelectionListener l : listeners) l.onSelected(selectedIndex, options[selectedIndex]);
    }

    @Override public void mousePressed(MouseEvent e) {
        int mx = e.getX(), my = e.getY();
        int barY = (getHeight() - BAR_HEIGHT) / 2;
        float sliderLeft = sliderX - sliderW / 2f;
        float sliderRight = sliderX + sliderW / 2f;

        if (mx >= sliderLeft - 10 && mx <= sliderRight + 10 &&
            my >= barY - 10 && my <= barY + BAR_HEIGHT + 10) {
            isDragging = true; isPressed = true;
        } else {
            for (int i = 0; i < optionCenters.length; i++) {
                float halfW = optionWidths[i] / 2f;
                if (mx >= optionCenters[i] - halfW - 10 && mx <= optionCenters[i] + halfW + 10 &&
                    my >= barY && my <= barY + BAR_HEIGHT) {
                    selectedIndex = i;
                    targetX = optionCenters[i];
                    targetW = optionWidths[i];
                    for (SelectionListener l : listeners) l.onSelected(i, options[i]);
                    break;
                }
            }
        }
    }

    @Override public void mouseDragged(MouseEvent e) {
        if (isDragging) {
            int mx = e.getX();
            float minX = optionCenters[0];
            float maxX = optionCenters[optionCenters.length - 1];
            sliderX = Math.max(minX, Math.min(maxX, mx));

            float totalRange = maxX - minX;
            float progress = (sliderX - minX) / totalRange;
            int idx = (int) (progress * (options.length - 1));
            idx = Math.max(0, Math.min(options.length - 2, idx));
            float localProgress = (sliderX - optionCenters[idx]) / (optionCenters[idx + 1] - optionCenters[idx]);
            localProgress = Math.max(0, Math.min(1, localProgress));
            sliderW = optionWidths[idx] + (optionWidths[idx + 1] - optionWidths[idx]) * localProgress;
        }
    }

    @Override public void mouseReleased(MouseEvent e) {
        if (isDragging) {
            isDragging = false; isPressed = false;
            snapToNearest();
        }
    }

    @Override public void mouseClicked(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}
    @Override public void mouseMoved(MouseEvent e) {}
}
