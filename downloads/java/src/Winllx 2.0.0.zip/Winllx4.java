import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
class Winllx5 {
    public static void Winllx4(){
 
        JFrame f = new JFrame("Winllx简介");
        f.setSize(400, 300);
        f.setLocation(580, 200);
        f.setLayout(null);
 
        JLabel l = new JLabel();
 
        //根据图片创建ImageIcon对象
        ImageIcon i = new ImageIcon("E:/java/winllxOS/系统/2.0/Winllx图标.png");
        //设置ImageIcon
        l.setIcon(i);
        //label的大小设置为ImageIcon,否则显示不完整
        l.setBounds(50, 50, i.getIconWidth(), i.getIconHeight());
 
        f.add(l);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
 
        f.setVisible(true);
    }
}