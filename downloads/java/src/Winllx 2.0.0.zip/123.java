/**变量/常量/字符串注释
 * a                      变量为主菜单选项变量
 * jinbi                  变量为已获得的Win豆数量
 * qiandaocishu           变量为判断今日是否签到
 * b                      变量为判断是否结束主菜单循环
 * a+[数字]和a+[字母]      变量为开启Scanner的变量
 * num+[数字]             变量为计算器变量
 * jieguo                 变量为计算器计算的结果
 * x                      变量为识别WI农场选项
 * z                      变量为判断是否结束WI农场主菜单循环
 * shijian                变量为WI农场判断种子成熟变量
 * q                      变量为电源选项判断
 */

import java.io.File;
import java.util.Scanner;
import java.io.IOException;

class Winllx1{
    @SuppressWarnings("deprecation")
    public static void main(String[] args){
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("系统正在启动，请稍后...");
            try{
                Thread.sleep(2000);     //等待
            } catch (InterruptedException e) {
                System.out.println("线程错误");
            }
            int a = 0;
            int b = 0;
            int z = 0;
            int za = 0;
            int jinbi = 0;
            int qiandaocishu = 0;
            int q = 0;
            while (b!=4) {//重复执行主菜单
                System.out.println("                菜单 ");
                System.out.println("1.Winllx的图标             2.弹出Winllx分窗口");
                System.out.println("3.计算器                   4打开虚拟键盘");
                System.out.println("5.暂无                     6.Winllx便笺");
                System.out.println("0.退出");
            System.out.println("请输入序号(数字):");
            a = scanner.nextInt();


            //选项1 
            switch(a){
            case 1:
            System.out.println("正在显示介绍...");
            Winllx5.Winllx4();
            break;
            case 2://选项2   打开Winllx分窗口
                    new Winllx();
                    System.out.println("已弹出窗口...");
                    break;

            case 3://选项3
            System.out.println("1.四则运算          2.面积计算");
            Scanner a3 = new Scanner(System.in); 
            za = scanner.nextInt();
            
            if(za == 1){        //四则运算
                System.out.println("计算器可计算整数/小数的加法(+)减法(-)乘法(*)除法(/)");
                Scanner num =new Scanner(System.in);
                System.out.println("请输入第一个运算数字：");
                double num1 = num.nextDouble();
                System.out.println("请输入需要的运算符（+ - * /）");
                char num2 = num.next().charAt(0);
                System.out.println("请输入第二个运算数字：");
                double num3 = num.nextDouble();
                double jieguo;
                if (num2 == '+'){
                    jieguo = num1+num3;
                    System.out.println(num1+"+"+num3+"="+jieguo);
                }else if(num2 == '-'){
                    jieguo = num1 + num3;
                    System.out.println(num1+"-"+num3+"="+jieguo);
                }else if(num2 == '*'){
                    jieguo = num1*num3;
                    System.out.println(num1+"*"+num3+"="+jieguo);
                }else if(num2 == '/'){
                    jieguo = num1/num3;
                    System.out.println(num1+"/"+num3+"="+jieguo);
                }else {
                    System.out.println("错误,无法计算");
                }
            }else if(za == 2){  //

            }

                System.out.println("请按任意键回车继续"); 
                Scanner a1 = new Scanner(System.in); 
                String aa = a1.next(); 
            break;

            case 4://选项4  虚拟键盘
                    System.out.println("暂时未开发");
                    System.out.println("请输入任意字符 回车继续"); 
                    Scanner a9 = new Scanner(System.in); 
                    String ab = a9.next(); 
                    break;

            case 6:
                Winllx3.Winllx2();
                System.out.println("便笺已启动");
                break;

            case 0://选项0  退出系统 
                    System.out.println("已退出Winllx系统");
                    b = 4;
                    break;        

            default:
                    System.out.println("无此服务，请重新输入");
                    System.out.println("请按任意键回车继续"); 
                    Scanner a2 = new Scanner(System.in); 
                    String ac = a2.next(); 
                }
            }
        }
        class Winllx {
        
            
        }
    }
}