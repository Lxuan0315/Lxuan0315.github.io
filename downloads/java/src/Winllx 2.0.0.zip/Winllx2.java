package Next1;
import java.util.Scanner;
class Demo {
    public static void main(String[] args) {
        System.out.println("计算器可以计算 整数 的+（加法） -（减法） *（乘法） /（除法） ");
        Scanner num =new Scanner(System.in);
        System.out.println("请输入第一个运算数字：");
        double num1 = num.nextDouble();
        System.out.println("请输入需要的运算符");
        char num2 = num.next().charAt(0);
        System.out.println("请输入第二个运算数字：");
        double num3 = num.nextDouble();
        double jieguo;
        if (num2 == '+'){
            jieguo = num1+num3;
            System.out.println(num1+"+"+num3+"="+jieguo);
        }else if(num2 == '-'){
            jieguo = num1 + num3;
            System.out.println(num1+"-"+num3+"="+jieguo);
        }else if(num2 == '*'){
            jieguo = num1*num3;
            System.out.println(num1+"*"+num3+"="+jieguo);
        }else if(num2 == '/'){
            jieguo = num1/num3;
            System.out.println(num1+"/"+num3+"="+jieguo);
        }else {
            System.out.println("错误,无法计算");
        }
    }
    }

