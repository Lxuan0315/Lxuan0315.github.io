
  
import java.awt.Dimension;
import java.awt.FlowLayout;
  
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
  
class Winllx3 {
    public static void Winllx2(){
  
        JFrame f = new JFrame("Winllx便签");
        f.setSize(400, 300);
        f.setLocation(200, 200);
  
        f.setLayout(new FlowLayout());
  
        JLabel l = new JLabel("输入区：");
  
        JTextArea ta = new JTextArea();
        ta.setPreferredSize(new Dimension(200, 150));
        //设置自动换行
        ta.setLineWrap(true);
        f.add(l);
        f.add(ta);
  
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  
        f.setVisible(true);
    }
}