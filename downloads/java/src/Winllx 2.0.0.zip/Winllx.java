import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.util.Scanner;


public class Winllx extends JFrame { // 创建父窗口类
	
	public  Winllx() {

		Container container = getContentPane(); // 获得窗体容器
		container.setLayout(null); // 容器使用null布局
		JTextArea ta = new JTextArea(20,50);
		JScrollPane sp = new JScrollPane(ta);
		JButton bl = new JButton("打开新窗口"); // 定义一个按钮
		bl.setBounds(10, 10, 100, 21); // 定义按钮在容器中的坐标和大小
		bl.addActionListener(new ActionListener() { // 为按钮添加点击事件
			public void actionPerformed(ActionEvent e) { // 创建MyJdialog对话框
				MyJDialog dialog = new MyJDialog(Winllx.this);
				dialog.setVisible(true);
			}
		});
		container.add(bl);
		container.setBackground(Color.WHITE); //设置颜色蓝色
		setSize(200, 200);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);}
	

	public static void main(String args[]) {
		System.out.println("请输入登录密码：");
		try (Scanner scanner = new Scanner(System.in)) {
			int psw=scanner.nextInt();
			int s = 0;
			while(s<=3){
				s++;
				if(psw==20120315){
					System.out.print("密码正确，系统已启动");
					new Winllx();
					
					break;
				}else{System.out.println("密码错误");
				int psw3 = 3-s;
				System.out.println("请再次输入登录密码，你还有"+psw3+"次机会");
			}
				if(s>2){
					System.out.println("账号冻结");
					break;
				}
				psw=scanner.nextInt();
			}
		}

	}
	
}


class MyJDialog extends JDialog { // 创建自定义窗体

	public MyJDialog(Winllx frame) {// 实例化一个JDialog类对象，指定对话框的父窗体和窗体标题和类型
		super(frame, "Winllx", true);
		Container container = getContentPane(); // 创建一个容器
		container.add(new JLabel("欢迎使用Winllx！")); // 在容器中添加标签
		setBounds(120, 120, 100, 100); // 设置对话框窗体在桌面显示的坐标和大小.
		container.setLayout(null); // 容器使用null布局
		JTextArea ta = new JTextArea(20,50);
		JScrollPane sp = new JScrollPane(ta);
		JButton bl = new JButton("打开新窗口"); // 定义一个按钮
		bl.setBounds(10, 10, 100, 21); // 定义按钮在容器中的坐标和大小
	}
}

