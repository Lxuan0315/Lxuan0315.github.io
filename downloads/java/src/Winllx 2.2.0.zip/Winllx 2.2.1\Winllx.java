import javax.swing.*;
import java.awt.*;
import java.lang.Exception;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.io.File;
import java.awt.event.ActionListener;

class Winllx {
    public static void main(String[] args) {
        ImageIcon cb2 = new ImageIcon("D:/Winllx/b2.png");
        ImageIcon cb3 = new ImageIcon("D:/Winllx/b3.png");
        ImageIcon cb0 = new ImageIcon("D:/Winllx/b0.png");
        ImageIcon cb1 = new ImageIcon("D:/Winllx/b1.png");
        ImageIcon cb4 = new ImageIcon("D:/Winllx/b4.png");

        // 图片自适应
        cb2 = new ImageIcon(cb2.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
        cb3 = new ImageIcon(cb3.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
        cb0 = new ImageIcon(cb0.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
        cb1 = new ImageIcon(cb1.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
        cb4 = new ImageIcon(cb4.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));

        int a;
        a = 0;
        JFrame a1 = new JFrame("Winllx");
        a1.getContentPane().setBackground(Color.WHITE);
        a1.setExtendedState(JFrame.MAXIMIZED_BOTH);// 设置窗口最大化
        a1.setLayout(null);

        JLabel l1 = new JLabel("Winllx");
        JLabel l2 = new JLabel("便笺");
        JLabel l3 = new JLabel("计算器");
        JLabel l4 = new JLabel("文件管理");
        l1.setBounds(600, 20, 100, 50);
        l1.setFont(l1.getFont().deriveFont(20f));// 设置标签字体大小
        l2.setBounds(320, 130, 80, 80);
        l3.setBounds(820, 130, 80, 80);
        l4.setBounds(310, 260, 80, 80);
        a1.add(l2);
        a1.add(l1);
        a1.add(l3);
        a1.add(l4);

        JButton b2 = new JButton("便笺");
        b2.setIcon(cb2);
        JButton b3 = new JButton("计算器");
        b3.setIcon(cb3);
        JButton b4 = new JButton("文件管理");
        b4.setIcon(cb4);
        JButton b5 = new JButton("读心术");
        JButton b02 = new JButton("缩小到托盘(任务栏)");
        JButton b0 = new JButton("退出");
        b0.setIcon(cb0);
        JButton b01 = new JButton("设置");
        b01.setIcon(cb1);

        b0.setBounds(1200, 550, 80, 80);
        b01.setBounds(1100, 550, 80, 80);
        b02.setBounds(900, 550, 150, 50);
        // 给按钮 增加 监听
        b0.setBorderPainted(false);
        b0.setBackground(Color.WHITE);

        b0.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Winllx0.Winllx01();
            }
        });

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        b01.setBorderPainted(false);
        b01.setBackground(Color.WHITE);

        b01.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame f = new JFrame("Winllx设置");
                f.setSize(350, 150);// 设置窗口大小
                // f.setResizable(false);
                f.setLocation(200, 200);// 设置窗口位置
                f.setLayout(null);

                JLabel l1 = new JLabel("主题色");
                JLabel l2 = new JLabel("全屏显示");
                JRadioButton r1 = new JRadioButton("默认(白)");
                JRadioButton r2 = new JRadioButton("黑色");
                JRadioButton r3 = new JRadioButton("蓝色");
                JRadioButton r4 = new JRadioButton("开启");
                JRadioButton r5 = new JRadioButton("关闭");
                ButtonGroup bg = new ButtonGroup();
                ButtonGroup bg2 = new ButtonGroup();

                r1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        a1.getContentPane().setBackground(Color.WHITE);
                        a1.repaint();

                    }
                });
                r2.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        a1.getContentPane().setBackground(Color.black);
                        a1.repaint();
                    }
                });
                r3.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        a1.getContentPane().setBackground(Color.blue);
                        a1.repaint();
                    }
                });
                r4.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        a1.setExtendedState(JFrame.MAXIMIZED_BOTH);//
                    }
                });
                r5.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        a1.setExtendedState(JFrame.NORMAL);
                    }
                });
                bg.add(r1);
                bg.add(r2);
                bg.add(r3);
                bg2.add(r4);
                bg2.add(r5);

                l1.setBounds(10, 0, 80, 30);// 设置标签位置
                r1.setBounds(10, 30, 80, 30);// 设置选项按钮位置
                r2.setBounds(10, 60, 80, 30);
                r3.setBounds(10, 90, 80, 30);
                l2.setBounds(10, 130, 80, 30);
                r4.setBounds(10, 160, 80, 30);
                r5.setBounds(10, 190, 80, 30);

                f.add(l1);
                f.add(r1);
                f.add(r2);
                f.add(r3);
                f.add(l2);
                f.add(r4);
                f.add(r5);

                f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                f.setVisible(true);
            }
        });
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        b2.setBounds(300, 70, 80, 80);
        b2.setBorderPainted(false);
        b2.setBackground(Color.WHITE);
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Winllx2.Winllx21();
            }
        });
        b3.setBounds(800, 70, 80, 80);
        b3.setBorderPainted(false);
        b3.setBackground(Color.WHITE);
        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Winllx3.Winllx31();
            }
        });
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        b4.setBounds(300, 200, 80, 80);
        b4.setBorderPainted(false);
        b4.setBackground(Color.WHITE);
        b4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Winllx4.Winllx41();
            }
        });
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        b5.setBounds(800, 200, 200, 50);
        b5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                a1.setVisible(false);
                JOptionPane.showMessageDialog(null, "启动成功，请返回cmd进行操作");
                System.out.println("欢迎来到读心术(二进制)\n在1-31中选择一个数字\n注：如果玩不起(更改所想数字)，请在不要按下Enter,并退出游戏\n按下Enter开始游戏");
                Scanner s = new Scanner(System.in);
                s.nextLine();

                int[] group1 = { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31 };
                int[] group2 = { 2, 3, 6, 7, 10, 11, 14, 15, 18, 19, 22, 23, 26, 27, 30, 31 };
                int[] group3 = { 4, 5, 6, 7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31 };
                int[] group4 = { 8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29, 30, 31 };
                int[] group5 = { 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 };

                int number = 0;
                System.out.println("你心中所想数字在这一组吗？");
                if (askGroup(s, group1))//
                    number += 1;
                if (askGroup(s, group2))
                    number += 2;
                if (askGroup(s, group3))
                    number += 4;
                if (askGroup(s, group4))
                    number += 8;
                if (askGroup(s, group5))
                    number += 16;

                JOptionPane.showMessageDialog(null, "你心中所想的数字是：" + number + "\n游戏结束");
                a1.setVisible(true);
            }

            private static boolean askGroup(Scanner s, int[] group) {// 询问某个组中是否有所想数字
                System.out.println("组：");
                for (int num : group) {// 遍历组中的数字
                    System.out.print(num + " ");// 打印组中的数字
                }
                System.out.println("你的数字在这个组中吗？ (0: 没有, 1: 有): ");
                int response = s.nextInt();// 获取用户输入
                return response == 1;// 返回是否在该组中

            }
        });
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        b02.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // 隐藏窗口
                a1.setVisible(false);
            }
        });
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        a1.add(b01);
        a1.add(b02);
        a1.add(b2);
        a1.add(b3);
        a1.add(b4);
        a1.add(b0);
        a1.add(b5);

        a1.setSize(300, 200);
        a1.setLocationRelativeTo(null);/// 设置窗口在屏幕中间
        a1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        a1.setVisible(true);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // 创建系统托盘实例
        final SystemTray tray = SystemTray.getSystemTray();

        // 创建托盘图标图像
        Image image = Toolkit.getDefaultToolkit().getImage("C:/Users/86132/Desktop/java.png");

        // 创建弹出菜单
        PopupMenu p1 = new PopupMenu();

        // 创建菜单项
        MenuItem openItem = new MenuItem("打开");
        MenuItem exitItem = new MenuItem("退出");

        // 添加菜单项到弹出菜单
        p1.add(openItem);
        p1.addSeparator();
        p1.add(exitItem);

        if (a == 0) {

            // 创建托盘图标
            TrayIcon trayIcon = new TrayIcon(image, "Winllx", p1);

            // 设置托盘图标自动调整大小
            trayIcon.setImageAutoSize(true);

            // 添加托盘图标到系统托盘
            try {
                tray.add(trayIcon);
            } catch (AWTException e1) {
                System.out.println("无法添加TrayIcon");
                return;
            }

            // 为“Open”菜单项添加事件处理
            openItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // 显示窗口
                    a1.setVisible(true);

                }
            });

            // 为“Exit”菜单项添加事件处理
            exitItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    tray.remove(trayIcon);
                    System.exit(0);
                }
            });

            // 为托盘图标添加双击事件处理
            trayIcon.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // 显示窗口
                    a1.setVisible(true);
                }
            });
        }

    }
}

class Winllx0 {

    static void Winllx01() {
        // 退出程序
        System.exit(0);
    }
}

class Winllx2 {
    static void Winllx21() {
        JFrame f = new JFrame("Winllx便签");
        f.setSize(400, 300);
        f.setLocation(200, 200);

        f.setLayout(new FlowLayout());

        JButton b1 = new JButton("设置");
        b1.setBounds(10, 250, 80, 30);
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Winllx2.Winllx22();
            }
        });

        JTextArea ta = new JTextArea();
        ta.setPreferredSize(new Dimension(380, 200));
        f.add(ta);
        f.add(b1);

        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        f.setVisible(true);

    }

    static void Winllx22() {
        JFrame f = new JFrame("Winllx便签设置");
        f.setSize(300, 150);// 设置窗口大小
        f.setLocation(200, 200);// 设置窗口位置

        JLabel f1 = new JLabel("自动换行");
        JRadioButton r1 = new JRadioButton("启用", true);// 默认选中
        JRadioButton r2 = new JRadioButton("禁用");
        ButtonGroup bg = new ButtonGroup();

        bg.add(r1);
        bg.add(r2);

        r1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            }
        });
        r2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

            }
        });

        r1.setBounds(90, 20, 80, 30);// 设置选项按钮位置
        r2.setBounds(90, 40, 80, 30);

        f.add(r1);
        f.add(r2);
        f.add(f1);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // 窗口可见
        f.setVisible(true);

    }
}

class Winllx3 {
    static void Winllx31() {
        // 窗体
        JFrame j1 = new JFrame("计算器");
        JLabel l1 = new JLabel("_______________________________________________________________");
        l1.setBounds(0, 95, 270, 45);
        JLabel l2 = new JLabel("_______________________________________________________________");
        l2.setBounds(0, 160, 270, 45);
        JLabel l3 = new JLabel("_______________________________________________________________");
        l3.setBounds(0, 220, 270, 45);
        j1.add(l3);
        JLabel l4 = new JLabel("_______________________________________________________________");
        l4.setBounds(0, 285, 270, 45);
        j1.add(l4);

        j1.add(l2);

        j1.add(l1);
        j1.setLayout(null);
        j1.setSize(270, 450);// 设置窗口大小
        j1.setResizable(false);// 设置窗口不可缩放
        // 按钮
        JButton b1 = new JButton("1");
        JButton b2 = new JButton("2");
        JButton b3 = new JButton("3");
        JButton b4 = new JButton("4");
        JButton b5 = new JButton("5");
        JButton b6 = new JButton("6");
        JButton b7 = new JButton("7");
        JButton b8 = new JButton("8");
        JButton b9 = new JButton("9");
        JButton b0 = new JButton("0");
        JButton b11 = new JButton("+");
        JButton b12 = new JButton("-");
        JButton b13 = new JButton("×");
        JButton b14 = new JButton("÷");
        JButton b15 = new JButton("=");
        JButton b16 = new JButton("C");
        JButton b17 = new JButton(".");
        JButton b18 = new JButton("00");
        JButton b19 = new JButton("%");
        JButton b20 = new JButton("⌫");

        b1.setBorder(BorderFactory.createEmptyBorder());
        b2.setBorder(BorderFactory.createEmptyBorder());
        b3.setBorder(BorderFactory.createEmptyBorder());
        b4.setBorder(BorderFactory.createEmptyBorder());
        b5.setBorder(BorderFactory.createEmptyBorder());
        b6.setBorder(BorderFactory.createEmptyBorder());
        b7.setBorder(BorderFactory.createEmptyBorder());
        b8.setBorder(BorderFactory.createEmptyBorder());
        b9.setBorder(BorderFactory.createEmptyBorder());
        b0.setBorder(BorderFactory.createEmptyBorder());
        b11.setBorder(BorderFactory.createEmptyBorder());
        b12.setBorder(BorderFactory.createEmptyBorder());
        b13.setBorder(BorderFactory.createEmptyBorder());
        b14.setBorder(BorderFactory.createEmptyBorder());
        b15.setBorder(BorderFactory.createEmptyBorder());
        b16.setBorder(BorderFactory.createEmptyBorder());
        b17.setBorder(BorderFactory.createEmptyBorder());
        b18.setBorder(BorderFactory.createEmptyBorder());
        b19.setBorder(BorderFactory.createEmptyBorder());
        b20.setBorder(BorderFactory.createEmptyBorder());

        // 设置按钮无底色
        b1.setOpaque(false);
        b2.setOpaque(false);
        b3.setOpaque(false);
        b4.setOpaque(false);
        b5.setOpaque(false);
        b6.setOpaque(false);
        b7.setOpaque(false);
        b8.setOpaque(false);
        b9.setOpaque(false);
        b0.setOpaque(false);
        b11.setOpaque(false);
        b12.setOpaque(false);
        b13.setOpaque(false);
        b14.setOpaque(false);
        b15.setOpaque(false);
        b16.setOpaque(false);
        b17.setOpaque(false);
        b18.setOpaque(false);
        b19.setOpaque(false);
        b20.setOpaque(false);

        ImageIcon icon1 = new ImageIcon("D:/Winllx/1/数字1.png");
        ImageIcon icon2 = new ImageIcon("D:/Winllx/1/数字2.png");
        ImageIcon icon3 = new ImageIcon("D:/Winllx/1/数字3.png");
        ImageIcon icon4 = new ImageIcon("D:/Winllx/1/数字4.png");
        ImageIcon icon5 = new ImageIcon("D:/Winllx/1/数字5.png");
        ImageIcon icon6 = new ImageIcon("D:/Winllx/1/数字6.png");
        ImageIcon icon7 = new ImageIcon("D:/Winllx/1/数字7.png");
        ImageIcon icon8 = new ImageIcon("D:/Winllx/1/数字8.png");
        ImageIcon icon9 = new ImageIcon("D:/Winllx/1/数字9.png");
        ImageIcon icon10 = new ImageIcon("D:/Winllx/1/数字0.png");
        ImageIcon icon11 = new ImageIcon("D:/Winllx/1/退格.png");
        ImageIcon icon12 = new ImageIcon("D:/Winllx/1/..png");
        ImageIcon icon13 = new ImageIcon("D:/Winllx/1/C.png");
        ImageIcon icon14 = new ImageIcon("D:/Winllx/1/%.png");
        ImageIcon icon15 = new ImageIcon("D:/Winllx/1/加号.png");
        ImageIcon icon16 = new ImageIcon("D:/Winllx/1/减号.png");
        ImageIcon icon17 = new ImageIcon("D:/Winllx/1/乘号.png");
        ImageIcon icon18 = new ImageIcon("D:/Winllx/1/除号.png");
        ImageIcon icon19 = new ImageIcon("D:/Winllx/1/数字00.png");
        ImageIcon icon20 = new ImageIcon("D:/Winllx/1/等于.png");
        // 调整照片大小
        icon1.setImage(icon1.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon2.setImage(icon2.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon3.setImage(icon3.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon4.setImage(icon4.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon5.setImage(icon5.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon6.setImage(icon6.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon7.setImage(icon7.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon8.setImage(icon8.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon9.setImage(icon9.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon10.setImage(icon10.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon11.setImage(icon11.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon12.setImage(icon12.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon13.setImage(icon13.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon14.setImage(icon14.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon15.setImage(icon15.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon16.setImage(icon16.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon17.setImage(icon17.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon18.setImage(icon18.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon19.setImage(icon19.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        icon20.setImage(icon20.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));

        // 设置按钮内容区域的对齐方式为居中
        b1.setHorizontalAlignment(SwingConstants.CENTER);
        b2.setHorizontalAlignment(SwingConstants.CENTER);
        b3.setHorizontalAlignment(SwingConstants.CENTER);
        b4.setHorizontalAlignment(SwingConstants.CENTER);
        b5.setHorizontalAlignment(SwingConstants.CENTER);
        b6.setHorizontalAlignment(SwingConstants.CENTER);
        b7.setHorizontalAlignment(SwingConstants.CENTER);
        b8.setHorizontalAlignment(SwingConstants.CENTER);
        b9.setHorizontalAlignment(SwingConstants.CENTER);
        b0.setHorizontalAlignment(SwingConstants.CENTER);
        b11.setHorizontalAlignment(SwingConstants.CENTER);
        b12.setHorizontalAlignment(SwingConstants.CENTER);
        b13.setHorizontalAlignment(SwingConstants.CENTER);
        b14.setHorizontalAlignment(SwingConstants.CENTER);
        b15.setHorizontalAlignment(SwingConstants.CENTER);
        b16.setHorizontalAlignment(SwingConstants.CENTER);
        b17.setHorizontalAlignment(SwingConstants.CENTER);
        b18.setHorizontalAlignment(SwingConstants.CENTER);
        b19.setHorizontalAlignment(SwingConstants.CENTER);
        ;
        b20.setHorizontalAlignment(SwingConstants.CENTER);

        // 为按钮添加图片
        b1.setIcon(icon1);
        b2.setIcon(icon2);
        b3.setIcon(icon3);
        b4.setIcon(icon4);
        b5.setIcon(icon5);
        b6.setIcon(icon6);
        b7.setIcon(icon7);
        b8.setIcon(icon8);
        b9.setIcon(icon9);
        b0.setIcon(icon10);
        b11.setIcon(icon15);
        b12.setIcon(icon16);
        b13.setIcon(icon17);
        b14.setIcon(icon18);
        b15.setIcon(icon20);
        b16.setIcon(icon13);
        b17.setIcon(icon12);
        b18.setIcon(icon19);
        b19.setIcon(icon14);
        b20.setIcon(icon11);

        // 第一行
        b1.setBounds(10, 260, 50, 50); // 1
        b2.setBounds(70, 260, 50, 50); // 2
        b3.setBounds(130, 260, 50, 50); // 3
        b11.setBounds(190, 260, 50, 50); // +
        // 第二行
        b4.setBounds(10, 195, 50, 50); // 4
        b5.setBounds(70, 195, 50, 50); // 5
        b6.setBounds(130, 195, 50, 50); // 6
        b12.setBounds(190, 195, 50, 50); // -
        // 第三行
        b7.setBounds(10, 130, 50, 50); // 7
        b8.setBounds(70, 130, 50, 50); // 8
        b9.setBounds(130, 130, 50, 50); // 9
        b13.setBounds(190, 130, 50, 50); // ×
        // 第四行
        b0.setBounds(10, 325, 50, 50); // 0
        b17.setBounds(70, 325, 50, 50);
        b18.setBounds(130, 325, 50, 50);
        b15.setBounds(190, 325, 50, 50); // =
        // 设置回车可触发=按钮
        j1.getRootPane().setDefaultButton(b15);

        // 顶行
        b16.setBounds(10, 65, 50, 50); // C
        b19.setBounds(70, 65, 50, 50);// %
        b20.setBounds(130, 65, 50, 50);// ⌫

        b14.setBounds(190, 65, 50, 50);// ÷

        // 设置按钮不可用
        b16.setBackground(Color.ORANGE);// 设置C的背景颜色为橙色

        b1.setBackground(Color.WHITE);// 设置其他按钮的背景颜色为白色
        b2.setBackground(Color.WHITE);
        b3.setBackground(Color.WHITE);
        b4.setBackground(Color.WHITE);
        b5.setBackground(Color.WHITE);
        b6.setBackground(Color.WHITE);
        b7.setBackground(Color.WHITE);
        b8.setBackground(Color.WHITE);
        b9.setBackground(Color.WHITE);
        b0.setBackground(Color.WHITE);
        b11.setBackground(Color.WHITE);
        b12.setBackground(Color.WHITE);
        b13.setBackground(Color.WHITE);
        b14.setBackground(Color.WHITE);
        b15.setBackground(Color.cyan); // 设置=的背景颜色为青色
        b17.setBackground(Color.WHITE);
        b18.setBackground(Color.WHITE);
        b19.setBackground(Color.WHITE);
        b20.setBackground(Color.WHITE);

        // 文本框
        JTextArea t1 = new JTextArea();
        // 设置文本框自动换行
        t1.setLineWrap(true);
        t1.setBounds(0, 0, 240, 50);

        // 按钮事件
        // 1
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "1";
                t1.setText(str);
            }
        });
        // 2
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "2";
                t1.setText(str);
            }
        });
        // 3
        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "3";
                t1.setText(str);
            }
        });
        // 4
        b4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "4";
                t1.setText(str);
            }
        });
        // 5
        b5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "5";
                t1.setText(str);
            }
        });
        // 6
        b6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "6";
                t1.setText(str);
            }
        });
        // 7
        b7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "7";
                t1.setText(str);
            }
        });
        // 8
        b8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "8";
                t1.setText(str);
            }
        });
        // 9
        b9.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "9";
                t1.setText(str);
            }
        });
        // 0
        b0.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "0";
                t1.setText(str);
            }
        });
        // .
        b17.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + ".";
                t1.setText(str);
            }
        });
        // 00
        b18.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "00";
                t1.setText(str);
            }
        });
        // %
        b19.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame f2 = new JFrame("百分比专用计算器");
                JButton b1 = new JButton("计算百分比值");
                JButton b2 = new JButton("计算百分比增加");
                JButton b3 = new JButton("计算百分比减少");
                JButton b4 = new JButton("计算百分比占比");
                JButton b5 = new JButton("计算百分比变化");

                b1.setBounds(10, 10, 200, 30);
                b2.setBounds(220, 10, 200, 30);
                b3.setBounds(430, 10, 200, 30);
                b4.setBounds(10, 50, 200, 30);
                b5.setBounds(220, 50, 200, 30);
                /////////////////////////////////////////////////////////////////////////////
                b1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比值");
                        JLabel l1 = new JLabel("输入数值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入百分比：");
                        JTextField t2 = new JTextField();
                        JButton b1 = new JButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result1 = n1 * (n2 / 100);
                                        JOptionPane.showMessageDialog(f, "结果：" + result1);
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }

                });
                /////////////////////////////////////////////////////////////////////////////
                b2.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比增加");
                        JLabel l1 = new JLabel("输入数值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入增加百分比：");
                        JTextField t2 = new JTextField();
                        JButton b1 = new JButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result2 = n1 + (n1 * (n2 / 100));
                                        JOptionPane.showMessageDialog(f, "结果：" + result2);
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }
                });
                /////////////////////////////////////////////////////////////////////////////

                b3.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比减少");
                        JLabel l1 = new JLabel("输入数值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入减少的百分比：");
                        JTextField t2 = new JTextField();
                        JButton b1 = new JButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result3 = n1 - (n1 * (n2 / 100));
                                        JOptionPane.showMessageDialog(f, "结果：" + result3);
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }
                });
                /////////////////////////////////////////////////////////////////////////////

                b4.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比占比");
                        JLabel l1 = new JLabel("输入部分值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入总值：");
                        JTextField t2 = new JTextField();
                        JButton b1 = new JButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result4 = (n1 / n2) * 100;
                                        JOptionPane.showMessageDialog(f, "结果：" + result4 + "%");
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }
                });
                /////////////////////////////////////////////////////////////////////////////

                b5.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比变化");
                        JLabel l1 = new JLabel("输入旧值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入新值：");
                        JTextField t2 = new JTextField();
                        JButton b1 = new JButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result5 = ((n1 - n2) / n2) * 100;
                                        JOptionPane.showMessageDialog(f, "百分比变化：" + result5 + "%");
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }
                });
                /////////////////////////////////////////////////////////////////////////////

                f2.add(b1);
                f2.add(b2);
                f2.add(b3);
                f2.add(b4);
                f2.add(b5);

                f2.setSize(1000, 200);
                f2.setLayout(null);
                f2.setVisible(true);
            }
        });
        // C
        b16.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                t1.setText("");

            }
        });
        // ⌫
        b20.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText().substring(0, t1.getText().length() - 1);
                t1.setText(str);

            }
        });
        // +
        b11.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // 判断是否有符号
                if (t1.getText().contains("-") || t1.getText().contains("+") || t1.getText().contains("×")
                        || t1.getText().contains("÷")) {
                    JOptionPane.showMessageDialog(j1, "你已输入了一个运算符！");

                } else {
                    String str = t1.getText() + "+";
                    t1.setText(str);
                }
            }
        });
        // -
        b12.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // 判断是否有符号
                if (t1.getText().contains("-") || t1.getText().contains("+") || t1.getText().contains("×")
                        || t1.getText().contains("÷")) {
                    JOptionPane.showMessageDialog(j1, "你已输入了一个运算符！");
                } else {
                    String str = t1.getText() + "-";
                    t1.setText(str);
                }

            }
        });
        // ×
        b13.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (t1.getText().contains("-") || t1.getText().contains("+") || t1.getText().contains("×")
                        || t1.getText().contains("÷")) {
                    JOptionPane.showMessageDialog(j1, "你已输入了一个运算符！");
                } else {
                    String str = t1.getText() + "×";
                    t1.setText(str);
                }
            }
        });
        // ÷
        b14.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // 判断是否有符号
                if (t1.getText().contains("-") || t1.getText().contains("+") || t1.getText().contains("×")
                        || t1.getText().contains("÷")) {
                    JOptionPane.showMessageDialog(j1, "你已输入了一个运算符！");
                } else {
                    String str = t1.getText() + "÷";
                    t1.setText(str);
                }

            }
        });
        // =
        b15.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (t1.getText().contains("+")) {
                    try {
                        // 截取+号前面的数字
                        String num1 = t1.getText().substring(0, t1.getText().indexOf("+"));
                        // 截取+号后面的数字
                        String num2 = t1.getText().substring(t1.getText().indexOf("+") + 1, t1.getText().length());
                        // 将字符串转换为double类型
                        double num11 = Double.parseDouble(num1);
                        double num22 = Double.parseDouble(num2);
                        String str = t1.getText() + "=" + (num11 + num22);
                        t1.setText(str);
                    } catch (Exception a) {
                        JOptionPane.showMessageDialog(j1, "缺少操作数！\n请重新输入");
                        t1.setText("");
                    }
                } else if (t1.getText().contains("-")) {
                    try {
                        // 截取-号前面的数字
                        String num1 = t1.getText().substring(0, t1.getText().indexOf("-"));
                        // 截取-号后面的数字
                        String num2 = t1.getText().substring(t1.getText().indexOf("-") + 1, t1.getText().length());
                        double num11 = Double.parseDouble(num1);
                        double num22 = Double.parseDouble(num2);
                        String str = t1.getText() + "=" + (num11 - num22);
                        t1.setText(str);
                    } catch (Exception a) {
                        JOptionPane.showMessageDialog(j1, "缺少操作数！\n请重新输入");
                        t1.setText("");
                    }
                } else if (t1.getText().contains("×")) {
                    try {
                        // 截取×号前面的数字
                        String num1 = t1.getText().substring(0, t1.getText().indexOf("×"));
                        // 截取×号后面的数字
                        String num2 = t1.getText().substring(t1.getText().indexOf("×") + 1, t1.getText().length());
                        double num11 = Double.parseDouble(num1);
                        double num22 = Double.parseDouble(num2);
                        String str = t1.getText() + "=" + (num11 * num22);
                        t1.setText(str);
                    } catch (Exception a) {
                        JOptionPane.showMessageDialog(j1, "缺少操作数\n请重新输入");
                        t1.setText("");
                    }
                } else if (t1.getText().contains("÷")) {
                    try {
                        // 截取×号前面的数字
                        String num1 = t1.getText().substring(0, t1.getText().indexOf("÷"));
                        // 截取×号后面的数字
                        String num2 = t1.getText().substring(t1.getText().indexOf("÷") + 1, t1.getText().length());
                        if (num2.equals("0")) {
                            JOptionPane.showMessageDialog(j1, "除数不能为0,请重新输入！");
                            // 删除错误的输入
                            String str = t1.getText().substring(0, t1.getText().indexOf("÷") + 1);
                            t1.setText(str);

                        } else {
                            double num11 = Double.parseDouble(num1);
                            double num22 = Double.parseDouble(num2);
                            String str = t1.getText() + "=" + (num11 / num22);
                            t1.setText(str);
                        }
                    } catch (Exception a) {
                        JOptionPane.showMessageDialog(j1, "未知错误\n请重新输入");
                        t1.setText("");
                    }
                } else {
                    JOptionPane.showMessageDialog(j1, "请输入一个运算符！");
                }
            }
        });

        // 添加组件
        j1.add(b1);
        j1.add(b2);
        j1.add(b3);
        j1.add(b4);
        j1.add(b5);
        j1.add(b6);
        j1.add(b7);
        j1.add(b8);
        j1.add(b9);
        j1.add(b0);
        j1.add(b11);
        j1.add(b12);
        j1.add(b13);
        j1.add(b14);
        j1.add(b15);
        j1.add(b16);
        j1.add(b17);
        j1.add(b18);
        j1.add(b19);
        j1.add(b20);
        j1.add(t1);

        j1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        j1.setVisible(true);
    }
}

class Winllx4 {
    static void Winllx41() {
        JFrame f1 = new JFrame("文件管理");
        f1.setSize(350, 80);
        f1.setResizable(false);
        f1.setLayout(null);

        JButton b1 = new JButton("新建");
        b1.setBounds(10, 10, 80, 30);

        JButton b2 = new JButton("打开");
        b2.setBounds(100, 10, 80, 30);
        JButton b3 = new JButton("预览文件");
        b3.setBounds(200, 10, 100, 30);
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "您的电脑不支持此功能", "该功能不会做", JOptionPane.ERROR_MESSAGE);
            }
        });
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "您的电脑不支持此功能", "该功能不会做", JOptionPane.ERROR_MESSAGE);

            }
        });
        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "您的电脑不支持此功能", "该功能不会做", JOptionPane.ERROR_MESSAGE);
            }
        });

        f1.add(b1);
        f1.add(b2);
        f1.add(b3);

        f1.setVisible(true);
    }
}

class Winllx5 {
    static void Winllx51() {
    }
}