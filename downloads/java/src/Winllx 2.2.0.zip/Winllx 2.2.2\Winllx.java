import javax.swing.*;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Path2D;
import java.util.*;

//Winllx 主程序入口
public class Winllx {
    public static void main(String[] args) {
        // 0.变量初始化
        boolean isTrayIcon = true; // 是否显示托盘图标
        boolean isFullScreen = false; // 是否全屏显示
        int maincolor = 0;

        // 1.桌面图标加载(非按钮)
        String[] iconNames = { "b0.png", "b1.png", "b2.png", "b3.png", "b4.png", "b5.png" };
        ImageIcon[] cb = new ImageIcon[iconNames.length];
        for (int i = 0; i < iconNames.length; i++) {
            cb[i] = new ImageIcon(iconNames[i]);
            cb[i] = new ImageIcon(cb[i].getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
        }

        // 2.加载动画
        Loading loading = new Loading();
        loading.show();

        // 3.主窗口设置
        JFrame a1 = new JFrame("Winllx");
        a1.getContentPane().setBackground(Color.WHITE);
        a1.setExtendedState(JFrame.MAXIMIZED_BOTH);
        a1.setLayout(null);
        a1.setSize(300, 200);
        a1.setLocationRelativeTo(null);
        a1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        a1.setVisible(true);

        // 4.桌面应用标题
        JLabel l1 = new JLabel("Winllx");
        JLabel l2 = new JLabel("便笺");
        JLabel l3 = new JLabel("计算器");
        JLabel l4 = new JLabel("文件管理");
        JLabel l6 = new JLabel("白板");
        l1.setBounds(600, 20, 100, 50);
        l1.setFont(l1.getFont().deriveFont(20f));
        l2.setBounds(320, 130, 80, 80);
        l3.setBounds(820, 130, 80, 80);
        l4.setBounds(310, 260, 80, 80);
        l6.setBounds(320, 390, 80, 80);

        a1.add(l2);
        a1.add(l1);
        a1.add(l3);
        a1.add(l4);
        a1.add(l6);

        // 5.桌面应用按钮
        JButton bian = new JButton("便笺");
        bian.setIcon(cb[2]);
        JButton b3 = new JButton("计算器");
        b3.setIcon(cb[3]);
        JButton b4 = new JButton("文件管理");
        b4.setIcon(cb[4]);
        JButton b5 = new JButton("读心术");
        JButton b6 = new JButton("白板");
        b6.setIcon(cb[5]);
        JButton b02 = new JButton("缩小到任务栏");
        JButton b0 = new JButton("退出");
        b0.setIcon(cb[0]);
        JButton b01 = new JButton("设置");
        b01.setIcon(cb[1]);
        b0.setBounds(1200, 550, 80, 80);
        b01.setBounds(1100, 550, 80, 80);
        b02.setBounds(900, 550, 150, 50);

        // 6.退出按钮
        b0.setBorderPainted(false);
        b0.setBackground(Color.WHITE);
        b0.addActionListener(e -> new Winllx0());

        // 7.系统设置按钮
        b01.setBorderPainted(false);
        b01.setBackground(Color.WHITE);
        b01.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame f = new JFrame("Winllx设置");
                f.setSize(350, 150);
                f.setLocation(200, 200);
                f.setLayout(null);
                JLabel l1 = new JLabel("主题色");
                JLabel l2 = new JLabel("全屏显示");
                JRadioButton r1 = new JRadioButton("默认(白)");
                JRadioButton r2 = new JRadioButton("黑色");
                JRadioButton r3 = new JRadioButton("蓝色");
                JRadioButton r4 = new JRadioButton("开启");
                JRadioButton r5 = new JRadioButton("关闭");
                ButtonGroup bg = new ButtonGroup();
                ButtonGroup bg2 = new ButtonGroup();
                r1.addActionListener(e1 -> {
                    a1.getContentPane().setBackground(Color.WHITE);
                    a1.repaint();
                });
                r2.addActionListener(e1 -> {
                    a1.getContentPane().setBackground(Color.black);
                    a1.repaint();
                });
                r3.addActionListener(e1 -> {
                    a1.getContentPane().setBackground(Color.blue);
                    a1.repaint();
                });
                r4.addActionListener(e1 -> a1.setExtendedState(JFrame.MAXIMIZED_BOTH));
                r5.addActionListener(e1 -> a1.setExtendedState(JFrame.NORMAL));
                bg.add(r1);
                bg.add(r2);
                bg.add(r3);
                bg2.add(r4);
                bg2.add(r5);
                l1.setBounds(10, 0, 80, 30);
                r1.setBounds(10, 30, 80, 30);
                r2.setBounds(10, 60, 80, 30);
                r3.setBounds(10, 90, 80, 30);
                l2.setBounds(10, 130, 80, 30);
                r4.setBounds(10, 160, 80, 30);
                r5.setBounds(10, 190, 80, 30);
                f.add(l1);
                f.add(r1);
                f.add(r2);
                f.add(r3);
                f.add(l2);
                f.add(r4);
                f.add(r5);
                f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                f.setVisible(true);
            }
        });

        // 8.桌面应用按钮布局与事件
        bian.setBounds(300, 70, 80, 80);
        bian.setBorderPainted(false);
        bian.setBackground(Color.WHITE);
        bian.addActionListener(e -> new Winllx2());
        b3.setBounds(800, 70, 80, 80);
        b3.setBorderPainted(false);
        b3.setBackground(Color.WHITE);
        b3.addActionListener(e -> new Winllx3());
        b4.setBounds(300, 200, 80, 80);
        b4.setBorderPainted(false);
        b4.setBackground(Color.WHITE);
        b4.addActionListener(e -> new Winllx4());
        b5.setBounds(800, 200, 200, 50);

        // 9.读心术
        b5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                a1.setVisible(false);
                JOptionPane.showMessageDialog(null, "启动成功，请返回cmd进行操作");
                System.out.println("欢迎来到读心术(二进制)\n在1-31中选择一个数字\n注：如果玩不起(更改所想数字)，请在不要按下Enter,并退出游戏\n按下Enter开始游戏");
                Scanner s = new Scanner(System.in);
                s.nextLine();
                int[] group1 = { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31 };
                int[] group2 = { 2, 3, 6, 7, 10, 11, 14, 15, 18, 19, 22, 23, 26, 27, 30, 31 };
                int[] group3 = { 4, 5, 6, 7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31 };
                int[] group4 = { 8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29, 30, 31 };
                int[] group5 = { 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 };
                int number = 0;
                System.out.println("你心中所想数字在这一组吗？");
                if (askGroup(s, group1))
                    number += 1;
                if (askGroup(s, group2))
                    number += 2;
                if (askGroup(s, group3))
                    number += 4;
                if (askGroup(s, group4))
                    number += 8;
                if (askGroup(s, group5))
                    number += 16;
                JOptionPane.showMessageDialog(null, "你心中所想的数字是：" + number + "\n游戏结束");
                a1.setVisible(true);
            }

            private static boolean askGroup(Scanner s, int[] group) {
                System.out.println("组：");
                for (int num : group)
                    System.out.print(num + " ");
                System.out.println("你的数字在这个组中吗？ (0: 没有, 1: 有): ");
                int response = s.nextInt();
                return response == 1;
            }
        });

        b6.setBounds(300, 330, 80, 80);
        b6.setBorderPainted(false);
        b6.setBackground(Color.WHITE);
        b6.addActionListener(e -> new Winllx7());

        // 10.托盘功能
        b02.addActionListener(e -> a1.setVisible(false));
        final SystemTray tray = SystemTray.getSystemTray();
        Image image = Toolkit.getDefaultToolkit().getImage("C:/Users/86132/Desktop/java.png");
        PopupMenu p1 = new PopupMenu();
        MenuItem openItem = new MenuItem("打开");
        MenuItem setItem = new MenuItem("设置");
        MenuItem exitItem = new MenuItem("退出");
        p1.addSeparator();
        p1.add(setItem);
        p1.addSeparator();
        p1.add(exitItem);

        if (isTrayIcon) {
            TrayIcon trayIcon = new TrayIcon(image, "Winllx", p1);
            trayIcon.setImageAutoSize(true);
            try {
                tray.add(trayIcon);
            } catch (AWTException e1) {
                System.out.println("无法添加到系统托盘\n请检查是否给予权限");
                return;
            }
            openItem.addActionListener(e -> a1.setVisible(true));
            exitItem.addActionListener(e -> {
                tray.remove(trayIcon);
                System.exit(0);
            });
            trayIcon.addActionListener(e -> a1.setVisible(true));
        }

        // 11.添加所有按钮到主窗口
        a1.add(b01);
        a1.add(b02);
        a1.add(bian);
        a1.add(b3);
        a1.add(b4);
        a1.add(b0);
        a1.add(b5);
        a1.add(b6);

        // 12.关闭加载动画
        loading.close();
    }
}

class Winllx0 {// 关机
    Winllx0() {
        try {
            Runtime.getRuntime().exec("shutdown -s -t 0");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "关机失败！请检查是否给予权限");
        }
    }
}

class Winllx2 {// 便笺

    Winllx2() {
        JFrame f = new JFrame("Winllx便签");
        f.setSize(400, 300);
        f.setLocation(200, 200);
        f.setLayout(new FlowLayout());
        JButton b1 = new JButton("设置");
        b1.setBounds(10, 250, 80, 30);
        b1.addActionListener(e -> Winllx2.Winllx22());
        JTextArea ta = new JTextArea();
        ta.setPreferredSize(new Dimension(380, 200));
        f.add(ta);
        f.add(b1);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.setVisible(true);
    }

    static void Winllx22() {
        JFrame f = new JFrame("Winllx便签设置");
        f.setSize(300, 150);
        f.setLocation(200, 200);
        JLabel f1 = new JLabel("自动换行");
        JRadioButton r1 = new JRadioButton("启用", true);
        JRadioButton r2 = new JRadioButton("禁用");
        ButtonGroup bg = new ButtonGroup();
        bg.add(r1);
        bg.add(r2);
        r1.setBounds(90, 20, 80, 30);
        r2.setBounds(90, 40, 80, 30);
        f.add(r1);
        f.add(r2);
        f.add(f1);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.setVisible(true);
    }
}

class Winllx3 {// 计算器

    Winllx3() {
        // 窗体
        JFrame j1 = new JFrame("计算器");
        JLabel l1 = new JLabel("_______________________________________________________________");
        l1.setBounds(0, 95, 270, 45);
        JLabel l2 = new JLabel("_______________________________________________________________");
        l2.setBounds(0, 160, 270, 45);
        JLabel l3 = new JLabel("_______________________________________________________________");
        l3.setBounds(0, 220, 270, 45);
        j1.add(l3);
        JLabel l4 = new JLabel("_______________________________________________________________");
        l4.setBounds(0, 285, 270, 45);
        j1.add(l4);

        j1.add(l2);

        j1.add(l1);
        j1.setLayout(null);
        j1.setSize(270, 450);// 设置窗口大小
        j1.setResizable(false);// 设置窗口不可缩放
        // 按钮
        JButton b1 = new JButton("1");
        JButton b2 = new JButton("2");
        JButton b3 = new JButton("3");
        JButton b4 = new JButton("4");
        JButton b5 = new JButton("5");
        JButton b6 = new JButton("6");
        JButton b7 = new JButton("7");
        JButton b8 = new JButton("8");
        JButton b9 = new JButton("9");
        JButton b0 = new JButton("0");
        JButton b11 = new JButton("+");
        JButton b12 = new JButton("-");
        JButton b13 = new JButton("×");
        JButton b14 = new JButton("÷");
        JButton b15 = new JButton("=");
        JButton b16 = new JButton("C");
        JButton b17 = new JButton(".");
        JButton b18 = new JButton("00");
        JButton b19 = new JButton("%");
        JButton b20 = new JButton("⌫");

        JButton[] buttons = { b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, b11, b12, b13, b14, b15, b16, b17, b18, b19,
                b20 };
        for (JButton btn : buttons) {
            btn.setBorder(BorderFactory.createEmptyBorder());
        }
        for (JButton btn : buttons) {
            btn.setOpaque(false);// 去掉背景色
        }

        ImageIcon icon1 = new ImageIcon("1/数字1.png");
        ImageIcon icon2 = new ImageIcon("1/数字2.png");
        ImageIcon icon3 = new ImageIcon("1/数字3.png");
        ImageIcon icon4 = new ImageIcon("1/数字4.png");
        ImageIcon icon5 = new ImageIcon("1/数字5.png");
        ImageIcon icon6 = new ImageIcon("1/数字6.png");
        ImageIcon icon7 = new ImageIcon("1/数字7.png");
        ImageIcon icon8 = new ImageIcon("1/数字8.png");
        ImageIcon icon9 = new ImageIcon("1/数字9.png");
        ImageIcon icon10 = new ImageIcon("1/数字0.png");
        ImageIcon icon11 = new ImageIcon("1/退格.png");
        ImageIcon icon12 = new ImageIcon("1/..png");
        ImageIcon icon13 = new ImageIcon("1/C.png");
        ImageIcon icon14 = new ImageIcon("1/%.png");
        ImageIcon icon15 = new ImageIcon("1/加号.png");
        ImageIcon icon16 = new ImageIcon("1/减号.png");
        ImageIcon icon17 = new ImageIcon("1/乘号.png");
        ImageIcon icon18 = new ImageIcon("1/除号.png");
        ImageIcon icon19 = new ImageIcon("1/数字00.png");
        ImageIcon icon20 = new ImageIcon("1/等于.png");
        // 调整照片大小
        ImageIcon[] icons1 = { icon1, icon2, icon3, icon4, icon5, icon6, icon7, icon8, icon9, icon10, icon11,
                icon12, icon13, icon14, icon15, icon16, icon17, icon18, icon19, icon20 };
        for (ImageIcon btn : icons1) {
            btn.setImage(btn.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH));
        }

        // 设置按钮内容区域的对齐方式为居中
        JButton[] buttons1 = { b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, b11, b12, b13, b14, b15, b16, b17, b18, b19,
                b20 };
        for (JButton btn : buttons1) {
            btn.setHorizontalAlignment(SwingConstants.CENTER);
        }

        // 为按钮添加图片
        JButton[] buttons2 = { b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, b11, b12, b13, b14, b15, b16, b17, b18, b19,
                b20 };
        ImageIcon[] icons2 = { icon1, icon2, icon3, icon4, icon5, icon6, icon7, icon8, icon9, icon10, icon15, icon16,
                icon17, icon18, icon20, icon13, icon12, icon19, icon14, icon11 };
        for (int i = 0; i < buttons2.length; i++) {
            buttons2[i].setIcon(icons2[i]);
        }

        // 第一行
        JButton[] buttons3 = { b1, b2, b3, b11, b4, b5, b6, b12, b7, b8, b9, b13, b0, b17, b18, b15, b16, b19, b20,
                b14 };
        // 坐标，依次为x, y, width, height
        int[][] bounds = {
                { 10, 260, 50, 50 }, // b1
                { 70, 260, 50, 50 }, // b2
                { 130, 260, 50, 50 }, // b3
                { 190, 260, 50, 50 }, // b11
                { 10, 195, 50, 50 }, // b4
                { 70, 195, 50, 50 }, // b5
                { 130, 195, 50, 50 }, // b6
                { 190, 195, 50, 50 }, // b12
                { 10, 130, 50, 50 }, // b7
                { 70, 130, 50, 50 }, // b8
                { 130, 130, 50, 50 }, // b9
                { 190, 130, 50, 50 }, // b13
                { 10, 325, 50, 50 }, // b0
                { 70, 325, 50, 50 }, // b17
                { 130, 325, 50, 50 }, // b18
                { 190, 325, 50, 50 }, // b15
                { 10, 65, 50, 50 }, // b16
                { 70, 65, 50, 50 }, // b19
                { 130, 65, 50, 50 }, // b20
                { 190, 65, 50, 50 } // b14
        };
        for (int i = 0; i < buttons3.length; i++) {
            buttons3[i].setBounds(bounds[i][0], bounds[i][1], bounds[i][2], bounds[i][3]);
        } // 设置回车可触发=按钮
        j1.getRootPane().setDefaultButton(b15);

        // 顶行
        b16.setBounds(10, 65, 50, 50); // C
        b19.setBounds(70, 65, 50, 50);// %
        b20.setBounds(130, 65, 50, 50);// ⌫

        b14.setBounds(190, 65, 50, 50);// ÷

        // 设置按钮不可用
        b16.setBackground(Color.ORANGE);// 设置C的背景颜色为橙色
        JButton[] buttons4 = { b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, b11, b12, b13, b14, b15, b16, b17, b18, b19,
                b20 };
        for (JButton btn : buttons3) {
            btn.setBackground(Color.WHITE);
        }
        b15.setBackground(Color.cyan); // 设置=的背景颜色为青色

        // 文本框
        JTextArea t1 = new JTextArea();
        // 设置文本框自动换行
        t1.setLineWrap(true);
        t1.setBounds(0, 0, 240, 50);

        // 按钮事件
        // 1
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "1";
                t1.setText(str);
            }
        });
        // 2
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "2";
                t1.setText(str);
            }
        });
        // 3
        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "3";
                t1.setText(str);
            }
        });
        // 4
        b4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "4";
                t1.setText(str);
            }
        });
        // 5
        b5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "5";
                t1.setText(str);
            }
        });
        // 6
        b6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "6";
                t1.setText(str);
            }
        });
        // 7
        b7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "7";
                t1.setText(str);
            }
        });
        // 8
        b8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "8";
                t1.setText(str);
            }
        });
        // 9
        b9.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "9";
                t1.setText(str);
            }
        });
        // 0
        b0.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "0";
                t1.setText(str);
            }
        });
        // .
        b17.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + ".";
                t1.setText(str);
            }
        });
        // 00
        b18.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "00";
                t1.setText(str);
            }
        });
        // %
        b19.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame f2 = new JFrame("百分比专用计算器");
                JButton b1 = new JButton("计算百分比值");
                JButton b2 = new JButton("计算百分比增加");
                JButton b3 = new JButton("计算百分比减少");
                JButton b4 = new JButton("计算百分比占比");
                JButton b5 = new JButton("计算百分比变化");

                b1.setBounds(10, 10, 200, 30);
                b2.setBounds(220, 10, 200, 30);
                b3.setBounds(430, 10, 200, 30);
                b4.setBounds(10, 50, 200, 30);
                b5.setBounds(220, 50, 200, 30);
                /////////////////////////////////////////////////////////////////////////////
                b1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比值");
                        JLabel l1 = new JLabel("输入数值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入百分比：");
                        JTextField t2 = new JTextField();
                        JButton b1 = new JButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result1 = n1 * (n2 / 100);
                                        JOptionPane.showMessageDialog(f, "结果：" + result1);
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }

                });
                /////////////////////////////////////////////////////////////////////////////
                b2.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比增加");
                        JLabel l1 = new JLabel("输入数值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入增加百分比：");
                        JTextField t2 = new JTextField();
                        JButton b1 = new JButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result2 = n1 + (n1 * (n2 / 100));
                                        JOptionPane.showMessageDialog(f, "结果：" + result2);
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }
                });
                /////////////////////////////////////////////////////////////////////////////

                b3.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比减少");
                        JLabel l1 = new JLabel("输入数值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入减少的百分比：");
                        JTextField t2 = new JTextField();
                        JButton b1 = new JButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result3 = n1 - (n1 * (n2 / 100));
                                        JOptionPane.showMessageDialog(f, "结果：" + result3);
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }
                });
                /////////////////////////////////////////////////////////////////////////////

                b4.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比占比");
                        JLabel l1 = new JLabel("输入部分值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入总值：");
                        JTextField t2 = new JTextField();
                        JButton b1 = new JButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result4 = (n1 / n2) * 100;
                                        JOptionPane.showMessageDialog(f, "结果：" + result4 + "%");
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }
                });
                /////////////////////////////////////////////////////////////////////////////

                b5.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比变化");
                        JLabel l1 = new JLabel("输入旧值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入新值：");
                        JTextField t2 = new JTextField();
                        JButton b1 = new JButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result5 = ((n1 - n2) / n2) * 100;
                                        JOptionPane.showMessageDialog(f, "百分比变化：" + result5 + "%");
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }
                });
                /////////////////////////////////////////////////////////////////////////////

                f2.add(b1);
                f2.add(b2);
                f2.add(b3);
                f2.add(b4);
                f2.add(b5);

                f2.setSize(1000, 200);
                f2.setLayout(null);
                f2.setVisible(true);
            }
        });
        // C
        b16.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                t1.setText("");

            }
        });
        // ⌫
        b20.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText().substring(0, t1.getText().length() - 1);
                t1.setText(str);

            }
        });
        // +
        b11.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // 判断是否有符号
                if (t1.getText().contains("-") || t1.getText().contains("+") || t1.getText().contains("×")
                        || t1.getText().contains("÷")) {
                    JOptionPane.showMessageDialog(j1, "你已输入了一个运算符！");

                } else {
                    String str = t1.getText() + "+";
                    t1.setText(str);
                }
            }
        });
        // -
        // b12.addActionListener(new ActionListener() {
        // public void actionPerformed(ActionEvent e) {
        // // 判断是否有符号
        // if (t1.getText().contains("-") || t1.getText().contains("+") ||
        // t1.getText().contains("×")
        // || t1.getText().contains("÷")) {
        // JOptionPane.showMessageDialog(j1, "你已输入了一个运算符！");
        // } else {
        // String str = t1.getText() + "-";
        // t1.setText(str);
        // }
        //
        // }
        // });
        // ×
        b13.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (t1.getText().contains("-") || t1.getText().contains("+") || t1.getText().contains("×")
                        || t1.getText().contains("÷")) {
                    JOptionPane.showMessageDialog(j1, "你已输入了一个运算符！");
                } else {
                    String str = t1.getText() + "×";
                    t1.setText(str);
                }
            }
        });
        // ÷
        b14.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // 判断是否有符号
                if (t1.getText().contains("-") || t1.getText().contains("+") || t1.getText().contains("×")
                        || t1.getText().contains("÷")) {
                    JOptionPane.showMessageDialog(j1, "你已输入了一个运算符！");
                } else {
                    String str = t1.getText() + "÷";
                    t1.setText(str);
                }

            }
        });
        // =
        b15.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (t1.getText().contains("+")) {
                    try {
                        // 截取+号前面的数字
                        String num1 = t1.getText().substring(0, t1.getText().indexOf("+"));
                        // 截取+号后面的数字
                        String num2 = t1.getText().substring(t1.getText().indexOf("+") + 1, t1.getText().length());
                        // 将字符串转换为double类型
                        double num11 = Double.parseDouble(num1);
                        double num22 = Double.parseDouble(num2);
                        String str = t1.getText() + "=" + (num11 + num22);
                        t1.setText(str);
                    } catch (Exception a) {
                        JOptionPane.showMessageDialog(j1, "缺少操作数！\n请重新输入");
                        t1.setText("");
                    }
                } else if (t1.getText().contains("-")) {
                    try {
                        // 截取-号前面的数字
                        String num1 = t1.getText().substring(0, t1.getText().indexOf("-"));
                        // 截取-号后面的数字
                        String num2 = t1.getText().substring(t1.getText().indexOf("-") + 1, t1.getText().length());
                        double num11 = Double.parseDouble(num1);
                        double num22 = Double.parseDouble(num2);
                        String str = t1.getText() + "=" + (num11 - num22);
                        t1.setText(str);
                    } catch (Exception a) {
                        JOptionPane.showMessageDialog(j1, "缺少操作数！\n请重新输入");
                        t1.setText("");
                    }
                } else if (t1.getText().contains("×")) {
                    try {
                        // 截取×号前面的数字
                        String num1 = t1.getText().substring(0, t1.getText().indexOf("×"));
                        // 截取×号后面的数字
                        String num2 = t1.getText().substring(t1.getText().indexOf("×") + 1, t1.getText().length());
                        double num11 = Double.parseDouble(num1);
                        double num22 = Double.parseDouble(num2);
                        String str = t1.getText() + "=" + (num11 * num22);
                        t1.setText(str);
                    } catch (Exception a) {
                        JOptionPane.showMessageDialog(j1, "缺少操作数\n请重新输入");
                        t1.setText("");
                    }
                } else if (t1.getText().contains("÷")) {
                    try {
                        // 截取×号前面的数字
                        String num1 = t1.getText().substring(0, t1.getText().indexOf("÷"));
                        // 截取×号后面的数字
                        String num2 = t1.getText().substring(t1.getText().indexOf("÷") + 1, t1.getText().length());
                        if (num2.equals("0")) {
                            JOptionPane.showMessageDialog(j1, "除数不能为0,请重新输入！");
                            // 删除错误的输入
                            String str = t1.getText().substring(0, t1.getText().indexOf("÷") + 1);
                            t1.setText(str);

                        } else {
                            double num11 = Double.parseDouble(num1);
                            double num22 = Double.parseDouble(num2);
                            String str = t1.getText() + "=" + (num11 / num22);
                            t1.setText(str);
                        }
                    } catch (Exception a) {
                        JOptionPane.showMessageDialog(j1, "未知错误\n请重新输入");
                        t1.setText("");
                    }
                } else {
                    JOptionPane.showMessageDialog(j1, "请输入一个运算符！");
                }
            }
        });

        // 添加组件
        j1.add(b1);
        j1.add(b2);
        j1.add(b3);
        j1.add(b4);
        j1.add(b5);
        j1.add(b6);
        j1.add(b7);
        j1.add(b8);
        j1.add(b9);
        j1.add(b0);
        j1.add(b11);
        j1.add(b12);
        j1.add(b13);
        j1.add(b14);
        j1.add(b15);
        j1.add(b16);
        j1.add(b17);
        j1.add(b18);
        j1.add(b19);
        j1.add(b20);
        j1.add(t1);

        j1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        j1.setVisible(true);
    }
}

class Winllx4 {// 文件管理

    Winllx4() {
        JFrame f1 = new JFrame("文件管理");
        f1.setSize(350, 80);
        f1.setResizable(false);
        f1.setLayout(null);
        JButton b1 = new JButton("新建");
        b1.setBounds(10, 10, 80, 30);
        JButton b2 = new JButton("打开");
        b2.setBounds(100, 10, 80, 30);
        JButton b3 = new JButton("预览文件");
        b3.setBounds(200, 10, 100, 30);
        b1.addActionListener(
                e -> JOptionPane.showMessageDialog(null, "您的电脑不支持此功能", "该功能不会做", JOptionPane.ERROR_MESSAGE));
        b2.addActionListener(
                e -> JOptionPane.showMessageDialog(null, "您的电脑不支持此功能", "该功能不会做", JOptionPane.ERROR_MESSAGE));
        b3.addActionListener(
                e -> JOptionPane.showMessageDialog(null, "您的电脑不支持此功能", "该功能不会做", JOptionPane.ERROR_MESSAGE));
        f1.add(b1);
        f1.add(b2);
        f1.add(b3);
        f1.setVisible(true);
    }
}
/*
class Winllx5 extends JFrame {
    private JTabbedPane tabbedPane;
    private ClockPanel clockPanel;
    private AlarmPanel alarmPanel;
    private CountdownPanel countdownPanel;
    private StopwatchPanel stopwatchPanel;

    public Winllx5() {
        setTitle("时钟");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // 创建选项卡面板
        tabbedPane = new JTabbedPane();

        // 创建各个功能面板
        clockPanel = new ClockPanel();
        alarmPanel = new AlarmPanel();
        countdownPanel = new CountdownPanel();
        stopwatchPanel = new StopwatchPanel();

        // 添加选项卡
        tabbedPane.addTab("时间", clockPanel);
        tabbedPane.addTab("闹钟", alarmPanel);
        tabbedPane.addTab("倒计时", countdownPanel);
        tabbedPane.addTab("计时器", stopwatchPanel);

        add(tabbedPane);

        // 每秒更新一次时钟
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                clockPanel.repaint();
            }
        }, 0, 1000);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ClockApp app = new ClockApp();
            app.setVisible(true);
        });
    }

    // 时钟面板
    class ClockPanel extends JPanel {
        private SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
        private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy年MM月dd日 EEEE");

        public ClockPanel() {
            setLayout(new BorderLayout());
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            // 获取当前时间
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR);
            int minute = calendar.get(Calendar.MINUTE);
            int second = calendar.get(Calendar.SECOND);

            // 绘制数字时间
            String time = timeFormat.format(calendar.getTime());
            String date = dateFormat.format(calendar.getTime());

            g.setFont(new Font("Arial", Font.BOLD, 24));
            FontMetrics fm = g.getFontMetrics();
            int timeWidth = fm.stringWidth(time);
            g.drawString(time, (getWidth() - timeWidth) / 2, 50);

            g.setFont(new Font("Arial", Font.PLAIN, 16));
            fm = g.getFontMetrics();
            int dateWidth = fm.stringWidth(date);
            g.drawString(date, (getWidth() - dateWidth) / 2, 80);

            // 绘制圆形钟表
            int centerX = getWidth() / 2;
            int centerY = getHeight() / 2 + 30;
            int radius = Math.min(getWidth(), getHeight()) / 3;

            // 绘制表盘
            g.setColor(Color.BLACK);
            g.drawOval(centerX - radius, centerY - radius, 2 * radius, 2 * radius);

            // 绘制刻度
            for (int i = 0; i < 60; i++) {
                double angle = Math.toRadians(6 * i);
                int x1 = centerX + (int) (0.9 * radius * Math.sin(angle));
                int y1 = centerY - (int) (0.9 * radius * Math.cos(angle));
                int x2 = centerX + (int) (radius * Math.sin(angle));
                int y2 = centerY - (int) (radius * Math.cos(angle));

                if (i % 5 == 0) {
                    // 小时刻度
                    g.setColor(Color.BLACK);
                    g.drawLine(x1, y1, x2, y2);
                } else {
                    // 分钟刻度
                    g.setColor(Color.GRAY);
                    g.drawLine(x1, y1, x2, y2);
                }
            }

            // 绘制时针
            double hourAngle = Math.toRadians(30 * hour + 0.5 * minute);
            int hourHandLength = radius / 2;
            int hourX = centerX + (int) (hourHandLength * Math.sin(hourAngle));
            int hourY = centerY - (int) (hourHandLength * Math.cos(hourAngle));
            g.setColor(Color.BLACK);
            g.drawLine(centerX, centerY, hourX, hourY);

            // 绘制分针
            double minuteAngle = Math.toRadians(6 * minute + 0.1 * second);
            int minuteHandLength = 3 * radius / 4;
            int minuteX = centerX + (int) (minuteHandLength * Math.sin(minuteAngle));
            int minuteY = centerY - (int) (minuteHandLength * Math.cos(minuteAngle));
            g.setColor(Color.BLUE);
            g.drawLine(centerX, centerY, minuteX, minuteY);

            // 绘制秒针
            double secondAngle = Math.toRadians(6 * second);
            int secondHandLength = 4 * radius / 5;
            int secondX = centerX + (int) (secondHandLength * Math.sin(secondAngle));
            int secondY = centerY - (int) (secondHandLength * Math.cos(secondAngle));
            g.setColor(Color.RED);
            g.drawLine(centerX, centerY, secondX, secondY);

            // 绘制中心点
            g.setColor(Color.RED);
            g.fillOval(centerX - 5, centerY - 5, 10, 10);
        }
    }

    // 闹钟面板
    class AlarmPanel extends JPanel {
        private DefaultListModel<String> alarmListModel;
        private JList<String> alarmList;
        private JButton addButton;
        private JButton deleteButton;

        public AlarmPanel() {
            setLayout(new BorderLayout());

            alarmListModel = new DefaultListModel<>();
            alarmList = new JList<>(alarmListModel);
            add(new JScrollPane(alarmList), BorderLayout.CENTER);

            JPanel buttonPanel = new JPanel();
            addButton = new JButton("添加闹钟");
            deleteButton = new JButton("删除闹钟");

            addButton.addActionListener(e -> addAlarm());
            deleteButton.addActionListener(e -> deleteAlarm());

            buttonPanel.add(addButton);
            buttonPanel.add(deleteButton);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        private void addAlarm() {
            JSpinner hourSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 23, 1));
            JSpinner minuteSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));

            JPanel panel = new JPanel(new GridLayout(2, 2));
            panel.add(new JLabel("小时:"));
            panel.add(hourSpinner);
            panel.add(new JLabel("分钟:"));
            panel.add(minuteSpinner);

            int result = JOptionPane.showConfirmDialog(null, panel, "设置闹钟",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                int hour = (Integer) hourSpinner.getValue();
                int minute = (Integer) minuteSpinner.getValue();
                alarmListModel.addElement(String.format("%02d:%02d", hour, minute));
            }
        }

        private void deleteAlarm() {
            int selectedIndex = alarmList.getSelectedIndex();
            if (selectedIndex != -1) {
                alarmListModel.remove(selectedIndex);
            }
        }
    }

    // 倒计时面板
    class CountdownPanel extends JPanel {
        private JSpinner hourSpinner;
        private JSpinner minuteSpinner;
        private JSpinner secondSpinner;
        private JButton startButton;
        private JButton stopButton;
        private JLabel countdownLabel;
        private java.util.Timer countdownTimer;
        private int remainingSeconds;

        public CountdownPanel() {
            setLayout(new BorderLayout());

            JPanel inputPanel = new JPanel(new GridLayout(3, 2));
            hourSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 23, 1));
            minuteSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));
            secondSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));

            inputPanel.add(new JLabel("小时:"));
            inputPanel.add(hourSpinner);
            inputPanel.add(new JLabel("分钟:"));
            inputPanel.add(minuteSpinner);
            inputPanel.add(new JLabel("秒:"));
            inputPanel.add(secondSpinner);

            JPanel buttonPanel = new JPanel();
            startButton = new JButton("开始");
            stopButton = new JButton("停止");
            stopButton.setEnabled(false);

            startButton.addActionListener(e -> startCountdown());
            stopButton.addActionListener(e -> stopCountdown());

            buttonPanel.add(startButton);
            buttonPanel.add(stopButton);

            countdownLabel = new JLabel("00:00:00", SwingConstants.CENTER);
            countdownLabel.setFont(new Font("Arial", Font.BOLD, 24));

            add(inputPanel, BorderLayout.NORTH);
            add(countdownLabel, BorderLayout.CENTER);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        private void startCountdown() {
            int hours = (Integer) hourSpinner.getValue();
            int minutes = (Integer) minuteSpinner.getValue();
            int seconds = (Integer) secondSpinner.getValue();

            remainingSeconds = hours * 3600 + minutes * 60 + seconds;
            updateCountdownLabel();

            startButton.setEnabled(false);
            stopButton.setEnabled(true);

            countdownTimer = new java.util.Timer();
            countdownTimer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    if (remainingSeconds > 0) {
                        remainingSeconds--;
                        SwingUtilities.invokeLater(() -> updateCountdownLabel());
                    } else {
                        stopCountdown();
                        JOptionPane.showMessageDialog(null, "倒计时结束!");
                    }
                }
            }, 1000, 1000);
        }

        private void stopCountdown() {
            if (countdownTimer != null) {
                countdownTimer.cancel();
                countdownTimer = null;
            }
            startButton.setEnabled(true);
            stopButton.setEnabled(false);
        }

        private void updateCountdownLabel() {
            int hours = remainingSeconds / 3600;
            int minutes = (remainingSeconds % 3600) / 60;
            int seconds = remainingSeconds % 60;
            countdownLabel.setText(String.format("%02d:%02d:%02d", hours, minutes, seconds));
        }
    }

    // 计时器面板
    class StopwatchPanel extends JPanel {
        private JLabel timeLabel;
        private JButton startButton;
        private JButton stopButton;
        private JButton resetButton;
        private Timer stopwatchTimer;
        private long startTime;
        private boolean isRunning;

        public StopwatchPanel() {
            setLayout(new BorderLayout());

            timeLabel = new JLabel("00:00:00.000", SwingConstants.CENTER);
            timeLabel.setFont(new Font("Arial", Font.BOLD, 24));
            add(timeLabel, BorderLayout.CENTER);

            JPanel buttonPanel = new JPanel();
            startButton = new JButton("开始");
            stopButton = new JButton("停止");
            resetButton = new JButton("重置");
            stopButton.setEnabled(false);

            startButton.addActionListener(e -> startStopwatch());
            stopButton.addActionListener(e -> stopStopwatch());
            resetButton.addActionListener(e -> resetStopwatch());

            buttonPanel.add(startButton);
            buttonPanel.add(stopButton);
            buttonPanel.add(resetButton);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        private void startStopwatch() {
            if (!isRunning) {
                startTime = System.currentTimeMillis() - (isRunning ? 0 : startTime);
                isRunning = true;
                startButton.setEnabled(false);
                stopButton.setEnabled(true);

                stopwatchTimer = new Timer(10, e -> {
                    long elapsed = System.currentTimeMillis() - startTime;
                    updateStopwatchLabel(elapsed);
                });
                stopwatchTimer.start();
            }
        }

        private void stopStopwatch() {
            if (isRunning) {
                stopwatchTimer.stop();
                isRunning = false;
                startButton.setEnabled(true);
                stopButton.setEnabled(false);
            }
        }

        private void resetStopwatch() {
            stopwatchTimer.stop();
            isRunning = false;
            startTime = 0;
            startButton.setEnabled(true);
            stopButton.setEnabled(false);
            timeLabel.setText("00:00:00.000");
        }

        private void updateStopwatchLabel(long elapsed) {
            long hours = elapsed / 3600000;
            long minutes = (elapsed % 3600000) / 60000;
            long seconds = (elapsed % 60000) / 1000;
            long millis = elapsed % 1000;
            timeLabel.setText(String.format("%02d:%02d:%02d.%03d", hours, minutes, seconds, millis));
        }
    }
}*/

class Loading {// 加载动画

    private JFrame frame;
    private JPanel panel;
    private int angle = 0;
    private javax.swing.Timer timer;

    public Loading() {
        initUI();
    }

    private void initUI() {
        frame = new JFrame("加载中");
        frame.setSize(200, 200);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setAlwaysOnTop(true);

        panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);

                int centerX = getWidth() / 2;
                int centerY = getHeight() / 2;
                int radius = 50;

                // 绘制圆环背景
                g2d.setColor(Color.LIGHT_GRAY);
                g2d.setStroke(new BasicStroke(2));
                g2d.drawOval(centerX - radius, centerY - radius,
                        radius * 2, radius * 2);

                // 绘制加载圆弧（3/4圆）
                g2d.setColor(Color.BLUE);
                g2d.setStroke(new BasicStroke(5));
                g2d.drawArc(centerX - radius, centerY - radius,
                        radius * 2, radius * 2, angle, 270);
            }
        };
        panel.setBackground(Color.WHITE);
        frame.add(panel);

        // 定时器控制动画旋转
        timer = new javax.swing.Timer(50, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                angle = (angle + 10) % 360; // 每次旋转5°
                panel.repaint();
            }
        });
        timer.start();
    }

    public void show() {
        frame.setVisible(true);
    }

    public void close() {
        timer.stop();
        frame.dispose();
    }

}

class Winllx7 extends JFrame {// 白板
    private DrawingPanel drawingPanel;
    private Color penColor = Color.BLACK; // 保存画笔颜色
    private Color currentColor = Color.BLACK;
    private int currentSize = 5;
    private boolean isEraser = false;
    private Stack<ShapeInfo> history = new Stack<>();
    private Stack<ShapeInfo> redoStack = new Stack<>();
    private Path2D.Double currentPath;

    private JButton undoBtn; // 对撤销按钮的引用
    private JButton redoBtn; // 对恢复按钮的引用

    Winllx7() {
        initUI();
        setVisible(true);
    }

    private void initUI() {
        setTitle("白板");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel borderPanel = new JPanel(new BorderLayout());
        borderPanel.setBorder(BorderFactory.createMatteBorder(10, 10, 10, 10, new Color(70, 130, 180))); // 钢蓝色边框

        // 工具栏
        JPanel toolBar = createToolBar();
        borderPanel.add(toolBar, BorderLayout.NORTH);

        // 绘制区域
        drawingPanel = new DrawingPanel();
        JScrollPane scrollPane = new JScrollPane(drawingPanel); // 添加滚动条
        borderPanel.add(scrollPane, BorderLayout.CENTER);

        JButton exitBtn = new JButton("退出");
        exitBtn.addActionListener(e -> System.exit(0));
        borderPanel.add(exitBtn, BorderLayout.SOUTH);

        add(borderPanel);
    }

    private JPanel createToolBar() {
        JPanel toolBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        toolBar.setBackground(new Color(230, 230, 250));

        // 颜色按钮
        JButton colorBtn = new JButton("颜色");
        colorBtn.addActionListener(e -> {
            Color newColor = JColorChooser.showDialog(null, "选择颜色", penColor);
            if (newColor != null) {
                penColor = newColor;
                currentColor = penColor;
                isEraser = false;
            }
        });

        // 大小选择
        String[] sizes = { "1", "3", "5", "8", "10", "15", "20" };
        JComboBox<String> sizeCombo = new JComboBox<>(sizes);
        sizeCombo.setSelectedIndex(2);
        sizeCombo.addActionListener(e -> currentSize = Integer.parseInt((String) sizeCombo.getSelectedItem()));

        // 橡皮擦
        JButton eraserBtn = new JButton("橡皮擦");
        eraserBtn.addActionListener(e -> {
            isEraser = true;
            currentColor = drawingPanel.getBackground();
        });

        // 画笔按钮
        JButton penBtn = new JButton("画笔");
        penBtn.addActionListener(e -> {
            isEraser = false;
            currentColor = penColor;
        });

        // 撤销/恢复
        undoBtn = new JButton("撤销");
        undoBtn.addActionListener(e -> undo());
        redoBtn = new JButton("恢复");
        redoBtn.addActionListener(e -> redo());

        // 清空画布
        JButton clearBtn = new JButton("清空");
        clearBtn.addActionListener(e -> {
            if (!history.isEmpty()) {
                redoStack.push(new ShapeInfo(true)); // 记录清空操作
            }
            history.clear();
            drawingPanel.repaint();
            updateButtonStates(); // 更新按钮状态
        });

        // 添加到工具栏
        toolBar.add(colorBtn);
        toolBar.add(new JLabel("粗细:"));
        toolBar.add(sizeCombo);
        toolBar.add(penBtn);
        toolBar.add(eraserBtn);
        toolBar.add(undoBtn);
        toolBar.add(redoBtn);
        toolBar.add(clearBtn);

        updateButtonStates(); // 初始化按钮状态

        return toolBar;
    }

    private void undo() {
        if (!history.isEmpty()) {
            redoStack.push(history.pop());
            drawingPanel.repaint();
            updateButtonStates(); // 更新按钮状态
        }
    }

    private void redo() {
        if (!redoStack.isEmpty()) {
            ShapeInfo top = redoStack.pop();
            if (top.isClear) {
                history.clear();
            } else {
                history.push(top);
            }
            drawingPanel.repaint();
            updateButtonStates(); // 更新按钮状态
        }
    }

    private void updateButtonStates() {
        undoBtn.setEnabled(!history.isEmpty());
        redoBtn.setEnabled(!redoStack.isEmpty());
    }

    private class DrawingPanel extends JPanel {
        public DrawingPanel() {
            setBackground(Color.WHITE);
            setPreferredSize(new Dimension(2000, 2000));

            MouseAdapter adapter = new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    currentPath = new Path2D.Double();
                    currentPath.moveTo(e.getX(), e.getY());
                }

                public void mouseDragged(MouseEvent e) {
                    currentPath.lineTo(e.getX(), e.getY());
                    repaint();
                }

                public void mouseReleased(MouseEvent e) {
                    if (currentPath != null) {
                        history.push(new ShapeInfo(currentPath,
                                isEraser ? getBackground() : currentColor,
                                currentSize, false));
                        redoStack.clear();
                    }
                }
            };

            addMouseListener(adapter);
            addMouseMotionListener(adapter);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);

            // 绘制历史记录
            for (ShapeInfo shape : history) {
                if (shape.isClear) {
                    clear(); // 清空画布逻辑
                } else {
                    g2d.setColor(shape.color);
                    g2d.setStroke(new BasicStroke(shape.size));
                    g2d.draw(shape.path);
                }
            }
            // 绘制当前路径
            if (currentPath != null) {
                g2d.setColor(isEraser ? getBackground() : currentColor);
                g2d.setStroke(new BasicStroke(currentSize));
                g2d.draw(currentPath);
            }
        }

        // 清空画布逻辑（可通过添加特殊ShapeInfo触发）
        private void clear() {
            history.clear();
        }
    }

    private static class ShapeInfo {
        Path2D.Double path;
        Color color;
        int size;
        boolean isClear; // 是否表示清空操作

        ShapeInfo(Path2D.Double path, Color color, int size, boolean isClear) {
            this.path = path;
            this.color = color;
            this.size = size;
            this.isClear = isClear;
        }

        ShapeInfo(boolean isClear) { // 用于清空操作的构造器
            this.isClear = isClear;
        }
    }
}