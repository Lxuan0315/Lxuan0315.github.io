package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FadingLabel extends JLabel {
    private float alpha = 1.0f;
    private Timer fadeTimer;
    private Color baseColor;
    private boolean isFading = false;
    private long animSequence = 0;

    public FadingLabel(String text) {
        super(text);
        baseColor = getForeground();
    }

    public void fadeOut(int duration) {
        long seq = ++animSequence;
        if (fadeTimer != null && fadeTimer.isRunning()) {
            fadeTimer.stop();
        }
        isFading = true;
        final int steps = Math.max(1, duration / 16);
        final float delta = alpha / steps;
        fadeTimer = new Timer(16, e -> {
            if (animSequence != seq) return;
            alpha -= delta;
            if (alpha <= 0.01f) {
                alpha = 0f;
                fadeTimer.stop();
                isFading = false;
            }
            updateForeground();
            repaint();
        });
        fadeTimer.start();
    }

    public void fadeIn(int duration) {
        long seq = ++animSequence;
        if (fadeTimer != null && fadeTimer.isRunning()) {
            fadeTimer.stop();
        }
        isFading = true;
        final int steps = Math.max(1, duration / 16);
        final float delta = (1.0f - alpha) / steps;
        fadeTimer = new Timer(16, e -> {
            if (animSequence != seq) return;
            alpha += delta;
            if (alpha >= 0.99f) {
                alpha = 1.0f;
                fadeTimer.stop();
                isFading = false;
            }
            updateForeground();
            repaint();
        });
        updateForeground();
        repaint();
        if (getParent() != null) {
            getParent().repaint();
        }
        fadeTimer.start();
    }

    private void updateForeground() {
        int r = baseColor.getRed();
        int g = baseColor.getGreen();
        int b = baseColor.getBlue();
        int a = Math.max(0, Math.min(255, (int) (alpha * 255)));
        super.setForeground(new Color(r, g, b, a));
    }

    @Override
    public void setForeground(Color c) {
        baseColor = c;
        if (!isFading) {
            super.setForeground(c);
        } else {
            updateForeground();
        }
    }

    public float getAlpha() {
        return alpha;
    }

    public void setAlpha(float alpha) {
        this.alpha = alpha;
        updateForeground();
        repaint();
    }
}
