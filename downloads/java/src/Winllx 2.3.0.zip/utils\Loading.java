package utils;

import javax.swing.*;
import java.awt.*;

public class Loading {
    private JFrame frame;
    
    public Loading() {
        frame = new JFrame("Loading...");
        frame.setSize(300, 150);
        frame.setLocationRelativeTo(null);
        frame.setUndecorated(true);
        frame.getContentPane().setBackground(Color.WHITE);
        frame.setLayout(new BorderLayout());
        
        JLabel label = new JLabel("Loading...", JLabel.CENTER);
        label.setFont(new Font("Microsoft YaHei", Font.BOLD, 16));
        frame.add(label, BorderLayout.CENTER);
    }
    
    public void show() {
        frame.setVisible(true);
    }
    
    public void close() {
        frame.dispose();
    }
}
