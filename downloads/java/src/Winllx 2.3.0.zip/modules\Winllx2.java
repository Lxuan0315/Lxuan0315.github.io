package modules;

import app.Winllx;
import utils.*;
import javax.swing.*;
import java.awt.*;

public class Winllx2 {
    public Winllx2() {
        JFrame frame = WinllxIcon.createFrame(LangManager.getString("module.note"));
        frame.setSize(500, 400);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());
        
        JTextArea textArea = new JTextArea();
        textArea.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        frame.add(new JScrollPane(textArea), BorderLayout.CENTER);
        
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
