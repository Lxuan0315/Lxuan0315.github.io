package utils;

import java.io.*;
import java.util.*;

public class LangManager {
    private static final String WINLLX_DIR = System.getProperty("user.dir") + "/Winllx";
    private static final String SETTINGS_FILE = WINLLX_DIR + "/app_settings.properties";
    private static final String LANG_DIR = System.getProperty("user.dir") + "/lang";

    private static Properties strings = new Properties();
    private static String currentLang = "zh";

    public static void init() {
        currentLang = loadLangFromConfig();
        loadLanguage(currentLang);
    }

    public static void setLanguage(String lang) {
        if (!lang.equals(currentLang)) {
            currentLang = lang;
            loadLanguage(lang);
            saveLangToConfig(lang);
        }
    }

    public static String getCurrentLang() { return currentLang; }

    public static String getString(String key) {
        return strings.getProperty(key, "[" + key + "]");
    }

    public static String getString(String key, Object... args) {
        String pattern = getString(key);
        try { return String.format(pattern, args); } catch (Exception e) { return pattern; }
    }

    private static void loadLanguage(String lang) {
        strings.clear();
        String filePath = LANG_DIR + "/strings_" + lang + ".properties";
        File file = new File(filePath);
        System.out.println("[LangManager] 尝试加载: " + file.getAbsolutePath());
        System.out.println("[LangManager] 文件是否存在: " + file.exists());
        if (file.exists()) {
            try (InputStreamReader isr = new InputStreamReader(new FileInputStream(file), "UTF-8")) {
                strings.load(isr);
                System.out.println("[LangManager] 加载成功，key 数量: " + strings.size());
                System.out.println("[LangManager] app.title = " + strings.getProperty("app.title"));
            } catch (IOException e) {
                System.err.println("加载语言文件失败: " + filePath);
            }
        } else {
            System.err.println("语言文件不存在: " + filePath);
        }
    }

    private static String loadLangFromConfig() {
        try {
            File f = new File(SETTINGS_FILE);
            if (f.exists()) {
                Properties p = new Properties();
                p.load(new FileInputStream(f));
                return p.getProperty("language", "zh");
            }
        } catch (Exception e) {}
        return "zh";
    }

    private static void saveLangToConfig(String lang) {
        try {
            File dir = new File(WINLLX_DIR);
            if (!dir.exists()) dir.mkdirs();
            Properties p = new Properties();
            File f = new File(SETTINGS_FILE);
            if (f.exists()) p.load(new FileInputStream(f));
            p.setProperty("language", lang);
            p.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        } catch (Exception e) {
            System.err.println("保存语言配置失败: " + e.getMessage());
        }
    }
}
