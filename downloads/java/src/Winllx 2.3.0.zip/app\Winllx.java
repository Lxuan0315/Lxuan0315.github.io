package app;

import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.Point;
import java.awt.PopupMenu;
import java.awt.Robot;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.Window;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.InputMismatchException;
import java.util.Properties;
import java.util.Scanner;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import ui.*;
import utils.*;
import modules.*;

public class Winllx {
    private static String APP_TITLE = "Winllx";
    private static final Color DEFAULT_BG = Color.WHITE;
    private static final String TRAY_ICON_PATH = "C:/Users/86132/Desktop/java.png";
    private static final String SETTINGS_FILE = System.getProperty("user.dir") + "/Winllx/app_settings.properties";
    private static final int[][] MIND_GROUPS = new int[][]{{1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31}, {2, 3, 6, 7, 10, 11, 14, 15, 18, 19, 22, 23, 26, 27, 30, 31}, {4, 5, 6, 7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31}, {8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29, 30, 31}, {16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31}};
    private static final int[] MIND_WEIGHTS = new int[]{1, 2, 4, 8, 16};
    private static boolean trayEnabled = true;
    private static TrayIcon trayIcon;
    private static JFrame mainFrame;
    
    private static final int GRID_CELL_WIDTH = 120;
    private static final int GRID_CELL_HEIGHT = 100;
    private static final int GRID_PADDING_X = 50;
    private static final int GRID_PADDING_Y = 120;
    private static GridLayoutManager gridManager;
    
    private static DraggableButton noteBtn;
    private static DraggableButton calcBtn;
    private static DraggableButton fileBtn;
    private static DraggableButton mindBtn;
    private static DraggableButton sysMonBtn;
    private static DraggableButton boardBtn;
    private static DraggableButton clockBtn;
    private static DraggableButton weatherBtn;
    private static DraggableButton minimizeBtn;
    private static DraggableButton settingsBtn;
    private static DraggableButton exitBtn;
    
    private static JLabel timeLabel;
    private static JLabel dateLabel;

    public static void main(String[] stringArray) {
        LangManager.init();
        Loading loading = new Loading();
        loading.show();
        WinllxIcon.init();
        Winllx.initMainWindow();
        SwingUtilities.invokeLater(() -> {
            Winllx.buildDesktopUI();
            Winllx.applySavedTextColor(Winllx.loadTextColor());
            Winllx.initSystemTray();
            loading.close();
        });
    }

    public static void setMainVisible(boolean bl) {
        if (mainFrame != null) {
            mainFrame.setVisible(bl);
        }
    }

    public static Color getMainBackgroundColor() {
        if (mainFrame != null) {
            return mainFrame.getContentPane().getBackground();
        }
        return DEFAULT_BG;
    }

    private static void initMainWindow() {
        APP_TITLE = LangManager.getString("app.title");
        mainFrame = new JFrame(APP_TITLE);
        Color color = Winllx.loadBackgroundColor();
        mainFrame.getContentPane().setBackground(color);
        mainFrame.setExtendedState(6);
        mainFrame.setLayout(null);
        mainFrame.setDefaultCloseOperation(3);
        WinllxIcon.applyToFrame(mainFrame);
        JPanel gridOverlay = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (gridManager != null) {
                    Graphics2D g2d = (Graphics2D) g.create();
                    gridManager.drawGrid(g2d);
                    g2d.dispose();
                }
            }
        };
        gridOverlay.setOpaque(false);
        gridOverlay.setBounds(0, 0, 9999, 9999);
        mainFrame.add(gridOverlay);
        mainFrame.setVisible(true);
        mainFrame.addComponentListener(new ComponentAdapter(){

            @Override
            public void componentResized(ComponentEvent componentEvent) {
                Winllx.updateLayout();
            }

            @Override
            public void componentShown(ComponentEvent componentEvent) {
                Winllx.updateLayout();
            }
        });
    }

    private static void applySavedTextColor(Color color) {
        for (Component component : mainFrame.getContentPane().getComponents()) {
            if (component instanceof JLabel) {
                ((JLabel)component).setForeground(color);
                continue;
            }
            if (component instanceof GlassButton) {
                ((GlassButton)component).setTextColor(color);
                continue;
            }
            if (!(component instanceof AbstractButton)) continue;
            ((AbstractButton)component).setForeground(color);
        }
        mainFrame.repaint();
    }

    private static void buildDesktopUI() {
        Winllx.initGridManager();
        Winllx.addDesktopLabels();
        Winllx.addDesktopButtons();
        Winllx.updateLayout();
    }

    private static void initGridManager() {
        gridManager = new GridLayoutManager(
                mainFrame.getContentPane().getWidth(),
                mainFrame.getContentPane().getHeight(),
                GRID_CELL_WIDTH, GRID_CELL_HEIGHT,
                GRID_PADDING_X, GRID_PADDING_Y
        );
        gridManager.setGridAlpha(Winllx.loadGridAlpha());
    }

    private static void addDesktopLabels() {
        timeLabel = new JLabel();
        timeLabel.setFont(new Font("Microsoft YaHei", 1, 36));
        dateLabel = new JLabel();
        dateLabel.setFont(new Font("Microsoft YaHei", 0, 14));
        Winllx.addToMain(timeLabel, dateLabel);
        Winllx.updateDateTime();
        Timer timer = new Timer(1000, actionEvent -> Winllx.updateDateTime());
        timer.start();
        Winllx.updateLayout();
    }

    private static void updateDateTime() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm");
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("MM\u6708dd\u65e5 EEEE");
        timeLabel.setText(simpleDateFormat.format(calendar.getTime()));
        dateLabel.setText(simpleDateFormat2.format(calendar.getTime()));
    }

    private static void updateLayout() {
        int n;
        FontMetrics fontMetrics;
        int n3 = mainFrame.getContentPane().getWidth();
        int n4 = mainFrame.getContentPane().getHeight();
        
        if (gridManager != null) {
            gridManager.setContainerSize(n3, n4);
        }

        if (timeLabel != null) {
            fontMetrics = timeLabel.getFontMetrics(timeLabel.getFont());
            n = fontMetrics.stringWidth(timeLabel.getText());
            timeLabel.setBounds((n3 - n) / 2, 10, n + 20, 50);
        }
        if (dateLabel != null) {
            fontMetrics = dateLabel.getFontMetrics(dateLabel.getFont());
            n = fontMetrics.stringWidth(dateLabel.getText());
            dateLabel.setBounds((n3 - n) / 2, 50, n + 20, 30);
        }
        
        DraggableButton[] allButtons = {noteBtn, calcBtn, fileBtn, mindBtn, sysMonBtn,
                                         boardBtn, clockBtn, weatherBtn, settingsBtn, exitBtn, minimizeBtn};

        int buttonsPerRow = Math.max(1, (n3 - GRID_PADDING_X * 2) / GRID_CELL_WIDTH);

        for (int i = 0; i < allButtons.length; i++) {
            if (allButtons[i] == null) continue;

            if (!allButtons[i].isDragging()) {
                int gx = allButtons[i].getGridX();
                int gy = allButtons[i].getGridY();

                if (gx < 0 || gy < 0) {
                    gx = i % buttonsPerRow;
                    gy = i / buttonsPerRow;
                    allButtons[i].setGridPosition(gx, gy);
                }

                Point pos = gridManager.getGridPosition(gx, gy);
                allButtons[i].setBounds(pos.x, pos.y, GRID_CELL_WIDTH, GRID_CELL_HEIGHT);
                allButtons[i].setGridManager(gridManager);
            }
        }

        mainFrame.repaint();
    }

    private static void addDesktopButtons() {
        noteBtn = Winllx.createDraggableButton(LangManager.getString("module.note"), 80, 80, actionEvent -> new Winllx2());
        calcBtn = Winllx.createDraggableButton(LangManager.getString("module.calc"), 80, 80, actionEvent -> new Winllx3());
        fileBtn = Winllx.createDraggableButton(LangManager.getString("module.file"), 80, 80, actionEvent -> new Winllx4());
        mindBtn = Winllx.createDraggableButton(LangManager.getString("module.mind"), 80, 80, actionEvent -> Winllx.launchMindReading());
        sysMonBtn = Winllx.createDraggableButton(LangManager.getString("module.sysmon"), 80, 80, actionEvent -> new WinllxSysMon());
        boardBtn = Winllx.createDraggableButton(LangManager.getString("module.board"), 80, 80, actionEvent -> new Winllx7());
        clockBtn = Winllx.createDraggableButton(LangManager.getString("module.clock"), 80, 80, actionEvent -> SwingUtilities.invokeLater(() -> new Winllx5().setVisible(true)));
        weatherBtn = Winllx.createDraggableButton(LangManager.getString("module.weather"), 80, 80, actionEvent -> new WinllxWeather());
        settingsBtn = Winllx.createDraggableButton(LangManager.getString("btn.settings"), 80, 80, actionEvent -> Winllx.openSettings());
        exitBtn = Winllx.createDraggableButton(LangManager.getString("btn.exit"), 80, 80, actionEvent -> new Winllx0());
        minimizeBtn = Winllx.createDraggableButton(LangManager.getString("btn.minimize"), 80, 80, actionEvent -> Winllx.setMainVisible(false));

        Winllx.addToMain(noteBtn, calcBtn, fileBtn, mindBtn, sysMonBtn, boardBtn, 
                         clockBtn, weatherBtn, settingsBtn, exitBtn, minimizeBtn);

        DraggableButton[] all = {noteBtn, calcBtn, fileBtn, mindBtn, sysMonBtn, 
                                  boardBtn, clockBtn, weatherBtn, settingsBtn, exitBtn, minimizeBtn};
        for (DraggableButton btn : all) {
            btn.setOnCollisionCheck((gx, gy) -> {
                for (DraggableButton other : all) {
                    if (other != btn && other != null 
                        && other.getGridX() >= 0 && other.getGridY() >= 0
                        && other.getGridX() == gx && other.getGridY() == gy) {
                        return true;
                    }
                }
                return false;
            });
        }
    }

    private static JLabel createLabel(String string, int n, int n2, int n3, int n4, float f) {
        JLabel jLabel = new JLabel(string);
        jLabel.setBounds(n, n2, n3, n4);
        if (f > 0.0f) {
            jLabel.setFont(jLabel.getFont().deriveFont(f));
        }
        return jLabel;
    }

    private static DraggableButton createDraggableButton(String string, int width, int height, ActionListener actionListener) {
        DraggableButton button = new DraggableButton(string, width, height);
        button.setBounds(0, 0, width, height);
        if (actionListener != null) {
            button.addActionListener(actionListener);
        }
        return button;
    }

    private static void addToMain(JComponent ... jComponentArray) {
        for (JComponent jComponent : jComponentArray) {
            mainFrame.add(jComponent);
        }
    }

    private static void launchMindReading() {
        Winllx.setMainVisible(false);
        JOptionPane.showMessageDialog(null, LangManager.getString("msg.start.success"));
        System.out.println(LangManager.getString("mind.welcome"));
        System.out.println(LangManager.getString("mind.choose"));
        System.out.println(LangManager.getString("mind.warning"));
        System.out.println(LangManager.getString("mind.press.enter"));
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();
        int n = 0;
        for (int i = 0; i < MIND_GROUPS.length; ++i) {
            System.out.println(LangManager.getString("mind.group.ask"));
            if (!Winllx.askGroup(scanner, MIND_GROUPS[i])) continue;
            n += MIND_WEIGHTS[i];
        }
        JOptionPane.showMessageDialog(null, String.format(LangManager.getString("mind.result"), n));
        Winllx.setMainVisible(true);
    }

    private static boolean askGroup(Scanner scanner, int[] nArray) {
        System.out.print(LangManager.getString("mind.group.label"));
        for (int n : nArray) {
            System.out.print(n + " ");
        }
        System.out.println("\n" + LangManager.getString("mind.group.prompt"));
        try {
            return scanner.nextInt() == 1;
        }
        catch (InputMismatchException inputMismatchException) {
            scanner.next();
            System.out.println(LangManager.getString("mind.input.invalid"));
            return false;
        }
    }

    private static void openSettings() {
        JFrame jFrame = WinllxIcon.createFrame(LangManager.getString("app.settings.title"));
        jFrame.setSize(380, 620);
        Point settingsPos = Winllx.loadSettingsPosition();
        jFrame.setLocation(settingsPos.x, settingsPos.y);
        jFrame.setLayout(null);
        jFrame.getContentPane().setBackground(Winllx.getMainBackgroundColor().darker());
        JLabel jLabel = new JLabel(LangManager.getString("setting.language"));
        jLabel.setBounds(10, 0, 80, 30);
        jFrame.add(jLabel);
        String[] stringArray = new String[]{LangManager.getString("lang.zh"), LangManager.getString("lang.zh_tw"), LangManager.getString("lang.en")};
        GlassSegmentedControl glassSegmentedControl = new GlassSegmentedControl(stringArray);
        glassSegmentedControl.setBounds(10, 30, 300, 60);
        String string2 = LangManager.getCurrentLang();
        int n2 = string2.equals("zh_tw") ? 1 : (string2.equals("en") ? 2 : 0);
        glassSegmentedControl.setSelectedIndex(n2);
        glassSegmentedControl.addSelectionListener((n, string) -> {
            String lang = n == 0 ? "zh" : (n == 1 ? "zh_tw" : "en");
            LangManager.setLanguage(lang);
            JOptionPane.showMessageDialog(jFrame, LangManager.getString("msg.lang.changed"), LangManager.getString("dialog.tip"), 1);
        });
        jFrame.add(glassSegmentedControl);
        JLabel jLabel2 = new JLabel(LangManager.getString("setting.theme"));
        jLabel2.setBounds(10, 100, 80, 30);
        jFrame.add(jLabel2);
        String[] stringArray2 = new String[]{LangManager.getString("setting.theme.white"), LangManager.getString("setting.theme.black"), LangManager.getString("setting.theme.custom")};
        GlassSegmentedControl glassSegmentedControl2 = new GlassSegmentedControl(stringArray2);
        glassSegmentedControl2.setBounds(10, 130, 300, 60);
        Color color = mainFrame.getContentPane().getBackground();
        int n3 = 0;
        if (color.equals(Color.BLACK)) {
            n3 = 1;
        } else if (!color.equals(Color.WHITE)) {
            n3 = 2;
        }
        glassSegmentedControl2.setSelectedIndex(n3);
        glassSegmentedControl2.addSelectionListener((n, string) -> {
            if (n == 2) {
                ColorPicker colorPicker = new ColorPicker((Window)jFrame, mainFrame.getContentPane().getBackground());
                colorPicker.addColorListener(selectedColor -> {
                    mainFrame.getContentPane().setBackground(selectedColor);
                    Winllx.saveBackgroundColor(selectedColor);
                    Winllx.syncTextColor();
                    mainFrame.repaint();
                });
                colorPicker.setVisible(true);
            } else {
                Winllx.applyTheme(n);
            }
        });
        jFrame.add(glassSegmentedControl2);
        JLabel jLabel3 = new JLabel(LangManager.getString("setting.icon.theme"));
        jLabel3.setBounds(10, 200, 80, 30);
        jFrame.add(jLabel3);
        String[] stringArray3 = new String[]{LangManager.getString("setting.icon.light"), LangManager.getString("setting.icon.dark")};
        GlassSegmentedControl glassSegmentedControl3 = new GlassSegmentedControl(stringArray3);
        glassSegmentedControl3.setBounds(10, 230, 200, 60);
        glassSegmentedControl3.setSelectedIndex(WinllxIcon.getCurrentTheme());
        JPanel jPanel = new JPanel();
        jPanel.setBounds(220, 200, 140, 120);
        jPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(100, 100, 100)), LangManager.getString("setting.icon.compare")));
        jPanel.setLayout(new GridLayout(2, 1, 5, 5));
        JPanel jPanel2 = new JPanel(new BorderLayout());
        jPanel2.setBackground(Color.WHITE);
        jPanel2.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        JLabel jLabel4 = new JLabel();
        jLabel4.setHorizontalAlignment(0);
        Image image = WinllxIcon.getIconImage(0);
        if (image != null) {
            jLabel4.setIcon(new ImageIcon(image.getScaledInstance(32, 32, 4)));
        }
        jPanel2.add((Component)jLabel4, "Center");
        JLabel jLabel5 = new JLabel(LangManager.getString("setting.icon.light"), 0);
        jLabel5.setFont(new Font("\u5fae\u8f6f\u96c5\u9ed1", 0, 10));
        jPanel2.add((Component)jLabel5, "South");
        jPanel.add(jPanel2);
        JPanel jPanel3 = new JPanel(new BorderLayout());
        jPanel3.setBackground(Color.BLACK);
        jPanel3.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        JLabel jLabel6 = new JLabel();
        jLabel6.setHorizontalAlignment(0);
        Image image2 = WinllxIcon.getIconImage(1);
        if (image2 != null) {
            jLabel6.setIcon(new ImageIcon(image2.getScaledInstance(32, 32, 4)));
        }
        jPanel3.add((Component)jLabel6, "Center");
        JLabel jLabel7 = new JLabel(LangManager.getString("setting.icon.dark"), 0);
        jLabel7.setFont(new Font("\u5fae\u8f6f\u96c5\u9ed1", 0, 10));
        jLabel7.setForeground(Color.WHITE);
        jPanel3.add((Component)jLabel7, "South");
        jPanel.add(jPanel3);
        jFrame.add(jPanel);
        glassSegmentedControl3.addSelectionListener((n, string) -> {
            WinllxIcon.setTheme(n);
            WinllxIcon.applyToFrame(mainFrame);
            WinllxIcon.applyToFrame(jFrame);
        });
        jFrame.add(glassSegmentedControl3);
        JLabel iconFailLabel = new JLabel(LangManager.getString("icon.load.fail"));
        iconFailLabel.setForeground(Color.RED);
        iconFailLabel.setFont(new Font("微软雅黑", 0, 12));
        iconFailLabel.setBounds(10, 290, 300, 20);
        iconFailLabel.setVisible(WinllxIcon.isAnyIconFailed());
        jFrame.add(iconFailLabel);
        GlassButton glassButton = GlassButton.createButton(LangManager.getString("btn.test"), 180, 40);
        glassButton.setBounds(10, 315, 180, 40);
        glassButton.addActionListener(actionEvent -> {
            JFrame jFrame2 = WinllxIcon.createFrame("\u56fe\u6807\u6d4b\u8bd5\u7a97\u53e3 - " + (WinllxIcon.getCurrentTheme() == 0 ? LangManager.getString("setting.icon.light") : LangManager.getString("setting.icon.dark")));
            jFrame2.setSize(300, 200);
            jFrame2.setLocationRelativeTo(jFrame);
            jFrame2.setLayout(new BorderLayout());
            JLabel label = new JLabel(LangManager.getString("setting.icon.theme") + "\uff1a" + (WinllxIcon.getCurrentTheme() == 0 ? LangManager.getString("setting.icon.light") : LangManager.getString("setting.icon.dark")), 0);
            label.setFont(new Font("\u5fae\u8f6f\u96c5\u9ed1", 1, 16));
            jFrame2.add((Component)label, "Center");
            jFrame2.setDefaultCloseOperation(2);
            jFrame2.setVisible(true);
        });
        jFrame.add(glassButton);
        JLabel jLabel8 = new JLabel(LangManager.getString("setting.volume"));
        jLabel8.setBounds(10, 350, 120, 30);
        jFrame.add(jLabel8);
        GlassSlider[] glassSliderArray = new GlassSlider[1];
        int n4 = Winllx.getSystemVolume();
        glassSliderArray[0] = GlassSlider.create(jFrame, 0, 360, 200, 50, n4, changeEvent -> {
            int n = glassSliderArray[0].getValue();
            Winllx.setSystemVolume(n);
        });
        glassSliderArray[0].setBounds(10, 380, 200, 50);
        jFrame.add(glassSliderArray[0]);
        JLabel jLabel9 = new JLabel(LangManager.getString("setting.grid"));
        jLabel9.setBounds(10, 440, 200, 30);
        jFrame.add(jLabel9);
        String[] gridOptions = {LangManager.getString("setting.grid.hide"), LangManager.getString("setting.grid.show")};
        GlassSegmentedControl gridSegmented = new GlassSegmentedControl(gridOptions);
        gridSegmented.setBounds(10, 470, 300, 60);
        int gridAlphaVal = gridManager != null ? gridManager.getGridAlpha() : 0;
        gridSegmented.setSelectedIndex(gridAlphaVal > 0 ? 1 : 0);
        gridSegmented.addSelectionListener((n, string) -> {
            int alpha = n == 0 ? 0 : 100;
            if (gridManager != null) {
                gridManager.setGridAlpha(alpha);
                mainFrame.repaint();
            }
            Winllx.saveGridAlpha(alpha);
        });
        jFrame.add(gridSegmented);
        jFrame.setDefaultCloseOperation(2);
        jFrame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                Winllx.saveSettingsPosition(jFrame.getLocation());
            }
        });
        jFrame.setVisible(true);
    }

    private static Color getContrastColor(Color color) {
        if (color == null) {
            return Color.BLACK;
        }
        double d = 0.2126 * (double)color.getRed() + 0.7152 * (double)color.getGreen() + 0.0722 * (double)color.getBlue();
        return d < 128.0 ? Color.WHITE : Color.BLACK;
    }

    private static void updateIconPreview(JLabel jLabel, int n) {
        Image image = WinllxIcon.getIconImage(n);
        if (image != null) {
            Image image2 = image.getScaledInstance(80, 80, 4);
            jLabel.setIcon(new ImageIcon(image2));
        } else {
            jLabel.setIcon(null);
            jLabel.setText(n == 0 ? LangManager.getString("setting.icon.light") : LangManager.getString("setting.icon.dark"));
        }
    }

    private static void syncTextColor() {
        Color color = mainFrame.getContentPane().getBackground();
        Color color2 = Winllx.getContrastColor(color);
        for (Component component : mainFrame.getContentPane().getComponents()) {
            if (component instanceof JLabel) {
                ((JLabel)component).setForeground(color2);
                continue;
            }
            if (component instanceof GlassButton) {
                ((GlassButton)component).setTextColor(color2);
                continue;
            }
            if (!(component instanceof AbstractButton)) continue;
            ((AbstractButton)component).setForeground(color2);
        }
        mainFrame.repaint();
    }

    private static void applyTheme(int n) {
        Color color = switch (n) {
            case 1 -> Color.BLACK;
            case 2 -> Color.BLUE;
            default -> Color.WHITE;
        };
        mainFrame.getContentPane().setBackground(color);
        Winllx.saveBackgroundColor(color);
        Winllx.syncTextColor();
        mainFrame.repaint();
    }

    private static Color loadBackgroundColor() {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                String string = properties.getProperty("bgColor");
                if (string != null && !string.isEmpty()) {
                    return Winllx.hexToColor(string);
                }
            }
        }
        catch (Exception exception) {
        }
        return DEFAULT_BG;
    }

    private static Color loadTextColor() {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                String string = properties.getProperty("textColor");
                if ("white".equalsIgnoreCase(string)) {
                    return Color.WHITE;
                }
            }
        }
        catch (Exception exception) {
        }
        return Color.BLACK;
    }

    private static int loadGridAlpha() {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                String string = properties.getProperty("gridAlpha");
                if (string != null && !string.isEmpty()) {
                    return Math.max(0, Math.min(100, Integer.parseInt(string)));
                }
            }
        }
        catch (Exception exception) {
        }
        return 0;
    }

    private static void saveGridAlpha(int alpha) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            File f = new File(SETTINGS_FILE);
            if (f.exists()) {
                properties.load(new FileInputStream(f));
            }
            properties.setProperty("gridAlpha", String.valueOf(alpha));
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static Point loadSettingsPosition() {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                String x = properties.getProperty("settingsX");
                String y = properties.getProperty("settingsY");
                if (x != null && y != null) {
                    return new Point(Integer.parseInt(x), Integer.parseInt(y));
                }
            }
        }
        catch (Exception exception) {
        }
        return new Point(0, 0);
    }

    private static void saveSettingsPosition(Point pos) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            File f = new File(SETTINGS_FILE);
            if (f.exists()) {
                properties.load(new FileInputStream(f));
            }
            properties.setProperty("settingsX", String.valueOf(pos.x));
            properties.setProperty("settingsY", String.valueOf(pos.y));
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static void saveBackgroundColor(Color color) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            properties.setProperty("bgColor", Winllx.colorToHex(color));
            properties.setProperty("textColor", Winllx.getContrastColor(color) == Color.WHITE ? "white" : "black");
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static String colorToHex(Color color) {
        return String.format("#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
    }

    private static Color hexToColor(String string) {
        if (string.startsWith("#")) {
            string = string.substring(1);
        }
        if (string.length() == 6) {
            int n = Integer.parseInt(string.substring(0, 2), 16);
            int n2 = Integer.parseInt(string.substring(2, 4), 16);
            int n3 = Integer.parseInt(string.substring(4, 6), 16);
            return new Color(n, n2, n3);
        }
        return DEFAULT_BG;
    }

    private static void initSystemTray() {
        if (!trayEnabled || !SystemTray.isSupported()) {
            return;
        }
        SystemTray systemTray = SystemTray.getSystemTray();
        Image image = Toolkit.getDefaultToolkit().getImage(TRAY_ICON_PATH);
        PopupMenu popupMenu = new PopupMenu();
        MenuItem menuItem = new MenuItem(LangManager.getString("tray.open"));
        MenuItem menuItem2 = new MenuItem(LangManager.getString("tray.settings"));
        MenuItem menuItem3 = new MenuItem(LangManager.getString("tray.exit"));
        popupMenu.add(menuItem);
        popupMenu.addSeparator();
        popupMenu.add(menuItem2);
        popupMenu.addSeparator();
        popupMenu.add(menuItem3);
        trayIcon = new TrayIcon(image, APP_TITLE, popupMenu);
        trayIcon.setImageAutoSize(true);
        menuItem.addActionListener(actionEvent -> Winllx.setMainVisible(true));
        menuItem2.addActionListener(actionEvent -> Winllx.openSettings());
        menuItem3.addActionListener(actionEvent -> {
            systemTray.remove(trayIcon);
            System.exit(0);
        });
        trayIcon.addActionListener(actionEvent -> Winllx.setMainVisible(true));
        try {
            systemTray.add(trayIcon);
        }
        catch (AWTException aWTException) {
            System.err.println(LangManager.getString("msg.tray.error"));
        }
    }

    private static void setSystemVolume(int n) {
        Winllx.setSystemVolumeRobot(n);
    }

    private static int getSystemVolume() {
        return 50;
    }

    private static void setSystemVolumeRobot(int n) {
        try {
            int n2;
            Robot robot = new Robot();
            int n3 = Math.max(0, Math.min(100, n));
            for (n2 = 0; n2 < 50; ++n2) {
                robot.keyPress(174);
                robot.keyRelease(174);
                Thread.sleep(5L);
            }
            for (n2 = 0; n2 < n3 / 2; ++n2) {
                robot.keyPress(175);
                robot.keyRelease(175);
                Thread.sleep(5L);
            }
        }
        catch (Exception exception) {
            JOptionPane.showMessageDialog(mainFrame, LangManager.getString("msg.volume.error"), LangManager.getString("dialog.tip"), 2);
        }
    }

    public static void showNotification(String string, String string2) {
        if (trayIcon != null) {
            trayIcon.displayMessage(string, string2, TrayIcon.MessageType.INFO);
        }
    }
}
