package ui;

import javax.swing.JComponent;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;

public class GridLayoutManager {

    private int cols;
    private int rows;
    private int cellWidth;
    private int cellHeight;
    private int paddingX;
    private int paddingY;
    private int containerWidth;
    private int containerHeight;
    private int gridAlpha = 100;

    public GridLayoutManager(int containerWidth, int containerHeight, 
                             int cellWidth, int cellHeight, 
                             int paddingX, int paddingY) {
        this.containerWidth = containerWidth;
        this.containerHeight = containerHeight;
        this.cellWidth = cellWidth;
        this.cellHeight = cellHeight;
        this.paddingX = paddingX;
        this.paddingY = paddingY;
        calculateGridSize();
    }

    public void setContainerSize(int width, int height) {
        this.containerWidth = width;
        this.containerHeight = height;
        calculateGridSize();
    }

    private void calculateGridSize() {
        cols = Math.max(1, (containerWidth - paddingX * 2) / cellWidth);
        rows = Math.max(1, (containerHeight - paddingY) / cellHeight);
    }

    public int getCols() {
        return cols;
    }

    public int getRows() {
        return rows;
    }

    public int getCellWidth() {
        return cellWidth;
    }

    public int getCellHeight() {
        return cellHeight;
    }

    public Point getGridPosition(int gridX, int gridY) {
        int x = paddingX + gridX * cellWidth;
        int y = paddingY + gridY * cellHeight;
        return new Point(x, y);
    }

    public Point getNearestGridPoint(int x, int y) {
        int gridX = Math.max(0, Math.min(cols - 1, (x - paddingX) / cellWidth));
        int gridY = Math.max(0, Math.min(rows - 1, (y - paddingY) / cellHeight));
        return getGridPosition(gridX, gridY);
    }

    public Point getNearestGridPoint(JComponent component) {
        int centerX = component.getX() + component.getWidth() / 2;
        int centerY = component.getY() + component.getHeight() / 2;
        return getNearestGridPoint(centerX, centerY);
    }

    public Rectangle getCellBounds(int gridX, int gridY) {
        Point pos = getGridPosition(gridX, gridY);
        return new Rectangle(pos.x, pos.y, cellWidth, cellHeight);
    }

    public boolean isWithinGrid(int x, int y) {
        return x >= paddingX && x <= paddingX + cols * cellWidth &&
               y >= paddingY && y <= paddingY + rows * cellHeight;
    }

    public boolean isValidGridPosition(int gridX, int gridY) {
        return gridX >= 0 && gridX < cols && gridY >= 0 && gridY < rows;
    }

    public Point getGridIndex(int x, int y) {
        int gridX = (x - paddingX) / cellWidth;
        int gridY = (y - paddingY) / cellHeight;
        return new Point(gridX, gridY);
    }

    public void drawGrid(Graphics2D g2d) {
        if (gridAlpha <= 0) return;
        g2d.setColor(new Color(200, 200, 200, gridAlpha));
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                Point p = getGridPosition(col, row);
                g2d.drawRect(p.x, p.y, cellWidth, cellHeight);
            }
        }
    }

    public void setGridAlpha(int gridAlpha) {
        this.gridAlpha = Math.max(0, Math.min(255, gridAlpha));
    }

    public int getGridAlpha() {
        return gridAlpha;
    }
}
