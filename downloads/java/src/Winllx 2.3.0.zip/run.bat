@echo off
cd /d "%~dp0"

echo ========================================
echo        Winllx Build and Run
echo ========================================
echo.

echo [1/2] Compiling...
javac -encoding UTF-8 -cp . app\*.java ui\*.java utils\*.java modules\*.java
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Compile failed!
    echo.
    pause
    exit /b 1
)
echo       Compile OK.
echo.

echo [2/2] Running...
echo ========================================
echo.
java -cp . app.Winllx

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Program exited abnormally.
    pause
)
