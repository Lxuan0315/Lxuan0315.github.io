package modules;

import app.Winllx;
import ui.*;
import utils.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Path2D;
import java.util.Stack;

public class Winllx7 extends JFrame { // 白板
    private Winllx mainWindow; // 引用主程序窗口
    private DrawingPanel drawingPanel;
    private Color penColor = Color.BLACK; // 保存画笔颜色
    private Color currentColor = Color.BLACK;
    private int currentSize = 5;
    private boolean isEraser = false;
    private Stack<ShapeInfo> history = new Stack<>();
    private Stack<ShapeInfo> redoStack = new Stack<>();
    private Path2D.Double currentPath;

    private GlassButton undoBtn; // 对撤销按钮的引用
    private GlassButton redoBtn; // 对恢复按钮的引用

    public Winllx7() {
        initUI();
        // 应用图标
        WinllxIcon.applyToFrame(this);
        setVisible(true);
    }

    private void initUI() {
        setTitle("白板");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel borderPanel = new JPanel(new BorderLayout());
        borderPanel.setBorder(BorderFactory.createMatteBorder(10, 10, 10, 10, new Color(70, 130, 180))); // 钢蓝色边框

        // 工具栏
        JPanel toolBar = createToolBar();
        borderPanel.add(toolBar, BorderLayout.NORTH);

        // 绘制区域
        drawingPanel = new DrawingPanel();
        JScrollPane scrollPane = new JScrollPane(drawingPanel); // 添加滚动条
        borderPanel.add(scrollPane, BorderLayout.CENTER);

        GlassButton exitBtn = GlassButton.createButton("退出", 100, 35);
        exitBtn.addActionListener(e -> {
            dispose(); // 销毁当前窗口
            Winllx.setMainVisible(true);
        });
        borderPanel.add(exitBtn, BorderLayout.SOUTH);

        add(borderPanel);
    }

    private JPanel createToolBar() {
        JPanel toolBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        toolBar.setBackground(Winllx.getMainBackgroundColor());

        // 颜色按钮
        GlassButton colorBtn = GlassButton.createButton("颜色", 80, 32);
        colorBtn.addActionListener(e -> {
            Color newColor = JColorChooser.showDialog(null, "选择颜色", penColor);
            if (newColor != null) {
                penColor = newColor;
                currentColor = penColor;
                isEraser = false;
            }
        });

        // 大小选择
        String[] sizes = { "1", "3", "5", "8", "10", "15", "20" };
        JComboBox<String> sizeCombo = new JComboBox<>(sizes);
        sizeCombo.setSelectedIndex(2);
        sizeCombo.addActionListener(e -> currentSize = Integer.parseInt((String) sizeCombo.getSelectedItem()));

        // 橡皮擦
        GlassButton eraserBtn = GlassButton.createButton("橡皮擦", 80, 32);
        eraserBtn.addActionListener(e -> {
            isEraser = true;
            currentColor = drawingPanel.getBackground();
        });

        // 画笔按钮
        GlassButton penBtn = GlassButton.createButton("画笔", 80, 32);
        penBtn.addActionListener(e -> {
            isEraser = false;
            currentColor = penColor;
        });

        // 撤销/恢复
        undoBtn = GlassButton.createButton("撤销", 80, 32);
        undoBtn.addActionListener(e -> undo());
        redoBtn = GlassButton.createButton("恢复", 80, 32);
        redoBtn.addActionListener(e -> redo());

        // 清空画布
        GlassButton clearBtn = GlassButton.createButton("清空", 80, 32);
        clearBtn.addActionListener(e -> {
            if (!history.isEmpty()) {
                redoStack.push(new ShapeInfo(true)); // 记录清空操作
            }
            history.clear();
            drawingPanel.repaint();
            updateButtonStates(); // 更新按钮状态
        });

        // 添加到工具栏
        toolBar.add(colorBtn);
        toolBar.add(new JLabel("粗细:"));
        toolBar.add(sizeCombo);
        toolBar.add(penBtn);
        toolBar.add(eraserBtn);
        toolBar.add(undoBtn);
        toolBar.add(redoBtn);
        toolBar.add(clearBtn);

        updateButtonStates(); // 初始化按钮状态

        return toolBar;
    }

    private void undo() {
        if (!history.isEmpty()) {
            redoStack.push(history.pop());
            drawingPanel.repaint();
            updateButtonStates(); // 更新按钮状态
        }
    }

    private void redo() {
        if (!redoStack.isEmpty()) {
            ShapeInfo top = redoStack.pop();
            if (top.isClear) {
                history.clear();
            } else {
                history.push(top);
            }
            drawingPanel.repaint();
            updateButtonStates(); // 更新按钮状态
        }
    }

    private void updateButtonStates() {
        undoBtn.setEnabled(!history.isEmpty());
        redoBtn.setEnabled(!redoStack.isEmpty());
    }

    private class DrawingPanel extends JPanel {
        public DrawingPanel() {
            setBackground(Color.WHITE);
            setPreferredSize(new Dimension(2000, 2000));

            MouseAdapter adapter = new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    currentPath = new Path2D.Double();
                    currentPath.moveTo(e.getX(), e.getY());
                }

                public void mouseDragged(MouseEvent e) {
                    currentPath.lineTo(e.getX(), e.getY());
                    repaint();
                }

                public void mouseReleased(MouseEvent e) {
                    if (currentPath != null) {
                        history.push(new ShapeInfo(currentPath,
                                isEraser ? getBackground() : currentColor,
                                currentSize, false));
                        redoStack.clear();
                    }
                }
            };

            addMouseListener(adapter);
            addMouseMotionListener(adapter);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);

            // 绘制历史记录
            for (ShapeInfo shape : history) {
                if (shape.isClear) {
                    clear(); // 清空画布逻辑
                } else {
                    g2d.setColor(shape.color);
                    g2d.setStroke(new BasicStroke(shape.size));
                    g2d.draw(shape.path);
                }
            }
            // 绘制当前路径
            if (currentPath != null) {
                g2d.setColor(isEraser ? getBackground() : currentColor);
                g2d.setStroke(new BasicStroke(currentSize));
                g2d.draw(currentPath);
            }
        }

        // 清空画布逻辑（可通过添加特殊ShapeInfo触发）
        private void clear() {
            history.clear();
        }
    }

    private static class ShapeInfo {
        Path2D.Double path;
        Color color;
        int size;
        boolean isClear; // 是否表示清空操作

        ShapeInfo(Path2D.Double path, Color color, int size, boolean isClear) {
            this.path = path;
            this.color = color;
            this.size = size;
            this.isClear = isClear;
        }

        ShapeInfo(boolean isClear) { // 用于清空操作的构造器
            this.isClear = isClear;
        }
    }
}
