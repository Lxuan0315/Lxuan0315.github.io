package utils;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Properties;
import javax.swing.*;

/**
 * Winllx 图标主题管理类
 * 负责加载、切换、保存图标主题配置
 */
public class WinllxIcon {

    // 图标主题常量
    public static final int THEME_LIGHT = 0;  // 浅色主题
    public static final int THEME_DARK = 1;   // 深色主题

    // 配置文件路径 - 与其他配置文件同目录不同文件
    private static final String WINLLX_DIR = System.getProperty("user.dir") + "/Winllx";
    private static final String ICON_CONFIG_FILE = WINLLX_DIR + "/icon_settings.properties";

    // 图标文件路径
    private static final String ICON_LIGHT_PATH = System.getProperty("user.dir") + "/icon/icon-light.png";
    private static final String ICON_DARK_PATH = System.getProperty("user.dir") + "/icon/icon-dark.png";

    // 当前图标主题
    private static int currentTheme = THEME_LIGHT;

    // 缓存的图标图像
    private static Image lightIcon = null;
    private static Image darkIcon = null;

    // 图标加载失败标记
    private static boolean lightIconFailed = false;
    private static boolean darkIconFailed = false;

    /**
     * 初始化图标管理器
     * 加载配置并预加载图标
     */
    public static void init() {
        loadConfig();
        preloadIcons();
    }

    /**
     * 获取当前图标主题
     */
    public static int getCurrentTheme() {
        return currentTheme;
    }

    /**
     * 设置图标主题并保存配置
     * @param theme 主题索引 (THEME_LIGHT 或 THEME_DARK)
     */
    public static void setTheme(int theme) {
        if (theme == THEME_LIGHT || theme == THEME_DARK) {
            int oldTheme = currentTheme;
            currentTheme = theme;
            saveConfig();
            System.out.println("图标主题已更新: " + (oldTheme == THEME_LIGHT ? "浅色" : "深色") + " -> " + (theme == THEME_LIGHT ? "浅色" : "深色"));
            System.out.println("当前图标路径: " + getCurrentIconPath());
        }
    }

    /**
     * 获取当前主题的图标图像
     */
    public static Image getCurrentIconImage() {
        return getIconImage(currentTheme);
    }

    /**
     * 获取指定主题的图标图像
     */
    public static Image getIconImage(int theme) {
        if (theme == THEME_LIGHT) {
            return lightIcon;
        } else {
            return darkIcon;
        }
    }

    /**
     * 应用图标到 JFrame 窗口
     * @param frame 要设置图标的窗口
     */
    public static void applyToFrame(JFrame frame) {
        applyToFrame(frame, currentTheme);
    }

    /**
     * 应用指定主题的图标到 JFrame 窗口
     */
    public static void applyToFrame(JFrame frame, int theme) {
        if (frame == null) return;
        Image icon = getIconImage(theme);
        if (icon == null) {
            System.err.println("警告: 图标未加载，使用默认图标");
            return;
        }
        java.util.List<Image> icons = new java.util.ArrayList<>();
        icons.add(icon.getScaledInstance(16, 16, Image.SCALE_SMOOTH));
        icons.add(icon.getScaledInstance(32, 32, Image.SCALE_SMOOTH));
        icons.add(icon.getScaledInstance(48, 48, Image.SCALE_SMOOTH));
        frame.setIconImages(icons);
        frame.invalidate();
        frame.repaint();
    }

    /**
     * 创建一个带图标的 JFrame
     * 使用当前主题的图标
     * @param title 窗口标题
     * @return 带图标的 JFrame
     */
    public static JFrame createFrame(String title) {
        JFrame frame = new JFrame(title);
        applyToFrame(frame);
        return frame;
    }

    /**
     * 获取当前主题的图标路径
     */
    public static String getCurrentIconPath() {
        return currentTheme == THEME_LIGHT ? ICON_LIGHT_PATH : ICON_DARK_PATH;
    }

    /**
     * 检查当前主题的图标是否加载失败
     */
    public static boolean isCurrentIconFailed() {
        return currentTheme == THEME_LIGHT ? lightIconFailed : darkIconFailed;
    }

    /**
     * 检查是否有任何图标加载失败
     */
    public static boolean isAnyIconFailed() {
        return lightIconFailed || darkIconFailed;
    }

    /**
     * 获取主题名称 (用于显示)
     */
    public static String getThemeName(int theme) {
        return theme == THEME_LIGHT ? LangManager.getString("setting.icon.light") : LangManager.getString("setting.icon.dark");
    }

    /**
     * 预加载图标图像到内存
     */
    private static void preloadIcons() {
        lightIcon = loadIcon(ICON_LIGHT_PATH, true);
        darkIcon = loadIcon(ICON_DARK_PATH, false);
    }

    private static Image loadIcon(String path, boolean isLight) {
        try {
            File file = new File(path);
            if (!file.exists()) {
                if (isLight) {
                    lightIconFailed = true;
                } else {
                    darkIconFailed = true;
                }
                return null;
            }
            BufferedImage image = javax.imageio.ImageIO.read(file);
            if (image == null) {
                if (isLight) {
                    lightIconFailed = true;
                } else {
                    darkIconFailed = true;
                }
                return null;
            }
            return image;
        } catch (Exception e) {
            if (isLight) {
                lightIconFailed = true;
            } else {
                darkIconFailed = true;
            }
            return null;
        }
    }

    /**
     * 从配置文件读取图标主题设置
     */
    private static void loadConfig() {
        try {
            File configFile = new File(ICON_CONFIG_FILE);
            if (configFile.exists()) {
                Properties props = new Properties();
                props.load(new FileInputStream(configFile));
                String themeStr = props.getProperty("iconTheme");
                if (themeStr != null) {
                    currentTheme = Integer.parseInt(themeStr);
                }
            }
        } catch (Exception e) {
            // 配置读取失败，使用默认值
            currentTheme = THEME_LIGHT;
        }
    }

    /**
     * 保存图标主题设置到配置文件
     */
    private static void saveConfig() {
        try {
            File dir = new File(WINLLX_DIR);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            Properties props = new Properties();
            props.setProperty("iconTheme", String.valueOf(currentTheme));

            FileOutputStream fos = new FileOutputStream(ICON_CONFIG_FILE);
            props.store(fos, "Winllx Icon Theme Settings");
            fos.close();
        } catch (Exception e) {
            System.err.println(LangManager.getString("icon.save.fail") + ": " + e.getMessage());
        }
    }
}
