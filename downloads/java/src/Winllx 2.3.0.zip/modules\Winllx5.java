package modules;

import app.Winllx;
import utils.*;
import javax.swing.*;
import java.awt.*;

public class Winllx5 extends JFrame {
    public Winllx5() {
        super(LangManager.getString("module.clock"));
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        
        JLabel label = new JLabel("Clock", JLabel.CENTER);
        label.setFont(new Font("Microsoft YaHei", Font.BOLD, 24));
        add(label, BorderLayout.CENTER);
        
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
