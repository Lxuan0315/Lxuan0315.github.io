import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Winllx3 {

    private static final int WIN_W = 270;
    private static final int WIN_H = 480;
    private static final int BTN_SIZE = 50;
    private static final int COL1 = 10, COL2 = 70, COL3 = 130, COL4 = 190;
    private static final int ROW1 = 65, ROW2 = 130, ROW3 = 195, ROW4 = 260, ROW5 = 325;

    private static final Color COLOR_ACCENT = Color.ORANGE;
    private static final Color COLOR_RESULT = Color.CYAN;
    private static final Color COLOR_DEFAULT = Color.WHITE;

    private static final Object[][] BTN_LAYOUT = {
        {"C", COL1, ROW1}, {"%", COL2, ROW1}, {"⬅", COL3, ROW1}, {"÷", COL4, ROW1},
        {"7", COL1, ROW2}, {"8", COL2, ROW2}, {"9", COL3, ROW2}, {"×", COL4, ROW2},
        {"4", COL1, ROW3}, {"5", COL2, ROW3}, {"6", COL3, ROW3}, {"-", COL4, ROW3},
        {"1", COL1, ROW4}, {"2", COL2, ROW4}, {"3", COL3, ROW4}, {"+", COL4, ROW4},
        {"0", COL1, ROW5}, {".", COL2, ROW5}, {"00", COL3, ROW5}, {"=", COL4, ROW5},
    };

    private static final String OPS = "+-×÷";
    private JFrame frame;

    public Winllx3() {
        frame = WinllxIcon.createFrame("计算器");
        frame.setLayout(null);
        frame.setSize(WIN_W, WIN_H);
        frame.setResizable(false);
        frame.getContentPane().setBackground(Winllx.getMainBackgroundColor());

        JTextArea display = new JTextArea();
        display.setLineWrap(true);
        display.setBounds(0, 0, 240, 50);
        display.setBackground(Winllx.getMainBackgroundColor());
        frame.add(display);

        for (Object[] cfg : BTN_LAYOUT) {
            String label = (String) cfg[0];
            int x = (int) cfg[1];
            int y = (int) cfg[2];

            JButton btn = GlassButtonDemo.createButton(label);
            btn.setBounds(x, y, BTN_SIZE, BTN_SIZE);
            btn.setFont(new Font("微软雅黑", Font.BOLD, 16));
            switch (label) {
                case "C" -> btn.setBackground(COLOR_ACCENT);
                case "=" -> btn.setBackground(COLOR_RESULT);
                default -> btn.setBackground(COLOR_DEFAULT);
            }

            btn.addActionListener(e -> handleButton(label, display));
            frame.add(btn);
        }

        JButton settingsBtn = GlassButtonDemo.createButton("设置");
        settingsBtn.setBounds(10, 385, 230, 35);
        settingsBtn.setFont(new Font("微软雅黑", Font.BOLD, 14));
        settingsBtn.setBackground(new Color(200, 200, 200));
        settingsBtn.addActionListener(e -> openSettings());
        frame.add(settingsBtn);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }

    private void openSettings() {
        JFrame dialog = WinllxIcon.createFrame("计算器设置");
        dialog.setSize(350, 220);
        dialog.setLocationRelativeTo(frame);
        dialog.setLayout(null);
        dialog.getContentPane().setBackground(Winllx.getMainBackgroundColor().darker());

        JLabel title = new JLabel("计算器模式");
        title.setFont(new Font("微软雅黑", Font.BOLD, 16));
        title.setForeground(Color.WHITE);
        title.setBounds(20, 10, 200, 30);
        dialog.add(title);

        String[] modes = {"标准", "科学"};
        GlassSegmentedControl selector = new GlassSegmentedControl(modes);
        selector.setBounds(20, 50, 300, 60);
        selector.setSelectedIndex(0);
        selector.addSelectionListener((index, opt) -> {
            if (index == 1) {
                dialog.dispose();
                frame.dispose();
                new Winllx3Sci();
            }
        });
        dialog.add(selector);

        dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialog.setVisible(true);
    }

    private void handleButton(String label, JTextArea display) {
        switch (label) {
            case "C" -> display.setText("");
            case "⬅" -> {
                String t = display.getText();
                if (!t.isEmpty()) {
                    display.setText(t.substring(0, t.length() - 1));
                }
            }
            case "=" -> calculate(display);
            case "%" -> openPercentCalculator();
            case "+", "-", "×", "÷" -> appendOperator(label, display);
            default -> display.setText(display.getText() + label);
        }
    }

    private void appendOperator(String op, JTextArea display) {
        String text = display.getText();
        if (containsOperator(text) && !text.endsWith(OPS)) {
            JOptionPane.showMessageDialog(frame, "你已输入了一个运算符！");
            return;
        }
        if (op.equals("-") && (text.isEmpty() || isLastCharOperator(text))) {
            display.setText(text + "-");
            return;
        }
        display.setText(text + op);
    }

    private boolean containsOperator(String text) {
        if (text.isEmpty()) return false;
        int start = text.startsWith("-") ? 1 : 0;
        for (int i = start; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '-' && i > 0 && OPS.indexOf(text.charAt(i - 1)) >= 0) continue;
            if (OPS.indexOf(c) >= 0) return true;
        }
        return false;
    }

    private boolean isLastCharOperator(String text) {
        if (text.isEmpty()) return false;
        char last = text.charAt(text.length() - 1);
        return OPS.indexOf(last) >= 0;
    }

    private void calculate(JTextArea display) {
        String text = display.getText();
        if (text.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "请输入一个运算符！");
            return;
        }
        int opPos = -1;
        int start = text.startsWith("-") ? 1 : 0;
        for (int i = start; i < text.length(); i++) {
            if (OPS.indexOf(text.charAt(i)) >= 0) {
                opPos = i;
                break;
            }
        }
        if (opPos == -1) {
            JOptionPane.showMessageDialog(frame, "请输入一个运算符！");
            return;
        }
        try {
            double a = Double.parseDouble(text.substring(0, opPos));
            double b = Double.parseDouble(text.substring(opPos + 1));
            char op = text.charAt(opPos);
            double result = switch (op) {
                case '+' -> a + b;
                case '-' -> a - b;
                case '×' -> a * b;
                case '÷' -> b == 0 ? throwDivZero() : a / b;
                default -> 0;
            };
            display.setText(text + "=" + result);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "缺少操作数！\n请重新输入");
            display.setText("");
        }
    }

    private double throwDivZero() {
        JOptionPane.showMessageDialog(frame, "除数不能为0,请重新输入！");
        throw new ArithmeticException();
    }

    private void openPercentCalculator() {
        JFrame pFrame = WinllxIcon.createFrame("百分比专用计算器");
        pFrame.setLayout(null);
        pFrame.setSize(1000, 200);
        pFrame.getContentPane().setBackground(Winllx.getMainBackgroundColor());

        String[][] configs = {
            {"计算百分比值", "输入数值：", "输入百分比：", "value"},
            {"计算百分比增加", "输入数值：", "输入增加百分比：", "increase"},
            {"计算百分比减少", "输入数值：", "输入减少百分比：", "decrease"},
            {"计算百分比占比", "输入部分值：", "输入总值：", "ratio"},
            {"计算百分比变化", "输入旧值：", "输入新值：", "change"}
        };

        for (int i = 0; i < configs.length; i++) {
            String[] cfg = configs[i];
            JButton btn = GlassButtonDemo.createButton(cfg[0]);
            btn.setBounds(10 + (i % 3) * 210, 10 + (i / 3) * 50, 200, 30);
            btn.addActionListener(e -> openPercentDialog(cfg[0], cfg[1], cfg[2], cfg[3]));
            pFrame.add(btn);
        }

        pFrame.setVisible(true);
    }

    private void openPercentDialog(String title, String label1, String label2, String type) {
        JFrame dialog = WinllxIcon.createFrame(title);
        dialog.setLayout(null);
        dialog.setSize(320, 200);
        dialog.getContentPane().setBackground(Winllx.getMainBackgroundColor());

        JLabel l1 = new JLabel(label1);
        JTextField t1 = new JTextField();
        JLabel l2 = new JLabel(label2);
        JTextField t2 = new JTextField();
        JButton calc = GlassButtonDemo.createButton("计算");

        l1.setBounds(10, 10, 100, 20);
        t1.setBounds(110, 10, 100, 20);
        l2.setBounds(10, 40, 100, 20);
        t2.setBounds(110, 40, 100, 20);
        calc.setBounds(10, 70, 80, 20);

        calc.addActionListener(e -> {
            try {
                double n1 = Double.parseDouble(t1.getText());
                double n2 = Double.parseDouble(t2.getText());
                String result = switch (type) {
                    case "value" -> "结果：" + (n1 * n2 / 100);
                    case "increase" -> "结果：" + (n1 + n1 * n2 / 100);
                    case "decrease" -> "结果：" + (n1 - n1 * n2 / 100);
                    case "ratio" -> "结果：" + (n1 / n2 * 100) + "%";
                    case "change" -> "百分比变化：" + ((n1 - n2) / n2 * 100) + "%";
                    default -> "";
                };
                JOptionPane.showMessageDialog(dialog, result);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
            }
        });

        dialog.add(l1);
        dialog.add(t1);
        dialog.add(l2);
        dialog.add(t2);
        dialog.add(calc);
        dialog.setVisible(true);
    }
}
