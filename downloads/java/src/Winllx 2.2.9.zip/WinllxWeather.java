import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WinllxWeather {

    private static final long CACHE_DURATION_MS = 10 * 60 * 1000;

    private static final Map<String, String> WMO_ICON_MAP = new HashMap<>();
    static {
        WMO_ICON_MAP.put("0", "☀️"); WMO_ICON_MAP.put("1", "🌤️"); WMO_ICON_MAP.put("2", "⛅");
        WMO_ICON_MAP.put("3", "☁️"); WMO_ICON_MAP.put("45", "🌫️"); WMO_ICON_MAP.put("48", "🌫️");
        WMO_ICON_MAP.put("51", "🌦️"); WMO_ICON_MAP.put("53", "🌦️"); WMO_ICON_MAP.put("55", "🌧️");
        WMO_ICON_MAP.put("61", "🌧️"); WMO_ICON_MAP.put("63", "🌧️"); WMO_ICON_MAP.put("65", "🌧️");
        WMO_ICON_MAP.put("71", "🌨️"); WMO_ICON_MAP.put("73", "🌨️"); WMO_ICON_MAP.put("75", "🌨️");
        WMO_ICON_MAP.put("80", "🌦️"); WMO_ICON_MAP.put("81", "🌧️"); WMO_ICON_MAP.put("82", "🌧️");
        WMO_ICON_MAP.put("95", "⛈️"); WMO_ICON_MAP.put("96", "⛈️"); WMO_ICON_MAP.put("99", "⛈️");
    }

    private static final Map<String, String> WMO_TEXT_MAP = new HashMap<>();
    static {
        WMO_TEXT_MAP.put("0", "晴"); WMO_TEXT_MAP.put("1", "多云"); WMO_TEXT_MAP.put("2", "阴");
        WMO_TEXT_MAP.put("3", "阴"); WMO_TEXT_MAP.put("45", "雾"); WMO_TEXT_MAP.put("48", "雾");
        WMO_TEXT_MAP.put("51", "毛毛雨"); WMO_TEXT_MAP.put("53", "小雨"); WMO_TEXT_MAP.put("55", "中雨");
        WMO_TEXT_MAP.put("61", "小雨"); WMO_TEXT_MAP.put("63", "中雨"); WMO_TEXT_MAP.put("65", "大雨");
        WMO_TEXT_MAP.put("71", "小雪"); WMO_TEXT_MAP.put("73", "中雪"); WMO_TEXT_MAP.put("75", "大雪");
        WMO_TEXT_MAP.put("80", "阵雨"); WMO_TEXT_MAP.put("81", "中雨"); WMO_TEXT_MAP.put("82", "大雨");
        WMO_TEXT_MAP.put("95", "雷雨"); WMO_TEXT_MAP.put("96", "雷暴"); WMO_TEXT_MAP.put("99", "雷暴");
    }

    private JFrame frame;
    private JTextField searchField;
    private JComboBox<String> cityHistoryCombo;
    private JLabel statusLabel;
    private JLabel errorLabel;
    private JPanel tabPanel;
    private CardLayout cardLayout;
    private JPanel cardsPanel;

    private final String[] TAB_NAMES = {"实时", "7天预报", "24小时", "天文"};
    private int currentTabIndex = 0;
    private GlassSegmentedControl tabSlider;

    private JPanel currentWeatherPanel;
    private JPanel forecast7Panel;
    private JPanel forecast24Panel;
    private JPanel astronomyPanel;

    private String currentCityId = "39.9042,116.4074";
    private String currentCityName = "北京";
    private final List<String> cityHistory = new ArrayList<>();
    private final String HISTORY_FILE = System.getProperty("user.dir") + "/Winllx/weather_cities.txt";

    private String currentWeatherText = "";
    private String currentTemp = "";
    private String currentIcon = "";
    private boolean updatingCombo = false;

    private String lastJson = "";

    public WinllxWeather() {
        initUI();
        loadCityHistory();
        fetchAllData();
    }

    private void initUI() {
        Color bgColor = Winllx.getMainBackgroundColor();

        frame = WinllxIcon.createFrame("天气");
        frame.setSize(900, 650);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        // 使用渐变背景面板
        GradientPanel gradientPanel = new GradientPanel();
        gradientPanel.setLayout(new BorderLayout());
        frame.setContentPane(gradientPanel);

        JPanel topPanel = new JPanel(new BorderLayout(10, 0));
        topPanel.setOpaque(false);
        topPanel.setBorder(new EmptyBorder(10, 15, 10, 15));

        searchField = new JTextField();
        searchField.setPreferredSize(new Dimension(200, 35));
        searchField.setBackground(new Color(0x16213e));
        searchField.setForeground(Color.GRAY);
        searchField.setCaretColor(Color.WHITE);
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0x333333)),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));
        searchField.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        searchField.setText("输入城市名称...");
        searchField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if ("输入城市名称...".equals(searchField.getText())) {
                    searchField.setText("");
                    searchField.setForeground(Color.WHITE);
                }
            }
            @Override
            public void focusLost(FocusEvent e) {
                if (searchField.getText().isEmpty()) {
                    searchField.setText("输入城市名称...");
                    searchField.setForeground(Color.GRAY);
                }
            }
        });
        searchField.addActionListener(e -> doSearch());

        cityHistoryCombo = new JComboBox<>();
        cityHistoryCombo.setPreferredSize(new Dimension(120, 35));
        cityHistoryCombo.setBackground(new Color(0x16213e));
        cityHistoryCombo.setForeground(Color.WHITE);
        cityHistoryCombo.setFont(new Font("Microsoft YaHei", Font.PLAIN, 13));
        cityHistoryCombo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                setBackground(isSelected ? new Color(0xe94560) : new Color(0x16213e));
                setForeground(Color.WHITE);
                return this;
            }
        });
        cityHistoryCombo.addActionListener(e -> {
            if (updatingCombo) return;
            if (cityHistoryCombo.getSelectedIndex() > 0) {
                String selected = (String) cityHistoryCombo.getSelectedItem();
                if (selected != null && !selected.isEmpty()) {
                    searchField.setText(selected);
                    searchField.setForeground(Color.WHITE);
                    doSearch();
                }
            }
        });

        JPanel searchWrapper = new JPanel(new BorderLayout(5, 0));
        searchWrapper.setOpaque(false);
        searchWrapper.add(searchField, BorderLayout.CENTER);
        searchWrapper.add(cityHistoryCombo, BorderLayout.EAST);

        GlassButton searchBtn = GlassButton.createButton("搜索", 80, 35);
        searchBtn.addActionListener(e -> doSearch());

        GlassButton locateBtn = GlassButton.createButton("📍定位", 80, 35);
        locateBtn.addActionListener(e -> doLocate());

        GlassButton refreshBtn = GlassButton.createButton("刷新", 80, 35);
        refreshBtn.addActionListener(e -> fetchAllData());

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnPanel.setOpaque(false);
        btnPanel.add(searchBtn);
        btnPanel.add(locateBtn);
        btnPanel.add(refreshBtn);

        topPanel.add(searchWrapper, BorderLayout.CENTER);
        topPanel.add(btnPanel, BorderLayout.EAST);
        frame.add(topPanel, BorderLayout.NORTH);

        cardLayout = new CardLayout();
        cardsPanel = new JPanel(cardLayout);
        cardsPanel.setOpaque(false);

        currentWeatherPanel = createPanel(BoxLayout.Y_AXIS, 20, 30, 20, 30);
        forecast7Panel = createPanel(BoxLayout.Y_AXIS, 10, 20, 10, 20);
        forecast24Panel = new JPanel(new BorderLayout());
        forecast24Panel.setOpaque(false);
        forecast24Panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        astronomyPanel = createPanel(BoxLayout.Y_AXIS, 30, 30, 30, 30);

        cardsPanel.add(currentWeatherPanel, "0");
        cardsPanel.add(forecast7Panel, "1");
        cardsPanel.add(forecast24Panel, "2");
        cardsPanel.add(astronomyPanel, "3");

        frame.add(cardsPanel, BorderLayout.CENTER);

        tabPanel = new JPanel(new BorderLayout());
        tabPanel.setOpaque(false);
        tabPanel.setBorder(new EmptyBorder(5, 10, 5, 10));

        tabSlider = new GlassSegmentedControl(TAB_NAMES);
        tabSlider.setPreferredSize(new Dimension(400, 60));
        tabSlider.addSelectionListener((index, option) -> switchTab(index));
        tabPanel.add(tabSlider, BorderLayout.CENTER);

        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBackground(new Color(0x16213e));
        statusPanel.setPreferredSize(new Dimension(0, 30));

        statusLabel = new JLabel("数据来自 Open-Meteo | 实时");
        statusLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
        statusLabel.setForeground(new Color(0xa0a0a0));
        statusLabel.setBorder(new EmptyBorder(0, 10, 0, 10));

        errorLabel = new JLabel("");
        errorLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
        errorLabel.setForeground(Color.RED);
        errorLabel.setBorder(new EmptyBorder(0, 10, 0, 10));

        statusPanel.add(statusLabel, BorderLayout.WEST);
        statusPanel.add(errorLabel, BorderLayout.EAST);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setOpaque(false);
        bottomPanel.add(tabPanel, BorderLayout.CENTER);
        bottomPanel.add(statusPanel, BorderLayout.SOUTH);

        frame.add(bottomPanel, BorderLayout.SOUTH);
        frame.setVisible(true);
    }

    private JPanel createPanel(int axis, int t, int l, int b, int r) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, axis));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(t, l, b, r));
        return p;
    }

    private void switchTab(int index) {
        currentTabIndex = index;
        cardLayout.show(cardsPanel, String.valueOf(index));
        if (tabSlider != null) tabSlider.setSelectedIndex(index);
    }

    private void doSearch() {
        String city = searchField.getText().trim();
        if (city.isEmpty() || "输入城市名称...".equals(city)) return;
        searchCityAndLoad(city);
    }

    private void doLocate() {
        new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    String json = httpGetString("http://ip-api.com/json/?lang=zh-CN&fields=city");
                    String city = extractString(json, "city");
                    if (city != null && !city.isEmpty()) {
                        SwingUtilities.invokeLater(() -> {
                            searchField.setText(city);
                            searchField.setForeground(Color.WHITE);
                            searchCityAndLoad(city);
                        });
                    } else {
                        SwingUtilities.invokeLater(() -> showError("定位失败：无法获取城市"));
                    }
                } catch (Exception ex) {
                    SwingUtilities.invokeLater(() -> showError("定位失败：" + ex.getMessage()));
                }
                return null;
            }
        }.execute();
    }

    private void searchCityAndLoad(String cityName) {
        errorLabel.setText("");
        new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    String encoded = URLEncoder.encode(cityName, StandardCharsets.UTF_8);
                    String url = "https://geocoding-api.open-meteo.com/v1/search?name=" + encoded + "&count=5&language=zh&format=json";
                    String json = httpGetString(url);
                    String results = extractArray(json, "results");

                    if (results == null && cityName.endsWith("市")) {
                        String cityName2 = cityName.substring(0, cityName.length() - 1);
                        String encoded2 = URLEncoder.encode(cityName2, StandardCharsets.UTF_8);
                        String url2 = "https://geocoding-api.open-meteo.com/v1/search?name=" + encoded2 + "&count=5&language=zh&format=json";
                        json = httpGetString(url2);
                        results = extractArray(json, "results");
                    }

                    if (results == null) {
                        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(frame, "未找到该城市", "提示", JOptionPane.WARNING_MESSAGE));
                        return null;
                    }
                    List<String> items = splitJsonArray(results);
                    if (items.isEmpty()) {
                        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(frame, "未找到该城市", "提示", JOptionPane.WARNING_MESSAGE));
                        return null;
                    }
                    String first = items.get(0);
                    String lat = extractString(first, "latitude");
                    String lon = extractString(first, "longitude");
                    String name = extractString(first, "name");
                    if (lat == null || lon == null) {
                        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(frame, "未找到该城市", "提示", JOptionPane.WARNING_MESSAGE));
                        return null;
                    }
                    currentCityId = lat + "," + lon;
                    currentCityName = name != null ? name : cityName;
                    addCityToHistory(currentCityName);
                    fetchAllData();
                } catch (Exception ex) {
                    SwingUtilities.invokeLater(() -> handleNetworkError("搜索失败", ex));
                }
                return null;
            }
        }.execute();
    }

    private void fetchAllData() {
        errorLabel.setText("");
        statusLabel.setText("数据来自 Open-Meteo | 加载中...");
        new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                doFetchAllData();
                return null;
            }
            @Override
            protected void done() {
                try {
                    get();
                    statusLabel.setText("数据来自 Open-Meteo | 已缓存");
                } catch (Exception e) {
                    statusLabel.setText("数据来自 Open-Meteo | 加载失败");
                }
            }
        }.execute();
    }

    private void doFetchAllData() {
        String[] parts = currentCityId.split(",");
        String lat = parts[0];
        String lon = parts[1];
        String url = "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m,pressure_msl,cloud_cover,precipitation" +
            "&hourly=temperature_2m,weather_code,precipitation_probability" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset" +
            "&timezone=auto&forecast_days=8";
        try {
            String json = httpGetString(url);
            lastJson = json;
            SwingUtilities.invokeLater(() -> {
                updateCurrentTabFromOpenMeteo(json);
                updateForecast7TabFromOpenMeteo(json);
                updateForecast24TabFromOpenMeteo(json);
                updateAstronomyTabFromOpenMeteo(json);
            });
        } catch (Exception ex) {
            System.err.println("天气API错误: " + ex.getMessage());
            ex.printStackTrace();
            SwingUtilities.invokeLater(() -> handleApiError("天气数据", ex));
        }
    }

    private void updateCurrentTabFromOpenMeteo(String json) {
        currentWeatherPanel.removeAll();
        String currentObj = extractObject(json, "current");
        if (currentObj == null) {
            showErrorPanel(currentWeatherPanel, "实时天气数据加载失败");
            return;
        }

        currentTemp = extractString(currentObj, "temperature_2m");
        String wmoCode = extractString(currentObj, "weather_code");
        currentWeatherText = getWeatherText(wmoCode);
        currentIcon = wmoCode;
        applyWeatherWallpaper(currentWeatherText);

        String updateTime = extractString(currentObj, "time");
        if (updateTime != null && updateTime.length() > 10) {
            updateTime = updateTime.substring(11, 16);
        }

        String humidity = extractString(currentObj, "relative_humidity_2m");
        String feelsLike = extractString(currentObj, "apparent_temperature");
        String windSpeed = extractString(currentObj, "wind_speed_10m");
        String windDir = extractString(currentObj, "wind_direction_10m");
        String pressure = extractString(currentObj, "pressure_msl");
        String cloud = extractString(currentObj, "cloud_cover");
        String precip = extractString(currentObj, "precipitation");

        String maxTemp = "-", minTemp = "-";
        String dailyObj = extractObject(json, "daily");
        if (dailyObj != null) {
            maxTemp = extractArrayValue(dailyObj, "temperature_2m_max", 0);
            minTemp = extractArrayValue(dailyObj, "temperature_2m_min", 0);
        }

        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setOpaque(false);
        center.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel timeLabel = new JLabel("更新于 " + (updateTime != null ? updateTime : "--:--"));
        timeLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
        timeLabel.setForeground(new Color(0x888888));
        timeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        center.add(timeLabel);
        center.add(Box.createVerticalStrut(8));

        JLabel cityLabel = new JLabel("📍 " + currentCityName);
        cityLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 20));
        cityLabel.setForeground(Color.WHITE);
        cityLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        center.add(cityLabel);
        center.add(Box.createVerticalStrut(10));

        // 温度大数字 - 使用渐变效果
        JLabel tempLabel = new JLabel((currentTemp != null ? currentTemp : "-") + "°") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                String text = getText();
                int x = (getWidth() - fm.stringWidth(text)) / 2;
                int y = fm.getAscent() + (getHeight() - fm.getHeight()) / 2;
                // 阴影
                g2.setColor(new Color(0, 0, 0, 80));
                g2.drawString(text, x + 3, y + 3);
                // 渐变文字
                GradientPaint gp = new GradientPaint(x, y - fm.getAscent(), Color.WHITE, x, y + fm.getDescent(), new Color(0xFFD700));
                g2.setPaint(gp);
                g2.drawString(text, x, y);
                g2.dispose();
            }
        };
        tempLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 140));
        tempLabel.setForeground(Color.WHITE);
        tempLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        tempLabel.setPreferredSize(new Dimension(400, 160));
        tempLabel.setMaximumSize(new Dimension(400, 160));
        center.add(tempLabel);
        center.add(Box.createVerticalStrut(5));

        JLabel rangeLabel = new JLabel((maxTemp != null ? maxTemp : "-") + "° / " + (minTemp != null ? minTemp : "-") + "°");
        rangeLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 18));
        rangeLabel.setForeground(new Color(0xCCCCCC));
        rangeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        center.add(rangeLabel);
        center.add(Box.createVerticalStrut(15));

        // 天气图标和文字 - 分开显示避免字体冲突
        Color weatherColor = getWeatherColor(currentWeatherText);
        JPanel condPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        condPanel.setOpaque(false);
        condPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel iconLabel = new JLabel(getWeatherIcon(currentIcon));
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 48));
        iconLabel.setForeground(weatherColor);

        JLabel textLabel = new JLabel(currentWeatherText);
        textLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 24));
        textLabel.setForeground(weatherColor);

        condPanel.add(iconLabel);
        condPanel.add(textLabel);
        center.add(condPanel);
        center.add(Box.createVerticalStrut(20));

        JSeparator sep = new JSeparator();
        sep.setMaximumSize(new Dimension(600, 1));
        sep.setForeground(new Color(0x333333));
        center.add(sep);
        center.add(Box.createVerticalStrut(15));

        String[][] fields = {
            {"湿度", (humidity != null ? humidity : "-") + "%"},
            {"风向", windDir != null ? windDirection(windDir) : "-"},
            {"风力", (windSpeed != null ? windSpeed : "-") + "km/h"},
            {"风速", (windSpeed != null ? windSpeed : "-") + "km/h"},
            {"气压", (pressure != null ? pressure : "-") + "hPa"},
            {"能见度", "-"},
            {"云量", (cloud != null ? cloud : "-") + "%"},
            {"降水量", (precip != null ? precip : "-") + "mm"},
            {"紫外线", "-"},
            {"露点", "-"},
            {"体感温度", (feelsLike != null ? feelsLike : "-") + "°"},
            {"空气质量", "-"}
        };

        JPanel grid = new JPanel(new GridLayout(3, 5, 12, 12));
        grid.setOpaque(false);
        grid.setMaximumSize(new Dimension(820, 260));
        grid.setAlignmentX(Component.CENTER_ALIGNMENT);

        for (int i = 0; i < 15; i++) {
            if (i < fields.length) {
                JPanel card = createGlassCard(new Color(0x16213e), 12, 0.6f);
                card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
                card.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));
                JLabel name = new JLabel(fields[i][0]);
                name.setFont(new Font("Microsoft YaHei", Font.PLAIN, 11));
                name.setForeground(new Color(0xAAAAAA));
                name.setAlignmentX(Component.CENTER_ALIGNMENT);
                JLabel value = new JLabel(fields[i][1]);
                value.setFont(new Font("Microsoft YaHei", Font.BOLD, 16));
                value.setForeground(Color.WHITE);
                value.setAlignmentX(Component.CENTER_ALIGNMENT);
                card.add(name);
                card.add(Box.createVerticalStrut(6));
                card.add(value);
                grid.add(card);
            } else {
                JPanel empty = new JPanel();
                empty.setOpaque(false);
                grid.add(empty);
            }
        }

        center.add(grid);
        currentWeatherPanel.add(Box.createVerticalGlue());
        currentWeatherPanel.add(center);
        currentWeatherPanel.add(Box.createVerticalGlue());
        currentWeatherPanel.revalidate();
        currentWeatherPanel.repaint();
    }

    private void updateForecast7TabFromOpenMeteo(String json) {
        forecast7Panel.removeAll();
        String dailyObj = extractObject(json, "daily");
        if (dailyObj == null) {
            showErrorPanel(forecast7Panel, "7天预报数据加载失败");
            return;
        }

        List<String> dates = extractArrayValues(dailyObj, "time");
        List<String> codes = extractArrayValues(dailyObj, "weather_code");
        List<String> maxTemps = extractArrayValues(dailyObj, "temperature_2m_max");
        List<String> minTemps = extractArrayValues(dailyObj, "temperature_2m_min");

        if (dates.isEmpty()) {
            showEmptyPanel(forecast7Panel, "暂无数据");
            return;
        }

        boolean alternate = false;
        for (int i = 0; i < dates.size() && i < 7; i++) {
            String date = dates.get(i);
            String code = i < codes.size() ? codes.get(i) : null;
            String maxT = i < maxTemps.size() ? maxTemps.get(i) : "-";
            String minT = i < minTemps.size() ? minTemps.get(i) : "-";
            String text = getWeatherText(code);

            JPanel row = createGlassCard(alternate ? new Color(0x1a1a2e) : new Color(0x16213e), 10, 0.5f);
            row.setLayout(new BorderLayout(10, 0));
            row.setPreferredSize(new Dimension(0, 56));
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
            row.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));

            String dateStr = date != null && date.length() >= 10 ? date.substring(5) : "-";
            JLabel dateLabel = new JLabel(dateStr);
            dateLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 14));
            dateLabel.setForeground(new Color(0xDDDDDD));

            JLabel iconLabel = new JLabel(getWeatherIcon(code));
            iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));

            JLabel tempLabel = new JLabel((maxT != null ? maxT : "-") + "° / " + (minT != null ? minT : "-") + "°");
            tempLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 14));
            tempLabel.setForeground(new Color(0xFFD700));

            JLabel dayLabel = new JLabel(text);
            dayLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 14));
            dayLabel.setForeground(Color.WHITE);

            JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
            left.setOpaque(false);
            left.add(dateLabel);
            left.add(iconLabel);
            left.add(tempLabel);

            JPanel centerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
            centerPanel.setOpaque(false);
            centerPanel.add(dayLabel);

            row.add(left, BorderLayout.WEST);
            row.add(centerPanel, BorderLayout.CENTER);

            forecast7Panel.add(Box.createVerticalStrut(4));
            forecast7Panel.add(row);
            alternate = !alternate;
        }

        forecast7Panel.revalidate();
        forecast7Panel.repaint();
    }

    private void updateForecast24TabFromOpenMeteo(String json) {
        forecast24Panel.removeAll();
        String hourlyObj = extractObject(json, "hourly");
        if (hourlyObj == null) {
            showErrorPanel(forecast24Panel, "24小时预报数据加载失败");
            return;
        }

        List<String> times = extractArrayValues(hourlyObj, "time");
        List<String> temps = extractArrayValues(hourlyObj, "temperature_2m");
        List<String> codes = extractArrayValues(hourlyObj, "weather_code");
        List<String> pops = extractArrayValues(hourlyObj, "precipitation_probability");

        if (times.isEmpty()) {
            showEmptyPanel(forecast24Panel, "暂无数据");
            return;
        }

        JPanel cardsContainer = new JPanel();
        cardsContainer.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        cardsContainer.setOpaque(false);

        for (int i = 0; i < times.size() && i < 24; i++) {
            String time = times.get(i);
            String temp = i < temps.size() ? temps.get(i) : "-";
            String code = i < codes.size() ? codes.get(i) : null;
            String pop = i < pops.size() ? pops.get(i) : "0";

            String timeStr = time != null && time.length() >= 13 ? time.substring(11, 16) : "-";

            JPanel card = createGlassCard(new Color(0x16213e), 12, 0.55f);
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.setPreferredSize(new Dimension(82, 130));
            card.setMaximumSize(new Dimension(82, 130));
            card.setBorder(BorderFactory.createEmptyBorder(10, 4, 10, 4));

            JLabel timeL = new JLabel(timeStr);
            timeL.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
            timeL.setForeground(new Color(0xBBBBBB));
            timeL.setAlignmentX(Component.CENTER_ALIGNMENT);

            JLabel iconL = new JLabel(getWeatherIcon(code));
            iconL.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
            iconL.setAlignmentX(Component.CENTER_ALIGNMENT);

            JLabel tempL = new JLabel((temp != null ? temp : "-") + "°");
            tempL.setFont(new Font("Microsoft YaHei", Font.BOLD, 18));
            tempL.setForeground(Color.WHITE);
            tempL.setAlignmentX(Component.CENTER_ALIGNMENT);

            JLabel popL = new JLabel("降水 " + (pop != null ? pop : "0") + "%");
            popL.setFont(new Font("Microsoft YaHei", Font.PLAIN, 10));
            popL.setForeground(new Color(0x6BB5FF));
            popL.setAlignmentX(Component.CENTER_ALIGNMENT);

            card.add(timeL);
            card.add(Box.createVerticalStrut(6));
            card.add(iconL);
            card.add(Box.createVerticalStrut(6));
            card.add(tempL);
            card.add(Box.createVerticalStrut(6));
            card.add(popL);
            cardsContainer.add(Box.createHorizontalStrut(6));
            cardsContainer.add(card);
        }

        JScrollPane scroll = new JScrollPane(cardsContainer,
                JScrollPane.VERTICAL_SCROLLBAR_NEVER,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(null);

        forecast24Panel.add(scroll, BorderLayout.CENTER);
        forecast24Panel.revalidate();
        forecast24Panel.repaint();
    }

    private void updateAstronomyTabFromOpenMeteo(String json) {
        astronomyPanel.removeAll();
        String dailyObj = extractObject(json, "daily");
        String sunrise = null, sunset = null;
        if (dailyObj != null) {
            sunrise = extractArrayValue(dailyObj, "sunrise", 0);
            sunset = extractArrayValue(dailyObj, "sunset", 0);
        }
        if (sunrise != null && sunrise.length() >= 16) sunrise = sunrise.substring(11, 16);
        if (sunset != null && sunset.length() >= 16) sunset = sunset.substring(11, 16);

        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setOpaque(false);
        center.setAlignmentX(Component.CENTER_ALIGNMENT);

        // 太阳区域 - 使用绘制组件
        JPanel sunRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        sunRow.setOpaque(false);
        sunRow.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel sunPanel = createSunPanel();
        JLabel sunText = new JLabel("日出 " + (sunrise != null ? sunrise : "--:--") + "  |  日落 " + (sunset != null ? sunset : "--:--"));
        sunText.setFont(new Font("Microsoft YaHei", Font.BOLD, 22));
        sunText.setForeground(new Color(0xFFD700));

        sunRow.add(sunPanel);
        sunRow.add(sunText);

        // 月亮区域
        JPanel moonRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        moonRow.setOpaque(false);
        moonRow.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel moonPanel = createMoonPanel();
        JLabel moonText = new JLabel("月升 --:--  |  月落 --:--");
        moonText.setFont(new Font("Microsoft YaHei", Font.BOLD, 18));
        moonText.setForeground(new Color(0xAAAAAA));

        moonRow.add(moonPanel);
        moonRow.add(moonText);

        // 月相
        JLabel phaseLabel = new JLabel("月相数据暂不可用");
        phaseLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 24));
        phaseLabel.setForeground(new Color(0xCCCCCC));
        phaseLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel hintLabel = new JLabel("（Open-Meteo 暂不提供月相数据）");
        hintLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
        hintLabel.setForeground(new Color(0x888888));
        hintLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        center.add(Box.createVerticalStrut(40));
        center.add(sunRow);
        center.add(Box.createVerticalStrut(30));
        center.add(moonRow);
        center.add(Box.createVerticalStrut(30));
        center.add(phaseLabel);
        center.add(Box.createVerticalStrut(10));
        center.add(hintLabel);

        astronomyPanel.add(center);
        astronomyPanel.revalidate();
        astronomyPanel.repaint();
    }

    private void showErrorPanel(JPanel panel, String msg) {
        panel.removeAll();
        JLabel error = new JLabel(msg);
        error.setFont(new Font("Microsoft YaHei", Font.BOLD, 16));
        error.setForeground(Color.RED);
        error.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(Box.createVerticalGlue());
        panel.add(error);
        panel.add(Box.createVerticalGlue());
        panel.revalidate();
        panel.repaint();
    }

    private void showEmptyPanel(JPanel panel, String msg) {
        panel.removeAll();
        JLabel empty = new JLabel(msg);
        empty.setFont(new Font("Microsoft YaHei", Font.BOLD, 16));
        empty.setForeground(new Color(0x888888));
        empty.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(Box.createVerticalGlue());
        panel.add(empty);
        panel.add(Box.createVerticalGlue());
        panel.revalidate();
        panel.repaint();
    }

    private void handleApiError(String module, Exception ex) {
        showError(module + "加载失败");
    }

    private void handleNetworkError(String context, Exception ex) {
        String msg = ex.getMessage();
        if (msg != null && (msg.contains("timed out") || msg.contains("超时") || msg.contains("SocketTimeoutException"))) {
            JOptionPane.showMessageDialog(frame, "网络超时，请检查网络连接", "错误", JOptionPane.ERROR_MESSAGE);
        }
        showError(context + "失败");
    }

    private void showError(String msg) {
        SwingUtilities.invokeLater(() -> {
            errorLabel.setText(msg);
            statusLabel.setText("数据来自 Open-Meteo | 实时");
        });
    }

    private void applyWeatherWallpaper(String weatherText) {
        if (weatherText == null) return;
        Color topColor, bottomColor;
        if (weatherText.contains("晴")) {
            topColor = new Color(0x1e5799);
            bottomColor = new Color(0x2989d8);
        } else if (weatherText.contains("雨") || weatherText.contains("阵雨") || weatherText.contains("雷雨")) {
            topColor = new Color(0x1a2a3a);
            bottomColor = new Color(0x0d1b2a);
        } else if (weatherText.contains("雪")) {
            topColor = new Color(0x3a4a5a);
            bottomColor = new Color(0x2C3E50);
        } else if (weatherText.contains("云") || weatherText.contains("阴") || weatherText.contains("雾")) {
            topColor = new Color(0x2a2a3a);
            bottomColor = new Color(0x1a1a2a);
        } else if (weatherText.contains("霾")) {
            topColor = new Color(0x3d3d3d);
            bottomColor = new Color(0x2d2d2d);
        } else {
            topColor = new Color(0x1a3a5c);
            bottomColor = new Color(0x0d1b2a);
        }
        if (frame.getContentPane() instanceof GradientPanel) {
            ((GradientPanel) frame.getContentPane()).setGradient(topColor, bottomColor);
        }
    }

    private String httpGetString(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);
        conn.setRequestProperty("User-Agent", "Winllx Weather/1.0");
        conn.setRequestProperty("Accept", "application/json");

        int code = conn.getResponseCode();
        if (code >= 400) {
            InputStream errorStream = conn.getErrorStream();
            String errorBody = "";
            if (errorStream != null) {
                try (BufferedReader errReader = new BufferedReader(new InputStreamReader(errorStream, StandardCharsets.UTF_8))) {
                    StringBuilder errSb = new StringBuilder();
                    String errLine;
                    while ((errLine = errReader.readLine()) != null) errSb.append(errLine);
                    errorBody = errSb.toString();
                }
            }
            conn.disconnect();
            throw new IOException("HTTP " + code + ": " + errorBody);
        }

        InputStream is = conn.getInputStream();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int len;
        while ((len = is.read(buffer)) != -1) {
            baos.write(buffer, 0, len);
        }
        is.close();
        conn.disconnect();
        
        String result = baos.toString(StandardCharsets.UTF_8.name());
        return result;
    }

    private void loadCityHistory() {
        try {
            File file = new File(HISTORY_FILE);
            if (file.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                String line;
                while ((line = reader.readLine()) != null) {
                    if (!line.isEmpty() && !cityHistory.contains(line)) {
                        cityHistory.add(line);
                    }
                }
                reader.close();
            }
        } catch (Exception e) {
            cityHistory.clear();
        }
        updateCityCombo();
    }

    private void saveCityHistory() {
        try {
            File file = new File(HISTORY_FILE);
            file.getParentFile().mkdirs();
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            for (String city : cityHistory) {
                writer.write(city);
                writer.newLine();
            }
            writer.close();
        } catch (Exception e) {}
    }

    private void addCityToHistory(String city) {
        if (city == null || city.isEmpty()) return;
        cityHistory.remove(city);
        cityHistory.add(0, city);
        if (cityHistory.size() > 10) cityHistory.remove(cityHistory.size() - 1);
        saveCityHistory();
        updateCityCombo();
    }

    private void updateCityCombo() {
        updatingCombo = true;
        cityHistoryCombo.removeAllItems();
        cityHistoryCombo.addItem("历史记录");
        for (String city : cityHistory) cityHistoryCombo.addItem(city);
        updatingCombo = false;
    }

    private String extractString(String json, String key) {
        if (json == null || key == null) return null;
        Pattern pattern = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\"([^\"]*)\"");
        Matcher matcher = pattern.matcher(json);
        if (matcher.find()) return matcher.group(1);
        pattern = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*([^,}\\]\\s]+)");
        matcher = pattern.matcher(json);
        if (matcher.find()) return matcher.group(1);
        return null;
    }

    private String extractObject(String json, String key) {
        if (json == null || key == null) return null;
        Pattern pattern = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\\{");
        Matcher matcher = pattern.matcher(json);
        if (!matcher.find()) return null;
        int start = matcher.end() - 1;
        int depth = 1;
        for (int i = start + 1; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '{') depth++;
            else if (c == '}') depth--;
            else if (c == '"') {
                i++;
                while (i < json.length()) {
                    char ch = json.charAt(i);
                    if (ch == '\\') {
                        i += 2;
                    } else if (ch == '"') {
                        break;
                    } else {
                        i++;
                    }
                }
            }
            if (depth == 0) return json.substring(start, i + 1);
        }
        return null;
    }

    private String extractArray(String json, String key) {
        if (json == null || key == null) return null;
        Pattern pattern = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\\[");
        Matcher matcher = pattern.matcher(json);
        if (!matcher.find()) return null;
        int start = matcher.end() - 1;
        int depth = 1;
        for (int i = start + 1; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '[') depth++;
            else if (c == ']') depth--;
            else if (c == '"') {
                i++;
                while (i < json.length()) {
                    char ch = json.charAt(i);
                    if (ch == '\\') {
                        i += 2;
                    } else if (ch == '"') {
                        break;
                    } else {
                        i++;
                    }
                }
            }
            if (depth == 0) return json.substring(start, i + 1);
        }
        return null;
    }

    private String extractArrayValue(String json, String key, int index) {
        String arr = extractArray(json, key);
        if (arr == null) return null;
        List<String> items = splitJsonArray(arr);
        if (index < 0 || index >= items.size()) return null;
        String item = items.get(index);
        if (item.startsWith("\"") && item.endsWith("\"") && item.length() >= 2) {
            return unescapeString(item.substring(1, item.length() - 1));
        }
        return item;
    }

    private List<String> extractArrayValues(String json, String key) {
        String arr = extractArray(json, key);
        if (arr == null) return new ArrayList<>();
        List<String> rawItems = splitJsonArray(arr);
        List<String> result = new ArrayList<>();
        for (String item : rawItems) {
            if (item.startsWith("\"") && item.endsWith("\"") && item.length() >= 2) {
                result.add(unescapeString(item.substring(1, item.length() - 1)));
            } else {
                result.add(item);
            }
        }
        return result;
    }

    private String unescapeString(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char next = s.charAt(i + 1);
                if (next == '"') { sb.append('"'); i++; }
                else if (next == '\\') { sb.append('\\'); i++; }
                else if (next == 'n') { sb.append('\n'); i++; }
                else if (next == 'r') { sb.append('\r'); i++; }
                else if (next == 't') { sb.append('\t'); i++; }
                else { sb.append(c); }
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private List<String> splitJsonArray(String arrayStr) {
        List<String> items = new ArrayList<>();
        if (arrayStr == null || !arrayStr.startsWith("[")) return items;
        int depth = 0;
        StringBuilder current = new StringBuilder();
        int i = 1;
        while (i < arrayStr.length()) {
            char c = arrayStr.charAt(i);
            if (c == '[') {
                depth++;
                current.append(c);
            } else if (c == ']') {
                depth--;
                if (depth < 0) {
                    String item = current.toString().trim();
                    if (!item.isEmpty()) items.add(item);
                    break;
                }
                current.append(c);
            } else if (c == '{') {
                depth++;
                current.append(c);
            } else if (c == '}') {
                depth--;
                current.append(c);
            } else if (c == '"') {
                current.append(c);
                i++;
                while (i < arrayStr.length()) {
                    char ch = arrayStr.charAt(i);
                    current.append(ch);
                    if (ch == '"') {
                        if (i > 0 && arrayStr.charAt(i - 1) == '\\') {
                            i++;
                            continue;
                        }
                        break;
                    }
                    i++;
                }
                i++;
                continue;
            } else if (c == ',' && depth == 0) {
                String item = current.toString().trim();
                if (!item.isEmpty()) items.add(item);
                current = new StringBuilder();
            } else {
                current.append(c);
            }
            i++;
        }
        return items;
    }

    private String getWeatherIcon(String code) {
        return code != null ? WMO_ICON_MAP.getOrDefault(code, "🌤️") : "🌤️";
    }

    private String getWeatherText(String code) {
        return code != null ? WMO_TEXT_MAP.getOrDefault(code, "多云") : "多云";
    }

    private String windDirection(String degStr) {
        try {
            double deg = Double.parseDouble(degStr);
            if (deg >= 337.5 || deg < 22.5) return "北";
            if (deg < 67.5) return "东北";
            if (deg < 112.5) return "东";
            if (deg < 157.5) return "东南";
            if (deg < 202.5) return "南";
            if (deg < 247.5) return "西南";
            if (deg < 292.5) return "西";
            return "西北";
        } catch (Exception e) {
            return "-";
        }
    }

    private Color getWeatherColor(String weatherText) {
        if (weatherText == null) return Color.WHITE;
        if (weatherText.contains("晴")) return new Color(0xFFD700);
        if (weatherText.contains("雨") || weatherText.contains("阵雨") || weatherText.contains("雷雨")) return new Color(0x4A90D9);
        if (weatherText.contains("雪")) return Color.WHITE;
        return new Color(0x888888);
    }


    private JPanel createRoundedPanel(Color color, int radius) {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(color);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
                super.paintComponent(g);
            }
        };
        panel.setOpaque(false);
        return panel;
    }

    // ========== 美化组件：渐变背景面板 ==========
    private static class GradientPanel extends JPanel {
        private Color topColor = new Color(0x1a3a5c);
        private Color bottomColor = new Color(0x0d1b2a);

        public void setGradient(Color top, Color bottom) {
            this.topColor = top;
            this.bottomColor = bottom;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            GradientPaint gp = new GradientPaint(0, 0, topColor, 0, getHeight(), bottomColor);
            g2.setPaint(gp);
            g2.fillRect(0, 0, getWidth(), getHeight());
        }
    }

    // ========== 美化组件：毛玻璃卡片 ==========
    private JPanel createGlassCard(Color baseColor, int radius, float alpha) {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // 半透明背景
                g2.setColor(new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), (int)(alpha * 255)));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
                // 顶部高光边框
                g2.setColor(new Color(255, 255, 255, 30));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
                // 内部高光
                g2.setColor(new Color(255, 255, 255, 15));
                g2.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, radius - 2, radius - 2);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        panel.setOpaque(false);
        return panel;
    }

    // ========== 美化组件：太阳绘制面板 ==========
    private JPanel createSunPanel() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int cx = getWidth() / 2;
                int cy = getHeight() / 2;
                int r = Math.min(cx, cy) - 10;
                // 光芒
                g2.setColor(new Color(0xFFD700));
                for (int i = 0; i < 12; i++) {
                    double angle = Math.toRadians(i * 30);
                    int x1 = cx + (int)(r * 0.6 * Math.cos(angle));
                    int y1 = cy + (int)(r * 0.6 * Math.sin(angle));
                    int x2 = cx + (int)(r * 0.9 * Math.cos(angle));
                    int y2 = cy + (int)(r * 0.9 * Math.sin(angle));
                    g2.setStroke(new BasicStroke(3, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    g2.drawLine(x1, y1, x2, y2);
                }
                // 太阳本体
                g2.setColor(new Color(0xFFA500));
                g2.fillOval(cx - r/2, cy - r/2, r, r);
                g2.setColor(new Color(0xFFD700));
                g2.fillOval(cx - r/2 + 2, cy - r/2 + 2, r - 4, r - 4);
            }
        };
        panel.setOpaque(false);
        panel.setPreferredSize(new Dimension(80, 80));
        return panel;
    }

    // ========== 美化组件：月亮绘制面板 ==========
    private JPanel createMoonPanel() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int cx = getWidth() / 2;
                int cy = getHeight() / 2;
                int r = Math.min(cx, cy) - 10;
                // 月亮本体
                g2.setColor(new Color(0xE0E0E0));
                g2.fillOval(cx - r/2, cy - r/2, r, r);
                // 月牙阴影
                g2.setColor(new Color(0x2a2a3a));
                g2.fillOval(cx - r/2 + 8, cy - r/2 - 3, r, r);
            }
        };
        panel.setOpaque(false);
        panel.setPreferredSize(new Dimension(80, 80));
        return panel;
    }

}
