
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

/**
 * Winllx 主程序入口
 */
public class Winllx {

    // ==================== 常量定义区 ====================
    private static String APP_TITLE = "Winllx";
    private static final Color DEFAULT_BG = Color.WHITE;
    private static final String TRAY_ICON_PATH = "C:/Users/86132/Desktop/java.png";
    private static final String SETTINGS_FILE = System.getProperty("user.dir") + "/Winllx/app_settings.properties";

    private static final int COL_LEFT = 300;
    private static final int COL_RIGHT = 800;
    private static final int ROW_TOP = 70;
    private static final int ROW_MIDDLE = 200;
    private static final int ROW_BOTTOM = 330;

    private static final int APP_BTN_SIZE = 80;
    private static final int WIDE_BTN_WIDTH = 200;
    private static final int SHORT_BTN_HEIGHT = 50;

    private static final int[][] MIND_GROUPS = {
        {1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31},
        {2, 3, 6, 7, 10, 11, 14, 15, 18, 19, 22, 23, 26, 27, 30, 31},
        {4, 5, 6, 7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31},
        {8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29, 30, 31},
        {16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31}
    };
    private static final int[] MIND_WEIGHTS = {1, 2, 4, 8, 16};

    // ==================== 状态变量 ====================
    private static boolean trayEnabled = true;
    private static TrayIcon trayIcon;

    private static JFrame mainFrame;

    private static GlassButton noteBtn, calcBtn, fileBtn, mindBtn, sysMonBtn, boardBtn, clockBtn, weatherBtn, minimizeBtn, settingsBtn, exitBtn;
    private static JLabel noteLabel, calcLabel, fileLabel, boardLabel, sysMonLabel, mindLabel, clockLabel, weatherLabel;

    // ==================== 主入口 ====================
    public static void main(String[] args) {
        // 先初始化语言，再创建任何 UI
        LangManager.init();

        Loading loading = new Loading();
        loading.show();

        // 初始化图标管理器
        WinllxIcon.init();

        initMainWindow();
        SwingUtilities.invokeLater(() -> {
            buildDesktopUI();
            applySavedTextColor(loadTextColor());
            initSystemTray();
            loading.close();
        });
    }

    public static void setMainVisible(boolean visible) {
        if (mainFrame != null) {
            mainFrame.setVisible(visible);
        }
    }

    public static Color getMainBackgroundColor() {
        if (mainFrame != null) {
            return mainFrame.getContentPane().getBackground();
        }
        return DEFAULT_BG;
    }

    private static void initMainWindow() {
        APP_TITLE = LangManager.getString("app.title");
        mainFrame = new JFrame(APP_TITLE);
        Color savedColor = loadBackgroundColor();
        mainFrame.getContentPane().setBackground(savedColor);
        mainFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        mainFrame.setLayout(null);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 应用图标到主窗口
        WinllxIcon.applyToFrame(mainFrame);

        mainFrame.setVisible(true);

        mainFrame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                updateLayout();
            }

            @Override
            public void componentShown(ComponentEvent e) {
                updateLayout();
            }
        });
    }

    private static void applySavedTextColor(Color textColor) {
        for (Component c : mainFrame.getContentPane().getComponents()) {
            if (c instanceof JLabel) {
                ((JLabel) c).setForeground(textColor);
            } else if (c instanceof GlassButton) {
                ((GlassButton) c).setTextColor(textColor);
            } else if (c instanceof AbstractButton) {
                ((AbstractButton) c).setForeground(textColor);
            }
        }
        mainFrame.repaint();
    }

    private static void buildDesktopUI() {
        addDesktopLabels();
        addDesktopButtons();
        updateLayout();
    }

    private static JLabel timeLabel;
    private static JLabel dateLabel;

    private static void addDesktopLabels() {
        timeLabel = new JLabel();
        timeLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 36));

        dateLabel = new JLabel();
        dateLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));

        noteLabel = createLabel(LangManager.getString("module.note"), 0, 0, 80, 80, 0);
        calcLabel = createLabel(LangManager.getString("module.calc"), 0, 0, 80, 80, 0);
        fileLabel = createLabel(LangManager.getString("module.file"), 0, 0, 80, 80, 0);
        boardLabel = createLabel(LangManager.getString("module.board"), 0, 0, 80, 80, 0);
        sysMonLabel = createLabel(LangManager.getString("module.sysmon"), 0, 0, 80, 80, 0);
        mindLabel = createLabel(LangManager.getString("module.mind"), 0, 0, 80, 80, 0);
        clockLabel = createLabel(LangManager.getString("module.clock"), 0, 0, 80, 80, 0);
        weatherLabel = createLabel(LangManager.getString("module.weather"), 0, 0, 80, 80, 0);

        addToMain(timeLabel, dateLabel, noteLabel, calcLabel, fileLabel, boardLabel, sysMonLabel, mindLabel, clockLabel, weatherLabel);

        updateDateTime();
        javax.swing.Timer timer = new javax.swing.Timer(1000, e -> updateDateTime());
        timer.start();

        updateLayout();
    }

    private static void updateDateTime() {
        java.util.Calendar calendar = java.util.Calendar.getInstance();
        java.text.SimpleDateFormat timeFormat = new java.text.SimpleDateFormat("HH:mm");
        java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("MM月dd日 EEEE");
        timeLabel.setText(timeFormat.format(calendar.getTime()));
        dateLabel.setText(dateFormat.format(calendar.getTime()));
    }

    private static void updateLayout() {
        int windowWidth = mainFrame.getContentPane().getWidth();
        int windowHeight = mainFrame.getContentPane().getHeight();

        int btnWidth = APP_BTN_SIZE;
        int btnHeight = APP_BTN_SIZE;
        int gap = 225;
        int labelOffset = 20;

        int totalBtnWidth = btnWidth * 2 + gap;
        int startX = (windowWidth - totalBtnWidth) / 2;
        int col1X = startX;
        int col2X = startX + btnWidth + gap;

        int rowTop = 100;
        int rowMiddle = rowTop + btnHeight + 80;
        int rowBottom = rowMiddle + btnHeight + 80;

        if (timeLabel != null) {
            FontMetrics fm = timeLabel.getFontMetrics(timeLabel.getFont());
            int timeWidth = fm.stringWidth(timeLabel.getText());
            timeLabel.setBounds((windowWidth - timeWidth) / 2, 10, timeWidth + 20, 50);
        }

        if (dateLabel != null) {
            FontMetrics fm = dateLabel.getFontMetrics(dateLabel.getFont());
            int dateWidth = fm.stringWidth(dateLabel.getText());
            dateLabel.setBounds((windowWidth - dateWidth) / 2, 50, dateWidth + 20, 30);
        }

        if (noteBtn != null) noteBtn.setBounds(col1X, rowTop, btnWidth, btnHeight);
        if (noteLabel != null) noteLabel.setBounds(col1X + labelOffset, rowTop + btnHeight + 10, 80, 30);

        if (calcBtn != null) calcBtn.setBounds(col2X, rowTop, btnWidth, btnHeight);
        if (calcLabel != null) calcLabel.setBounds(col2X + labelOffset, rowTop + btnHeight + 10, 80, 30);

        if (fileBtn != null) fileBtn.setBounds(col1X, rowMiddle, btnWidth, btnHeight);
        if (fileLabel != null) fileLabel.setBounds(col1X + labelOffset, rowMiddle + btnHeight + 10, 80, 30);

        if (mindBtn != null) mindBtn.setBounds(col2X, rowMiddle, btnWidth, btnHeight);
        if (mindLabel != null) mindLabel.setBounds(col2X + labelOffset, rowMiddle + btnHeight + 10, 80, 30);

        if (sysMonBtn != null) sysMonBtn.setBounds(col1X, rowBottom, btnWidth, btnHeight);
        if (sysMonLabel != null) sysMonLabel.setBounds(col1X + labelOffset, rowBottom + btnHeight + 10, 80, 30);

        if (clockBtn != null) clockBtn.setBounds(col2X, rowBottom, btnWidth, btnHeight);
        if (clockLabel != null) clockLabel.setBounds(col2X + labelOffset, rowBottom + btnHeight + 10, 80, 30);

        int boardRowY = rowBottom + btnHeight + 50;
        if (boardBtn != null) boardBtn.setBounds(col1X, boardRowY, btnWidth, btnHeight);
        if (boardLabel != null) boardLabel.setBounds(col1X + labelOffset, boardRowY + btnHeight + 10, 80, 30);

        if (weatherBtn != null) weatherBtn.setBounds(col2X, boardRowY, btnWidth, btnHeight);
        if (weatherLabel != null) weatherLabel.setBounds(col2X + labelOffset, boardRowY + btnHeight + 10, 80, 30);

        int bottomBtnWidth = 100;
        int bottomBtnHeight = SHORT_BTN_HEIGHT;
        int bottomGap = 20;
        int totalBottomWidth = bottomBtnWidth * 3 + bottomGap * 2;
        int bottomStartX = windowWidth - totalBottomWidth - 20;
        int bottomRowY = windowHeight - bottomBtnHeight - 20;

        if (minimizeBtn != null) minimizeBtn.setBounds(bottomStartX, bottomRowY, bottomBtnWidth, bottomBtnHeight);
        if (settingsBtn != null) settingsBtn.setBounds(bottomStartX + bottomBtnWidth + bottomGap, bottomRowY, bottomBtnWidth, bottomBtnHeight);
        if (exitBtn != null) exitBtn.setBounds(bottomStartX + (bottomBtnWidth + bottomGap) * 2, bottomRowY, bottomBtnWidth, bottomBtnHeight);

        mainFrame.repaint();
    }

    private static void addDesktopButtons() {
        noteBtn = createAppButton(LangManager.getString("module.note"), 0, 0, e -> new Winllx2());
        calcBtn = createAppButton(LangManager.getString("module.calc"), 0, 0, e -> new Winllx3());
        fileBtn = createAppButton(LangManager.getString("module.file"), 0, 0, e -> new Winllx4());
        mindBtn = createStyledButton(LangManager.getString("module.mind"), 0, 0, APP_BTN_SIZE, APP_BTN_SIZE, e -> launchMindReading());
        sysMonBtn = createAppButton(LangManager.getString("module.sysmon"), 0, 0, e -> new WinllxSysMon());
        boardBtn = createAppButton(LangManager.getString("module.board"), 0, 0, e -> new Winllx7());
        clockBtn = createAppButton(LangManager.getString("module.clock"), 0, 0, e -> {
            SwingUtilities.invokeLater(() -> new Winllx5().setVisible(true));
        });
        weatherBtn = createAppButton(LangManager.getString("module.weather"), 0, 0, e -> new WinllxWeather());

        minimizeBtn = createStyledButton(LangManager.getString("btn.minimize"), 0, 0, 150, SHORT_BTN_HEIGHT, e -> setMainVisible(false));
        settingsBtn = createAppButton(LangManager.getString("btn.settings"), 0, 0, e -> openSettings());
        exitBtn = createAppButton(LangManager.getString("btn.exit"), 0, 0, e -> new Winllx0());

        addToMain(noteBtn, calcBtn, fileBtn, mindBtn, sysMonBtn, boardBtn, clockBtn, weatherBtn, minimizeBtn, settingsBtn, exitBtn);
    }

    private static JLabel createLabel(String text, int x, int y, int w, int h, float fontSize) {
        JLabel label = new JLabel(text);
        label.setBounds(x, y, w, h);
        if (fontSize > 0) {
            label.setFont(label.getFont().deriveFont(fontSize));
        }
        return label;
    }

    private static GlassButton createAppButton(String text, int x, int y, ActionListener action) {
        GlassButton btn = GlassButton.createButton(text, APP_BTN_SIZE, APP_BTN_SIZE);
        btn.setBounds(x, y, APP_BTN_SIZE, APP_BTN_SIZE);
        if (action != null) {
            btn.addActionListener(action);
        }
        return btn;
    }

    private static GlassButton createStyledButton(String text, int x, int y, int w, int h, ActionListener action) {
        GlassButton btn = GlassButton.createButton(text, w, h);
        if (action != null) {
            btn.addActionListener(action);
        }
        return btn;
    }

    private static void addToMain(JComponent... components) {
        for (JComponent c : components) {
            mainFrame.add(c);
        }
    }

    private static void launchMindReading() {
        setMainVisible(false);
        JOptionPane.showMessageDialog(null, LangManager.getString("msg.start.success"));

        System.out.println(LangManager.getString("mind.welcome"));
        System.out.println(LangManager.getString("mind.choose"));
        System.out.println(LangManager.getString("mind.warning"));
        System.out.println(LangManager.getString("mind.press.enter"));

        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();

        int result = 0;
        for (int i = 0; i < MIND_GROUPS.length; i++) {
            System.out.println(LangManager.getString("mind.group.ask"));
            if (askGroup(scanner, MIND_GROUPS[i])) {
                result += MIND_WEIGHTS[i];
            }
        }

        JOptionPane.showMessageDialog(null, String.format(LangManager.getString("mind.result"), result));
        setMainVisible(true);
    }

    private static boolean askGroup(Scanner scanner, int[] group) {
        System.out.print(LangManager.getString("mind.group.label"));
        for (int num : group) {
            System.out.print(num + " ");
        }
        System.out.println("\n" + LangManager.getString("mind.group.prompt"));
        try {
            return scanner.nextInt() == 1;
        } catch (InputMismatchException e) {
            scanner.next();
            System.out.println(LangManager.getString("mind.input.invalid"));
            return false;
        }
    }

    private static void openSettings() {
        JFrame dialog = WinllxIcon.createFrame(LangManager.getString("app.settings.title"));
        dialog.setSize(380, 620);
        dialog.setLocation(200, 200);
        dialog.setLayout(null);
        dialog.getContentPane().setBackground(Winllx.getMainBackgroundColor().darker());

        // 语言设置
        JLabel langLabel = new JLabel(LangManager.getString("setting.language"));
        langLabel.setBounds(10, 0, 80, 30);
        dialog.add(langLabel);

        String[] langOptions = {
            LangManager.getString("lang.zh"),
            LangManager.getString("lang.zh_tw"),
            LangManager.getString("lang.en")
        };
        GlassSegmentedControl langSelector = new GlassSegmentedControl(langOptions);
        langSelector.setBounds(10, 30, 300, 60);
        String currentLang = LangManager.getCurrentLang();
        int langIdx = currentLang.equals("zh_tw") ? 1 : (currentLang.equals("en") ? 2 : 0);
        langSelector.setSelectedIndex(langIdx);

        langSelector.addSelectionListener((index, opt) -> {
            String newLang = index == 0 ? "zh" : (index == 1 ? "zh_tw" : "en");
            LangManager.setLanguage(newLang);
            JOptionPane.showMessageDialog(dialog, LangManager.getString("msg.lang.changed"), LangManager.getString("dialog.tip"), JOptionPane.INFORMATION_MESSAGE);
        });
        dialog.add(langSelector);

        // 主题色设置
        JLabel themeLabel = new JLabel(LangManager.getString("setting.theme"));
        themeLabel.setBounds(10, 100, 80, 30);
        dialog.add(themeLabel);

        String[] themes = {LangManager.getString("setting.theme.white"), LangManager.getString("setting.theme.black"), LangManager.getString("setting.theme.custom")};
        GlassSegmentedControl themeSelector = new GlassSegmentedControl(themes);
        themeSelector.setBounds(10, 130, 300, 60);

        Color currentBg = mainFrame.getContentPane().getBackground();
        int initialIndex = 0;
        if (currentBg.equals(Color.BLACK)) {
            initialIndex = 1;
        } else if (!currentBg.equals(Color.WHITE)) {
            initialIndex = 2;
        }
        themeSelector.setSelectedIndex(initialIndex);

        themeSelector.addSelectionListener((index, opt) -> {
            if (index == 2) {
                ColorPicker picker = new ColorPicker(dialog, mainFrame.getContentPane().getBackground());
                picker.addColorListener(color -> {
                    mainFrame.getContentPane().setBackground(color);
                    saveBackgroundColor(color);
                    syncTextColor();
                    mainFrame.repaint();
                });
                picker.setVisible(true);
            } else {
                applyTheme(index);
            }
        });
        dialog.add(themeSelector);

        // 图标主题设置
        JLabel iconLabel = new JLabel(LangManager.getString("setting.icon.theme"));
        iconLabel.setBounds(10, 200, 80, 30);
        dialog.add(iconLabel);

        String[] iconThemes = {LangManager.getString("setting.icon.light"), LangManager.getString("setting.icon.dark")};
        GlassSegmentedControl iconSelector = new GlassSegmentedControl(iconThemes);
        iconSelector.setBounds(10, 230, 200, 60);
        iconSelector.setSelectedIndex(WinllxIcon.getCurrentTheme());

        // 图标预览区域 - 对比展示浅色和深色图标
        JPanel previewPanel = new JPanel();
        previewPanel.setBounds(220, 200, 140, 120);
        previewPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(100, 100, 100)), LangManager.getString("setting.icon.compare")));
        previewPanel.setLayout(new GridLayout(2, 1, 5, 5));

        // 浅色图标预览
        JPanel lightPanel = new JPanel(new BorderLayout());
        lightPanel.setBackground(Color.WHITE);
        lightPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        JLabel lightIconLabel = new JLabel();
        lightIconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        Image lightIcon = WinllxIcon.getIconImage(0);
        if (lightIcon != null) {
            lightIconLabel.setIcon(new ImageIcon(lightIcon.getScaledInstance(32, 32, Image.SCALE_SMOOTH)));
        }
        lightPanel.add(lightIconLabel, BorderLayout.CENTER);
        JLabel lightText = new JLabel(LangManager.getString("setting.icon.light"), SwingConstants.CENTER);
        lightText.setFont(new Font("微软雅黑", Font.PLAIN, 10));
        lightPanel.add(lightText, BorderLayout.SOUTH);
        previewPanel.add(lightPanel);

        // 深色图标预览
        JPanel darkPanel = new JPanel(new BorderLayout());
        darkPanel.setBackground(Color.BLACK);
        darkPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        JLabel darkIconLabel = new JLabel();
        darkIconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        Image darkIcon = WinllxIcon.getIconImage(1);
        if (darkIcon != null) {
            darkIconLabel.setIcon(new ImageIcon(darkIcon.getScaledInstance(32, 32, Image.SCALE_SMOOTH)));
        }
        darkPanel.add(darkIconLabel, BorderLayout.CENTER);
        JLabel darkText = new JLabel(LangManager.getString("setting.icon.dark"), SwingConstants.CENTER);
        darkText.setFont(new Font("微软雅黑", Font.PLAIN, 10));
        darkText.setForeground(Color.WHITE);
        darkPanel.add(darkText, BorderLayout.SOUTH);
        previewPanel.add(darkPanel);

        dialog.add(previewPanel);

        iconSelector.addSelectionListener((index, opt) -> {
            WinllxIcon.setTheme(index);
            WinllxIcon.applyToFrame(mainFrame);
            WinllxIcon.applyToFrame(dialog);
        });
        dialog.add(iconSelector);

        // 测试按钮 - 打开测试窗口查看图标效果
        GlassButton testBtn = GlassButton.createButton(LangManager.getString("btn.test"), 180, 40);
        testBtn.setBounds(10, 295, 180, 40);
        testBtn.addActionListener(e -> {
            JFrame testFrame = WinllxIcon.createFrame("图标测试窗口 - " + (WinllxIcon.getCurrentTheme() == 0 ? LangManager.getString("setting.icon.light") : LangManager.getString("setting.icon.dark")));
            testFrame.setSize(300, 200);
            testFrame.setLocationRelativeTo(dialog);
            testFrame.setLayout(new BorderLayout());

            JLabel testLabel = new JLabel(LangManager.getString("setting.icon.theme") + "：" + (WinllxIcon.getCurrentTheme() == 0 ? LangManager.getString("setting.icon.light") : LangManager.getString("setting.icon.dark")), SwingConstants.CENTER);
            testLabel.setFont(new Font("微软雅黑", Font.BOLD, 16));
            testFrame.add(testLabel, BorderLayout.CENTER);

            testFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            testFrame.setVisible(true);
        });
        dialog.add(testBtn);

        // 音量设置
        JLabel volumeLabel = new JLabel(LangManager.getString("setting.volume"));
        volumeLabel.setBounds(10, 350, 120, 30);
        dialog.add(volumeLabel);

        GlassSlider[] sliderRef = new GlassSlider[1];
        // 读取当前系统音量
        int currentVol = getSystemVolume();
        sliderRef[0] = GlassSlider.create(dialog, 0, 360, 200, 50, currentVol, evt -> {
            int volume = sliderRef[0].getValue();
            setSystemVolume(volume);
        });
        sliderRef[0].setBounds(10, 380, 200, 50);
        dialog.add(sliderRef[0]);

        dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialog.setVisible(true);
    }

    private static Color getContrastColor(Color bg) {
        if (bg == null) return Color.BLACK;
        double y = 0.2126 * bg.getRed() + 0.7152 * bg.getGreen() + 0.0722 * bg.getBlue();
        return y < 128 ? Color.WHITE : Color.BLACK;
    }

    private static void updateIconPreview(JLabel preview, int theme) {
        Image icon = WinllxIcon.getIconImage(theme);
        if (icon != null) {
            Image scaled = icon.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
            preview.setIcon(new ImageIcon(scaled));
        } else {
            preview.setIcon(null);
            preview.setText(theme == 0 ? LangManager.getString("setting.icon.light") : LangManager.getString("setting.icon.dark"));
        }
    }

    private static void syncTextColor() {
        Color bg = mainFrame.getContentPane().getBackground();
        Color textColor = getContrastColor(bg);
        for (Component c : mainFrame.getContentPane().getComponents()) {
            if (c instanceof JLabel) {
                ((JLabel) c).setForeground(textColor);
            } else if (c instanceof GlassButton) {
                ((GlassButton) c).setTextColor(textColor);
            } else if (c instanceof AbstractButton) {
                ((AbstractButton) c).setForeground(textColor);
            }
        }
        mainFrame.repaint();
    }

    private static void applyTheme(int index) {
        Color color = switch (index) {
            case 1 ->
                Color.BLACK;
            case 2 ->
                Color.BLUE;
            default ->
                Color.WHITE;
        };
        mainFrame.getContentPane().setBackground(color);
        saveBackgroundColor(color);
        syncTextColor();
        mainFrame.repaint();
    }

    private static Color loadBackgroundColor() {
        try {
            java.io.File file = new java.io.File(SETTINGS_FILE);
            if (file.exists()) {
                java.util.Properties props = new java.util.Properties();
                props.load(new java.io.FileInputStream(file));
                String hex = props.getProperty("bgColor");
                if (hex != null && !hex.isEmpty()) {
                    return hexToColor(hex);
                }
            }
        } catch (Exception e) {
        }
        return DEFAULT_BG;
    }

    private static Color loadTextColor() {
        try {
            java.io.File file = new java.io.File(SETTINGS_FILE);
            if (file.exists()) {
                java.util.Properties props = new java.util.Properties();
                props.load(new java.io.FileInputStream(file));
                String tc = props.getProperty("textColor");
                if ("white".equalsIgnoreCase(tc)) {
                    return Color.WHITE;
                }
            }
        } catch (Exception e) {
        }
        return Color.BLACK;
    }

    private static void saveBackgroundColor(Color color) {
        try {
            java.io.File dir = new java.io.File(SETTINGS_FILE).getParentFile();
            if (dir != null && !dir.exists()) {
                dir.mkdirs();
            }
            java.util.Properties props = new java.util.Properties();
            props.setProperty("bgColor", colorToHex(color));
            props.setProperty("textColor", getContrastColor(color) == Color.WHITE ? "white" : "black");
            props.store(new java.io.FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        } catch (Exception e) {
        }
    }

    private static String colorToHex(Color color) {
        return String.format("#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
    }

    private static Color hexToColor(String hex) {
        if (hex.startsWith("#")) {
            hex = hex.substring(1);
        }
        if (hex.length() == 6) {
            int r = Integer.parseInt(hex.substring(0, 2), 16);
            int g = Integer.parseInt(hex.substring(2, 4), 16);
            int b = Integer.parseInt(hex.substring(4, 6), 16);
            return new Color(r, g, b);
        }
        return DEFAULT_BG;
    }

    private static void initSystemTray() {
        if (!trayEnabled || !SystemTray.isSupported()) {
            return;
        }

        SystemTray tray = SystemTray.getSystemTray();
        Image image = Toolkit.getDefaultToolkit().getImage(TRAY_ICON_PATH);

        PopupMenu popup = new PopupMenu();
        MenuItem openItem = new MenuItem(LangManager.getString("tray.open"));
        MenuItem settingsItem = new MenuItem(LangManager.getString("tray.settings"));
        MenuItem exitItem = new MenuItem(LangManager.getString("tray.exit"));

        popup.add(openItem);
        popup.addSeparator();
        popup.add(settingsItem);
        popup.addSeparator();
        popup.add(exitItem);

        trayIcon = new TrayIcon(image, APP_TITLE, popup);
        trayIcon.setImageAutoSize(true);

        openItem.addActionListener(e -> setMainVisible(true));
        settingsItem.addActionListener(e -> openSettings());
        exitItem.addActionListener(e -> {
            tray.remove(trayIcon);
            System.exit(0);
        });
        trayIcon.addActionListener(e -> setMainVisible(true));

        try {
            tray.add(trayIcon);
        } catch (AWTException ex) {
            System.err.println(LangManager.getString("msg.tray.error"));
        }
    }

    private static void setSystemVolume(int volume) {
        setSystemVolumeRobot(volume);
    }

    private static int getSystemVolume() {
        return 50;
    }

    private static void setSystemVolumeRobot(int volume) {
        try {
            Robot robot = new Robot();
            int vol = Math.max(0, Math.min(100, volume));

            for (int i = 0; i < 50; i++) {
                robot.keyPress(0xAE);
                robot.keyRelease(0xAE);
                Thread.sleep(5);
            }
            for (int i = 0; i < vol / 2; i++) {
                robot.keyPress(0xAF);
                robot.keyRelease(0xAF);
                Thread.sleep(5);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(mainFrame, LangManager.getString("msg.volume.error"), LangManager.getString("dialog.tip"), JOptionPane.WARNING_MESSAGE);
        }
    }

    public static void showNotification(String caption, String text) {
        if (trayIcon != null) {
            trayIcon.displayMessage(caption, text, TrayIcon.MessageType.INFO);
        }
    }

}

// ==================== 子模块：关机 ====================
class Winllx0 {

    public Winllx0() {
        try {
            Runtime.getRuntime().exec("shutdown -s -t 0");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, LangManager.getString("msg.shutdown.error"));
        }
    }
}

// ==================== 子模块：便笺 ====================
class Winllx2 {

    // 修改：统一使用 winllx 目录，便笺内容和配置文件同目录不同文件
    private static final String WINLLX_DIR = System.getProperty("user.dir") + "/Winllx";
    private static final String NOTES_FILE = WINLLX_DIR + "/notes.txt";
    private static final String CONFIG_FILE = WINLLX_DIR + "/config.properties";
    private static final int MAX_TABS = 50;
    // 新增：设置窗口单例引用
    private JFrame settingsFrameRef = null;

    private JFrame frame;
    private JTabbedPane tabbedPane;
    private java.util.List<String> loadedTitles = new java.util.ArrayList<>();
    private java.util.List<String> loadedContents = new java.util.ArrayList<>();
    private java.util.List<Boolean> loadedWraps = new java.util.ArrayList<>();

    // 新增：保存每个标签页 JTextArea 的引用，避免用 getComponentAt 坐标查找
    private java.util.List<JTextArea> textAreas = new java.util.ArrayList<>();

    // 新增：全局默认自动换行设置，从 config.properties 读取
    private boolean defaultLineWrap = true;

    public Winllx2() {
        loadConfig();   // 先读全局配置
        loadNotes();
        initUI();
    }

    private void initUI() {
        frame = WinllxIcon.createFrame(LangManager.getString("app.title") + LangManager.getString("module.note"));
        frame.setSize(500, 400);
        frame.setLocation(200, 200);
        frame.setLayout(new BorderLayout());
        frame.getContentPane().setBackground(Winllx.getMainBackgroundColor());

        tabbedPane = new JTabbedPane();

        if (loadedTitles.isEmpty()) {
            addNewTab("便签 1", "", defaultLineWrap);
        } else {
            for (int i = 0; i < loadedTitles.size(); i++) {
                boolean wrap = i < loadedWraps.size() ? loadedWraps.get(i) : defaultLineWrap;
                addNewTab(loadedTitles.get(i), loadedContents.get(i), wrap);
            }
        }

        // 鼠标监听：右键菜单 + 双击重命名
        tabbedPane.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && SwingUtilities.isLeftMouseButton(e)) {
                    int idx = tabbedPane.indexAtLocation(e.getX(), e.getY());
                    if (idx >= 0) {
                        renameTab(idx);
                    }
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    int idx = tabbedPane.indexAtLocation(e.getX(), e.getY());
                    if (idx >= 0) {
                        showTabContextMenu(idx, e.getX(), e.getY());
                    }
                }
            }
        });

        // 关闭窗口时自动保存
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                saveNotes();
            }
        });

        // 底部面板
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        bottomPanel.setOpaque(false);

        GlassButton addBtn = GlassButton.createButton(LangManager.getString("btn.add"), 45, 40);
        addBtn.setPreferredSize(new Dimension(45, 40));
        addBtn.addActionListener(e -> {
            int count = tabbedPane.getTabCount();
            if (count >= MAX_TABS) {
                JOptionPane.showMessageDialog(frame, String.format(LangManager.getString("msg.tab.limit"), MAX_TABS), LangManager.getString("dialog.tip"), JOptionPane.WARNING_MESSAGE);
                return;
            }
            // 修改：新建标签页使用全局默认值
            addNewTab("便签 " + (count + 1), "", defaultLineWrap);
            tabbedPane.setSelectedIndex(count);
        });

        GlassButton settingsBtn = GlassButton.createButton(LangManager.getString("btn.settings"), 80, 40);
        settingsBtn.setPreferredSize(new Dimension(80, 40));
        settingsBtn.addActionListener(e -> openSettings());

        bottomPanel.add(addBtn);
        bottomPanel.add(settingsBtn);

        frame.add(tabbedPane, BorderLayout.CENTER);
        frame.add(bottomPanel, BorderLayout.SOUTH);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }

    private void addNewTab(String title, String content, boolean lineWrap) {
        JTextArea textArea = new JTextArea(content);
        textArea.setLineWrap(lineWrap);
        textArea.setWrapStyleWord(true);
        textArea.setBackground(Winllx.getMainBackgroundColor());
        textAreas.add(textArea);

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.getViewport().setBackground(Winllx.getMainBackgroundColor());
        tabbedPane.addTab(title, scrollPane);
    }

    private void renameTab(int idx) {
        String current = tabbedPane.getTitleAt(idx);
        String newName = JOptionPane.showInputDialog(frame, LangManager.getString("dialog.rename"), current);
        if (newName != null && !newName.trim().isEmpty()) {
            tabbedPane.setTitleAt(idx, newName.trim());
        }
    }

    private void showTabContextMenu(int idx, int x, int y) {
        JPopupMenu menu = new JPopupMenu();

        JMenuItem renameItem = new JMenuItem(LangManager.getString("dialog.rename"));
        renameItem.addActionListener(ev -> renameTab(idx));

        JMenuItem closeItem = new JMenuItem(LangManager.getString("btn.close"));
        closeItem.addActionListener(ev -> {
            if (tabbedPane.getTabCount() > 1) {
                textAreas.remove(idx); // 同步移除引用
                tabbedPane.remove(idx);
            } else {
                JOptionPane.showMessageDialog(frame, LangManager.getString("msg.tab.keepone"), LangManager.getString("dialog.tip"), JOptionPane.WARNING_MESSAGE);
            }
        });

        menu.add(renameItem);
        menu.add(closeItem);
        menu.show(tabbedPane, x, y);
    }

    private void saveNotes() {
        try {
            java.io.File dir = new java.io.File(WINLLX_DIR);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            Properties props = new Properties();
            int count = 0;
            for (int i = 0; i < tabbedPane.getTabCount(); i++) {
                String title = tabbedPane.getTitleAt(i);
                // 修改：直接从 textAreas 列表获取，不再使用 getComponentAt(i) 坐标查找
                JTextArea textArea = textAreas.get(i);
                props.setProperty("title." + count, title);
                props.setProperty("content." + count, textArea.getText());
                props.setProperty("wrap." + count, String.valueOf(textArea.getLineWrap()));
                count++;
            }
            props.setProperty("count", String.valueOf(count));

            try (java.io.FileOutputStream fos = new java.io.FileOutputStream(NOTES_FILE)) {
                props.store(fos, "Winllx Notes");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, String.format(LangManager.getString("msg.save.error"), e.getMessage()), LangManager.getString("dialog.error"), JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void loadNotes() {
        java.io.File file = new java.io.File(NOTES_FILE);
        if (!file.exists()) {
            return;
        }

        try (java.io.FileInputStream fis = new java.io.FileInputStream(NOTES_FILE)) {
            Properties props = new Properties();
            props.load(fis);

            int count = Integer.parseInt(props.getProperty("count", "0"));
            if (count > 100) {
                System.err.println(String.format(LangManager.getString("msg.notes.reset"), count));
                return;
            }

            for (int i = 0; i < count; i++) {
                String title = props.getProperty("title." + i, "便签 " + (i + 1));
                String content = props.getProperty("content." + i, "");
                boolean wrap = Boolean.parseBoolean(props.getProperty("wrap." + i, "true"));
                loadedTitles.add(title);
                loadedContents.add(content);
                loadedWraps.add(wrap);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 新增：读取全局配置文件 config.properties
    private void loadConfig() {
        java.io.File file = new java.io.File(CONFIG_FILE);
        if (!file.exists()) {
            return;
        }
        try (java.io.FileInputStream fis = new java.io.FileInputStream(CONFIG_FILE)) {
            Properties props = new Properties();
            props.load(fis);
            defaultLineWrap = Boolean.parseBoolean(props.getProperty("note.wrap.default", "true"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 新增：保存全局配置文件 config.properties
    private void saveConfig() {
        try {
            java.io.File dir = new java.io.File(WINLLX_DIR);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            Properties props = new Properties();
            props.setProperty("note.wrap.default", String.valueOf(defaultLineWrap));

            try (java.io.FileOutputStream fos = new java.io.FileOutputStream(CONFIG_FILE)) {
                props.store(fos, "Winllx Configuration");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void openSettings() {
        // 如果设置窗口已存在且可见，直接置顶，不再新建
        if (settingsFrameRef != null && settingsFrameRef.isVisible()) {
            settingsFrameRef.toFront();
            settingsFrameRef.requestFocus();
            return;
        }

        int idx = tabbedPane.getSelectedIndex();
        if (idx < 0) {
            return;
        }

        JTextArea textArea = textAreas.get(idx);

        settingsFrameRef = WinllxIcon.createFrame(LangManager.getString("app.title") + LangManager.getString("module.note") + LangManager.getString("btn.settings"));
        settingsFrameRef.setSize(350, 280);
        settingsFrameRef.setLocation(200, 200);
        settingsFrameRef.setLayout(null);
        settingsFrameRef.getContentPane().setBackground(Winllx.getMainBackgroundColor().darker());

        JLabel label = new JLabel(LangManager.getString("setting.wrap"));
        label.setForeground(Color.WHITE);
        label.setBounds(20, 10, 80, 30);
        settingsFrameRef.add(label);

        String[] wrapOptions = {LangManager.getString("btn.enable"), LangManager.getString("btn.disable")};
        GlassSegmentedControl wrapSelector = new GlassSegmentedControl(wrapOptions);
        wrapSelector.setBounds(20, 50, 200, 72);

        int initialIndex = defaultLineWrap ? 0 : 1;
        wrapSelector.setSelectedIndex(initialIndex);

        wrapSelector.addSelectionListener((selectedIdx, opt) -> {
            boolean newWrap = selectedIdx == 0;
            textArea.setLineWrap(newWrap);
            defaultLineWrap = newWrap;
            saveConfig();
        });

        settingsFrameRef.add(wrapSelector);

        GlassButton clearBtn = GlassButton.createButton(LangManager.getString("btn.clear"), 200, 40);
        clearBtn.setBounds(20, 140, 200, 40);
        clearBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                    settingsFrameRef,
                    LangManager.getString("msg.clear.confirm"),
                    LangManager.getString("msg.clear.title"),
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );
            if (confirm == JOptionPane.YES_OPTION) {
                clearAllNotes();
            }
        });
        settingsFrameRef.add(clearBtn);

        settingsFrameRef.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        settingsFrameRef.setVisible(true);
    }

    // 新增：清空所有便笺数据
    private void clearAllNotes() {
        try {
            // 删除配置文件
            java.io.File notesFile = new java.io.File(NOTES_FILE);
            java.io.File configFile = new java.io.File(CONFIG_FILE);
            if (notesFile.exists()) {
                notesFile.delete();
            }
            if (configFile.exists()) {
                configFile.delete();
            }

            // 清空内存中的数据
            loadedTitles.clear();
            loadedContents.clear();
            loadedWraps.clear();
            textAreas.clear();
            tabbedPane.removeAll();

            // 重置默认值并新建一个空白标签页
            defaultLineWrap = true;
            addNewTab("便签 1", "", defaultLineWrap);

            JOptionPane.showMessageDialog(frame, LangManager.getString("msg.clear.success"), LangManager.getString("dialog.tip"), JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, String.format(LangManager.getString("msg.save.error"), e.getMessage()), LangManager.getString("dialog.error"), JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
// ==================== 子模块：加载动画 ====================

class Loading {

    private JFrame frame;
    private javax.swing.Timer timer;
    private int angle = 0;

    public Loading() {
        initUI();
    }

    private void initUI() {
        frame = WinllxIcon.createFrame(LangManager.getString("app.loading.title"));
        frame.setSize(200, 200);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setAlwaysOnTop(true);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int cx = getWidth() / 2;
                int cy = getHeight() / 2;
                int r = 50;

                g2d.setColor(Color.LIGHT_GRAY);
                g2d.setStroke(new BasicStroke(2));
                g2d.drawOval(cx - r, cy - r, r * 2, r * 2);

                g2d.setColor(Color.BLUE);
                g2d.setStroke(new BasicStroke(5));
                g2d.drawArc(cx - r, cy - r, r * 2, r * 2, angle, 270);
            }
        };
        panel.setBackground(Color.WHITE);
        frame.add(panel);

        timer = new javax.swing.Timer(50, e -> {
            angle = (angle + 10) % 360;
            panel.repaint();
        });
        timer.start();
    }

    public void show() {
        frame.setVisible(true);
    }

    public void close() {
        if (timer != null) {
            timer.stop();
        }
        if (frame != null) {
            frame.dispose();
        }
    }
}

// ==================== 子模块：时钟 ====================
class Winllx5 extends JFrame {

    private JTabbedPane tabbedPane;
    private ClockPanel clockPanel;
    private AlarmPanel alarmPanel;
    private CountdownPanel countdownPanel;
    private StopwatchPanel stopwatchPanel;

    public Winllx5() {
        setTitle(LangManager.getString("module.clock"));
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Winllx.getMainBackgroundColor());

        // 应用图标
        WinllxIcon.applyToFrame(this);

        tabbedPane = new JTabbedPane();
        clockPanel = new ClockPanel();
        alarmPanel = new AlarmPanel();
        countdownPanel = new CountdownPanel();
        stopwatchPanel = new StopwatchPanel();

        tabbedPane.addTab(LangManager.getString("clock.tab.time"), clockPanel);
        tabbedPane.addTab(LangManager.getString("clock.tab.alarm"), alarmPanel);
        tabbedPane.addTab(LangManager.getString("clock.tab.countdown"), countdownPanel);
        tabbedPane.addTab(LangManager.getString("clock.tab.stopwatch"), stopwatchPanel);

        add(tabbedPane);

        java.util.Timer timer = new java.util.Timer();
        timer.scheduleAtFixedRate(new java.util.TimerTask() {
            @Override
            public void run() {
                clockPanel.repaint();
            }
        }, 0, 1000);
    }

    class ClockPanel extends JPanel {

        private java.text.SimpleDateFormat timeFormat = new java.text.SimpleDateFormat("HH:mm:ss");
        private java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyy年MM月dd日 EEEE");

        public ClockPanel() {
            setLayout(new BorderLayout());
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR);
            int minute = calendar.get(Calendar.MINUTE);
            int second = calendar.get(Calendar.SECOND);

            String time = timeFormat.format(calendar.getTime());
            String date = dateFormat.format(calendar.getTime());

            g.setFont(new Font("Microsoft YaHei", Font.BOLD, 24));
            FontMetrics fm = g.getFontMetrics();
            int timeWidth = fm.stringWidth(time);
            g.drawString(time, (getWidth() - timeWidth) / 2, 50);

            g.setFont(new Font("Microsoft YaHei", Font.PLAIN, 16));
            fm = g.getFontMetrics();
            int dateWidth = fm.stringWidth(date);
            g.drawString(date, (getWidth() - dateWidth) / 2, 80);

            int centerX = getWidth() / 2;
            int centerY = getHeight() / 2 + 30;
            int radius = Math.min(getWidth(), getHeight()) / 3;

            g.setColor(Color.BLACK);
            g.drawOval(centerX - radius, centerY - radius, 2 * radius, 2 * radius);

            for (int i = 0; i < 60; i++) {
                double angle = Math.toRadians(6 * i);
                int x1 = centerX + (int) (0.9 * radius * Math.sin(angle));
                int y1 = centerY - (int) (0.9 * radius * Math.cos(angle));
                int x2 = centerX + (int) (radius * Math.sin(angle));
                int y2 = centerY - (int) (radius * Math.cos(angle));

                if (i % 5 == 0) {
                    g.setColor(Color.BLACK);
                    g.drawLine(x1, y1, x2, y2);
                } else {
                    g.setColor(Color.GRAY);
                    g.drawLine(x1, y1, x2, y2);
                }
            }

            double hourAngle = Math.toRadians(30 * hour + 0.5 * minute);
            int hourHandLength = radius / 2;
            int hourX = centerX + (int) (hourHandLength * Math.sin(hourAngle));
            int hourY = centerY - (int) (hourHandLength * Math.cos(hourAngle));
            g.setColor(Color.BLACK);
            g.drawLine(centerX, centerY, hourX, hourY);

            double minuteAngle = Math.toRadians(6 * minute + 0.1 * second);
            int minuteHandLength = 3 * radius / 4;
            int minuteX = centerX + (int) (minuteHandLength * Math.sin(minuteAngle));
            int minuteY = centerY - (int) (minuteHandLength * Math.cos(minuteAngle));
            g.setColor(Color.BLUE);
            g.drawLine(centerX, centerY, minuteX, minuteY);

            double secondAngle = Math.toRadians(6 * second);
            int secondHandLength = 4 * radius / 5;
            int secondX = centerX + (int) (secondHandLength * Math.sin(secondAngle));
            int secondY = centerY - (int) (secondHandLength * Math.cos(secondAngle));
            g.setColor(Color.RED);
            g.drawLine(centerX, centerY, secondX, secondY);

            g.setColor(Color.RED);
            g.fillOval(centerX - 5, centerY - 5, 10, 10);
        }
    }

    class AlarmPanel extends JPanel {

        private DefaultListModel<String> alarmListModel;
        private JList<String> alarmList;
        private JButton addButton;
        private JButton deleteButton;

        public AlarmPanel() {
            setLayout(new BorderLayout());

            alarmListModel = new DefaultListModel<>();
            alarmList = new JList<>(alarmListModel);
            add(new JScrollPane(alarmList), BorderLayout.CENTER);

            JPanel buttonPanel = new JPanel();
            addButton = new JButton(LangManager.getString("clock.alarm.add"));
            deleteButton = new JButton(LangManager.getString("clock.alarm.delete"));

            addButton.addActionListener(e -> addAlarm());
            deleteButton.addActionListener(e -> deleteAlarm());

            buttonPanel.add(addButton);
            buttonPanel.add(deleteButton);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        private void addAlarm() {
            JSpinner hourSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 23, 1));
            JSpinner minuteSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));

            JPanel panel = new JPanel(new GridLayout(2, 2));
            panel.add(new JLabel(LangManager.getString("clock.hour")));
            panel.add(hourSpinner);
            panel.add(new JLabel(LangManager.getString("clock.minute")));
            panel.add(minuteSpinner);

            int result = JOptionPane.showConfirmDialog(null, panel, LangManager.getString("clock.alarm.set"),
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                int hour = (Integer) hourSpinner.getValue();
                int minute = (Integer) minuteSpinner.getValue();
                alarmListModel.addElement(String.format("%02d:%02d", hour, minute));
            }
        }

        private void deleteAlarm() {
            int selectedIndex = alarmList.getSelectedIndex();
            if (selectedIndex != -1) {
                alarmListModel.remove(selectedIndex);
            }
        }
    }

    class CountdownPanel extends JPanel {

        private JSpinner hourSpinner;
        private JSpinner minuteSpinner;
        private JSpinner secondSpinner;
        private JButton startButton;
        private JButton stopButton;
        private JLabel countdownLabel;
        private java.util.Timer countdownTimer;
        private int remainingSeconds;

        public CountdownPanel() {
            setLayout(new BorderLayout());

            JPanel inputPanel = new JPanel(new GridLayout(3, 2));
            hourSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 23, 1));
            minuteSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));
            secondSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));

            inputPanel.add(new JLabel(LangManager.getString("clock.hour")));
            inputPanel.add(hourSpinner);
            inputPanel.add(new JLabel(LangManager.getString("clock.minute")));
            inputPanel.add(minuteSpinner);
            inputPanel.add(new JLabel(LangManager.getString("clock.second")));
            inputPanel.add(secondSpinner);

            JPanel buttonPanel = new JPanel();
            startButton = new JButton(LangManager.getString("clock.countdown.start"));
            stopButton = new JButton(LangManager.getString("clock.countdown.stop"));
            stopButton.setEnabled(false);

            startButton.addActionListener(e -> startCountdown());
            stopButton.addActionListener(e -> stopCountdown());

            buttonPanel.add(startButton);
            buttonPanel.add(stopButton);

            countdownLabel = new JLabel("00:00:00", SwingConstants.CENTER);
            countdownLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 24));

            add(inputPanel, BorderLayout.NORTH);
            add(countdownLabel, BorderLayout.CENTER);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        private void startCountdown() {
            int hours = (Integer) hourSpinner.getValue();
            int minutes = (Integer) minuteSpinner.getValue();
            int seconds = (Integer) secondSpinner.getValue();

            remainingSeconds = hours * 3600 + minutes * 60 + seconds;
            updateCountdownLabel();

            startButton.setEnabled(false);
            stopButton.setEnabled(true);

            countdownTimer = new java.util.Timer();
            countdownTimer.scheduleAtFixedRate(new java.util.TimerTask() {
                @Override
                public void run() {
                    if (remainingSeconds > 0) {
                        remainingSeconds--;
                        SwingUtilities.invokeLater(() -> updateCountdownLabel());
                    } else {
                        stopCountdown();
                        Winllx.showNotification(LangManager.getString("clock.countdown.end"), LangManager.getString("clock.countdown.msg"));
                    }
                }
            }, 1000, 1000);
        }

        private void stopCountdown() {
            if (countdownTimer != null) {
                countdownTimer.cancel();
                countdownTimer = null;
            }
            startButton.setEnabled(true);
            stopButton.setEnabled(false);
        }

        private void updateCountdownLabel() {
            int hours = remainingSeconds / 3600;
            int minutes = (remainingSeconds % 3600) / 60;
            int seconds = remainingSeconds % 60;
            countdownLabel.setText(String.format("%02d:%02d:%02d", hours, minutes, seconds));
        }
    }

    class StopwatchPanel extends JPanel {

        private JLabel timeLabel;
        private GlassButton startButton;
        private GlassButton stopButton;
        private GlassButton resetButton;
        private GlassButton lapButton;
        private javax.swing.Timer stopwatchTimer;
        private long startTime;
        private boolean isRunning;
        private long elapsedAtStop = 0;

        // 目标时间提醒
        private JTextField targetTimeField;
        private JLabel targetStatusLabel;
        private boolean targetReached = false;
        private long targetMillis = -1;

        // 计次记录
        private DefaultListModel<String> lapListModel;
        private JList<String> lapList;
        private java.util.List<Long> lapTimes = new ArrayList<>();
        private long lastLapElapsed = 0;

        public StopwatchPanel() {
            setLayout(new BorderLayout(10, 10));
            setBackground(Winllx.getMainBackgroundColor());

            // 顶部：时间显示
            timeLabel = new JLabel("00:00:00.000", SwingConstants.CENTER);
            timeLabel.setFont(new Font("Consolas", Font.BOLD, 36));
            timeLabel.setForeground(new Color(0, 200, 255));
            timeLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));
            add(timeLabel, BorderLayout.NORTH);

            // 中部：目标时间设置 + 计次列表
            JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
            centerPanel.setBackground(Winllx.getMainBackgroundColor());
            centerPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

            // 目标时间面板
            JPanel targetPanel = new JPanel(new GridLayout(2, 1, 5, 5));
            targetPanel.setBackground(Winllx.getMainBackgroundColor().darker());
            targetPanel.setBorder(BorderFactory.createTitledBorder(
                    BorderFactory.createLineBorder(new Color(55, 55, 65)),
                    LangManager.getString("clock.target.title"), javax.swing.border.TitledBorder.LEFT,
                    javax.swing.border.TitledBorder.TOP,
                    new Font("微软雅黑", Font.BOLD, 12), new Color(200, 160, 255)
            ));

            JLabel hintLabel = new JLabel(LangManager.getString("clock.target.hint"));
            hintLabel.setFont(new Font("微软雅黑", Font.PLAIN, 11));
            hintLabel.setForeground(new Color(150, 150, 150));

            targetTimeField = new JTextField(10);
            targetTimeField.setFont(new Font("Consolas", Font.PLAIN, 14));
            targetTimeField.setBackground(Winllx.getMainBackgroundColor().darker().darker());
            targetTimeField.setForeground(Color.WHITE);
            targetTimeField.setCaretColor(new Color(0, 200, 255));

            JPanel targetRow1 = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
            targetRow1.setBackground(Winllx.getMainBackgroundColor().darker());
            targetRow1.add(hintLabel);
            targetRow1.add(targetTimeField);
            targetPanel.add(targetRow1);

            GlassButton setTargetBtn = GlassButton.createButton(LangManager.getString("clock.target.set"), 60, 28);
            setTargetBtn.setPreferredSize(new Dimension(60, 28));
            setTargetBtn.addActionListener(e -> parseTargetTime());

            GlassButton clearTargetBtn = GlassButton.createButton(LangManager.getString("clock.target.clear"), 60, 28);
            clearTargetBtn.setPreferredSize(new Dimension(60, 28));
            clearTargetBtn.addActionListener(e -> {
                targetTimeField.setText("");
                targetMillis = -1;
                targetReached = false;
                targetStatusLabel.setText(LangManager.getString("clock.target.none"));
                targetStatusLabel.setForeground(new Color(150, 150, 150));
            });

            targetStatusLabel = new JLabel(LangManager.getString("clock.target.none"));
            targetStatusLabel.setFont(new Font("微软雅黑", Font.BOLD, 12));
            targetStatusLabel.setForeground(new Color(150, 150, 150));

            JPanel targetRow2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
            targetRow2.setBackground(Winllx.getMainBackgroundColor().darker());
            targetRow2.add(setTargetBtn);
            targetRow2.add(clearTargetBtn);
            targetRow2.add(targetStatusLabel);
            targetPanel.add(targetRow2);

            centerPanel.add(targetPanel, BorderLayout.NORTH);

            // 计次列表面板
            JPanel lapPanel = new JPanel(new BorderLayout(5, 5));
            lapPanel.setBackground(Winllx.getMainBackgroundColor());
            lapPanel.setBorder(BorderFactory.createTitledBorder(
                    BorderFactory.createLineBorder(new Color(55, 55, 65)),
                    LangManager.getString("clock.lap.title"), javax.swing.border.TitledBorder.LEFT,
                    javax.swing.border.TitledBorder.TOP,
                    new Font("微软雅黑", Font.BOLD, 12), new Color(100, 200, 255)
            ));

            lapListModel = new DefaultListModel<>();
            lapList = new JList<>(lapListModel);
            lapList.setFont(new Font("Consolas", Font.PLAIN, 13));
            lapList.setBackground(Winllx.getMainBackgroundColor().darker());
            lapList.setForeground(new Color(200, 200, 220));
            lapList.setSelectionBackground(Winllx.getMainBackgroundColor().darker());
            JScrollPane lapScroll = new JScrollPane(lapList);
            lapScroll.setPreferredSize(new Dimension(0, 120));
            lapScroll.setBorder(BorderFactory.createLineBorder(new Color(55, 55, 65), 1));
            lapPanel.add(lapScroll, BorderLayout.CENTER);

            centerPanel.add(lapPanel, BorderLayout.CENTER);
            add(centerPanel, BorderLayout.CENTER);

            // 底部：控制按钮
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
            buttonPanel.setBackground(Winllx.getMainBackgroundColor());
            buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));

            startButton = GlassButton.createButton(LangManager.getString("clock.stopwatch.start"), 80, 38);
            startButton.setPreferredSize(new Dimension(80, 38));
            startButton.addActionListener(e -> startStopwatch());
            buttonPanel.add(startButton);

            stopButton = GlassButton.createButton(LangManager.getString("clock.stopwatch.stop"), 80, 38);
            stopButton.setPreferredSize(new Dimension(80, 38));
            stopButton.addActionListener(e -> stopStopwatch());
            stopButton.setEnabled(false);
            buttonPanel.add(stopButton);

            lapButton = GlassButton.createButton(LangManager.getString("clock.stopwatch.lap"), 80, 38);
            lapButton.setPreferredSize(new Dimension(80, 38));
            lapButton.addActionListener(e -> recordLap());
            lapButton.setEnabled(false);
            buttonPanel.add(lapButton);

            resetButton = GlassButton.createButton(LangManager.getString("clock.stopwatch.reset"), 80, 38);
            resetButton.setPreferredSize(new Dimension(80, 38));
            resetButton.addActionListener(e -> resetStopwatch());
            buttonPanel.add(resetButton);

            add(buttonPanel, BorderLayout.SOUTH);
        }

        private void parseTargetTime() {
            String input = targetTimeField.getText().trim();
            if (input.isEmpty()) {
                targetStatusLabel.setText(LangManager.getString("clock.target.input.empty"));
                targetStatusLabel.setForeground(new Color(255, 100, 100));
                return;
            }

            long millis = parseTimeString(input);
            if (millis < 0) {
                targetStatusLabel.setText(LangManager.getString("clock.target.format.error"));
                targetStatusLabel.setForeground(new Color(255, 100, 100));
                JOptionPane.showMessageDialog(this,
                        LangManager.getString("clock.target.format.detail"),
                        LangManager.getString("clock.target.format.error"), JOptionPane.ERROR_MESSAGE);
                return;
            }

            targetMillis = millis;
            targetReached = false;
            targetStatusLabel.setText(String.format(LangManager.getString("clock.target.status"), formatTime(millis)));
            targetStatusLabel.setForeground(new Color(80, 255, 120));
        }

        /**
         * 解析时间字符串，返回毫秒数，-1 表示解析失败
         */
        private long parseTimeString(String input) {
            input = input.trim();
            try {
                // 纯数字 = 秒
                if (input.matches("\\d+")) {
                    return Long.parseLong(input) * 1000L;
                }

                String[] parts = input.split(":");
                if (parts.length == 2) {
                    // MM:SS
                    long min = Long.parseLong(parts[0].trim());
                    long sec = Long.parseLong(parts[1].trim());
                    if (sec >= 60) {
                        return -1;
                    }
                    return (min * 60 + sec) * 1000L;
                }
                if (parts.length == 3) {
                    // HH:MM:SS
                    long hour = Long.parseLong(parts[0].trim());
                    long min = Long.parseLong(parts[1].trim());
                    long sec = Long.parseLong(parts[2].trim());
                    if (min >= 60 || sec >= 60) {
                        return -1;
                    }
                    return (hour * 3600 + min * 60 + sec) * 1000L;
                }
                return -1;
            } catch (NumberFormatException e) {
                return -1;
            }
        }

        private String formatTime(long millis) {
            long hours = millis / 3600000;
            long minutes = (millis % 3600000) / 60000;
            long seconds = (millis % 60000) / 1000;
            if (hours > 0) {
                return String.format("%02d:%02d:%02d", hours, minutes, seconds);
            }
            return String.format("%02d:%02d", minutes, seconds);
        }

        private void startStopwatch() {
            if (!isRunning) {
                startTime = System.currentTimeMillis() - elapsedAtStop;
                isRunning = true;
                startButton.setEnabled(false);
                stopButton.setEnabled(true);
                lapButton.setEnabled(true);

                stopwatchTimer = new javax.swing.Timer(10, e -> {
                    long elapsed = System.currentTimeMillis() - startTime;
                    updateStopwatchLabel(elapsed);

                    // 检查目标时间
                    if (targetMillis > 0 && !targetReached && elapsed >= targetMillis) {
                        targetReached = true;
                        targetStatusLabel.setText(LangManager.getString("clock.target.reached"));
                        targetStatusLabel.setForeground(new Color(255, 200, 60));
                        Winllx.showNotification(LangManager.getString("clock.notify.title"), String.format(LangManager.getString("clock.notify.msg"), formatTime(targetMillis)));
                        // 播放系统提示音
                        java.awt.Toolkit.getDefaultToolkit().beep();
                    }
                });
                stopwatchTimer.start();
            }
        }

        private void stopStopwatch() {
            if (isRunning) {
                if (stopwatchTimer != null) {
                    stopwatchTimer.stop();
                }
                elapsedAtStop = System.currentTimeMillis() - startTime;
                isRunning = false;
                startButton.setEnabled(true);
                stopButton.setEnabled(false);
                lapButton.setEnabled(false);
            }
        }

        private void resetStopwatch() {
            if (stopwatchTimer != null) {
                stopwatchTimer.stop();
            }
            isRunning = false;
            startTime = 0;
            elapsedAtStop = 0;
            lastLapElapsed = 0;
            targetReached = false;
            lapTimes.clear();
            lapListModel.clear();
            startButton.setEnabled(true);
            stopButton.setEnabled(false);
            lapButton.setEnabled(false);
            timeLabel.setText("00:00:00.000");
            if (targetMillis > 0) {
                targetStatusLabel.setText(String.format(LangManager.getString("clock.target.status"), formatTime(targetMillis)));
                targetStatusLabel.setForeground(new Color(80, 255, 120));
            }
        }

        private void recordLap() {
            if (!isRunning) {
                return;
            }
            long elapsed = System.currentTimeMillis() - startTime;
            long lapDuration = elapsed - lastLapElapsed;
            lastLapElapsed = elapsed;
            lapTimes.add(elapsed);

            int lapNum = lapTimes.size();
            String totalStr = formatStopwatch(elapsed);
            String lapStr = formatStopwatch(lapDuration);
            lapListModel.addElement(String.format(LangManager.getString("clock.lap.entry"), lapNum, lapStr, totalStr));

            // 自动滚动到底部
            lapList.ensureIndexIsVisible(lapListModel.size() - 1);
        }

        private void updateStopwatchLabel(long elapsed) {
            timeLabel.setText(formatStopwatch(elapsed));
        }

        private String formatStopwatch(long elapsed) {
            long hours = elapsed / 3600000;
            long minutes = (elapsed % 3600000) / 60000;
            long seconds = (elapsed % 60000) / 1000;
            long millis = elapsed % 1000;
            return String.format("%02d:%02d:%02d.%03d", hours, minutes, seconds, millis);
        }
    }

}
