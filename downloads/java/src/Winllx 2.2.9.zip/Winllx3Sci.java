import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * Winllx 科学计算器模块（增强版）
 * 新增：历史记录、单位换算、复制结果、清空历史
 */
public class Winllx3Sci {

    private static final int WIN_W = 520;
    private static final int WIN_H = 750;
    private static final String HISTORY_FILE = System.getProperty("user.dir") + "/Winllx/calc_history.txt";

    private static final String[][] BUTTONS = {
        {"sin", "cos", "tan", "log", "ln"},
        {"π", "e", "x²", "x³", "x^y"},
        {"√", "³√", "(", ")", "n!"},
        {"C", "⌫", "%", "÷", "1/x"},
        {"7", "8", "9", "×", "Ans"},
        {"4", "5", "6", "-", "deg"},
        {"1", "2", "3", "+", "="},
        {"0", ".", "00", "EXP", "Rand"}
    };

    private JFrame frame;
    private JTextArea display;
    private JLabel modeLabel;
    private String lastAnswer = "0";
    private boolean isDegree = true;
    private final List<String> historyList = new ArrayList<>();
    private JFrame historyFrameRef = null;

    public Winllx3Sci() {
        loadHistory();
        initUI();
    }

    private void initUI() {
        frame = WinllxIcon.createFrame("科学计算器");
        frame.setLayout(new BorderLayout(10, 10));
        frame.setSize(WIN_W, WIN_H);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(Winllx.getMainBackgroundColor());

        /* ---------- 顶部显示区 ---------- */
        JPanel topPanel = new JPanel(new BorderLayout(8, 8));
        topPanel.setBackground(Winllx.getMainBackgroundColor());
        topPanel.setBorder(BorderFactory.createEmptyBorder(12, 18, 6, 18));

        modeLabel = new JLabel("DEG", SwingConstants.RIGHT);
        modeLabel.setFont(new Font("微软雅黑", Font.BOLD, 14));
        modeLabel.setForeground(new Color(0, 200, 255));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Winllx.getMainBackgroundColor());
        headerPanel.add(modeLabel, BorderLayout.WEST);

        JButton settingsBtn = GlassButtonDemo.createButton("设置");
        settingsBtn.setPreferredSize(new Dimension(60, 30));
        settingsBtn.setFont(new Font("微软雅黑", Font.BOLD, 12));
        settingsBtn.addActionListener(e -> openSettings());
        headerPanel.add(settingsBtn, BorderLayout.EAST);

        topPanel.add(headerPanel, BorderLayout.NORTH);

        display = new JTextArea(3, 22);
        display.setFont(new Font("Consolas", Font.BOLD, 26));
        display.setLineWrap(true);
        display.setWrapStyleWord(true);
        display.setEditable(false);
        display.setBackground(Winllx.getMainBackgroundColor().darker());
        display.setForeground(new Color(230, 230, 230));
        display.setCaretColor(new Color(0, 200, 255));
        display.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));

        JScrollPane scroll = new JScrollPane(display);
        scroll.setPreferredSize(new Dimension(WIN_W - 40, 140));
        scroll.setBorder(BorderFactory.createLineBorder(new Color(55, 55, 65), 1));
        topPanel.add(scroll, BorderLayout.CENTER);

        frame.add(topPanel, BorderLayout.NORTH);

        /* ---------- 按钮区 ---------- */
        JPanel btnPanel = new JPanel(new GridLayout(8, 5, 10, 10));
        btnPanel.setBorder(BorderFactory.createEmptyBorder(6, 18, 18, 18));
        btnPanel.setBackground(Winllx.getMainBackgroundColor());

        for (String[] row : BUTTONS) {
            for (String label : row) {
                JButton btn = GlassButtonDemo.createButton(label);
                btn.setFont(new Font("微软雅黑", Font.BOLD, 14));
                btn.setForeground(resolveForeground(label));
                btn.addActionListener(e -> handleButton(label));
                btnPanel.add(btn);
            }
        }

        frame.add(btnPanel, BorderLayout.CENTER);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }

    /* ==================== 设置窗口 ==================== */
    private void openSettings() {
        JFrame dialog = WinllxIcon.createFrame("计算器设置");
        dialog.setSize(350, 320);
        dialog.setLocationRelativeTo(frame);
        dialog.setLayout(null);
        dialog.getContentPane().setBackground(Winllx.getMainBackgroundColor().darker());

        // 计算器模式
        JLabel modeTitle = new JLabel("计算器模式");
        modeTitle.setFont(new Font("微软雅黑", Font.BOLD, 16));
        modeTitle.setForeground(Color.WHITE);
        modeTitle.setBounds(20, 10, 200, 30);
        dialog.add(modeTitle);

        String[] modes = {"标准", "科学"};
        GlassSegmentedControl modeSelector = new GlassSegmentedControl(modes);
        modeSelector.setBounds(20, 45, 300, 60);
        modeSelector.setSelectedIndex(1);
        modeSelector.addSelectionListener((index, opt) -> {
            if (index == 0) {
                dialog.dispose();
                frame.dispose();
                new Winllx3();
            }
        });
        dialog.add(modeSelector);

        // 历史记录按钮
        JButton historyBtn = GlassButtonDemo.createButton("历史记录");
        historyBtn.setBounds(20, 120, 130, 40);
        historyBtn.setFont(new Font("微软雅黑", Font.BOLD, 13));
        historyBtn.addActionListener(e -> {
            dialog.dispose();
            openHistoryWindow();
        });
        dialog.add(historyBtn);

        JButton convertBtn = GlassButtonDemo.createButton("单位换算");
        convertBtn.setBounds(170, 120, 130, 40);
        convertBtn.setFont(new Font("微软雅黑", Font.BOLD, 13));
        convertBtn.addActionListener(e -> openUnitConverter());
        dialog.add(convertBtn);

        JButton copyBtn = GlassButtonDemo.createButton("复制结果");
        copyBtn.setBounds(20, 175, 130, 40);
        copyBtn.setFont(new Font("微软雅黑", Font.BOLD, 13));
        copyBtn.addActionListener(e -> copyLastResult());
        dialog.add(copyBtn);

        JButton clearBtn = GlassButtonDemo.createButton("清空历史");
        clearBtn.setBounds(170, 175, 130, 40);
        clearBtn.setFont(new Font("微软雅黑", Font.BOLD, 13));
        clearBtn.setForeground(new Color(255, 100, 100));
        clearBtn.addActionListener(e -> clearHistory());
        dialog.add(clearBtn);

        dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialog.setVisible(true);
    }

    /* ==================== 历史记录窗口 ==================== */
    private void openHistoryWindow() {
        if (historyFrameRef != null && historyFrameRef.isVisible()) {
            historyFrameRef.toFront();
            return;
        }

        historyFrameRef = WinllxIcon.createFrame("计算历史");
        historyFrameRef.setSize(400, 500);
        historyFrameRef.setLocationRelativeTo(frame);
        historyFrameRef.getContentPane().setBackground(Winllx.getMainBackgroundColor());
        historyFrameRef.setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel("历史记录", SwingConstants.CENTER);
        title.setFont(new Font("微软雅黑", Font.BOLD, 18));
        title.setForeground(Color.WHITE);
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        historyFrameRef.add(title, BorderLayout.NORTH);

        JPanel listPanel = new JPanel();
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
        listPanel.setBackground(Winllx.getMainBackgroundColor());

        if (historyList.isEmpty()) {
            JLabel empty = new JLabel("暂无历史记录", SwingConstants.CENTER);
            empty.setFont(new Font("微软雅黑", Font.PLAIN, 14));
            empty.setForeground(new Color(150, 150, 150));
            listPanel.add(empty);
        } else {
            for (int i = historyList.size() - 1; i >= 0; i--) {
                String entry = historyList.get(i);
                JPanel itemPanel = createHistoryItem(entry, i);
                listPanel.add(itemPanel);
                listPanel.add(Box.createRigidArea(new Dimension(0, 5)));
            }
        }

        JScrollPane scroll = new JScrollPane(listPanel);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(55, 55, 65), 1));
        scroll.getVerticalScrollBar().setUnitIncrement(20);
        historyFrameRef.add(scroll, BorderLayout.CENTER);

        // 底部按钮
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        bottomPanel.setBackground(Winllx.getMainBackgroundColor());

        JButton useBtn = GlassButtonDemo.createButton("使用选中");
        useBtn.setPreferredSize(new Dimension(100, 35));
        useBtn.addActionListener(e -> {
            if (!historyList.isEmpty()) {
                String last = historyList.get(historyList.size() - 1);
                String result = last.substring(last.lastIndexOf("=") + 1).trim();
                display.setText(result);
            }
        });
        bottomPanel.add(useBtn);

        JButton closeBtn = GlassButtonDemo.createButton("关闭");
        closeBtn.setPreferredSize(new Dimension(80, 35));
        closeBtn.addActionListener(e -> historyFrameRef.dispose());
        bottomPanel.add(closeBtn);

        historyFrameRef.add(bottomPanel, BorderLayout.SOUTH);
        historyFrameRef.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        historyFrameRef.setVisible(true);
    }

    private JPanel createHistoryItem(String entry, int index) {
        JPanel panel = new JPanel(new BorderLayout(5, 0));
        panel.setBackground(Winllx.getMainBackgroundColor().darker().darker());
        panel.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        JLabel exprLabel = new JLabel(entry);
        exprLabel.setFont(new Font("Consolas", Font.PLAIN, 13));
        exprLabel.setForeground(new Color(200, 200, 220));
        panel.add(exprLabel, BorderLayout.CENTER);

        // 点击条目直接填入结果
        panel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                String result = entry.substring(entry.lastIndexOf("=") + 1).trim();
                display.setText(result);
                historyFrameRef.dispose();
            }

            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                panel.setBackground(Winllx.getMainBackgroundColor().darker());
                panel.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                panel.setBackground(Winllx.getMainBackgroundColor().darker().darker());
            }
        });

        return panel;
    }

    /* ==================== 单位换算器 ==================== */
    private void openUnitConverter() {
        JFrame convFrame = WinllxIcon.createFrame("单位换算");
        convFrame.setSize(400, 400);
        convFrame.setLocationRelativeTo(frame);
        convFrame.getContentPane().setBackground(Winllx.getMainBackgroundColor().darker());
        convFrame.setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel("单位换算", SwingConstants.CENTER);
        title.setFont(new Font("微软雅黑", Font.BOLD, 18));
        title.setForeground(Color.WHITE);
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        convFrame.add(title, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(Winllx.getMainBackgroundColor().darker());
        tabs.setForeground(Color.WHITE);

        // 长度换算
        tabs.addTab("长度", createConverterPanel(
            new String[]{"米(m)", "千米(km)", "厘米(cm)", "毫米(mm)", "英寸(in)", "英尺(ft)"},
            new double[]{1, 1000, 0.01, 0.001, 0.0254, 0.3048}
        ));

        // 重量换算
        tabs.addTab("重量", createConverterPanel(
            new String[]{"千克(kg)", "克(g)", "吨(t)", "磅(lb)", "盎司(oz)"},
            new double[]{1, 0.001, 1000, 0.453592, 0.0283495}
        ));

        // 温度换算
        tabs.addTab("温度", createTempConverterPanel());

        // 数据存储换算
        tabs.addTab("存储", createConverterPanel(
            new String[]{"字节(B)", "KB", "MB", "GB", "TB"},
            new double[]{1, 1024, 1024 * 1024, 1024 * 1024 * 1024, 1024L * 1024 * 1024 * 1024}
        ));

        convFrame.add(tabs, BorderLayout.CENTER);
        convFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        convFrame.setVisible(true);
    }

    private JPanel createConverterPanel(String[] units, double[] toBase) {
        JPanel panel = new JPanel(null);
        panel.setBackground(Winllx.getMainBackgroundColor().darker());

        JLabel inLabel = new JLabel("输入:");
        inLabel.setForeground(Color.WHITE);
        inLabel.setBounds(30, 20, 50, 25);
        panel.add(inLabel);

        JTextField inputField = new JTextField("1");
        inputField.setBounds(80, 20, 120, 25);
        panel.add(inputField);

        JComboBox<String> fromBox = new JComboBox<>(units);
        fromBox.setBounds(210, 20, 120, 25);
        panel.add(fromBox);

        JLabel outLabel = new JLabel("结果:");
        outLabel.setForeground(Color.WHITE);
        outLabel.setBounds(30, 60, 50, 25);
        panel.add(outLabel);

        JTextField outputField = new JTextField();
        outputField.setEditable(false);
        outputField.setBounds(80, 60, 120, 25);
        outputField.setBackground(Winllx.getMainBackgroundColor().darker().darker());
        outputField.setForeground(new Color(0, 255, 150));
        panel.add(outputField);

        JComboBox<String> toBox = new JComboBox<>(units);
        toBox.setBounds(210, 60, 120, 25);
        panel.add(toBox);

        JButton calcBtn = GlassButtonDemo.createButton("换算");
        calcBtn.setBounds(30, 110, 100, 35);
        calcBtn.addActionListener(e -> {
            try {
                double val = Double.parseDouble(inputField.getText());
                int fromIdx = fromBox.getSelectedIndex();
                int toIdx = toBox.getSelectedIndex();
                double base = val * toBase[fromIdx];
                double result = base / toBase[toIdx];
                outputField.setText(String.format("%.6f", result).replaceAll("0+$", "").replaceAll("\\.$", ""));
            } catch (NumberFormatException ex) {
                outputField.setText("输入错误");
            }
        });
        panel.add(calcBtn);

        JButton swapBtn = GlassButtonDemo.createButton("⇄ 交换");
        swapBtn.setBounds(150, 110, 100, 35);
        swapBtn.addActionListener(e -> {
            int temp = fromBox.getSelectedIndex();
            fromBox.setSelectedIndex(toBox.getSelectedIndex());
            toBox.setSelectedIndex(temp);
        });
        panel.add(swapBtn);

        return panel;
    }

    private JPanel createTempConverterPanel() {
        JPanel panel = new JPanel(null);
        panel.setBackground(Winllx.getMainBackgroundColor().darker());

        String[] units = {"摄氏度(°C)", "华氏度(°F)", "开尔文(K)"};

        JLabel inLabel = new JLabel("输入:");
        inLabel.setForeground(Color.WHITE);
        inLabel.setBounds(30, 20, 50, 25);
        panel.add(inLabel);

        JTextField inputField = new JTextField("0");
        inputField.setBounds(80, 20, 120, 25);
        panel.add(inputField);

        JComboBox<String> fromBox = new JComboBox<>(units);
        fromBox.setBounds(210, 20, 120, 25);
        panel.add(fromBox);

        JLabel outLabel = new JLabel("结果:");
        outLabel.setForeground(Color.WHITE);
        outLabel.setBounds(30, 60, 50, 25);
        panel.add(outLabel);

        JTextField outputField = new JTextField();
        outputField.setEditable(false);
        outputField.setBounds(80, 60, 120, 25);
        outputField.setBackground(Winllx.getMainBackgroundColor().darker().darker());
        outputField.setForeground(new Color(0, 255, 150));
        panel.add(outputField);

        JComboBox<String> toBox = new JComboBox<>(units);
        toBox.setBounds(210, 60, 120, 25);
        panel.add(toBox);

        JButton calcBtn = GlassButtonDemo.createButton("换算");
        calcBtn.setBounds(30, 110, 100, 35);
        calcBtn.addActionListener(e -> {
            try {
                double val = Double.parseDouble(inputField.getText());
                int from = fromBox.getSelectedIndex();
                int to = toBox.getSelectedIndex();
                double celsius;

                // 先转摄氏度
                switch (from) {
                    case 0 -> celsius = val;
                    case 1 -> celsius = (val - 32) * 5 / 9;
                    case 2 -> celsius = val - 273.15;
                    default -> celsius = val;
                }

                // 再转目标
                double result = switch (to) {
                    case 0 -> celsius;
                    case 1 -> celsius * 9 / 5 + 32;
                    case 2 -> celsius + 273.15;
                    default -> celsius;
                };

                outputField.setText(String.format("%.2f", result));
            } catch (NumberFormatException ex) {
                outputField.setText("输入错误");
            }
        });
        panel.add(calcBtn);

        return panel;
    }

    /* ==================== 工具方法 ==================== */
    private void copyLastResult() {
        String text = display.getText();
        String toCopy;
        if (text.contains("\n= ")) {
            toCopy = text.substring(text.lastIndexOf("\n= ") + 4).trim();
        } else if (text.contains("=")) {
            toCopy = text.substring(text.lastIndexOf("=") + 1).trim();
        } else {
            toCopy = text;
        }

        java.awt.datatransfer.StringSelection selection = new java.awt.datatransfer.StringSelection(toCopy);
        java.awt.Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);

        JOptionPane.showMessageDialog(frame, "已复制到剪贴板: " + toCopy, "复制成功", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearHistory() {
        int confirm = JOptionPane.showConfirmDialog(frame,
            "确定要清空所有历史记录吗？", "确认清空",
            JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) {
            historyList.clear();
            saveHistory();
            JOptionPane.showMessageDialog(frame, "历史记录已清空", "提示", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /* ==================== 历史记录持久化 ==================== */
    private void loadHistory() {
        File file = new File(HISTORY_FILE);
        if (!file.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) historyList.add(line.trim());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveHistory() {
        try {
            File dir = new File(System.getProperty("user.dir") + "/Winllx");
            if (!dir.exists()) dir.mkdirs();
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(HISTORY_FILE))) {
                for (String entry : historyList) {
                    bw.write(entry);
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void addToHistory(String expr, String result) {
        String entry = expr + " = " + result;
        historyList.add(entry);
        if (historyList.size() > 100) {
            historyList.remove(0); // 只保留最近100条
        }
        saveHistory();
    }

    /* ==================== 按钮路由 ==================== */
    private void handleButton(String label) {
        switch (label) {
            case "C" -> display.setText("");
            case "⌫" -> {
                String t = display.getText();
                if (t.contains("\n= ")) {
                    display.setText("");
                } else if (!t.isEmpty()) {
                    display.setText(t.substring(0, t.length() - 1));
                }
            }
            case "=" -> calculate();
            case "sin", "cos", "tan", "log", "ln", "sqrt", "cbrt", "fact" ->
                appendInput(label + "(");
            case "π" -> appendInput("π");
            case "e" -> appendInput("e");
            case "x²" -> appendInput("^2");
            case "x³" -> appendInput("^3");
            case "x^y" -> appendInput("^");
            case "√" -> appendInput("sqrt(");
            case "³√" -> appendInput("cbrt(");
            case "n!" -> appendInput("fact(");
            case "1/x" -> appendInput("1/(");
            case "Ans" -> appendInput("Ans");
            case "deg" -> {
                isDegree = !isDegree;
                modeLabel.setText(isDegree ? "DEG" : "RAD");
            }
            case "EXP" -> appendInput("E");
            case "Rand" -> appendInput(String.format("%.8f", Math.random()));
            case "×" -> appendInput("×");
            case "÷" -> appendInput("÷");
            case "%", "+", "-", "(", ")", "." -> appendInput(label);
            default -> appendInput(label);
        }
    }

    private void appendInput(String text) {
        String current = display.getText();
        if (current.contains("\n= ")) {
            int idx = current.lastIndexOf("\n= ");
            String result = current.substring(idx + 3).trim();

            boolean starter = text.matches("\\d|\\.00|π|e|Ans|Rand");
            boolean func = text.matches("sin\\(|cos\\(|tan\\(|log\\(|ln\\(|sqrt\\(|cbrt\\(|fact\\(");
            boolean op = text.matches("[+\\-×÷^%]|\\^2|\\^3|\\^");

            if (starter) {
                display.setText(text);
                return;
            }
            if (func) {
                display.setText(text + result + ")");
                return;
            }
            if (op) {
                display.setText(result + text);
                return;
            }
            display.setText(result + text);
            return;
        }
        display.setText(current + text);
    }

    private void calculate() {
        String raw = display.getText();
        String expr = raw.contains("\n= ") ? raw.substring(0, raw.indexOf("\n= ")) : raw;
        expr = expr.trim();
        if (expr.isEmpty()) return;

        try {
            ExpressionEvaluator ev = new ExpressionEvaluator(isDegree, lastAnswer);
            double result = ev.evaluate(expr);
            lastAnswer = String.valueOf(result);
            String formatted = formatResult(result);
            display.setText(expr + "\n= " + formatted);
            addToHistory(expr, formatted);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame,
                    "计算错误: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String formatResult(double v) {
        if (Double.isNaN(v)) return "NaN";
        if (Double.isInfinite(v)) return "Infinity";
        if (v == Math.floor(v) && Math.abs(v) < 1e15) return String.valueOf((long) v);

        String s = String.format("%.12f", v);
        s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        return s.length() > 18 ? String.format("%.8e", v) : s;
    }

    private static Color resolveForeground(String label) {
        return switch (label) {
            case "C" -> new Color(255, 90, 90);
            case "=" -> new Color(80, 255, 120);
            case "⌫" -> new Color(255, 200, 60);
            case "+", "-", "×", "÷", "^", "%", "x²", "x³", "x^y" -> new Color(100, 200, 255);
            case "sin", "cos", "tan", "log", "ln", "π", "e", "√", "³√", "n!", "1/x",
                 "Ans", "deg", "EXP", "Rand" -> new Color(200, 160, 255);
            default -> new Color(220, 220, 220);
        };
    }

    /* ==================== 表达式求值器 ==================== */
    private static class ExpressionEvaluator {
        private final boolean deg;
        private final String ans;

        ExpressionEvaluator(boolean deg, String ans) {
            this.deg = deg;
            this.ans = ans;
        }

        private static final class Token {
            enum Type { NUMBER, OPERATOR, FUNCTION, LEFT_PAREN, RIGHT_PAREN }
            final Type type;
            final String value;
            final double num;

            Token(double num) { this.type = Type.NUMBER; this.num = num; this.value = null; }
            Token(Type type, String value) { this.type = type; this.value = value; this.num = Double.NaN; }
        }

        double evaluate(String expr) {
            return evalRPN(toRPN(tokenize(expr)));
        }

        private List<Token> tokenize(String s) {
            List<Token> tokens = new ArrayList<>();
            int i = 0, n = s.length();
            while (i < n) {
                char c = s.charAt(i);
                if (Character.isWhitespace(c)) { i++; continue; }

                if (Character.isDigit(c) || c == '.') {
                    int st = i;
                    while (i < n && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '.' ||
                           s.charAt(i) == 'E' || s.charAt(i) == 'e')) {
                        if ((s.charAt(i) == 'E' || s.charAt(i) == 'e') && i + 1 < n &&
                            (s.charAt(i + 1) == '+' || s.charAt(i + 1) == '-')) i += 2;
                        else i++;
                    }
                    tokens.add(new Token(Double.parseDouble(s.substring(st, i))));
                    continue;
                }

                if (Character.isLetter(c)) {
                    int st = i;
                    while (i < n && Character.isLetter(s.charAt(i))) i++;
                    String w = s.substring(st, i);
                    switch (w) {
                        case "sin", "cos", "tan", "log", "ln", "sqrt", "cbrt", "fact", "abs" ->
                            tokens.add(new Token(Token.Type.FUNCTION, w));
                        case "pi", "π" -> tokens.add(new Token(Math.PI));
                        case "e" -> tokens.add(new Token(Math.E));
                        case "Ans" -> {
                            try { tokens.add(new Token(Double.parseDouble(ans))); }
                            catch (NumberFormatException e) { tokens.add(new Token(0)); }
                        }
                        default -> throw new RuntimeException("未知符号: " + w);
                    }
                    continue;
                }

                switch (c) {
                    case '+' -> tokens.add(new Token(Token.Type.OPERATOR, "+"));
                    case '-' -> tokens.add(new Token(Token.Type.OPERATOR, "-"));
                    case '*' -> tokens.add(new Token(Token.Type.OPERATOR, "*"));
                    case '/' -> tokens.add(new Token(Token.Type.OPERATOR, "/"));
                    case '^' -> tokens.add(new Token(Token.Type.OPERATOR, "^"));
                    case '%' -> tokens.add(new Token(Token.Type.OPERATOR, "%"));
                    case '×' -> tokens.add(new Token(Token.Type.OPERATOR, "*"));
                    case '÷' -> tokens.add(new Token(Token.Type.OPERATOR, "/"));
                    case '(' -> tokens.add(new Token(Token.Type.LEFT_PAREN, "("));
                    case ')' -> tokens.add(new Token(Token.Type.RIGHT_PAREN, ")"));
                    default -> throw new RuntimeException("无效字符: '" + c + "'");
                }
                i++;
            }
            return tokens;
        }

        private List<Token> toRPN(List<Token> tokens) {
            List<Token> out = new ArrayList<>();
            Stack<Token> stack = new Stack<>();

            for (Token t : tokens) {
                switch (t.type) {
                    case NUMBER -> out.add(t);
                    case FUNCTION -> stack.push(t);
                    case OPERATOR -> {
                        while (!stack.isEmpty() && stack.peek().type != Token.Type.LEFT_PAREN) {
                            Token top = stack.peek();
                            int pt = prec(top), pc = prec(t);
                            if (pt > pc || (pt == pc && !rightAssoc(t))) out.add(stack.pop());
                            else break;
                        }
                        stack.push(t);
                    }
                    case LEFT_PAREN -> stack.push(t);
                    case RIGHT_PAREN -> {
                        while (!stack.isEmpty() && stack.peek().type != Token.Type.LEFT_PAREN) out.add(stack.pop());
                        if (stack.isEmpty()) throw new RuntimeException("括号不匹配");
                        stack.pop();
                        if (!stack.isEmpty() && stack.peek().type == Token.Type.FUNCTION) out.add(stack.pop());
                    }
                }
            }
            while (!stack.isEmpty()) {
                if (stack.peek().type == Token.Type.LEFT_PAREN) throw new RuntimeException("括号不匹配");
                out.add(stack.pop());
            }
            return out;
        }

        private int prec(Token t) {
            if (t.type == Token.Type.FUNCTION) return 4;
            return switch (t.value) {
                case "^" -> 4;
                case "*", "/", "%" -> 3;
                case "+", "-" -> 2;
                default -> 0;
            };
        }

        private boolean rightAssoc(Token t) { return "^".equals(t.value); }

        private double evalRPN(List<Token> rpn) {
            Stack<Double> st = new Stack<>();
            for (Token t : rpn) {
                switch (t.type) {
                    case NUMBER -> st.push(t.num);
                    case OPERATOR -> {
                        if (st.size() < 2) throw new RuntimeException("表达式不完整");
                        double b = st.pop(), a = st.pop(), r;
                        r = switch (t.value) {
                            case "+" -> a + b;
                            case "-" -> a - b;
                            case "*" -> a * b;
                            case "/" -> {
                                if (Math.abs(b) < 1e-15) throw new RuntimeException("除数不能为 0");
                                yield a / b;
                            }
                            case "^" -> Math.pow(a, b);
                            case "%" -> a % b;
                            default -> throw new RuntimeException("未知运算符: " + t.value);
                        };
                        st.push(r);
                    }
                    case FUNCTION -> {
                        if (st.isEmpty()) throw new RuntimeException("函数缺少参数");
                        double x = st.pop(), r;
                        r = switch (t.value) {
                            case "sin" -> deg ? Math.sin(Math.toRadians(x)) : Math.sin(x);
                            case "cos" -> deg ? Math.cos(Math.toRadians(x)) : Math.cos(x);
                            case "tan" -> deg ? Math.tan(Math.toRadians(x)) : Math.tan(x);
                            case "log" -> Math.log10(x);
                            case "ln" -> Math.log(x);
                            case "sqrt" -> {
                                if (x < 0) throw new RuntimeException("负数不能开平方");
                                yield Math.sqrt(x);
                            }
                            case "cbrt" -> Math.cbrt(x);
                            case "abs" -> Math.abs(x);
                            case "fact" -> {
                                if (x < 0 || Math.abs(x - Math.round(x)) > 1e-10)
                                    throw new RuntimeException("阶乘仅支持非负整数");
                                int n = (int) Math.round(x);
                                if (n > 170) throw new RuntimeException("数值过大");
                                yield factorial(n);
                            }
                            default -> throw new RuntimeException("未知函数: " + t.value);
                        };
                        st.push(r);
                    }
                    default -> throw new RuntimeException("非法 token");
                }
            }
            if (st.size() != 1) throw new RuntimeException("表达式格式错误");
            return st.pop();
        }

        private double factorial(int n) {
            double r = 1;
            for (int i = 2; i <= n; i++) r *= i;
            return r;
        }
    }
}
