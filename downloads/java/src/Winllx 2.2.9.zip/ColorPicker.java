import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.event.*;

public class ColorPicker extends JDialog {

    public interface ColorListener {
        void onColorSelected(Color color);
    }

    private Color selectedColor = Color.WHITE;
    private final List<ColorListener> listeners = new ArrayList<>();
    private final List<Color> recentColors = new ArrayList<>();

    private int mode = 0;
    private float hue = 0f;
    private float saturation = 1f;
    private float brightness = 1f;

    private JPanel previewPanel;
    private JTextField hexField;
    private JSlider rSlider, gSlider, bSlider;
    private GlassSegmentedControl modeSelector;

    public ColorPicker(Window owner, Color initialColor) {
        super(owner, "自定义颜色", ModalityType.APPLICATION_MODAL);
        if (initialColor != null) {
            selectedColor = initialColor;
            float[] hsb = Color.RGBtoHSB(initialColor.getRed(), initialColor.getGreen(), initialColor.getBlue(), null);
            hue = hsb[0];
            saturation = hsb[1];
            brightness = hsb[2];
        }
        initRecentColors();
        initUI();
        pack();
        setLocationRelativeTo(owner);

        Timer refreshTimer = new Timer(33, e -> {
            if (isVisible()) {
                getContentPane().repaint();
            }
        });
        refreshTimer.start();
    }

    public void addColorListener(ColorListener l) {
        listeners.add(l);
    }

    private void confirmSelection() {
        addRecentColor(selectedColor);
        for (ColorListener l : listeners) {
            l.onColorSelected(selectedColor);
        }
        dispose();
    }

    public Color getSelectedColor() {
        return selectedColor;
    }

    private void initRecentColors() {
        recentColors.add(Color.WHITE);
        recentColors.add(Color.BLACK);
        recentColors.add(new Color(255, 100, 100));
        recentColors.add(new Color(100, 200, 255));
        recentColors.add(new Color(150, 255, 150));
        recentColors.add(new Color(255, 200, 100));
        recentColors.add(new Color(200, 150, 255));
        recentColors.add(new Color(255, 150, 200));
    }

    private void initUI() {
        int w = 560;
        int h = 660;

        JPanel content = new JPanel(null);
        content.setPreferredSize(new Dimension(w, h));
        content.setBackground(new Color(245, 245, 247));

        SpectrumPanel spectrumPanel = new SpectrumPanel();
        spectrumPanel.setBounds(20, 82, 520, 240);
        content.add(spectrumPanel);

        String[] modes = {"线性光谱条", "色轮"};
        modeSelector = new GlassSegmentedControl(modes);
        modeSelector.setBounds(20, 20, 520, 52);
        modeSelector.addSelectionListener((idx, opt) -> {
            mode = idx;
            spectrumPanel.clearCache();
            content.repaint();
        });
        content.add(modeSelector);

        int sectionY = 332;

        JLabel previewLabel = new JLabel("颜色预览");
        previewLabel.setBounds(20, sectionY, 80, 25);
        previewLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 13));
        content.add(previewLabel);

        previewPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(selectedColor);
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2d.setColor(new Color(0, 0, 0, 30));
                g2d.setStroke(new BasicStroke(1));
                g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
                g2d.dispose();
            }
        };
        previewPanel.setBounds(20, sectionY + 25, 180, 64);
        content.add(previewPanel);

        JLabel hexLabel = new JLabel("HEX");
        hexLabel.setBounds(220, sectionY, 40, 25);
        hexLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 13));
        content.add(hexLabel);

        hexField = new JTextField();
        hexField.setBounds(220, sectionY + 25, 140, 40);
        hexField.setFont(new Font("Consolas", Font.PLAIN, 16));
        hexField.setText(colorToHex(selectedColor));
        hexField.setHorizontalAlignment(JTextField.CENTER);
        hexField.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));
        hexField.addActionListener(e -> {
            try {
                Color c = hexToColor(hexField.getText());
                setColor(c);
                confirmSelection();
            } catch (Exception ex) {
                hexField.setText(colorToHex(selectedColor));
            }
        });
        content.add(hexField);

        sectionY += 100;

        JLabel rgbLabel = new JLabel("RGB");
        rgbLabel.setBounds(20, sectionY, 40, 25);
        rgbLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 13));
        content.add(rgbLabel);

        rSlider = createRGBSlider(0, 255, selectedColor.getRed(), Color.RED);
        rSlider.setBounds(60, sectionY + 2, 480, 36);
        content.add(rSlider);

        gSlider = createRGBSlider(0, 255, selectedColor.getGreen(), Color.GREEN);
        gSlider.setBounds(60, sectionY + 42, 480, 36);
        content.add(gSlider);

        bSlider = createRGBSlider(0, 255, selectedColor.getBlue(), Color.BLUE);
        bSlider.setBounds(60, sectionY + 82, 480, 36);
        content.add(bSlider);

        sectionY += 140;

        JLabel recentLabel = new JLabel("最近使用");
        recentLabel.setBounds(20, sectionY, 80, 25);
        recentLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 13));
        content.add(recentLabel);

        JPanel recentPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        recentPanel.setBounds(100, sectionY, 440, 40);
        recentPanel.setOpaque(false);
        for (Color c : recentColors) {
            JPanel swatch = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    Graphics2D g2d = (Graphics2D) g.create();
                    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2d.setColor(c);
                    g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                    g2d.setColor(new Color(0, 0, 0, 30));
                    g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                    g2d.dispose();
                }
            };
            swatch.setPreferredSize(new Dimension(36, 36));
            swatch.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            swatch.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    setColor(c);
                }
            });
            recentPanel.add(swatch);
        }
        content.add(recentPanel);

        sectionY += 60;

        GlassButton okBtn = GlassButton.createButton("确定");
        okBtn.setBounds(340, sectionY, 90, 38);
        okBtn.addActionListener(e -> confirmSelection());
        content.add(okBtn);

        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
            .put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "confirmColor");
        getRootPane().getActionMap().put("confirmColor", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                confirmSelection();
            }
        });

        GlassButton cancelBtn = GlassButton.createButton("取消");
        cancelBtn.setBounds(450, sectionY, 90, 38);
        cancelBtn.addActionListener(e -> dispose());
        content.add(cancelBtn);

        setContentPane(content);
    }

    private JSlider createRGBSlider(int min, int max, int value, Color color) {
        JSlider slider = new JSlider(JSlider.HORIZONTAL, min, max, value);
        slider.setOpaque(false);
        slider.setUI(new javax.swing.plaf.basic.BasicSliderUI(slider) {
            @Override
            public void paintTrack(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int trackY = trackRect.y + trackRect.height / 2 - 4;
                g2d.setColor(new Color(200, 200, 200));
                g2d.fillRoundRect(trackRect.x, trackY, trackRect.width, 8, 8, 8);
                GradientPaint gp;
                if (color == Color.RED) {
                    gp = new GradientPaint(trackRect.x, trackY, new Color(0, gSlider.getValue(), bSlider.getValue()),
                            trackRect.x + trackRect.width, trackY, new Color(255, gSlider.getValue(), bSlider.getValue()));
                } else if (color == Color.GREEN) {
                    gp = new GradientPaint(trackRect.x, trackY, new Color(rSlider.getValue(), 0, bSlider.getValue()),
                            trackRect.x + trackRect.width, trackY, new Color(rSlider.getValue(), 255, bSlider.getValue()));
                } else {
                    gp = new GradientPaint(trackRect.x, trackY, new Color(rSlider.getValue(), gSlider.getValue(), 0),
                            trackRect.x + trackRect.width, trackY, new Color(rSlider.getValue(), gSlider.getValue(), 255));
                }
                g2d.setPaint(gp);
                g2d.fillRoundRect(trackRect.x, trackY, trackRect.width, 8, 8, 8);
                g2d.dispose();
            }

            @Override
            public void paintThumb(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int x = thumbRect.x + thumbRect.width / 2 - 9;
                int y = thumbRect.y + thumbRect.height / 2 - 9;
                g2d.setColor(Color.WHITE);
                g2d.fillOval(x, y, 18, 18);
                g2d.setColor(new Color(0, 0, 0, 40));
                g2d.setStroke(new BasicStroke(1));
                g2d.drawOval(x, y, 17, 17);
                g2d.dispose();
            }
        });
        slider.addChangeListener(e -> {
            if (!slider.getValueIsAdjusting()) return;
            Color c = new Color(rSlider.getValue(), gSlider.getValue(), bSlider.getValue());
            updateFromRGB(c);
        });
        return slider;
    }

    private void setColor(Color color) {
        selectedColor = color;
        float[] hsb = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
        hue = hsb[0];
        saturation = hsb[1];
        brightness = hsb[2];
        rSlider.setValue(color.getRed());
        gSlider.setValue(color.getGreen());
        bSlider.setValue(color.getBlue());
        hexField.setText(colorToHex(color));
        previewPanel.repaint();
        getContentPane().repaint();
    }

    private void updateFromHSB() {
        Color c = Color.getHSBColor(hue, saturation, brightness);
        selectedColor = c;
        rSlider.setValue(c.getRed());
        gSlider.setValue(c.getGreen());
        bSlider.setValue(c.getBlue());
        hexField.setText(colorToHex(c));
        previewPanel.repaint();
    }

    private void updateFromRGB(Color c) {
        selectedColor = c;
        float[] hsb = Color.RGBtoHSB(c.getRed(), c.getGreen(), c.getBlue(), null);
        hue = hsb[0];
        saturation = hsb[1];
        brightness = hsb[2];
        hexField.setText(colorToHex(c));
        previewPanel.repaint();
        getContentPane().repaint();
    }

    private void addRecentColor(Color c) {
        recentColors.remove(c);
        recentColors.add(0, c);
        if (recentColors.size() > 8) {
            recentColors.remove(recentColors.size() - 1);
        }
    }

    private static String colorToHex(Color c) {
        return String.format("#%02X%02X%02X", c.getRed(), c.getGreen(), c.getBlue());
    }

    private static Color hexToColor(String hex) {
        hex = hex.trim();
        if (hex.startsWith("#")) hex = hex.substring(1);
        if (hex.length() == 3) {
            hex = "" + hex.charAt(0) + hex.charAt(0) + hex.charAt(1) + hex.charAt(1) + hex.charAt(2) + hex.charAt(2);
        }
        int r = Integer.parseInt(hex.substring(0, 2), 16);
        int g = Integer.parseInt(hex.substring(2, 4), 16);
        int b = Integer.parseInt(hex.substring(4, 6), 16);
        return new Color(r, g, b);
    }

    private class SpectrumPanel extends JPanel implements MouseListener, MouseMotionListener {
        private boolean dragging = false;
        private BufferedImage wheelBuf;

        public SpectrumPanel() {
            setOpaque(true);
            setBackground(new Color(245, 245, 247));
            addMouseListener(this);
            addMouseMotionListener(this);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();

            if (mode == 0) {
                paintSpectrumBar(g2d, w, h);
            } else {
                paintColorWheel(g2d, w, h);
            }

            g2d.dispose();
        }

        private void paintSpectrumBar(Graphics2D g2d, int w, int h) {
            int barH = 36;
            int barY = 10;
            int barX = 10;
            int barW = w - 20 - 60;

            BufferedImage hueBar = new BufferedImage(barW, barH, BufferedImage.TYPE_INT_RGB);
            int[] pixels = new int[barW * barH];
            for (int x = 0; x < barW; x++) {
                float hu = (float) x / barW;
                int rgb = Color.HSBtoRGB(hu, 1f, brightness);
                for (int y = 0; y < barH; y++) {
                    pixels[y * barW + x] = rgb;
                }
            }
            hueBar.setRGB(0, 0, barW, barH, pixels, 0, barW);
            g2d.drawImage(hueBar, barX, barY, null);
            g2d.setColor(new Color(0, 0, 0, 30));
            g2d.setStroke(new BasicStroke(1));
            g2d.drawRoundRect(barX, barY, barW, barH, 8, 8);

            int thumbX = barX + (int) (hue * barW) - 8;
            g2d.setColor(Color.WHITE);
            g2d.fillOval(thumbX, barY + barH / 2 - 10, 20, 20);
            g2d.setColor(new Color(0, 0, 0, 40));
            g2d.drawOval(thumbX, barY + barH / 2 - 10, 19, 19);

            int briX = barX + barW + 15;
            int briW = 45;
            BufferedImage briBar = new BufferedImage(briW, barH, BufferedImage.TYPE_INT_RGB);
            int[] briPixels = new int[briW * barH];
            for (int x = 0; x < briW; x++) {
                float b = (float) x / briW;
                int rgb = Color.HSBtoRGB(hue, 1f, b);
                for (int y = 0; y < barH; y++) {
                    briPixels[y * briW + x] = rgb;
                }
            }
            briBar.setRGB(0, 0, briW, barH, briPixels, 0, briW);
            g2d.drawImage(briBar, briX, barY, null);
            g2d.drawRoundRect(briX, barY, briW, barH, 8, 8);

            int briThumbX = briX + (int) (brightness * briW) - 6;
            g2d.setColor(Color.WHITE);
            g2d.fillOval(briThumbX, barY + barH / 2 - 8, 16, 16);
            g2d.setColor(new Color(0, 0, 0, 40));
            g2d.drawOval(briThumbX, barY + barH / 2 - 8, 15, 15);

            int satY = barY + barH + 15;
            int satH = 36;
            BufferedImage satBar = new BufferedImage(barW, satH, BufferedImage.TYPE_INT_RGB);
            int[] satPixels = new int[barW * satH];
            for (int x = 0; x < barW; x++) {
                float s = (float) x / barW;
                int rgb = Color.HSBtoRGB(hue, s, brightness);
                for (int y = 0; y < satH; y++) {
                    satPixels[y * barW + x] = rgb;
                }
            }
            satBar.setRGB(0, 0, barW, satH, satPixels, 0, barW);
            g2d.drawImage(satBar, barX, satY, null);
            g2d.drawRoundRect(barX, satY, barW, satH, 8, 8);

            int satThumbX = barX + (int) (saturation * barW) - 8;
            g2d.setColor(Color.WHITE);
            g2d.fillOval(satThumbX, satY + satH / 2 - 10, 20, 20);
            g2d.setColor(new Color(0, 0, 0, 40));
            g2d.drawOval(satThumbX, satY + satH / 2 - 10, 19, 19);
        }

        private void paintColorWheel(Graphics2D g2d, int w, int h) {
            int size = Math.min(w - 80, h - 20);
            int cx = size / 2 + 10;
            int cy = h / 2;
            int radius = size / 2 - 5;

            if (wheelBuf == null || wheelBuf.getWidth() != size || wheelBuf.getHeight() != size) {
                wheelBuf = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
                int[] pixels = new int[size * size];
                int cx2 = size / 2;
                int cy2 = size / 2;
                for (int y = 0; y < size; y++) {
                    for (int x = 0; x < size; x++) {
                        float dx = x - cx2;
                        float dy = y - cy2;
                        float dist = (float) Math.sqrt(dx * dx + dy * dy);
                        if (dist <= radius) {
                            float angle = (float) Math.atan2(dy, dx);
                            if (angle < 0) angle += 2 * Math.PI;
                            float hu = angle / (2 * (float) Math.PI);
                            float sat = dist / radius;
                            int rgb = Color.HSBtoRGB(hu, sat, brightness);
                            pixels[y * size + x] = 0xFF000000 | rgb;
                        } else {
                            pixels[y * size + x] = 0;
                        }
                    }
                }
                wheelBuf.setRGB(0, 0, size, size, pixels, 0, size);
            }
            g2d.drawImage(wheelBuf, cx - size / 2, cy - size / 2, null);

            float angle = hue * 2 * (float) Math.PI;
            int selX = cx + (int) (Math.cos(angle) * saturation * radius);
            int selY = cy + (int) (Math.sin(angle) * saturation * radius);
            g2d.setColor(Color.WHITE);
            g2d.fillOval(selX - 8, selY - 8, 16, 16);
            g2d.setColor(new Color(0, 0, 0, 40));
            g2d.drawOval(selX - 8, selY - 8, 15, 15);
            g2d.setColor(selectedColor);
            g2d.fillOval(selX - 5, selY - 5, 10, 10);

            int briX = size + 25;
            int briW = 40;
            int briH = size;
            int briY = cy - briH / 2;
            BufferedImage briBar = new BufferedImage(briW, briH, BufferedImage.TYPE_INT_RGB);
            int[] briPixels = new int[briW * briH];
            for (int y = 0; y < briH; y++) {
                float b = 1f - (float) y / briH;
                int rgb = Color.HSBtoRGB(hue, saturation, b);
                for (int x = 0; x < briW; x++) {
                    briPixels[y * briW + x] = rgb;
                }
            }
            briBar.setRGB(0, 0, briW, briH, briPixels, 0, briW);
            g2d.drawImage(briBar, briX, briY, null);
            g2d.setColor(new Color(0, 0, 0, 30));
            g2d.drawRoundRect(briX, briY, briW, briH, 8, 8);

            int briThumbY = briY + (int) ((1f - brightness) * briH) - 6;
            g2d.setColor(Color.WHITE);
            g2d.fillOval(briX + briW / 2 - 8, briThumbY, 16, 16);
            g2d.setColor(new Color(0, 0, 0, 40));
            g2d.drawOval(briX + briW / 2 - 8, briThumbY, 15, 15);
        }

        public void clearCache() {
            wheelBuf = null;
            repaint();
        }

        @Override
        public void mousePressed(MouseEvent e) {
            dragging = true;
            handleMouse(e.getX(), e.getY());
        }

        @Override
        public void mouseDragged(MouseEvent e) {
            if (dragging) {
                handleMouse(e.getX(), e.getY());
            }
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            dragging = false;
        }

        private void handleMouse(int mx, int my) {
            int w = getWidth();
            int h = getHeight();

            if (mode == 0) {
                int barH = 36;
                int barY = 10;
                int barX = 10;
                int barW = w - 20 - 60;

                if (mx >= barX && mx <= barX + barW && my >= barY && my <= barY + barH) {
                    hue = (float) (mx - barX) / barW;
                    hue = Math.max(0, Math.min(1, hue));
                    wheelBuf = null;
                    updateFromHSB();
                    repaint();
                    return;
                }

                int briX = barX + barW + 15;
                int briW = 45;
                if (mx >= briX && mx <= briX + briW && my >= barY && my <= barY + barH) {
                    brightness = (float) (mx - briX) / briW;
                    brightness = Math.max(0, Math.min(1, brightness));
                    wheelBuf = null;
                    updateFromHSB();
                    repaint();
                    return;
                }

                int satY = barY + barH + 15;
                int satH = 36;
                if (mx >= barX && mx <= barX + barW && my >= satY && my <= satY + satH) {
                    saturation = (float) (mx - barX) / barW;
                    saturation = Math.max(0, Math.min(1, saturation));
                    wheelBuf = null;
                    updateFromHSB();
                    repaint();
                    return;
                }
            } else {
                int size = Math.min(w - 80, h - 20);
                int cx = size / 2 + 10;
                int cy = h / 2;
                int radius = size / 2 - 5;

                float dx = mx - cx;
                float dy = my - cy;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);

                if (dist <= radius + 10) {
                    float angle = (float) Math.atan2(dy, dx);
                    if (angle < 0) angle += 2 * Math.PI;
                    hue = angle / (2 * (float) Math.PI);
                    saturation = Math.min(1f, dist / radius);
                    updateFromHSB();
                    repaint();
                    return;
                }

                int briX = size + 25;
                int briW = 40;
                int briH = size;
                int briY = cy - briH / 2;
                if (mx >= briX && mx <= briX + briW && my >= briY && my <= briY + briH) {
                    brightness = 1f - (float) (my - briY) / briH;
                    brightness = Math.max(0, Math.min(1, brightness));
                    wheelBuf = null;
                    updateFromHSB();
                    repaint();
                    return;
                }
            }
        }

        @Override public void mouseClicked(MouseEvent e) {}
        @Override public void mouseEntered(MouseEvent e) {}
        @Override public void mouseExited(MouseEvent e) {}
        @Override public void mouseMoved(MouseEvent e) {}
    }
}
