import javax.swing.*;
public class TestCalc2 {
    public static void main(String[] args) {
        try {
            System.out.println("Testing Winllx3 instantiation...");
            Class<?> cls = Class.forName("Winllx3");
            System.out.println("Class loaded: " + cls.getClassLoader());
            System.out.println("Constructors: " + java.util.Arrays.toString(cls.getConstructors()));
            javax.swing.SwingUtilities.invokeLater(() -> {
                try {
                    Object obj = cls.getDeclaredConstructor().newInstance();
                    System.out.println("Winllx3 created successfully!");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
