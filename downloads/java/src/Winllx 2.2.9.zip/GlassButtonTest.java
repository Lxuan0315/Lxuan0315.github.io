import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

public class GlassButtonTest extends JFrame {

    public GlassButtonTest() {
        setTitle("Apple Liquid Glass Button 测试");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel contentPanel = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth(), h = getHeight();

                // 彩色渐变背景 - 让折射效果更明显
                GradientPaint bg1 = new GradientPaint(0, 0, new Color(80, 120, 200), w, 0, new Color(200, 100, 150));
                g2d.setPaint(bg1);
                g2d.fillRect(0, 0, w, h);

                GradientPaint bg2 = new GradientPaint(0, 0, new Color(100, 180, 220, 120),
                        0, h, new Color(60, 80, 160, 180));
                g2d.setPaint(bg2);
                g2d.fillRect(0, 0, w, h);

                // 装饰性圆形
                for (int i = 0; i < 8; i++) {
                    float angle = (float) (i * Math.PI / 4);
                    float rx = w * 0.5f + (float) Math.cos(angle) * w * 0.35f;
                    float ry = h * 0.5f + (float) Math.sin(angle) * h * 0.3f;
                    float size = 80 + i * 15;

                    RadialGradientPaint circleGrad = new RadialGradientPaint(
                            rx, ry, size,
                            new float[]{0f, 0.6f, 1f},
                            new Color[]{
                                    new Color(255, 255, 255, 25),
                                    new Color(255, 255, 255, 10),
                                    new Color(255, 255, 255, 0)
                            }
                    );
                    g2d.setPaint(circleGrad);
                    g2d.fill(new Ellipse2D.Float(rx - size / 2, ry - size / 2, size, size));
                }

                // 横向条纹
                for (int i = 0; i < 20; i++) {
                    float y = i * h / 20f;
                    float alpha = Math.max(0f, Math.min(1f, (float) Math.sin(i * 0.5) * 0.03f + 0.02f));
                    g2d.setColor(new Color(255, 255, 255, (int) (alpha * 255)));
                    g2d.fillRect(0, (int) y, w, 2);
                }

                // 垂直渐变遮罩
                GradientPaint overlay = new GradientPaint(
                        0, 0, new Color(0, 0, 0, 0),
                        0, h, new Color(0, 0, 20, 40)
                );
                g2d.setPaint(overlay);
                g2d.fillRect(0, 0, w, h);
            }
        };

        // 使用绝对布局来精确放置按钮
        contentPanel.setLayout(null);

        // ========== 方形/圆角矩形按钮 ==========

        // 按钮1 - 基础
        GlassButton btn1 = GlassButton.createButton("确认");
        btn1.setBounds(80, 80, 140, 48);
        btn1.setOnClickListener(button -> JOptionPane.showMessageDialog(null, "确认！"));
        contentPanel.add(btn1);

        // 按钮2 - 大尺寸
        GlassButton btn2 = GlassButton.createButton("下一步", 180, 56);
        btn2.setBounds(280, 70, 180, 56);
        btn2.setOnClickListener(button -> JOptionPane.showMessageDialog(null, "下一步！"));
        contentPanel.add(btn2);

        // 按钮3 - 小尺寸
        GlassButton btn3 = GlassButton.createButton("取消", new Font("Microsoft YaHei", Font.PLAIN, 13),
                new Color(80, 80, 80), 100, 40);
        btn3.setBounds(520, 85, 100, 40);
        contentPanel.add(btn3);

        // 按钮4 - 大圆角
        GlassButton btn4 = GlassButton.createButton("设置", 120, 44, 22);
        btn4.setBounds(100, 180, 120, 44);
        contentPanel.add(btn4);

        // 按钮5 - 最大尺寸，全圆角
        GlassButton btn5 = GlassButton.createButton("Liquid Glass", new Font("Microsoft YaHei", Font.BOLD, 18),
                new Color(20, 20, 20), 240, 64, 32);
        btn5.setBounds(260, 170, 240, 64);
        contentPanel.add(btn5);

        // 按钮6 - 细长型
        GlassButton btn6 = GlassButton.createButton("提交表单", 160, 40);
        btn6.setBounds(100, 280, 160, 40);
        contentPanel.add(btn6);

        // 按钮7 - 方形圆角
        GlassButton btn7 = GlassButton.createButton("保存", 100, 100, 24);
        btn7.setBounds(320, 280, 100, 100);
        contentPanel.add(btn7);

        // 按钮8 - 蓝色文字
        GlassButton btn8 = GlassButton.createButton("Apple Style", new Font("Microsoft YaHei", Font.BOLD, 16),
                new Color(0, 122, 255), 200, 52, 26);
        btn8.setBounds(460, 280, 200, 52);
        contentPanel.add(btn8);

        // ========== 圆形按钮 ==========

        // 圆形按钮1 - 基础圆形
        GlassButton circleBtn1 = GlassButton.createCircleButton("+", 60);
        circleBtn1.setBounds(80, 400, 60, 60);
        circleBtn1.setOnClickListener(button -> JOptionPane.showMessageDialog(null, "添加！"));
        contentPanel.add(circleBtn1);

        // 圆形按钮2 - 较大圆形
        GlassButton circleBtn2 = GlassButton.createCircleButton("OK", 80);
        circleBtn2.setBounds(170, 390, 80, 80);
        contentPanel.add(circleBtn2);

        // 圆形按钮3 - 小圆形
        GlassButton circleBtn3 = GlassButton.createCircleButton("×", 50, 
                new Font("Microsoft YaHei", Font.BOLD, 20), new Color(150, 50, 50));
        circleBtn3.setBounds(280, 405, 50, 50);
        contentPanel.add(circleBtn3);

        // 圆形按钮4 - 大圆形
        GlassButton circleBtn4 = GlassButton.createCircleButton("Tap Me", 100,
                new Font("Microsoft YaHei", Font.BOLD, 14), new Color(30, 30, 30));
        circleBtn4.setBounds(370, 380, 100, 100);
        circleBtn4.setOnClickListener(button -> JOptionPane.showMessageDialog(null, "圆形按钮点击！"));
        contentPanel.add(circleBtn4);

        // 圆形按钮5 - 图标风格
        GlassButton circleBtn5 = GlassButton.createCircleButton("▶", 55,
                new Font("Microsoft YaHei", Font.BOLD, 18), new Color(30, 30, 30));
        circleBtn5.setBounds(500, 402, 55, 55);
        contentPanel.add(circleBtn5);

        // 圆形按钮6 - 设置图标风格
        GlassButton circleBtn6 = GlassButton.createCircleButton("⚙", 55,
                new Font("Segoe UI Symbol", Font.PLAIN, 22), new Color(40, 40, 40));
        circleBtn6.setBounds(580, 402, 55, 55);
        contentPanel.add(circleBtn6);

        add(contentPanel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new GlassButtonTest().setVisible(true);
        });
    }
}