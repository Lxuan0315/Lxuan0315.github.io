import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
//旧版滑块
public class GlassSlider extends JComponent {
    private int min = 0, max = 100, value = 50;
    private boolean dragging = false;
    private float velocityX = 0f, velocityY = 0f;
    private int prevMouseX, prevMouseY;
    private float glassProgress = 0f, targetProgress = 0f;
    private float scaleProgress = 0f, targetScale = 0f;

    private static final int THUMB_W_IDLE = 22, THUMB_H_IDLE = 16;
    private static final int THUMB_W_DRAG = 36, THUMB_H_DRAG = 26;
    private static final int TRACK_H = 5, MARGIN = 14;
    private static final float VELOCITY_SMOOTH = 0.4f, VELOCITY_DECAY = 0.78f;
    private static final float STRETCH_FACTOR = 0.35f, TRANSITION_SPEED = 0.12f;

    private Timer animTimer;
    private EventListenerList listenerList = new EventListenerList();
    private ChangeEvent changeEvent = null;

    public static GlassSlider create(Container container, int x, int y, 
                                      int width, int height, int initialValue,
                                      ChangeListener onChange) {
        GlassSlider slider = new GlassSlider();
        slider.setBounds(x, y, width, height);
        slider.setValue(initialValue);
        if (onChange != null) slider.addChangeListener(onChange);
        container.add(slider);
        return slider;
    }

    /**
     * 简化版：使用默认尺寸(260x56)，用setLocation/setSize自行调整
     */
    public static GlassSlider create(Container container, int initialValue,
                                      ChangeListener onChange) {
        return create(container, 0, 0, 260, 56, initialValue, onChange);
    }
    // ==================== 工厂方法结束 ====================

    public GlassSlider() {
        setPreferredSize(new Dimension(260, 56));
        setOpaque(false);

        MouseAdapter ma = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (e.getButton() == MouseEvent.BUTTON1) {
                    dragging = true;
                    prevMouseX = e.getX();
                    prevMouseY = e.getY();
                    targetProgress = 1f;
                    targetScale = 1f;
                    updateValueFromMouse(e.getX());
                }
            }
            @Override
            public void mouseReleased(MouseEvent e) {
                dragging = false;
                targetProgress = 0f;
                targetScale = 0f;
            }
            @Override
            public void mouseDragged(MouseEvent e) {
                if (!dragging) return;
                int dx = e.getX() - prevMouseX;
                int dy = e.getY() - prevMouseY;
                velocityX = velocityX * (1 - VELOCITY_SMOOTH) + dx * VELOCITY_SMOOTH;
                velocityY = velocityY * (1 - VELOCITY_SMOOTH) + dy * VELOCITY_SMOOTH;
                prevMouseX = e.getX();
                prevMouseY = e.getY();
                updateValueFromMouse(e.getX());
            }
        };
        addMouseListener(ma);
        addMouseMotionListener(ma);

        animTimer = new Timer(16, e -> {
            glassProgress += (targetProgress - glassProgress) * TRANSITION_SPEED;
            if (Math.abs(targetProgress - glassProgress) < 0.001f) glassProgress = targetProgress;
            scaleProgress += (targetScale - scaleProgress) * TRANSITION_SPEED;
            if (Math.abs(targetScale - scaleProgress) < 0.001f) scaleProgress = targetScale;
            if (!dragging) {
                velocityX *= VELOCITY_DECAY;
                velocityY *= VELOCITY_DECAY;
                if (Math.abs(velocityX) < 0.1f) velocityX = 0;
                if (Math.abs(velocityY) < 0.1f) velocityY = 0;
            }
            repaint();
        });
        animTimer.start();
    }

    private void updateValueFromMouse(int mouseX) {
        int trackLeft = MARGIN + THUMB_W_DRAG / 2;
        int trackRight = getWidth() - MARGIN - THUMB_W_DRAG / 2;
        int newValue = min + (int)((mouseX - trackLeft) * (max - min) / (float)(trackRight - trackLeft));
        newValue = Math.max(min, Math.min(max, newValue));
        if (newValue != value) { value = newValue; fireStateChanged(); }
    }

    public int getValue() { return value; }
    public void setValue(int v) {
        if (v < min) v = min; if (v > max) v = max;
        if (v != value) { value = v; repaint(); fireStateChanged(); }
    }
    public void addChangeListener(ChangeListener l) { listenerList.add(ChangeListener.class, l); }
    public void removeChangeListener(ChangeListener l) { listenerList.remove(ChangeListener.class, l); }
    protected void fireStateChanged() {
        for (ChangeListener l : listenerList.getListeners(ChangeListener.class)) {
            if (changeEvent == null) changeEvent = new ChangeEvent(this);
            l.stateChanged(changeEvent);
        }
    }

    private float currentThumbW() { return THUMB_W_IDLE + (THUMB_W_DRAG - THUMB_W_IDLE) * scaleProgress; }
    private float currentThumbH() { return THUMB_H_IDLE + (THUMB_H_DRAG - THUMB_H_IDLE) * scaleProgress; }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);

        int w = getWidth(), h = getHeight();
        float thumbW = currentThumbW(), thumbH = currentThumbH();
        int trackLeft = (int)(MARGIN + thumbW / 2);
        int trackRight = (int)(w - MARGIN - thumbW / 2);
        int trackY = h / 2 - TRACK_H / 2;

        g2.setColor(new Color(0, 0, 0, 50));
        g2.fillRoundRect(trackLeft, trackY, trackRight - trackLeft, TRACK_H, TRACK_H, TRACK_H);
        g2.setColor(new Color(0, 0, 0, 35));
        g2.fillRoundRect(trackLeft + 1, trackY + 1, trackRight - trackLeft - 2, TRACK_H - 2, TRACK_H - 2, TRACK_H - 2);

        int thumbCenterX = trackLeft + (int)((value - min) / (float)(max - min) * (trackRight - trackLeft));
        if (thumbCenterX > trackLeft) {
            g2.setPaint(new GradientPaint(trackLeft, trackY, new Color(255,255,255,60),
                    thumbCenterX, trackY, new Color(255,255,255,120)));
            g2.fillRoundRect(trackLeft, trackY, thumbCenterX - trackLeft, TRACK_H, TRACK_H, TRACK_H);
        }

        float thumbX = thumbCenterX - thumbW / 2f;
        float thumbY = h / 2f - thumbH / 2f;
        Ellipse2D.Float ellipse = new Ellipse2D.Float(thumbX, thumbY, thumbW, thumbH);

        if (glassProgress < 0.99f) drawNormalThumb(g2, ellipse, 1f - glassProgress);
        if (glassProgress > 0.01f) drawGlassThumb(g2, ellipse, velocityX * glassProgress, velocityY * glassProgress, glassProgress);
        g2.dispose();
    }

    private void drawNormalThumb(Graphics2D g2, Ellipse2D.Float e, float a) {
        Composite oc = g2.getComposite();
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, a));
        g2.setColor(new Color(0,0,0,(int)(60*a)));
        g2.fill(new Ellipse2D.Float(e.x+0.5f, e.y+1.5f, e.width, e.height));
        g2.setPaint(new GradientPaint(e.x, e.y, new Color(220,220,220), e.x, e.y+e.height, new Color(160,160,160)));
        g2.fill(e);
        g2.setColor(new Color(140,140,140,(int)(200*a)));
        g2.setStroke(new BasicStroke(1f)); g2.draw(e);
        g2.setColor(new Color(255,255,255,(int)(140*a)));
        g2.fill(new Ellipse2D.Float(e.x+e.width*0.15f, e.y+e.height*0.15f, e.width*0.55f, e.height*0.4f));
        g2.setComposite(oc);
    }

    private void drawGlassThumb(Graphics2D g2, Ellipse2D.Float base, float vx, float vy, float a) {
        Composite oc = g2.getComposite();
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, a));
        float sx = Math.max(-base.width*0.5f, Math.min(base.width*0.5f, vx*STRETCH_FACTOR));
        float sy = Math.max(-base.height*0.5f, Math.min(base.height*0.5f, vy*STRETCH_FACTOR));
        float x = base.x + (sx<0?sx:0), y = base.y + (sy<0?sy:0);
        float bw = base.width + Math.abs(sx), bh = base.height + Math.abs(sy);
        Ellipse2D.Float shape = new Ellipse2D.Float(x, y, bw, bh);

        for (int i=0; i<4; i++) {
            float aa = (0.12f-i*0.025f)*a; if(aa<=0) continue;
            g2.setColor(new Color(0,0,0,(int)(aa*255)));
            g2.fill(new Ellipse2D.Float(x+0.8f, y+1.8f+i*1.2f, bw-0.5f, bh-0.5f));
        }
        g2.setPaint(new LinearGradientPaint(x, y, x, y+bh,
                new float[]{0,0.2f,0.5f,0.8f,1},
                new Color[]{c(150,a),c(100,a),c(35,a),c(80,a),c(140,a)}));
        g2.fill(shape);
        g2.setColor(c(110,a)); g2.setStroke(new BasicStroke(1f)); g2.draw(shape);
        g2.setColor(c(30,a)); g2.draw(new Ellipse2D.Float(x+1, y+1, bw-2, bh-2));

        float in=3, ax=x+in, ay=y+in, aw=bw-2*in, ah=bh-2*in;
        g2.setColor(c(90,a)); g2.setStroke(new BasicStroke(4.5f,1,1));
        g2.draw(new Arc2D.Float(ax-1.5f, ay-1.5f, aw+3, ah+3, 123, 104, Arc2D.OPEN));
        g2.setColor(c(170,a)); g2.setStroke(new BasicStroke(2.2f,1,1));
        g2.draw(new Arc2D.Float(ax, ay, aw, ah, 125, 100, Arc2D.OPEN));
        g2.setColor(c(230,a)); g2.setStroke(new BasicStroke(1.3f,1,1));
        g2.draw(new Arc2D.Float(ax+0.5f, ay+0.5f, aw-1, ah-1, 128, 94, Arc2D.OPEN));

        g2.setColor(c(45,a)); g2.setStroke(new BasicStroke(1f));
        g2.draw(new Arc2D.Float(x+4, y+bh-3.5f, bw-8, 2.5f, 0, 180, Arc2D.OPEN));
        g2.setColor(c(28,a)); g2.setStroke(new BasicStroke(bw*0.14f,1,1));
        g2.draw(new Arc2D.Float(x+2, y+2, bw-4, bh-4, 125, 90, Arc2D.OPEN));
        g2.setComposite(oc);
    }

    private Color c(int alpha, float multiplier) {
        return new Color(255, 255, 255, (int)(alpha * multiplier));
    }
}