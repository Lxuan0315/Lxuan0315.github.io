import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class Winllx3 {// 计算器

    Winllx3() {
        // 窗体
        JFrame j1 = new JFrame("计算器");
        j1.setLayout(null);
        j1.setSize(270, 450);// 设置窗口大小
        j1.setResizable(false);// 设置窗口不可缩放
        // 按钮
        JButton b1 = GlassButtonDemo.createButton("1");
        JButton b2 = GlassButtonDemo.createButton("2");
        JButton b3 = GlassButtonDemo.createButton("3");
        JButton b4 = GlassButtonDemo.createButton("4");
        JButton b5 = GlassButtonDemo.createButton("5");
        JButton b6 = GlassButtonDemo.createButton("6");
        JButton b7 = GlassButtonDemo.createButton("7");
        JButton b8 = GlassButtonDemo.createButton("8");
        JButton b9 = GlassButtonDemo.createButton("9");
        JButton b0 = GlassButtonDemo.createButton("0");
        JButton b11 = GlassButtonDemo.createButton("+");
        JButton b12 = GlassButtonDemo.createButton("-");
        JButton b13 = GlassButtonDemo.createButton("×");
        JButton b14 = GlassButtonDemo.createButton("÷");
        JButton b15 = GlassButtonDemo.createButton("=");
        JButton b16 = GlassButtonDemo.createButton("C");
        JButton b17 = GlassButtonDemo.createButton(".");
        JButton b18 = GlassButtonDemo.createButton("00");
        JButton b19 = GlassButtonDemo.createButton("%");
        JButton b20 = GlassButtonDemo.createButton("⌫");

        JButton[] buttons = { b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, b11, b12, b13, b14, b15, b16, b17, b18, b19,
                b20 };
        for (JButton btn : buttons) {
            btn.setBorder(BorderFactory.createEmptyBorder());
        }
        for (JButton btn : buttons) {
            btn.setOpaque(false);// 去掉背景色
        }

        // 设置按钮内容区域的对齐方式为居中
        JButton[] buttons1 = { b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, b11, b12, b13, b14, b15, b16, b17, b18, b19,
                b20 };
        for (JButton btn : buttons1) {
            btn.setHorizontalAlignment(SwingConstants.CENTER);
        }


        // 第一行
        JButton[] buttons3 = { b1, b2, b3, b11, b4, b5, b6, b12, b7, b8, b9, b13, b0, b17, b18, b15, b16, b19, b20,
                b14 };
        // 坐标，依次为x, y, width, height
        int[][] bounds = {
                { 10, 260, 50, 50 }, // b1
                { 70, 260, 50, 50 }, // b2
                { 130, 260, 50, 50 }, // b3
                { 190, 260, 50, 50 }, // b11
                { 10, 195, 50, 50 }, // b4
                { 70, 195, 50, 50 }, // b5
                { 130, 195, 50, 50 }, // b6
                { 190, 195, 50, 50 }, // b12
                { 10, 130, 50, 50 }, // b7
                { 70, 130, 50, 50 }, // b8
                { 130, 130, 50, 50 }, // b9
                { 190, 130, 50, 50 }, // b13
                { 10, 325, 50, 50 }, // b0
                { 70, 325, 50, 50 }, // b17
                { 130, 325, 50, 50 }, // b18
                { 190, 325, 50, 50 }, // b15
                { 10, 65, 50, 50 }, // b16
                { 70, 65, 50, 50 }, // b19
                { 130, 65, 50, 50 }, // b20
                { 190, 65, 50, 50 } // b14
        };
        for (int i = 0; i < buttons3.length; i++) {
            buttons3[i].setBounds(bounds[i][0], bounds[i][1], bounds[i][2], bounds[i][3]);
        } // 设置回车可触发=按钮
        j1.getRootPane().setDefaultButton(b15);

        // 顶行
        b16.setBounds(10, 65, 50, 50); // C
        b19.setBounds(70, 65, 50, 50);// %
        b20.setBounds(130, 65, 50, 50);// ⌫

        b14.setBounds(190, 65, 50, 50);// ÷

        // 设置按钮不可用
        b16.setBackground(Color.ORANGE);// 设置C的背景颜色为橙色
        JButton[] buttons4 = { b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, b11, b12, b13, b14, b15, b16, b17, b18, b19,
                b20 };
        for (JButton btn : buttons3) {
            btn.setBackground(Color.WHITE);
        }
        b15.setBackground(Color.cyan); // 设置=的背景颜色为青色

        // 文本框
        JTextArea t1 = new JTextArea();
        // 设置文本框自动换行
        t1.setLineWrap(true);
        t1.setBounds(0, 0, 240, 50);

        // 按钮事件
        // 1
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "1";
                t1.setText(str);
            }
        });
        // 2
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "2";
                t1.setText(str);
            }
        });
        // 3
        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "3";
                t1.setText(str);
            }
        });
        // 4
        b4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "4";
                t1.setText(str);
            }
        });
        // 5
        b5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "5";
                t1.setText(str);
            }
        });
        // 6
        b6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "6";
                t1.setText(str);
            }
        });
        // 7
        b7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "7";
                t1.setText(str);
            }
        });
        // 8
        b8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "8";
                t1.setText(str);
            }
        });
        // 9
        b9.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "9";
                t1.setText(str);
            }
        });
        // 0
        b0.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "0";
                t1.setText(str);
            }
        });
        // .
        b17.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + ".";
                t1.setText(str);
            }
        });
        // 00
        b18.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText() + "00";
                t1.setText(str);
            }
        });
        // %
        b19.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame f2 = new JFrame("百分比专用计算器");
                JButton b1 = GlassButtonDemo.createButton("计算百分比值");
                JButton b2 = GlassButtonDemo.createButton("计算百分比增加");
                JButton b3 = GlassButtonDemo.createButton("计算百分比减少");
                JButton b4 = GlassButtonDemo.createButton("计算百分比占比");
                JButton b5 = GlassButtonDemo.createButton("计算百分比变化");

                b1.setBounds(10, 10, 200, 30);
                b2.setBounds(220, 10, 200, 30);
                b3.setBounds(430, 10, 200, 30);
                b4.setBounds(10, 50, 200, 30);
                b5.setBounds(220, 50, 200, 30);
                /////////////////////////////////////////////////////////////////////////////
                b1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比值");
                        JLabel l1 = new JLabel("输入数值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入百分比：");
                        JTextField t2 = new JTextField();
                        JButton b1 = GlassButtonDemo.createButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result1 = n1 * (n2 / 100);
                                        JOptionPane.showMessageDialog(f, "结果：" + result1);
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }

                });
                /////////////////////////////////////////////////////////////////////////////
                b2.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比增加");
                        JLabel l1 = new JLabel("输入数值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入增加百分比：");
                        JTextField t2 = new JTextField();
                        JButton b1 = GlassButtonDemo.createButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result2 = n1 + (n1 * (n2 / 100));
                                        JOptionPane.showMessageDialog(f, "结果：" + result2);
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }
                });
                /////////////////////////////////////////////////////////////////////////////

                b3.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比减少");
                        JLabel l1 = new JLabel("输入数值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入减少的百分比：");
                        JTextField t2 = new JTextField();
                        JButton b1 = GlassButtonDemo.createButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result3 = n1 - (n1 * (n2 / 100));
                                        JOptionPane.showMessageDialog(f, "结果：" + result3);
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }
                });
                /////////////////////////////////////////////////////////////////////////////

                b4.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比占比");
                        JLabel l1 = new JLabel("输入部分值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入总值：");
                        JTextField t2 = new JTextField();
                        JButton b1 = GlassButtonDemo.createButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result4 = (n1 / n2) * 100;
                                        JOptionPane.showMessageDialog(f, "结果：" + result4 + "%");
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }
                });
                /////////////////////////////////////////////////////////////////////////////

                b5.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JFrame f = new JFrame("计算百分比变化");
                        JLabel l1 = new JLabel("输入旧值：");
                        JTextField t1 = new JTextField();
                        JLabel l2 = new JLabel("输入新值：");
                        JTextField t2 = new JTextField();
                        JButton b1 = GlassButtonDemo.createButton("计算");
                        b1.setBounds(10, 70, 80, 20);

                        b1.addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent e) {

                                String s1 = t1.getText();
                                String s2 = t2.getText();
                                try {
                                    double n1 = Double.parseDouble(s1);
                                    try {
                                        double n2 = Double.parseDouble(s2);

                                        // 计算并显示结果
                                        double result5 = ((n1 - n2) / n2) * 100;
                                        JOptionPane.showMessageDialog(f, "百分比变化：" + result5 + "%");
                                    } catch (NumberFormatException ex) {
                                        JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(f, "我真服了\n你输的什么玩意\n计算器只能处理数字！");
                                }
                            }
                        });
                        l1.setBounds(10, 10, 80, 20);
                        t1.setBounds(100, 10, 100, 20);
                        l2.setBounds(10, 40, 80, 20);
                        t2.setBounds(100, 40, 100, 20);

                        f.add(l1);
                        f.add(l2);
                        f.add(t1);
                        f.add(t2);
                        f.add(b1);
                        f.setSize(320, 200);
                        f.setLayout(null);
                        f.setVisible(true);

                    }
                });
                /////////////////////////////////////////////////////////////////////////////

                f2.add(b1);
                f2.add(b2);
                f2.add(b3);
                f2.add(b4);
                f2.add(b5);

                f2.setSize(1000, 200);
                f2.setLayout(null);
                f2.setVisible(true);
            }
        });
        // C
        b16.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                t1.setText("");

            }
        });
        // ⌫
        b20.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String str = t1.getText().substring(0, t1.getText().length() - 1);
                t1.setText(str);

            }
        });
        // +
        b11.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // 判断是否有符号
                if (t1.getText().contains("-") || t1.getText().contains("+") || t1.getText().contains("×")
                        || t1.getText().contains("÷")) {
                    JOptionPane.showMessageDialog(j1, "你已输入了一个运算符！");

                } else {
                    String str = t1.getText() + "+";
                    t1.setText(str);
                }
            }
        });
        // -
        // b12.addActionListener(new ActionListener() {
        // public void actionPerformed(ActionEvent e) {
        // // 判断是否有符号
        // if (t1.getText().contains("-") || t1.getText().contains("+") ||
        // t1.getText().contains("×")
        // || t1.getText().contains("÷")) {
        // JOptionPane.showMessageDialog(j1, "你已输入了一个运算符！");
        // } else {
        // String str = t1.getText() + "-";
        // t1.setText(str);
        // }
        //
        // }
        // });
        // ×
        b13.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (t1.getText().contains("-") || t1.getText().contains("+") || t1.getText().contains("×")
                        || t1.getText().contains("÷")) {
                    JOptionPane.showMessageDialog(j1, "你已输入了一个运算符！");
                } else {
                    String str = t1.getText() + "×";
                    t1.setText(str);
                }
            }
        });
        // ÷
        b14.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // 判断是否有符号
                if (t1.getText().contains("-") || t1.getText().contains("+") || t1.getText().contains("×")
                        || t1.getText().contains("÷")) {
                    JOptionPane.showMessageDialog(j1, "你已输入了一个运算符！");
                } else {
                    String str = t1.getText() + "÷";
                    t1.setText(str);
                }

            }
        });
        // =
        b15.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (t1.getText().contains("+")) {
                    try {
                        // 截取+号前面的数字
                        String num1 = t1.getText().substring(0, t1.getText().indexOf("+"));
                        // 截取+号后面的数字
                        String num2 = t1.getText().substring(t1.getText().indexOf("+") + 1, t1.getText().length());
                        // 将字符串转换为double类型
                        double num11 = Double.parseDouble(num1);
                        double num22 = Double.parseDouble(num2);
                        String str = t1.getText() + "=" + (num11 + num22);
                        t1.setText(str);
                    } catch (Exception a) {
                        JOptionPane.showMessageDialog(j1, "缺少操作数！\n请重新输入");
                        t1.setText("");
                    }
                } else if (t1.getText().contains("-")) {
                    try {
                        // 截取-号前面的数字
                        String num1 = t1.getText().substring(0, t1.getText().indexOf("-"));
                        // 截取-号后面的数字
                        String num2 = t1.getText().substring(t1.getText().indexOf("-") + 1, t1.getText().length());
                        double num11 = Double.parseDouble(num1);
                        double num22 = Double.parseDouble(num2);
                        String str = t1.getText() + "=" + (num11 - num22);
                        t1.setText(str);
                    } catch (Exception a) {
                        JOptionPane.showMessageDialog(j1, "缺少操作数！\n请重新输入");
                        t1.setText("");
                    }
                } else if (t1.getText().contains("×")) {
                    try {
                        // 截取×号前面的数字
                        String num1 = t1.getText().substring(0, t1.getText().indexOf("×"));
                        // 截取×号后面的数字
                        String num2 = t1.getText().substring(t1.getText().indexOf("×") + 1, t1.getText().length());
                        double num11 = Double.parseDouble(num1);
                        double num22 = Double.parseDouble(num2);
                        String str = t1.getText() + "=" + (num11 * num22);
                        t1.setText(str);
                    } catch (Exception a) {
                        JOptionPane.showMessageDialog(j1, "缺少操作数\n请重新输入");
                        t1.setText("");
                    }
                } else if (t1.getText().contains("÷")) {
                    try {
                        // 截取×号前面的数字
                        String num1 = t1.getText().substring(0, t1.getText().indexOf("÷"));
                        // 截取×号后面的数字
                        String num2 = t1.getText().substring(t1.getText().indexOf("÷") + 1, t1.getText().length());
                        if (num2.equals("0")) {
                            JOptionPane.showMessageDialog(j1, "除数不能为0,请重新输入！");
                            // 删除错误的输入
                            String str = t1.getText().substring(0, t1.getText().indexOf("÷") + 1);
                            t1.setText(str);

                        } else {
                            double num11 = Double.parseDouble(num1);
                            double num22 = Double.parseDouble(num2);
                            String str = t1.getText() + "=" + (num11 / num22);
                            t1.setText(str);
                        }
                    } catch (Exception a) {
                        JOptionPane.showMessageDialog(j1, "未知错误\n请重新输入");
                        t1.setText("");
                    }
                } else {
                    JOptionPane.showMessageDialog(j1, "请输入一个运算符！");
                }
            }
        });

        // 添加组件
        j1.add(b1);
        j1.add(b2);
        j1.add(b3);
        j1.add(b4);
        j1.add(b5);
        j1.add(b6);
        j1.add(b7);
        j1.add(b8);
        j1.add(b9);
        j1.add(b0);
        j1.add(b11);
        j1.add(b12);
        j1.add(b13);
        j1.add(b14);
        j1.add(b15);
        j1.add(b16);
        j1.add(b17);
        j1.add(b18);
        j1.add(b19);
        j1.add(b20);
        j1.add(t1);

        j1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        j1.setVisible(true);
    }
}

