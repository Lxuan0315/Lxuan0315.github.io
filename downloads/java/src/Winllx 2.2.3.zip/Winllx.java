
import javax.swing.*;

//Winllx 主程序入口
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.sound.sampled.*;

public class Winllx {

    // 0.变量初始化
    private static boolean isTrayIcon = true;
    private static boolean isFullScreen = false;
    private static int maincolor = 0;
    private static JFrame a1;

    public static void setMainVisible(boolean visible) {
        if (a1 != null) {
            a1.setVisible(visible);
        }
    }

    // 设置系统音量（ Windows PowerShell + Core Audio API）
    private static void setSystemVolume(int volume) {
        try {
            int vol = Math.max(0, Math.min(100, volume));

            // PowerShell 脚本：使用 Windows Core Audio API 控制音量
            String psScript = "Add-Type -TypeDefinition @\" \n" +
                    "using System; \n" +
                    "using System.Runtime.InteropServices; \n" +
                    "public class VolumeControl { \n" +
                    "    [DllImport(\"user32.dll\")] \n" +
                    "    public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, uint dwExtraInfo); \n"
                    +
                    "} \n" +
                    "\"@; \n" +
                    "$vol = " + vol + "; \n" +
                    "$current = 0; \n" +
                    "for ($i = 0; $i < 50; $i++) { \n" +
                    "    [VolumeControl]::keybd_event(0xAE, 0, 0, 0); \n" +
                    "    Start-Sleep -Milliseconds 10; \n" +
                    "} \n" +
                    "for ($i = 0; $i < $vol; $i++) { \n" +
                    "    [VolumeControl]::keybd_event(0xAF, 0, 0, 0); \n" +
                    "    Start-Sleep -Milliseconds 10; \n" +
                    "}";

            ProcessBuilder pb = new ProcessBuilder("powershell.exe", "-Command", psScript);
            pb.redirectErrorStream(true);
            Process process = pb.start();
            process.waitFor(2, java.util.concurrent.TimeUnit.SECONDS);

            System.out.println("音量已设置为: " + vol + "%");

        } catch (Exception e) {
            System.err.println("PowerShell 控制音量失败: " + e.getMessage());
            // 降级到 Robot 方案
            setSystemVolumeRobot(volume);
        }
    }

// 备用方案：使用 Robot 模拟键盘按键（更可靠）
private static void setSystemVolumeRobot(int volume) {
    try {
        Robot robot = new Robot();
        int vol = Math.max(0, Math.min(100, volume));
        
        // 先降到 0（按 50 次降低音量）
        for (int i = 0; i < 50; i++) {
            robot.keyPress(0xAE);
            robot.keyRelease(0xAE);
            Thread.sleep(5);
        }
        // 再升到目标音量
        for (int i = 0; i < vol / 2; i++) {
            robot.keyPress(0xAF);
            robot.keyRelease(0xAF);            Thread.sleep(5);
        }
        System.out.println("Robot 方式设置音量为: " + vol + "%");
        
    } catch (Exception e) {
        System.err.println("Robot 控制音量失败: " + e.getMessage());
    }
}    public static void main(String[] args) {
        // 2.加载动画
        Loading loading = new Loading();
        loading.show();

        // 3.主窗口设置
        a1 = new JFrame("Winllx");
        a1.getContentPane().setBackground(Color.WHITE);
        a1.setExtendedState(JFrame.MAXIMIZED_BOTH);
        a1.setLayout(null);
        a1.setSize(300, 200);
        a1.setLocationRelativeTo(null);
        a1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        a1.setVisible(true);
        // 4.桌面应用标题
        JLabel l1 = new JLabel("Winllx");
        JLabel l2 = new JLabel("便笺");
        JLabel l3 = new JLabel("计算器");
        JLabel l4 = new JLabel("文件管理");
        JLabel l6 = new JLabel("白板");
        l1.setBounds(600, 20, 100, 50);
        l1.setFont(l1.getFont().deriveFont(20f));
        l2.setBounds(320, 130, 80, 80);
        l3.setBounds(820, 130, 80, 80);
        l4.setBounds(310, 260, 80, 80);
        l6.setBounds(320, 390, 80, 80);

        a1.add(l2);
        a1.add(l1);
        a1.add(l3);
        a1.add(l4);
        a1.add(l6);

        // 5.桌面应用按钮
        JButton bian = GlassButtonDemo.createButton("便笺");
        JButton b3 = GlassButtonDemo.createButton("计算器");
        JButton b4 = GlassButtonDemo.createButton("文件管理");
        JButton b5 = GlassButtonDemo.createButton("读心术");
        JButton b6 = GlassButtonDemo.createButton("白板");
        JButton b02 = GlassButtonDemo.createButton("缩小到任务栏");
        JButton b0 = GlassButtonDemo.createButton("退出");
        JButton b01 = GlassButtonDemo.createButton("设置");
        b0.setBounds(1200, 550, 80, 80);
        b01.setBounds(1100, 550, 80, 80);
        b02.setBounds(900, 550, 150, 50);

        // 6.退出按钮
        b0.setBorderPainted(false);
        b0.setBackground(Color.WHITE);
        b0.addActionListener(e -> new Winllx0());

        // 7.系统设置按钮
        b01.setBorderPainted(false);
        b01.setBackground(Color.WHITE);
        b01.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame f = new JFrame("Winllx设置");
                f.setSize(350, 350);
                f.setLocation(200, 200);
                f.setLayout(null);
                JLabel l1 = new JLabel("主题色");
                JLabel l2 = new JLabel("全屏显示");
                JRadioButton r1 = new JRadioButton("默认(白)");
                JRadioButton r2 = new JRadioButton("黑色");
                JRadioButton r3 = new JRadioButton("蓝色");
                JRadioButton r4 = new JRadioButton("开启");
                JRadioButton r5 = new JRadioButton("关闭");
                ButtonGroup bg = new ButtonGroup();
                ButtonGroup bg2 = new ButtonGroup();
                r1.addActionListener(e1 -> {
                    a1.getContentPane().setBackground(Color.WHITE);
                    a1.repaint();
                });
                r2.addActionListener(e1 -> {
                    a1.getContentPane().setBackground(Color.black);
                    a1.repaint();
                });
                r3.addActionListener(e1 -> {
                    a1.getContentPane().setBackground(Color.blue);
                    a1.repaint();
                });
                r4.addActionListener(e1 -> a1.setExtendedState(JFrame.MAXIMIZED_BOTH));
                r5.addActionListener(e1 -> a1.setExtendedState(JFrame.NORMAL));
                bg.add(r1);
                bg.add(r2);
                bg.add(r3);
                bg2.add(r4);
                bg2.add(r5);
                l1.setBounds(10, 0, 80, 30);
                r1.setBounds(10, 30, 80, 30);
                r2.setBounds(10, 60, 80, 30);
                r3.setBounds(10, 90, 80, 30);
                l2.setBounds(10, 130, 80, 30);
                r4.setBounds(10, 160, 80, 30);
                r5.setBounds(10, 190, 80, 30);
                f.add(l1);
                f.add(r1);
                f.add(r2);
                f.add(r3);
                f.add(l2);
                f.add(r4);
                f.add(r5);
                // 音量控制滑块
                JLabel volumeLabel = new JLabel("音量(需系统权限)");
                volumeLabel.setBounds(10, 230, 80, 30);

                // 使用数组包装
                GlassSlider[] volumeSliderRef = new GlassSlider[1];
                volumeSliderRef[0] = GlassSlider.create(f, 0, 260, 200, 50, 50, evt -> {
                    int volume = volumeSliderRef[0].getValue();
                });

                volumeSliderRef[0].setBounds(10, 260, 200, 50);
                f.add(volumeLabel);
                f.add(volumeSliderRef[0]);
                f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                f.setVisible(true);
            }
        });

        // 8.桌面应用按钮布局与事件
        bian.setBounds(300, 70, 80, 80);
        bian.setBorderPainted(false);
        bian.setBackground(Color.WHITE);
        bian.addActionListener(e -> new Winllx2());
        b3.setBounds(800, 70, 80, 80);
        b3.setBorderPainted(false);
        b3.setBackground(Color.WHITE);
        b3.addActionListener(e -> new Winllx3());
        b4.setBounds(300, 200, 80, 80);
        b4.setBorderPainted(false);
        b4.setBackground(Color.WHITE);
        b4.addActionListener(e -> new Winllx4());
        b5.setBounds(800, 200, 200, 50);

        // 9.读心术
        b5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                a1.setVisible(false);
                JOptionPane.showMessageDialog(null, "启动成功，请返回cmd进行操作");
                System.out.println("欢迎来到读心术(二进制)\n在1-31中选择一个数字\n注：如果玩不起(更改所想数字)，请在不要按下Enter,并退出游戏\n按下Enter开始游戏");
                Scanner s = new Scanner(System.in);
                s.nextLine();
                int[] group1 = { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31 };
                int[] group2 = { 2, 3, 6, 7, 10, 11, 14, 15, 18, 19, 22, 23, 26, 27, 30, 31 };
                int[] group3 = { 4, 5, 6, 7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31 };
                int[] group4 = { 8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29, 30, 31 };
                int[] group5 = { 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 };
                int number = 0;
                System.out.println("你心中所想数字在这一组吗？");
                if (askGroup(s, group1)) {
                    number += 1;
                }
                if (askGroup(s, group2)) {
                    number += 2;
                }
                if (askGroup(s, group3)) {
                    number += 4;
                }
                if (askGroup(s, group4)) {
                    number += 8;
                }
                if (askGroup(s, group5)) {
                    number += 16;
                }
                JOptionPane.showMessageDialog(null, "你心中所想的数字是：" + number + "\n游戏结束");
                a1.setVisible(true);
            }

            private static boolean askGroup(Scanner s, int[] group) {
                System.out.println("组：");
                for (int num : group) {
                    System.out.print(num + " ");
                }
                System.out.println("你的数字在这个组中吗？ (0: 没有, 1: 有): ");
                int response = s.nextInt();
                return response == 1;
            }
        });

        b6.setBounds(300, 330, 80, 80);
        b6.setBorderPainted(false);
        b6.setBackground(Color.WHITE);
        b6.addActionListener(e -> new Winllx7(null));

        // 10.托盘功能
        b02.addActionListener(e -> a1.setVisible(false));
        final SystemTray tray = SystemTray.getSystemTray();
        Image image = Toolkit.getDefaultToolkit().getImage("C:/Users/86132/Desktop/java.png");
        PopupMenu p1 = new PopupMenu();
        MenuItem openItem = new MenuItem("打开");
        MenuItem setItem = new MenuItem("设置");
        MenuItem exitItem = new MenuItem("退出");
        p1.addSeparator();
        p1.add(setItem);
        p1.addSeparator();
        p1.add(exitItem);

        if (isTrayIcon) {
            TrayIcon trayIcon = new TrayIcon(image, "Winllx", p1);
            trayIcon.setImageAutoSize(true);
            try {
                tray.add(trayIcon);
            } catch (AWTException e1) {
                System.out.println("无法添加到系统托盘\n请检查是否给予权限");
                return;
            }
            openItem.addActionListener(e -> a1.setVisible(true));
            exitItem.addActionListener(e -> {
                tray.remove(trayIcon);
                System.exit(0);
            });
            trayIcon.addActionListener(e -> a1.setVisible(true));
        }

        // 11.添加所有按钮到主窗口
        a1.add(b01);
        a1.add(b02);
        a1.add(bian);
        a1.add(b3);
        a1.add(b4);
        a1.add(b0);
        a1.add(b5);
        a1.add(b6);

        // 12.关闭加载动画
        loading.close();
    }
}

class Winllx0 {// 关机

    Winllx0() {
        try {
            Runtime.getRuntime().exec("shutdown -s -t 0");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "关机失败！请检查是否给予权限");
        }
    }
}

class Winllx2 {// 便笺

    Winllx2() {
        JFrame f = new JFrame("Winllx便签");
        f.setSize(400, 300);
        f.setLocation(200, 200);
        f.setLayout(new FlowLayout());
        JButton b1 = new JButton("设置");
        b1.setBounds(10, 250, 80, 30);
        b1.addActionListener(e -> Winllx2.Winllx22());
        JTextArea ta = new JTextArea();
        ta.setPreferredSize(new Dimension(380, 200));
        f.add(ta);
        f.add(b1);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.setVisible(true);
    }

    static void Winllx22() {
        JFrame f = new JFrame("Winllx便签设置");
        f.setSize(300, 150);
        f.setLocation(200, 200);
        JLabel f1 = new JLabel("自动换行");
        JRadioButton r1 = new JRadioButton("启用", true);
        JRadioButton r2 = new JRadioButton("禁用");
        ButtonGroup bg = new ButtonGroup();
        bg.add(r1);
        bg.add(r2);
        r1.setBounds(90, 20, 80, 30);
        r2.setBounds(90, 40, 80, 30);
        f.add(r1);
        f.add(r2);
        f.add(f1);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.setVisible(true);
    }
}

class Winllx4 {// 文件管理

    Winllx4() {
        JFrame f1 = new JFrame("文件管理");
        f1.setSize(350, 80);
        f1.setResizable(false);
        f1.setLayout(null);
        JButton b1 = new JButton("新建");
        b1.setBounds(10, 10, 80, 30);
        JButton b2 = new JButton("打开");
        b2.setBounds(100, 10, 80, 30);
        JButton b3 = new JButton("预览文件");
        b3.setBounds(200, 10, 100, 30);
        b1.addActionListener(
                e -> JOptionPane.showMessageDialog(null, "您的电脑不支持此功能", "该功能不会做", JOptionPane.ERROR_MESSAGE));
        b2.addActionListener(
                e -> JOptionPane.showMessageDialog(null, "您的电脑不支持此功能", "该功能不会做", JOptionPane.ERROR_MESSAGE));
        b3.addActionListener(
                e -> JOptionPane.showMessageDialog(null, "您的电脑不支持此功能", "该功能不会做", JOptionPane.ERROR_MESSAGE));
        f1.add(b1);
        f1.add(b2);
        f1.add(b3);
        f1.setVisible(true);
    }
}

/*
 * class Winllx5 extends JFrame {
 * private JTabbedPane tabbedPane;
 * private ClockPanel clockPanel;
 * private AlarmPanel alarmPanel;
 * private CountdownPanel countdownPanel;
 * private StopwatchPanel stopwatchPanel;
 * 
 * public Winllx5() {
 * setTitle("时钟");
 * setSize(400, 500);
 * setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 * setLocationRelativeTo(null);
 * 
 * // 创建选项卡面板
 * tabbedPane = new JTabbedPane();
 * 
 * // 创建各个功能面板
 * clockPanel = new ClockPanel();
 * alarmPanel = new AlarmPanel();
 * countdownPanel = new CountdownPanel();
 * stopwatchPanel = new StopwatchPanel();
 * 
 * // 添加选项卡
 * tabbedPane.addTab("时间", clockPanel);
 * tabbedPane.addTab("闹钟", alarmPanel);
 * tabbedPane.addTab("倒计时", countdownPanel);
 * tabbedPane.addTab("计时器", stopwatchPanel);
 * 
 * add(tabbedPane);
 * 
 * // 每秒更新一次时钟
 * Timer timer = new Timer();
 * timer.scheduleAtFixedRate(new TimerTask() {
 * 
 * @Override
 * public void run() {
 * clockPanel.repaint();
 * }
 * }, 0, 1000);
 * }
 * 
 * public static void main(String[] args) {
 * SwingUtilities.invokeLater(() -> {
 * ClockApp app = new ClockApp();
 * app.setVisible(true);
 * });
 * }
 * 
 * // 时钟面板
 * class ClockPanel extends JPanel {
 * private SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
 * private SimpleDateFormat dateFormat = new
 * SimpleDateFormat("yyyy年MM月dd日 EEEE");
 * 
 * public ClockPanel() {
 * setLayout(new BorderLayout());
 * }
 * 
 * @Override
 * protected void paintComponent(Graphics g) {
 * super.paintComponent(g);
 * 
 * // 获取当前时间
 * Calendar calendar = Calendar.getInstance();
 * int hour = calendar.get(Calendar.HOUR);
 * int minute = calendar.get(Calendar.MINUTE);
 * int second = calendar.get(Calendar.SECOND);
 * 
 * // 绘制数字时间
 * String time = timeFormat.format(calendar.getTime());
 * String date = dateFormat.format(calendar.getTime());
 * 
 * g.setFont(new Font("Arial", Font.BOLD, 24));
 * FontMetrics fm = g.getFontMetrics();
 * int timeWidth = fm.stringWidth(time);
 * g.drawString(time, (getWidth() - timeWidth) / 2, 50);
 * 
 * g.setFont(new Font("Arial", Font.PLAIN, 16));
 * fm = g.getFontMetrics();
 * int dateWidth = fm.stringWidth(date);
 * g.drawString(date, (getWidth() - dateWidth) / 2, 80);
 * 
 * // 绘制圆形钟表
 * int centerX = getWidth() / 2;
 * int centerY = getHeight() / 2 + 30;
 * int radius = Math.min(getWidth(), getHeight()) / 3;
 * 
 * // 绘制表盘
 * g.setColor(Color.BLACK);
 * g.drawOval(centerX - radius, centerY - radius, 2 * radius, 2 * radius);
 * 
 * // 绘制刻度
 * for (int i = 0; i < 60; i++) {
 * double angle = Math.toRadians(6 * i);
 * int x1 = centerX + (int) (0.9 * radius * Math.sin(angle));
 * int y1 = centerY - (int) (0.9 * radius * Math.cos(angle));
 * int x2 = centerX + (int) (radius * Math.sin(angle));
 * int y2 = centerY - (int) (radius * Math.cos(angle));
 * 
 * if (i % 5 == 0) {
 * // 小时刻度
 * g.setColor(Color.BLACK);
 * g.drawLine(x1, y1, x2, y2);
 * } else {
 * // 分钟刻度
 * g.setColor(Color.GRAY);
 * g.drawLine(x1, y1, x2, y2);
 * }
 * }
 * 
 * // 绘制时针
 * double hourAngle = Math.toRadians(30 * hour + 0.5 * minute);
 * int hourHandLength = radius / 2;
 * int hourX = centerX + (int) (hourHandLength * Math.sin(hourAngle));
 * int hourY = centerY - (int) (hourHandLength * Math.cos(hourAngle));
 * g.setColor(Color.BLACK);
 * g.drawLine(centerX, centerY, hourX, hourY);
 * 
 * // 绘制分针
 * double minuteAngle = Math.toRadians(6 * minute + 0.1 * second);
 * int minuteHandLength = 3 * radius / 4;
 * int minuteX = centerX + (int) (minuteHandLength * Math.sin(minuteAngle));
 * int minuteY = centerY - (int) (minuteHandLength * Math.cos(minuteAngle));
 * g.setColor(Color.BLUE);
 * g.drawLine(centerX, centerY, minuteX, minuteY);
 * 
 * // 绘制秒针
 * double secondAngle = Math.toRadians(6 * second);
 * int secondHandLength = 4 * radius / 5;
 * int secondX = centerX + (int) (secondHandLength * Math.sin(secondAngle));
 * int secondY = centerY - (int) (secondHandLength * Math.cos(secondAngle));
 * g.setColor(Color.RED);
 * g.drawLine(centerX, centerY, secondX, secondY);
 * 
 * // 绘制中心点
 * g.setColor(Color.RED);
 * g.fillOval(centerX - 5, centerY - 5, 10, 10);
 * }
 * }
 * 
 * // 闹钟面板
 * class AlarmPanel extends JPanel {
 * private DefaultListModel<String> alarmListModel;
 * private JList<String> alarmList;
 * private JButton addButton;
 * private JButton deleteButton;
 * 
 * public AlarmPanel() {
 * setLayout(new BorderLayout());
 * 
 * alarmListModel = new DefaultListModel<>();
 * alarmList = new JList<>(alarmListModel);
 * add(new JScrollPane(alarmList), BorderLayout.CENTER);
 * 
 * JPanel buttonPanel = new JPanel();
 * addButton = new JButton("添加闹钟");
 * deleteButton = new JButton("删除闹钟");
 * 
 * addButton.addActionListener(e -> addAlarm());
 * deleteButton.addActionListener(e -> deleteAlarm());
 * 
 * buttonPanel.add(addButton);
 * buttonPanel.add(deleteButton);
 * add(buttonPanel, BorderLayout.SOUTH);
 * }
 * 
 * private void addAlarm() {
 * JSpinner hourSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 23, 1));
 * JSpinner minuteSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));
 * 
 * JPanel panel = new JPanel(new GridLayout(2, 2));
 * panel.add(new JLabel("小时:"));
 * panel.add(hourSpinner);
 * panel.add(new JLabel("分钟:"));
 * panel.add(minuteSpinner);
 * 
 * int result = JOptionPane.showConfirmDialog(null, panel, "设置闹钟",
 * JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
 * 
 * if (result == JOptionPane.OK_OPTION) {
 * int hour = (Integer) hourSpinner.getValue();
 * int minute = (Integer) minuteSpinner.getValue();
 * alarmListModel.addElement(String.format("%02d:%02d", hour, minute));
 * }
 * }
 * 
 * private void deleteAlarm() {
 * int selectedIndex = alarmList.getSelectedIndex();
 * if (selectedIndex != -1) {
 * alarmListModel.remove(selectedIndex);
 * }
 * }
 * }
 * 
 * // 倒计时面板
 * class CountdownPanel extends JPanel {
 * private JSpinner hourSpinner;
 * private JSpinner minuteSpinner;
 * private JSpinner secondSpinner;
 * private JButton startButton;
 * private JButton stopButton;
 * private JLabel countdownLabel;
 * private java.util.Timer countdownTimer;
 * private int remainingSeconds;
 * 
 * public CountdownPanel() {
 * setLayout(new BorderLayout());
 * 
 * JPanel inputPanel = new JPanel(new GridLayout(3, 2));
 * hourSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 23, 1));
 * minuteSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));
 * secondSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));
 * 
 * inputPanel.add(new JLabel("小时:"));
 * inputPanel.add(hourSpinner);
 * inputPanel.add(new JLabel("分钟:"));
 * inputPanel.add(minuteSpinner);
 * inputPanel.add(new JLabel("秒:"));
 * inputPanel.add(secondSpinner);
 * 
 * JPanel buttonPanel = new JPanel();
 * startButton = new JButton("开始");
 * stopButton = new JButton("停止");
 * stopButton.setEnabled(false);
 * 
 * startButton.addActionListener(e -> startCountdown());
 * stopButton.addActionListener(e -> stopCountdown());
 * 
 * buttonPanel.add(startButton);
 * buttonPanel.add(stopButton);
 * 
 * countdownLabel = new JLabel("00:00:00", SwingConstants.CENTER);
 * countdownLabel.setFont(new Font("Arial", Font.BOLD, 24));
 * 
 * add(inputPanel, BorderLayout.NORTH);
 * add(countdownLabel, BorderLayout.CENTER);
 * add(buttonPanel, BorderLayout.SOUTH);
 * }
 * 
 * private void startCountdown() {
 * int hours = (Integer) hourSpinner.getValue();
 * int minutes = (Integer) minuteSpinner.getValue();
 * int seconds = (Integer) secondSpinner.getValue();
 * 
 * remainingSeconds = hours * 3600 + minutes * 60 + seconds;
 * updateCountdownLabel();
 * 
 * startButton.setEnabled(false);
 * stopButton.setEnabled(true);
 * 
 * countdownTimer = new java.util.Timer();
 * countdownTimer.scheduleAtFixedRate(new TimerTask() {
 * 
 * @Override
 * public void run() {
 * if (remainingSeconds > 0) {
 * remainingSeconds--;
 * SwingUtilities.invokeLater(() -> updateCountdownLabel());
 * } else {
 * stopCountdown();
 * JOptionPane.showMessageDialog(null, "倒计时结束!");
 * }
 * }
 * }, 1000, 1000);
 * }
 * 
 * private void stopCountdown() {
 * if (countdownTimer != null) {
 * countdownTimer.cancel();
 * countdownTimer = null;
 * }
 * startButton.setEnabled(true);
 * stopButton.setEnabled(false);
 * }
 * 
 * private void updateCountdownLabel() {
 * int hours = remainingSeconds / 3600;
 * int minutes = (remainingSeconds % 3600) / 60;
 * int seconds = remainingSeconds % 60;
 * countdownLabel.setText(String.format("%02d:%02d:%02d", hours, minutes,
 * seconds));
 * }
 * }
 * 
 * // 计时器面板
 * class StopwatchPanel extends JPanel {
 * private JLabel timeLabel;
 * private JButton startButton;
 * private JButton stopButton;
 * private JButton resetButton;
 * private Timer stopwatchTimer;
 * private long startTime;
 * private boolean isRunning;
 * 
 * public StopwatchPanel() {
 * setLayout(new BorderLayout());
 * 
 * timeLabel = new JLabel("00:00:00.000", SwingConstants.CENTER);
 * timeLabel.setFont(new Font("Arial", Font.BOLD, 24));
 * add(timeLabel, BorderLayout.CENTER);
 * 
 * JPanel buttonPanel = new JPanel();
 * startButton = new JButton("开始");
 * stopButton = new JButton("停止");
 * resetButton = new JButton("重置");
 * stopButton.setEnabled(false);
 * 
 * startButton.addActionListener(e -> startStopwatch());
 * stopButton.addActionListener(e -> stopStopwatch());
 * resetButton.addActionListener(e -> resetStopwatch());
 * 
 * buttonPanel.add(startButton);
 * buttonPanel.add(stopButton);
 * buttonPanel.add(resetButton);
 * add(buttonPanel, BorderLayout.SOUTH);
 * }
 * 
 * private void startStopwatch() {
 * if (!isRunning) {
 * startTime = System.currentTimeMillis() - (isRunning ? 0 : startTime);
 * isRunning = true;
 * startButton.setEnabled(false);
 * stopButton.setEnabled(true);
 * 
 * stopwatchTimer = new Timer(10, e -> {
 * long elapsed = System.currentTimeMillis() - startTime;
 * updateStopwatchLabel(elapsed);
 * });
 * stopwatchTimer.start();
 * }
 * }
 * 
 * private void stopStopwatch() {
 * if (isRunning) {
 * stopwatchTimer.stop();
 * isRunning = false;
 * startButton.setEnabled(true);
 * stopButton.setEnabled(false);
 * }
 * }
 * 
 * private void resetStopwatch() {
 * stopwatchTimer.stop();
 * isRunning = false;
 * startTime = 0;
 * startButton.setEnabled(true);
 * stopButton.setEnabled(false);
 * timeLabel.setText("00:00:00.000");
 * }
 * 
 * private void updateStopwatchLabel(long elapsed) {
 * long hours = elapsed / 3600000;
 * long minutes = (elapsed % 3600000) / 60000;
 * long seconds = (elapsed % 60000) / 1000;
 * long millis = elapsed % 1000;
 * timeLabel.setText(String.format("%02d:%02d:%02d.%03d", hours, minutes,
 * seconds, millis));
 * }
 * }
 * }
 */
class Loading {// 加载动画

    private JFrame frame;
    private JPanel panel;
    private int angle = 0;
    private javax.swing.Timer timer;

    public Loading() {
        initUI();
    }

    private void initUI() {
        frame = new JFrame("加载中");
        frame.setSize(200, 200);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setAlwaysOnTop(true);

        panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);

                int centerX = getWidth() / 2;
                int centerY = getHeight() / 2;
                int radius = 50;

                // 绘制圆环背景
                g2d.setColor(Color.LIGHT_GRAY);
                g2d.setStroke(new BasicStroke(2));
                g2d.drawOval(centerX - radius, centerY - radius,
                        radius * 2, radius * 2);

                // 绘制加载圆弧（3/4圆）
                g2d.setColor(Color.BLUE);
                g2d.setStroke(new BasicStroke(5));
                g2d.drawArc(centerX - radius, centerY - radius,
                        radius * 2, radius * 2, angle, 270);
            }
        };
        panel.setBackground(Color.WHITE);
        frame.add(panel);

        // 定时器控制动画旋转
        timer = new javax.swing.Timer(50, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                angle = (angle + 10) % 360; // 每次旋转5°
                panel.repaint();
            }
        });
        timer.start();
    }

    public void show() {
        frame.setVisible(true);
    }

    public void close() {
        timer.stop();
        frame.dispose();
    }

}
