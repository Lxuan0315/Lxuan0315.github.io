import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

/**
 * JButton btn = GlassButtonDemo.createButton();
 */
public class GlassButtonDemo {

    public static JButton createButton(String text) {
        JellyGlassButton btn = new JellyGlassButton(text);
        btn.setForeground(new Color(220, 220, 220));
        btn.setFont(new Font("微软雅黑", Font.BOLD, 14));
        return btn;
    }

    // ==================== 按钮内部类 ====================
    private static class JellyGlassButton extends JButton {
        private float deformX = 0f;
        private float deformY = 0f;
        private boolean pressed = false;
        private float animDeformX = 0f;
        private float animDeformY = 0f;
        private Timer animTimer;

        private static final float DEFORM_STRENGTH = 0.2f;
        private static final float GLASS_OPACITY = 0.35f;
        private static final float EDGE_OPACITY = 0.55f;

        public JellyGlassButton(String text) {
            super(text);
            setFont(new Font("微软雅黑", Font.BOLD, 14));
            setForeground(new Color(60, 60, 60));
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setPreferredSize(new Dimension(120, 40));

            MouseAdapter ma = new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    pressed = true;
                    updateDeform(e);
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    pressed = false;
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    if (pressed) updateDeform(e);
                }
            };
            addMouseListener(ma);
            addMouseMotionListener(new MouseMotionAdapter() {
                @Override
                public void mouseDragged(MouseEvent e) {
                    if (pressed) updateDeform(e);
                }
            });

            animTimer = new Timer(16, e -> {
                if (!pressed) {
                    animDeformX += (0 - animDeformX) * 0.2f;
                    animDeformY += (0 - animDeformY) * 0.2f;
                    if (Math.abs(animDeformX) < 0.01f && Math.abs(animDeformY) < 0.01f) {
                        animDeformX = 0f;
                        animDeformY = 0f;
                    }
                    repaint();
                }
            });
            animTimer.start();
        }

        private void updateDeform(MouseEvent e) {
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float rawX = (e.getX() - cx) / cx;
            float rawY = (e.getY() - cy) / cy;
            rawX = Math.max(-1f, Math.min(1f, rawX));
            rawY = Math.max(-1f, Math.min(1f, rawY));
            deformX = rawX;
            deformY = rawY;
            animDeformX = rawX;
            animDeformY = rawY;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);

            int w = getWidth();
            int h = getHeight();
            int margin = 6;
            int arc = 18;

            float dx = animDeformX;
            float dy = animDeformY;

            float stretchX = dx * w * DEFORM_STRENGTH;
            float stretchY = dy * h * DEFORM_STRENGTH;

            float left = margin + (dx < 0 ? stretchX : 0);
            float top = margin + (dy < 0 ? stretchY : 0);
            float bw = w - 2 * margin + Math.abs(stretchX);
            float bh = h - 2 * margin + Math.abs(stretchY);

            float actualArc = arc - Math.abs(stretchX + stretchY) * 0.15f;
            actualArc = Math.max(6f, actualArc);

            AffineTransform original = g2.getTransform();

            // 阴影
            for (int i = 0; i < 5; i++) {
                float alpha = pressed ? 0.07f - i * 0.012f : 0.1f - i * 0.015f;
                if (alpha <= 0) continue;
                g2.setColor(new Color(0, 0, 0, (int) (alpha * 255)));
                float sx = left + 1f + stretchX * 0.1f;
                float sy = top + 2f + stretchY * 0.1f + i * 1.5f;
                g2.fill(new RoundRectangle2D.Float(sx, sy, bw - 2, bh - 2, actualArc, actualArc));
            }

            // 玻璃壳体
            RoundRectangle2D.Float glassShape = new RoundRectangle2D.Float(left, top, bw, bh, actualArc, actualArc);

            float gradDX = dx * bw * 0.3f;
            float gradDY = dy * bh * 0.3f;

            LinearGradientPaint glassPaint = new LinearGradientPaint(
                    left + gradDX, top + gradDY,
                    left + bw - gradDX, top + bh - gradDY,
                    new float[]{0.0f, 0.15f, 0.5f, 0.85f, 1.0f},
                    new Color[]{
                            new Color(255, 255, 255, (int) (EDGE_OPACITY * 255)),
                            new Color(255, 255, 255, (int) (GLASS_OPACITY * 255 * 0.8f)),
                            new Color(255, 255, 255, (int) (GLASS_OPACITY * 255 * 0.15f)),
                            new Color(255, 255, 255, (int) (GLASS_OPACITY * 255 * 0.6f)),
                            new Color(255, 255, 255, (int) (EDGE_OPACITY * 255))
                    }
            );
            g2.setPaint(glassPaint);
            g2.fill(glassShape);

            // 边框
            g2.setColor(new Color(255, 255, 255, 85));
            g2.setStroke(new BasicStroke(1f));
            g2.draw(glassShape);
            g2.setColor(new Color(0, 0, 0, 20));
            g2.draw(new RoundRectangle2D.Float(left + 1, top + 1, bw - 2, bh - 2, actualArc - 2, actualArc - 2));

            // 光环高光
            drawGlowRing(g2, left, top, bw, bh, actualArc, dx, dy);

            // 底部反光
            float refY = top + bh - 4 + dy * 2f;
            g2.setColor(new Color(255, 255, 255, 35));
            g2.setStroke(new BasicStroke(1f));
            g2.draw(new Line2D.Float(left + 4, refY, left + bw - 4, refY));
            g2.setColor(new Color(255, 255, 255, 15));
            g2.draw(new Line2D.Float(left + 6, refY + 1.5f, left + bw - 6, refY + 1.5f));

            // 左侧环境光
            g2.setColor(new Color(255, 255, 255, 20));
            float envW = Math.max(10f, bw * 0.18f);
            g2.fill(new RoundRectangle2D.Float(left + 1.5f, top + actualArc * 0.5f,
                    envW, bh - actualArc, actualArc * 0.5f, actualArc * 0.5f));

            // 文字
            g2.setTransform(original);
            FontMetrics fm = g2.getFontMetrics();
            String text = getText();
            int tx = (int) ((w - fm.stringWidth(text)) / 2f + stretchX * 0.4f);
            int ty = (int) ((h - fm.getHeight()) / 2f + fm.getAscent() + stretchY * 0.4f);

            g2.setColor(new Color(0, 0, 0, 35));
            g2.drawString(text, tx + 1, ty + 1);
            g2.setColor(getForeground());
            g2.drawString(text, tx, ty);

            g2.dispose();
        }

        private void drawGlowRing(Graphics2D g2, float left, float top,
                                   float bw, float bh, float arc,
                                   float dx, float dy) {
            if (pressed) return;

            float inset = 3f;
            float l = left + inset;
            float t = top + inset;
            float r = l + bw - 2 * inset;
            float b = t + bh - 2 * inset;
            float ar = arc - inset;
            float arcDiam = ar * 2;
            float arcStart = 125f;
            float arcExtent = 100f;

            // 扩散光晕
            g2.setColor(new Color(255, 255, 255, 70));
            g2.setStroke(new BasicStroke(5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.draw(new Arc2D.Float(l - 1.5f, t - 1.5f, arcDiam + 3, arcDiam + 3,
                    arcStart - 2, arcExtent + 4, Arc2D.OPEN));

            // 中间层
            g2.setColor(new Color(255, 255, 255, 140));
            g2.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.draw(new Arc2D.Float(l, t, arcDiam, arcDiam, arcStart, arcExtent, Arc2D.OPEN));

            // 最亮核心
            g2.setColor(new Color(255, 255, 255, 210));
            g2.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.draw(new Arc2D.Float(l + 0.5f, t + 0.5f, arcDiam - 1, arcDiam - 1,
                    arcStart + 3, arcExtent - 6, Arc2D.OPEN));

            // 上边缘光带
            int segments = 25;
            for (int i = 0; i < segments; i++) {
                float tt = (float) i / segments;
                float x = l + ar + (r - ar - (l + ar)) * tt;
                float y = t;
                float brightness = (1f - tt) * (1f - tt);
                int alpha = (int) (160 * brightness);
                if (alpha < 6) continue;
                float sw = 2f * brightness + 0.3f;
                g2.setColor(new Color(255, 255, 255, alpha));
                g2.setStroke(new BasicStroke(sw, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.draw(new Line2D.Float(x - 2.5f, y, x + 2.5f, y));
            }

            // 左边缘光带
            for (int i = 0; i < segments; i++) {
                float tt = (float) i / segments;
                float x = l;
                float y = t + ar + (b - ar - (t + ar)) * tt;
                float brightness = (1f - tt) * (1f - tt);
                int alpha = (int) (160 * brightness);
                if (alpha < 6) continue;
                float sw = 2f * brightness + 0.3f;
                g2.setColor(new Color(255, 255, 255, alpha));
                g2.setStroke(new BasicStroke(sw, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.draw(new Line2D.Float(x, y - 2.5f, x, y + 2.5f));
            }
        }
    }
}