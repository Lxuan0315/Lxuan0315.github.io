package modules;

import ui.GlassBrowserPanel;
import ui.GlassFrame;
import utils.LangManager;

import javax.swing.*;
import java.awt.*;

/**
 * 读心术模块（JCEF + 网页版液态玻璃）。
 * 原命令行版（Scanner + 控制台输出）替换为 web/mind/mind.html 窗口版：
 * 5 组 1-31 数字卡片 + 有/没有按钮，按权重加权求和得出结果。
 * MIND_GROUPS / MIND_WEIGHTS 数据从 Winllx.java 迁移至此。
 */
public class MindReaderModule {

    private static final int[][] MIND_GROUPS = new int[][]{
            {1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31},
            {2, 3, 6, 7, 10, 11, 14, 15, 18, 19, 22, 23, 26, 27, 30, 31},
            {4, 5, 6, 7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31},
            {8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29, 30, 31},
            {16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31}};

    private JFrame frame;
    private GlassBrowserPanel browserPanel;

    public MindReaderModule() {
        frame = new GlassFrame(LangManager.getString("module.mind"));
        frame.setSize(560, 640);
        frame.setMinimumSize(new Dimension(430, 520));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        browserPanel = new GlassBrowserPanel("mind/mind.html", true);
        frame.add(browserPanel, BorderLayout.CENTER);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                if (browserPanel != null) browserPanel.closeBrowser();
            }
        });
        frame.setVisible(true);
        System.out.println("[WinllxMind] 读心术窗口已启动 (JCEF + mind.html)");
    }

    public GlassBrowserPanel getBrowserPanel() {
        return browserPanel;
    }
}
