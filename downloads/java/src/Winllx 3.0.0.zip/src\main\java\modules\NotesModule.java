package modules;

import ui.GlassBrowserPanel;
import ui.GlassFrame;
import utils.LangManager;

import javax.swing.*;
import java.awt.*;
import java.io.File;

/**
 * 便笺模块（JCEF + 网页版液态玻璃）。
 *
 * 原 Swing UI（JTabbedPane + GlassButton）已被替换为 JCEF 浏览器组件，
 * 加载 web/notes/notes.html —— 该页面完全移植了 React 项目中的 LiquidGlass
 * 按钮组件（SVG feDisplacementMap 滤镜、弹性方向缩放、鼠标跟踪、色差、光晕）。
 *
 * 数据持久化由 notes.html 自身通过 localStorage 完成，
 * GlassBrowserPanel 已设置 cache_path，localStorage 会持久化到 Winllx/jcef_cache。
 *
 * 强制用 GlassFrame（自定义无边框毛玻璃）创建，不跟随全局"毛玻璃窗口"开关，
 * 彻底解决系统原生边框。GlassFrame 嵌 JCEF 已由 LiquidGlassModule / SettingsFrame 验证稳定。
 */
public class NotesModule {

    private static final String NOTES_DIR = System.getProperty("user.dir") + "/Winllx/notes";
    private static final String NOTES_HTML = "notes/notes.html";

    private JFrame frame;
    private GlassBrowserPanel browserPanel;

    /** 已打开的便笺窗口注册表：供全局设置实时推送液态玻璃参数到这些窗口 */
    private static final java.util.Set<NotesModule> OPEN =
            java.util.concurrent.ConcurrentHashMap.newKeySet();

    public NotesModule() {
        new File(NOTES_DIR).mkdirs();
        OPEN.add(this);

        frame = new GlassFrame(LangManager.getString("module.note"));
        frame.setSize(720, 560);
        frame.setMinimumSize(new Dimension(450, 350));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        // 创建 JCEF 浏览器面板，加载 notes.html。
        // 若 JCEF 仍在后台预热，面板内部会先显示占位、待就绪后再挂载浏览器，不会阻塞 EDT。
        browserPanel = new GlassBrowserPanel(NOTES_HTML);
        frame.add(browserPanel, BorderLayout.CENTER);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                OPEN.remove(NotesModule.this);
                // 关闭前触发 JS 端保存（beforeunload / saveBeforeClose）。
                // 保存等待与浏览器销毁放到后台线程，避免在 EDT 上 sleep 造成关窗卡顿。
                if (browserPanel != null) {
                    final GlassBrowserPanel bp = browserPanel;
                    bp.triggerSaveBeforeClose();
                    new Thread(() -> {
                        try { Thread.sleep(200); } catch (InterruptedException ignored) {}
                        bp.closeBrowser();
                    }, "notes-close").start();
                }
            }
        });
        frame.setVisible(true);
        frame.requestFocus();
        System.out.println("[Winllx2] 便笺窗口已启动 (JCEF + notes.html)");
    }

    /** 获取浏览器面板（供外部执行 JS / 推送设置） */
    public GlassBrowserPanel getBrowserPanel() {
        return browserPanel;
    }

    /** 全局设置改动时，把液态玻璃参数实时推送到所有已打开的便笺窗口 */
    public static void pushLiquidGlassToAll(String payloadJson) {
        if (payloadJson == null || payloadJson.isEmpty()) return;
        for (NotesModule w : OPEN) {
            try {
                GlassBrowserPanel p = w.getBrowserPanel();
                if (p != null && p.isBrowserActive()) {
                    p.executeJavaScript("try{if(window.applyLiquidGlassParams)window.applyLiquidGlassParams("
                            + payloadJson + ");}catch(e){};");
                }
            } catch (Throwable ignored) {
            }
        }
    }
}
