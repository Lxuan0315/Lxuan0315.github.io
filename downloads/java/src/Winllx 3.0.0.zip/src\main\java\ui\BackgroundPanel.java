package ui;

import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

public class BackgroundPanel extends JPanel {
    public static final int FIT_FILL = 0;
    public static final int FIT_FIT = 1;
    public static final int FIT_STRETCH = 2;
    public static final int FIT_CENTER = 3;

    private BufferedImage backgroundImage;
    private float imageOpacity = 1.0f;
    private int fitMode = FIT_FILL;

    /** 缩放结果缓存：主界面每帧重绘都要按窗口大小缩放整张背景大图，
     *  原来的实现每帧都用 RENDER_QUALITY 双线性重采样（大图非常慢，直接拖累桌面按钮拖动/吸附动画）。
     *  这里缓存缩放后的位图，仅在窗口尺寸/图片/适配模式变化时重算，paint 时只做一次 drawImage。 */
    private BufferedImage scaledCache;
    private int cacheW = -1, cacheH = -1;
    private int cacheFit = -1;
    private BufferedImage cacheSrc;

    public BackgroundPanel() {
        setOpaque(true);
        setLayout(null);
    }

    public void setBackgroundImage(BufferedImage image) {
        this.backgroundImage = image;
        invalidateCache();
        repaint();
    }

    private void invalidateCache() {
        scaledCache = null;
        cacheW = cacheH = -1;
        cacheFit = -1;
        cacheSrc = null;
    }

    public BufferedImage getBackgroundImage() {
        return backgroundImage;
    }

    public boolean hasBackgroundImage() {
        return backgroundImage != null;
    }

    public void setImageOpacity(float opacity) {
        this.imageOpacity = Math.max(0f, Math.min(1f, opacity));
        repaint();
    }

    public float getImageOpacity() {
        return imageOpacity;
    }

    public void setFitMode(int mode) {
        this.fitMode = mode;
        invalidateCache();
        repaint();
    }

    public int getFitMode() {
        return fitMode;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();

        g2d.setColor(getBackground());
        g2d.fillRect(0, 0, getWidth(), getHeight());

        if (backgroundImage != null && imageOpacity > 0) {
            Composite oldComp = g2d.getComposite();
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, imageOpacity));

            int pw = getWidth();
            int ph = getHeight();
            int iw = backgroundImage.getWidth();
            int ih = backgroundImage.getHeight();

            if (fitMode == FIT_CENTER) {
                // 不缩放，直接居中绘制，无需缓存
                g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
                g2d.drawImage(backgroundImage, (pw - iw) / 2, (ph - ih) / 2, null);
            } else {
                BufferedImage scaled = ensureScaled(pw, ph, iw, ih);
                if (scaled != null) {
                    g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
                    if (fitMode == FIT_STRETCH) {
                        g2d.drawImage(scaled, 0, 0, null);
                    } else {
                        g2d.drawImage(scaled, (pw - scaled.getWidth()) / 2, (ph - scaled.getHeight()) / 2, null);
                    }
                }
            }

            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.25f * imageOpacity));
            GradientPaint topOverlay = new GradientPaint(
                    0, 0, new Color(0, 0, 0, 180),
                    0, Math.min(100, ph * 0.12f), new Color(0, 0, 0, 0)
            );
            g2d.setPaint(topOverlay);
            g2d.fillRect(0, 0, pw, Math.min(100, ph / 8));

            g2d.setComposite(oldComp);
        }

        g2d.dispose();
    }

    /** 按当前 fit 模式生成/复用缩放后的位图。仅在尺寸/图片/模式变化时重算，避免每帧重采样大图。 */
    private BufferedImage ensureScaled(int pw, int ph, int iw, int ih) {
        if (pw <= 0 || ph <= 0 || iw <= 0 || ih <= 0) return null;
        if (scaledCache != null && cacheW == pw && cacheH == ph
                && cacheFit == fitMode && cacheSrc == backgroundImage) {
            return scaledCache;
        }

        int sw, sh;
        switch (fitMode) {
            case FIT_FIT -> {
                double scale = Math.min((double) pw / iw, (double) ph / ih);
                sw = Math.max(1, (int) (iw * scale));
                sh = Math.max(1, (int) (ih * scale));
            }
            case FIT_STRETCH -> { sw = pw; sh = ph; }
            default -> { // FIT_FILL
                double scale = Math.max((double) pw / iw, (double) ph / ih);
                sw = Math.max(1, (int) (iw * scale));
                sh = Math.max(1, (int) (ih * scale));
            }
        }

        // 一次性高质量缩放（只在尺寸变化时发生），并把结果缓存下来
        BufferedImage out = new BufferedImage(sw, sh, BufferedImage.TYPE_INT_ARGB);
        Graphics2D sg = out.createGraphics();
        sg.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        sg.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        sg.drawImage(backgroundImage, 0, 0, sw, sh, null);
        sg.dispose();

        scaledCache = out;
        cacheW = pw;
        cacheH = ph;
        cacheFit = fitMode;
        cacheSrc = backgroundImage;
        return out;
    }
}
