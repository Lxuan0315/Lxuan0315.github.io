package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;

/**
 * LiquidButton —— 桌面按钮，视觉规格 1:1 照搬「液态玻璃」应用（web/glass）里演示按钮的效果。
 *
 * 对照原版（LiquidGlass React 组件）逐项还原：
 *  - border-radius: 32px
 *  - 半透明磨砂玻璃面（对应原版 backdrop-filter: blur(20px) saturate(140%)）
 *  - 顶部受光 + 顶部径向高光
 *  - 135° 斜向白色扫光（原版 screen / overlay 两层高光叠加后的效果）
 *  - 内圈 0.5px 白色亮边（原版 inset box-shadow 白线）
 *  - box-shadow: 0px 12px 40px rgba(0,0,0,0.25) 的外投影（近似）
 *  - 按下时整体向内轻微缩放
 */
public class LiquidButton extends JPanel {

    private String text;
    private Color textColor = new Color(255, 255, 255);
    private Color accentColor = null;   // setBackground 设置的强调色（白色视为无强调）

    private boolean pressed = false;
    private boolean hover = false;
    private float pressAnim = 0f;       // 按下动画进度 0..1
    private float hoverAnim = 0f;       // 悬停动画进度 0..1
    private Timer animTimer;
    private final List<ActionListener> listeners = new ArrayList<>();

    private static final int DEFAULT_W = 100;
    private static final int DEFAULT_H = 34;

    /** 玻璃面到组件边缘的留白，用于容纳原版的外投影（Swing 绘制不会越出组件边界） */
    private static final int PAD = 8;

    public LiquidButton(String text) {
        this.text = text != null ? text : "";
        setOpaque(false);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setFont(new Font("Microsoft YaHei", Font.BOLD, 14));
        setPreferredSize(new Dimension(DEFAULT_W, DEFAULT_H));
        initMouse();
    }

    // ===== 工厂方法（与 GlassButton.createButton 同名，便于直接替换）=====

    public static LiquidButton createButton(String text) {
        return new LiquidButton(text);
    }

    public static LiquidButton createButton(String text, int width, int height) {
        LiquidButton btn = new LiquidButton(text);
        btn.setPreferredSize(new Dimension(width, height));
        return btn;
    }

    /** 圆角参数仅为兼容保留：本按钮固定为 32px 圆角（原版演示值） */
    public static LiquidButton createButton(String text, int width, int height, int cornerRadius) {
        return createButton(text, width, height);
    }

    // ===== 事件 API（与 GlassButton 一致）=====

    public void addActionListener(ActionListener listener) {
        listeners.add(listener);
    }

    public void removeActionListener(ActionListener listener) {
        listeners.remove(listener);
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text != null ? text : "";
        repaint();
    }

    @Override
    public void setFont(Font font) {
        super.setFont(font);
        repaint();
    }

    @Override
    public void setForeground(Color c) {
        if (c != null) {
            this.textColor = c;
            repaint();
        }
    }

    /** 兼容旧调用：setBackground 用作强调色着色（如计算器橙色/青色键）；白色=纯玻璃 */
    @Override
    public void setBackground(Color c) {
        this.accentColor = (c == null || c.equals(Color.WHITE)) ? null : c;
        repaint();
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        if (!enabled) {
            pressed = false;
            hover = false;
        }
        repaint();
    }

    // ===== 交互 =====

    private void initMouse() {
        MouseAdapter ma = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (!isEnabled() || !SwingUtilities.isLeftMouseButton(e)) return;
                pressed = true;
                startAnim();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (!isEnabled()) return;
                boolean fire = pressed && contains(e.getPoint());
                pressed = false;
                startAnim();
                if (fire) {
                    ActionEvent ev = new ActionEvent(LiquidButton.this, ActionEvent.ACTION_PERFORMED, text);
                    for (ActionListener l : new ArrayList<>(listeners)) {
                        l.actionPerformed(ev);
                    }
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                hover = true;
                if (isEnabled()) startAnim();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hover = false;
                pressed = false;
                startAnim();
            }
        };
        addMouseListener(ma);
    }

    private void startAnim() {
        if (animTimer == null) {
            animTimer = new Timer(16, e -> {
                float pressTarget = (pressed && isEnabled()) ? 1f : 0f;
                float hoverTarget = (hover && isEnabled()) ? 1f : 0f;
                pressAnim += (pressTarget - pressAnim) * 0.30f;
                hoverAnim += (hoverTarget - hoverAnim) * 0.22f;
                repaint();
                if (Math.abs(pressTarget - pressAnim) < 0.01f && Math.abs(hoverTarget - hoverAnim) < 0.01f) {
                    pressAnim = pressTarget;
                    hoverAnim = hoverTarget;
                    animTimer.stop();
                    repaint();
                }
            });
        }
        if (!animTimer.isRunning()) animTimer.start();
    }

    // ===== 绘制 =====

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);

        int w = getWidth();
        int h = getHeight();
        if (w <= 2 * PAD + 4 || h <= 2 * PAD + 4) { g2d.dispose(); return; }

        if (!isEnabled()) {
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.38f));
        }

        // 按下时向内轻微缩放（始终在组件边界内，无需额外边距）
        float scale = 1f - 0.05f * pressAnim;
        g2d.translate(w / 2.0, h / 2.0);
        g2d.scale(scale, scale);
        g2d.translate(-w / 2.0, -h / 2.0);

        // 玻璃面矩形（四周留出 PAD，用于画原版的外投影）
        float sx = PAD, sy = PAD;
        float sw = w - PAD * 2f, sh = h - PAD * 2f;
        float rad = Math.min(32f, Math.min(sw / 2f, sh / 2f));   // 原版 border-radius: 32px
        float arc = rad * 2f;
        RoundRectangle2D shape = new RoundRectangle2D.Float(sx, sy, sw, sh, arc, arc);

        float hov = Math.min(1f, hoverAnim + pressAnim);

        // --- 0) 外投影（原版 box-shadow: 0px 12px 40px rgba(0,0,0,0.25) 的分层近似）---
        for (int i = 4; i >= 0; i--) {
            float grow = i * 1.6f;
            int alpha = (int) (34 * (1f - i / 5.5f)) + (int) (hov * 8);
            g2d.setColor(new Color(0, 0, 0, Math.max(0, alpha)));
            g2d.fill(new RoundRectangle2D.Float(
                    sx - grow, sy - grow + 2.5f + i * 0.7f,
                    sw + grow * 2f, sh + grow * 2f,
                    (rad + grow) * 2f, (rad + grow) * 2f));
        }

        // --- 1) 玻璃填充：半透明磨砂，透出底下的桌面（对应原版 blur+saturate 的观感）---
        float bump = hoverAnim * 0.05f + pressAnim * 0.10f;
        GradientPaint fill;
        if (accentColor != null) {
            int r = accentColor.getRed(), gg = accentColor.getGreen(), b = accentColor.getBlue();
            fill = new GradientPaint(sx, sy, new Color(r, gg, b, clamp((int) ((0.72f + bump) * 255))),
                    sx, sy + sh, new Color(r, gg, b, clamp((int) ((0.54f + bump * 0.7f) * 255))));
        } else {
            // 原版演示里玻璃是"透明层 + 背景模糊"，在深色底上整体呈深色，所以这里用深色半透明玻璃面
            fill = new GradientPaint(sx, sy, new Color(20, 22, 30, clamp((int) ((0.34f + bump) * 255))),
                    sx, sy + sh, new Color(8, 10, 16, clamp((int) ((0.50f + bump * 0.7f) * 255))));
        }
        g2d.setPaint(fill);
        g2d.fill(shape);

        Shape oldClip = g2d.getClip();
        g2d.setClip(shape);

        // --- 2) 顶部受光面渐变 ---
        g2d.setPaint(new GradientPaint(sx, sy, new Color(255, 255, 255, 150),
                sx, sy + sh * 0.55f, new Color(255, 255, 255, 0)));
        g2d.fillRect((int) sx, (int) sy, (int) sw, (int) sh);

        // --- 2a) 顶部径向高光（原版 radial-gradient circle at 50% 0%，悬停/按下增强）---
        g2d.setPaint(new RadialGradientPaint(
                new Point2D.Float(sx + sw / 2f, sy + 1f), Math.max(sw, sh) * 0.85f,
                new float[]{0f, 1f},
                new Color[]{new Color(255, 255, 255, (int) (90 + 90 * hov)),
                            new Color(255, 255, 255, 0)}));
        g2d.fill(shape);

        // --- 2b) 135° 斜向扫光（原版 screen + overlay 两层高光合成后的效果）---
        g2d.setPaint(new LinearGradientPaint(
                new Point2D.Float(sx, sy), new Point2D.Float(sx + sw, sy + sh),
                new float[]{0f, 0.33f, 0.66f, 1f},
                new Color[]{new Color(255, 255, 255, 0), new Color(255, 255, 255, 40),
                            new Color(255, 255, 255, 112), new Color(255, 255, 255, 0)}));
        g2d.fill(shape);

        // --- 2c) 内圈 0.5px 白色亮边（原版 inset box-shadow 白线）---
        g2d.setColor(new Color(255, 255, 255, 200));
        g2d.setStroke(new BasicStroke(1f));
        g2d.draw(new RoundRectangle2D.Float(sx + 0.5f, sy + 0.5f, sw - 1f, sh - 1f,
                Math.max(0, arc - 1f), Math.max(0, arc - 1f)));
        g2d.setClip(oldClip);

        // --- 3) 外缘：白色高光主边 + 极淡深色发线（原版 0 0 0 0.5px inset 白边的外侧表现）---
        g2d.setColor(new Color(60, 66, 80, 40));
        g2d.setStroke(new BasicStroke(1f));
        g2d.draw(new RoundRectangle2D.Float(sx - 0.5f, sy - 0.5f, sw + 1f, sh + 1f, arc + 1f, arc + 1f));

        g2d.setColor(new Color(255, 255, 255, 170 + (int) (hov * 60)));
        g2d.setStroke(new BasicStroke(1.4f));
        g2d.draw(new RoundRectangle2D.Float(sx, sy, sw, sh, arc, arc));

        // --- 4) 文字（中心对齐 + 轻微提亮描边，保证透过玻璃仍清晰）---
        g2d.setFont(getFont());
        FontMetrics fm = g2d.getFontMetrics();
        int tx = Math.round(sx + (sw - fm.stringWidth(text)) / 2f);
        int ty = Math.round(sy + (sh - fm.getHeight()) / 2f) + fm.getAscent();
        g2d.setColor(new Color(0, 0, 0, 130));
        g2d.drawString(text, tx, ty + 2);
        g2d.setColor(new Color(0, 0, 0, 70));
        g2d.drawString(text, tx + 1, ty + 1);
        g2d.setColor(textColor);
        g2d.drawString(text, tx, ty);

        g2d.dispose();
    }

    private static int clamp(int v) {
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }
}
