package ui;

import org.cef.browser.CefBrowser;
import org.cef.handler.CefDisplayHandlerAdapter;
import utils.LangManager;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Base64;
import java.util.Properties;

/**
 * 主程序设置窗口（JCEF + 网页版设置面板）。
 *
 * 创建/关闭方式与便笺窗口（NotesModule）完全一致：
 * GlassFrame 无边框 + 共享 JCEF + DISPOSE_ON_CLOSE + windowClosing 同步 closeBrowser。
 */
public class SettingsFrame {

    private static final String SETTINGS_HTML = "settings/settings.html";

    private final JFrame frame;
    private GlassBrowserPanel browserPanel;
    private Timer bridgePollTimer;

    // 拖拽相关（窗口级，基于屏幕坐标）
    private Point dragStartScreen = null;      // 按下时的鼠标屏幕坐标
    private Point dragWindowOrigin = null;     // 按下时窗口的起始位置

    public interface HostActions {
        void applyLang(String lang);
        void applyThemeMode(int mode);
        void applyBgColor(String colorHex);
        void applyBgImage(File imageFile, String dataUrlPreview);
        void clearBgImage();
        void applyBgFit(int mode);
        void applyBgOpacity(float opacity);
        void applyIconTheme(int theme);
        void showIconThemeTest(int theme);
        void applyVolume(int volume);
        /** 后台线程读取当前系统真实音量（不会阻塞 EDT），结果通过回调返回 */
        void querySystemVolume(java.util.function.IntConsumer onReady);
        void applyGridShow(boolean show);
        void applyGlassWin(boolean enable);
        void applyTray(boolean enable);
        void applyAutoStart(boolean enable);
        boolean isAutoStartOn();
        void applyLiquidGlass(String payloadStr);
        void clearCache();
        void resetAllSettings();
        File pickBgImageByFileChooser(Component parent);
        String getSettingsSnapshotJson();
        void onCloseSettings(Point location);
        JFrame getMainFrame();
    }

    private final HostActions host;

    public SettingsFrame(HostActions host) {
        if (host == null) throw new IllegalArgumentException("SettingsFrame.HostActions 不能为空");
        this.host = host;

        // GlassFrame plain 模式：去掉毛玻璃与三色按钮，只保留可拖动/调整大小的框架，
        // 白色卡片（settings.html）铺满整个窗口作为唯一视觉主体
        frame = new GlassFrame(LangManager.getString("app.settings.title"), true);

        frame.setSize(860, 600);
        frame.setMinimumSize(new Dimension(480, 380));
        Point saved = _loadSettingsPos();
        if (saved.x == 0 && saved.y == 0) {
            frame.setLocationRelativeTo(host.getMainFrame());
        } else {
            frame.setLocation(saved);
        }
        frame.setLayout(new BorderLayout());

        // 与计算器等模块窗口完全一致：EDT 同步创建 local 模式浏览器面板并铺满窗口。
        // JCEF 内核已在主程序启动时预热（jcef-prewarm），同步创建也足够快；
        // local 模式让每个设置窗口用独立 CefClient，关闭时整体 dispose，杜绝"灰框残留"。
        browserPanel = new GlassBrowserPanel(SETTINGS_HTML, true);
        frame.add(browserPanel, BorderLayout.CENTER);

        // 和便笺完全一致：DISPOSE_ON_CLOSE + windowClosing 里同步关闭浏览器
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                if (browserPanel != null) {
                    final GlassBrowserPanel bp = browserPanel;
                    bp.triggerSaveBeforeClose();
                    // 保存等待 + 浏览器销毁放后台线程，避免在 EDT 上 sleep 造成关窗卡顿
                    new Thread(() -> {
                        try { Thread.sleep(200); } catch (InterruptedException ignored) {}
                        bp.closeBrowser();
                    }, "settings-close").start();
                }
                // 确保通知宿主窗口已关闭
                try { host.onCloseSettings(frame.getLocation()); } catch (Throwable ignore) {}
            }
        });

        frame.setVisible(true);
        frame.requestFocus();

        // JCEF 未就绪时浏览器会延后创建：布局刷新、JS flush 轮询、title 桥都需等创建完成后再执行
        browserPanel.onBrowserReady(() -> {
            browserPanel.forceLayoutRefresh();

            // 额外兜底：每 300ms 触发一次 JS 端 flush
            bridgePollTimer = new Timer(300, ev -> execJS(
                    "(function(){try{if(typeof window.__javaFlushBridge==='function')window.__javaFlushBridge();}" +
                            "catch(e){}})();"));
            bridgePollTimer.setRepeats(true);
            bridgePollTimer.start();

            // 浏览器已就绪：装 title 桥；等页面加载后装 JS flush + 发 snapshot
            installBridgeTitleBridge();
            new Timer(600, ev -> {
                installJsBridgeFlush();
                pushSnapshot();
                ((Timer) ev.getSource()).stop();
            }).start();

            // 异步读取系统真实音量并更新 slider（不阻塞 EDT）
            host.querySystemVolume(v -> SwingUtilities.invokeLater(() -> execJS(
                    "(function(){try{" +
                    "var el=document.getElementById('sVol');" +
                    "if(el){el.value="+v+";}" +
                    "var vv=document.getElementById('sVolVal');" +
                    "if(vv){vv.textContent='"+v+"';}" +
                    "}catch(e){}})();"
            )));
        });
        System.out.println("[SettingsFrame] 已启动（local 模式，与计算器等模块窗口一致）");
    }

    // ============================================================================
    // title 桥：browserPanel.getClient().addDisplayHandler 监听标题变化
    // ============================================================================

    private void installBridgeTitleBridge() {
        try {
            if (browserPanel == null) return;
            org.cef.CefClient client = browserPanel.getClient();
            if (client == null) return;

            client.addDisplayHandler(new CefDisplayHandlerAdapter() {
                @Override
                public void onTitleChange(CefBrowser browser, String title) {
                    if (title != null && title.startsWith("__BRIDGE__")) {
                        String payload = title.substring("__BRIDGE__".length());
                        try {
                            String json = new String(Base64.getDecoder().decode(payload), java.nio.charset.StandardCharsets.UTF_8);
                            notifyAllBridgeConsumers(json);
                        } catch (Throwable t) {
                            System.err.println("[Settings-title-bridge] decode 失败: " + t.getMessage());
                        }
                        try {
                            browser.executeJavaScript(
                                    "(function(){try{document.title='Winllx 设置';}catch(e){}})();",
                                    "restore-title", 0);
                        } catch (Throwable ignore) {}
                    }
                }
            });
        } catch (Throwable t) {
            System.err.println("[Settings-title-bridge] 安装 DisplayHandler 失败：" + t.getMessage());
        }
    }

    private static final java.util.List<SettingsFrame> _activeFrames =
            java.util.Collections.synchronizedList(new java.util.ArrayList<>());

    {
        _activeFrames.add(this);
    }

    private static void notifyAllBridgeConsumers(String jsonArr) {
        synchronized (_activeFrames) {
            for (SettingsFrame sf : _activeFrames) {
                try { sf._consumeJsonEvents(jsonArr); } catch (Throwable ignore) {}
            }
        }
    }

    // ============================================================================
    // 事件消费 / 注入 JS 桥 flush
    // ============================================================================
    private void installJsBridgeFlush() {
        String install =
                "(function(){" +
                        "if(window.__javaBridgeFlushInstalled)return;" +
                        "window.__javaBridgeFlushInstalled=true;" +
                        "var orig=window.__pushBridge;window.__pushBridge=function(a,p){" +
                        "  if(orig)try{orig(a,p);}catch(e){};" +
                        "  window.__javaFlushBridge();" +
                        "};" +
                        "window.__javaFlushBridge=function(){" +
                        "  var k='__appBridgeQueue';var a=window[k]||[];if(!a.length)return;" +
                        "  window[k]=[];" +
                        "  try{" +
                        "    var s=JSON.stringify(a);" +
                        "    var b=(typeof btoa==='function')?btoa(unescape(encodeURIComponent(s))):'';" +
                        "    if(b)document.title='__BRIDGE__'+b;" +
                        "  }catch(e){}" +
                        "};" +
                        "window.__pullSnapshotFromJava=function(){" +
                        "  try{window.__needSnapshotNow=true;document.title='__BRIDGE__'+btoa(unescape(encodeURIComponent(" +
                        "  JSON.stringify([{action:'__needSnapshot',payload:{}}]))));}catch(e){}" +
                        "};" +
                        "window.__pickBgImageInJava=function(cb){" +
                        "  try{window.__pickBgCb=cb;document.title='__BRIDGE__'+btoa(unescape(encodeURIComponent(" +
                        "  JSON.stringify([{action:'__needPickBg',payload:{}}]))));}catch(e){if(cb)cb({});}" +
                        "};" +
                        // ===== 窗口拖拽桥（基于屏幕绝对坐标，Java 端记录起点算增量） =====
                        "window.__javaStartDrag=function(sx,sy){try{document.title='__BRIDGE__'+btoa(unescape(encodeURIComponent(JSON.stringify([{action:'__startDrag',payload:{sx:sx,sy:sy}}]))));}catch(e){}};" +
                        "window.__javaDoDrag=function(sx,sy){try{document.title='__BRIDGE__'+btoa(unescape(encodeURIComponent(JSON.stringify([{action:'__doDrag',payload:{sx:sx,sy:sy}}]))));}catch(e){}};" +
                        "window.__javaStopDrag=function(){try{document.title='__BRIDGE__'+btoa(unescape(encodeURIComponent(JSON.stringify([{action:'__stopDrag',payload:{}}]))));}catch(e){}};" +
                        // ===========================
                        "})();";
        execJS(install);
    }

    private void _consumeJsonEvents(String jsonArrText) {
        if (jsonArrText == null || jsonArrText.isEmpty()) return;
        try {
            java.util.List<int[]> ranges = _splitJsonArray(jsonArrText);
            for (int[] r : ranges) {
                String obj = jsonArrText.substring(r[0], r[1]);
                String action = _jsonStr(obj, "action");
                String payloadStr = _jsonSub(obj, "payload");
                if (action == null) continue;
                if (action.startsWith("__need")) {
                    if ("__needSnapshot".equals(action)) {
                        SwingUtilities.invokeLater(this::pushSnapshot);
                    } else if ("__needPickBg".equals(action)) {
                        SwingUtilities.invokeLater(() -> {
                            File f = host.pickBgImageByFileChooser(frame);
                            String resp = buildImagePickResponse(f);
                            String lit = toJsString(resp);
                            execJS("(function(){try{var j=JSON.parse(" + lit + ");" +
                                    "if(window.__pickBgCb){var cb=window.__pickBgCb;window.__pickBgCb=null;cb(j);}" +
                                    "if(window.__applyBgPickFromJava)window.__applyBgPickFromJava(j);" +
                                    "}catch(e){console.warn(e);}})();");
                        });
                    }
                    continue;
                }
                // ===== 处理窗口拖拽事件（屏幕绝对坐标） =====
                if ("__startDrag".equals(action)) {
                    final String fps = payloadStr;
                    SwingUtilities.invokeLater(() -> {
                        int sx = 0, sy = 0;
                        try {
                            sx = Integer.parseInt(_jsonStr(fps, "sx"));
                            sy = Integer.parseInt(_jsonStr(fps, "sy"));
                        } catch (Exception ignore) {}
                        dragStartScreen = new java.awt.Point(sx, sy);
                        dragWindowOrigin = frame != null ? frame.getLocation() : new Point(0, 0);
                    });
                    continue;
                }
                if ("__doDrag".equals(action)) {
                    final String fps = payloadStr;
                    SwingUtilities.invokeLater(() -> {
                        int sx = 0, sy = 0;
                        try {
                            sx = Integer.parseInt(_jsonStr(fps, "sx"));
                            sy = Integer.parseInt(_jsonStr(fps, "sy"));
                        } catch (Exception ignore) {}
                        if (dragStartScreen != null && dragWindowOrigin != null && frame != null) {
                            int nx = dragWindowOrigin.x + (sx - dragStartScreen.x);
                            int ny = dragWindowOrigin.y + (sy - dragStartScreen.y);
                            frame.setLocation(nx, ny);
                        }
                    });
                    continue;
                }
                if ("__stopDrag".equals(action)) {
                    dragStartScreen = null;
                    dragWindowOrigin = null;
                    continue;
                }
                // =================================
                final String fa = action, fp = payloadStr;
                SwingUtilities.invokeLater(() -> handleBridgeEvent(fa, fp));
            }
        } catch (Throwable t) {
            System.err.println("[Settings] consume 事件失败: " + t.getMessage());
        }
    }

    private static java.util.List<int[]> _splitJsonArray(String arrText) {
        java.util.List<int[]> out = new java.util.ArrayList<>();
        if (arrText == null) return out;
        String t = arrText.trim();
        if (t.isEmpty()) return out;
        if (t.charAt(0) != '[') {
            out.add(new int[]{0, t.length()});
            return out;
        }
        int i = 1, depth = 0, start = -1;
        boolean inStr = false; char q = 0; boolean esc = false;
        while (i < t.length() - 1) {
            char c = t.charAt(i);
            if (inStr) {
                if (esc) esc = false;
                else if (c == '\\') esc = true;
                else if (c == q) inStr = false;
            } else {
                if (c == '"' || c == '\'') { inStr = true; q = c; }
                else if (c == '{' || c == '[') {
                    if (depth == 0 && c == '{') start = i;
                    depth++;
                } else if (c == '}' || c == ']') {
                    depth--;
                    if (depth == 0 && c == '}' && start >= 0) {
                        out.add(new int[]{start, i + 1});
                        start = -1;
                    }
                }
            }
            i++;
        }
        return out;
    }

    // ============================================================================
    // 事件处理（payloadStr = "{...}"）
    // ============================================================================
    private void handleBridgeEvent(String action, String payloadStr) {
        if (action == null) return;
        String valStr = _jsonStr(payloadStr, "value");
        String modeStr = _jsonStr(payloadStr, "mode");
        switch (action) {
            case "pageReady": {
                new Timer(120, ev -> { pushSnapshot(); ((Timer) ev.getSource()).stop(); }).start();
                return;
            }
            case "closeWindow":
                // 和便笺一样：直接 dispose，由 windowClosing 处理浏览器关闭
                SwingUtilities.invokeLater(() -> {
                    if (bridgePollTimer != null) bridgePollTimer.stop();
                    try { host.onCloseSettings(frame.getLocation()); } catch (Throwable ignore) {}
                    frame.dispose();
                });
                return;
            case "setLang":
                host.applyLang(valStr == null ? "zh" : valStr);
                return;
            case "setTheme": {
                int mode = 0;
                try { mode = Integer.parseInt(modeStr == null ? "0" : modeStr); } catch (Exception ignore) {}
                host.applyThemeMode(mode);
                new Timer(60, ev -> { pushSnapshot(); ((Timer) ev.getSource()).stop(); }).start();
                return;
            }
            case "setBgColor":
                host.applyBgColor(valStr == null ? "#FFFFFF" : valStr);
                return;
            case "pickBgImage": {
                File f = host.pickBgImageByFileChooser(frame);
                if (f != null) {
                    String resp = buildImagePickResponse(f);
                    execJS("(function(){try{var j=JSON.parse(" + toJsString(resp) + ");" +
                            "if(window.__applyBgPickFromJava)window.__applyBgPickFromJava(j);" +
                            "}catch(e){console.warn(e);}})();");
                }
                return;
            }
            case "setBgImageData":
                System.out.println("[Settings-Bridge] JS 已预览背景图: " + _jsonStr(payloadStr, "name"));
                return;
            case "clearBgImage":
                host.clearBgImage();
                new Timer(50, ev -> { pushSnapshot(); ((Timer) ev.getSource()).stop(); }).start();
                return;
            case "setBgFit": {
                int m = 0;
                try { m = Integer.parseInt(valStr == null ? "0" : valStr); } catch (Exception ignore) {}
                host.applyBgFit(m);
                return;
            }
            case "setBgOpacity": {
                float op = 1.0f;
                try { op = Float.parseFloat(valStr == null ? "1" : valStr); } catch (Exception ignore) {}
                host.applyBgOpacity(op);
                return;
            }
            case "setIconTheme": {
                int t = 0;
                try { t = Integer.parseInt(valStr == null ? "0" : valStr); } catch (Exception ignore) {}
                host.applyIconTheme(t);
                new Timer(50, ev -> { pushSnapshot(); ((Timer) ev.getSource()).stop(); }).start();
                return;
            }
            case "testIconTheme": {
                int t = 0;
                try { t = Integer.parseInt(valStr == null ? "0" : valStr); } catch (Exception ignore) {}
                host.showIconThemeTest(t);
                return;
            }
            case "setVolume": {
                int v = 50;
                try { v = Integer.parseInt(valStr == null ? "50" : valStr); } catch (Exception ignore) {}
                host.applyVolume(v);
                return;
            }
            case "setGrid": {
                boolean on = "true".equalsIgnoreCase(_jsonStr(payloadStr, "show"));
                host.applyGridShow(on);
                return;
            }
            case "setGlassWin": {
                boolean on = "true".equalsIgnoreCase(_jsonStr(payloadStr, "enable"));
                host.applyGlassWin(on);
                return;
            }
            case "setTray": {
                boolean on = "true".equalsIgnoreCase(_jsonStr(payloadStr, "enable"));
                host.applyTray(on);
                return;
            }
            case "setAutoStart": {
                boolean on = "true".equalsIgnoreCase(_jsonStr(payloadStr, "enable"));
                host.applyAutoStart(on);
                return;
            }
            case "setLiquidGlass":
                host.applyLiquidGlass(payloadStr);
                return;
            case "clearCache":
                host.clearCache();
                return;
            case "resetAll":
                host.resetAllSettings();
                new Timer(80, ev -> { pushSnapshot(); ((Timer) ev.getSource()).stop(); }).start();
                return;
            default:
                System.out.println("[Settings-Bridge] 未处理 action: " + action);
        }
    }

    // ============================================================================
    // Snapshot 注入 / 工具
    // ============================================================================
    private void pushSnapshot() {
        String snap = host.getSettingsSnapshotJson();
        if (snap == null) snap = "{}";
        execJS("(function(){try{" +
                "if(typeof window.__applySnapshot==='function')window.__applySnapshot(" + toJsString(snap) + ");" +
                "else if(typeof window.__applyFromJava==='function')window.__applyFromJava(JSON.parse(" + toJsString(snap) + "));" +
                "}catch(e){console.warn('snapshot fail',e);}})();");
    }

    private void execJS(String js) {
        if (browserPanel != null) browserPanel.executeJavaScript(js);
    }

    private static Point _loadSettingsPos() {
        try {
            File f = new File(System.getProperty("user.dir") + "/Winllx/app_settings.properties");
            if (f.exists()) {
                Properties p = new Properties();
                p.load(new java.io.FileInputStream(f));
                String x = p.getProperty("settingsX");
                String y = p.getProperty("settingsY");
                if (x != null && y != null) return new Point(Integer.parseInt(x), Integer.parseInt(y));
            }
        } catch (Exception ignore) {}
        return new Point(0, 0);
    }

    private String buildImagePickResponse(File f) {
        String path = "", name = "", preview = "";
        if (f != null) {
            path = f.getAbsolutePath();
            name = f.getName();
            try {
                BufferedImage img = ImageIO.read(f);
                if (img != null) {
                    int maxW = 600;
                    int w = img.getWidth(), h = img.getHeight();
                    if (w > maxW) {
                        int nh = (int) Math.round(h * (maxW * 1.0 / w));
                        Image scaled = img.getScaledInstance(maxW, nh, Image.SCALE_SMOOTH);
                        BufferedImage b2 = new BufferedImage(maxW, nh, BufferedImage.TYPE_INT_RGB);
                        Graphics2D g = b2.createGraphics();
                        g.drawImage(scaled, 0, 0, null);
                        g.dispose();
                        img = b2;
                    }
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    ImageIO.write(img, "jpg", bos);
                    preview = "data:image/jpeg;base64," + Base64.getEncoder().encodeToString(bos.toByteArray());
                }
            } catch (Throwable t) { preview = ""; }
            host.applyBgImage(f, preview);
            SwingUtilities.invokeLater(this::pushSnapshot);
        }
        return "{\"path\":" + toJsonStr(path) + ",\"name\":" + toJsonStr(name) +
                ",\"preview\":" + toJsonStr(preview) + "}";
    }

    private static String toJsString(String s) {
        if (s == null) return "''";
        StringBuilder sb = new StringBuilder(s.length() + 16);
        sb.append('\'');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '\'': sb.append("\\'"); break;
                case '\r': sb.append("\\r"); break;
                case '\n': sb.append("\\n"); break;
                case '\t': sb.append("\\t"); break;
                case '"':  sb.append("\\\""); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\x%02X", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('\'');
        return sb.toString();
    }

    private static String toJsonStr(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder(s.length() + 16);
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '"':  sb.append("\\\""); break;
                case '\r': sb.append("\\r"); break;
                case '\n': sb.append("\\n"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04X", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('"');
        return sb.toString();
    }

    private static String _jsonStr(String json, String key) {
        if (json == null || json.isEmpty()) return null;
        String pat = "\"" + key + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(pat).matcher(json);
        if (m.find()) return _unescape(m.group(1));
        String pat2 = "\"" + key + "\"\\s*:\\s*(true|false|null|-?\\d+(?:\\.\\d+)?)";
        java.util.regex.Matcher m2 = java.util.regex.Pattern.compile(pat2).matcher(json);
        return m2.find() ? m2.group(1) : null;
    }

    private static String _unescape(String s) {
        if (s == null) return null;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                switch (n) {
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case '/': sb.append('/'); break;
                    case 'u':
                        if (i + 4 < s.length()) {
                            try { sb.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16)); i += 4; }
                            catch (Exception ignore) { sb.append("\\u"); }
                        } else sb.append("\\u");
                        break;
                    default: sb.append(n);
                }
            } else sb.append(c);
        }
        return sb.toString();
    }

    private static String _jsonSub(String json, String key) {
        if (json == null || json.isEmpty()) return "{}";
        String pat = "\"" + key + "\"\\s*:";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(pat).matcher(json);
        if (!m.find()) return "{}";
        int start = m.end();
        while (start < json.length() && Character.isWhitespace(json.charAt(start))) start++;
        if (start >= json.length()) return "{}";
        char fc = json.charAt(start);
        if (fc == '{' || fc == '[') {
            int depth = 1; int i = start + 1;
            boolean inStr = false; char q = 0; boolean esc = false;
            while (i < json.length() && depth > 0) {
                char c = json.charAt(i);
                if (inStr) {
                    if (esc) esc = false;
                    else if (c == '\\') esc = true;
                    else if (c == q) inStr = false;
                } else {
                    if (c == '"' || c == '\'') { inStr = true; q = c; }
                    else if (c == '{' || c == '[') depth++;
                    else if (c == '}' || c == ']') depth--;
                }
                i++;
            }
            return json.substring(start, i);
        } else {
            int i = start;
            while (i < json.length() && json.charAt(i) != ',' && json.charAt(i) != '}') i++;
            return json.substring(start, i);
        }
    }
}
