package modules;

import ui.GlassBrowserPanel;
import ui.GlassFrame;
import utils.LangManager;

import javax.swing.*;
import java.awt.*;

/**
 * 日历模块（JCEF + 网页版液态玻璃）。
 *
 * 加载 web/calendar/calendar.html：月视图、前后翻月、回到今天，
 * 点击某天可添加/编辑/删除事件，数据由页面自身通过 localStorage 持久化。
 */
public class CalendarModule {

    private static final String REL = "calendar/calendar.html";

    private JFrame frame;
    private GlassBrowserPanel browserPanel;

    public CalendarModule() {
        frame = new GlassFrame(LangManager.getString("module.calendar"));
        frame.setSize(760, 720);
        frame.setMinimumSize(new Dimension(520, 480));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        browserPanel = new GlassBrowserPanel(REL, true);
        frame.add(browserPanel, BorderLayout.CENTER);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                if (browserPanel != null) browserPanel.closeBrowser();
            }
        });
        frame.setVisible(true);
        System.out.println("[WinllxCalendar] 日历窗口已启动 (JCEF + calendar.html)");
    }

    public GlassBrowserPanel getBrowserPanel() {
        return browserPanel;
    }
}
