package ui;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Windows 系统主音量控制。
 *
 * 实现方式：调用随程序发布的 lib/volctl.exe（C#/.NET Framework 4.x，Core Audio IAudioEndpointVolume COM）。
 * 为什么不直接在 Java 里调 Core Audio：
 *   1. JNA 手动 vtable 偏移极其脆弱，IAudioEndpointVolume 有个容易漏掉的 GetMasterVolumeLevel slot；
 *   2. PowerShell + Add-Type 的 COM 接口在某些线程模型下 CoInitialize 会返回 S_FALSE 导致后续调用 COE_NOTINITIALIZED；
 *   3. C# + [ComImport] + Activator.CreateInstance(Type.GetTypeFromCLSID(...)) 是 .NET 生态里 Core Audio 的标准做法。
 *
 * 与 volctl.exe 的协议（纯文本 stdout）：
 *   VOL::<0-100> / MUTED::<0-100>  —— 当前音量（MUTED 表示处于静音）
 *   SET_OK / MUTE_OK / UNMUTE_OK   —— 操作成功
 *   ERR::<message>                 —— 操作失败
 *
 * 设计要点：
 *   - 读（get）走调用线程（调用方本就是后台线程），阻塞 <200ms；
 *   - 写（set）提交到后台单线程执行器并做 80ms 去抖，避免拖动滑条时每个事件同步 spawn .NET 进程阻塞 JCEF bridge 线程。
 */
public final class SystemVolumeControl {

    private static final String EXE_RELATIVE = "lib" + File.separator + "volctl.exe";

    private static volatile boolean initialized = false;
    private static volatile boolean available = false;
    private static volatile String lastError = null;

    /** 写操作执行器（单线程、守护，保证 set 串行且不阻塞调用线程）。 */
    private static final ScheduledExecutorService WRITER = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "volctl-writer");
        t.setDaemon(true);
        return t;
    });

    /** 去抖：只把最新值写下去，避免拖动过程中的中间值疯狂 spawn 进程。 */
    private static final long DEBOUNCE_MS = 80;
    private static final Object WRITE_LOCK = new Object();
    private static volatile int pendingVolume = -1;
    private static ScheduledFuture<?> pendingTask = null;

    private static volatile File resolvedExe = null;

    private SystemVolumeControl() {}

    /** 初始化（验证 volctl.exe 可执行）。幂等。后台线程调用。 */
    public static void init() {
        if (initialized) return;
        synchronized (SystemVolumeControl.class) {
            if (initialized) return;
            try {
                String result = invoke("get");
                available = result != null && (result.startsWith("VOL::") || result.startsWith("MUTED::"));
                if (available) {
                    lastError = null;
                    // 启动时若处于静音，主动解除静音，避免"拖滑条没声音"被误判为功能失效
                    if (result.startsWith("MUTED::")) {
                        try { invoke("unmute"); } catch (Throwable ignore) {}
                    }
                } else {
                    lastError = result == null ? "volctl.exe 不可执行" : result;
                }
            } catch (Throwable t) {
                lastError = t.getMessage();
                available = false;
            }
            initialized = true;
            System.out.println("[SystemVolumeControl] init=" + available + (lastError != null ? " err=" + lastError : "")
                    + " exe=" + (resolvedExe != null ? resolvedExe.getAbsolutePath() : "null"));
        }
    }

    /** 读系统主音量 0~100。不可用时返回 50。 */
    public static int getVolume() {
        try {
            String result = invoke("get");
            if (result == null) return 50;
            if (result.startsWith("VOL::")) {
                return Integer.parseInt(result.substring(5));
            }
            if (result.startsWith("MUTED::")) {
                return Integer.parseInt(result.substring(7));
            }
            return 50;
        } catch (Throwable t) {
            return 50;
        }
    }

    /** 写系统主音量 0~100。异步 + 去抖：调用立即返回，真正的 volctl.exe 在后台执行。 */
    public static void setVolume(int pct) {
        final int v = Math.max(0, Math.min(100, pct));
        pendingVolume = v;
        synchronized (WRITE_LOCK) {
            if (pendingTask != null && !pendingTask.isDone()) {
                pendingTask.cancel(false);
            }
            pendingTask = WRITER.schedule(() -> {
                int target = pendingVolume;
                try {
                    invoke("set", String.valueOf(target));
                } catch (Throwable t) {
                    System.err.println("[SystemVolumeControl] setVolume 异常: " + t.getMessage());
                }
            }, DEBOUNCE_MS, TimeUnit.MILLISECONDS);
        }
    }

    public static boolean isAvailable() { return available; }
    public static String getLastError() { return lastError; }

    // ==================== 内部工具 ====================

    /** 多候选目录查找 volctl.exe：user.dir、其父目录、运行代码所在位置（classes/jar 所在目录及其上层）。 */
    private static File resolveExe() {
        File cached = resolvedExe;
        if (cached != null && cached.exists()) return cached;

        Set<File> bases = new LinkedHashSet<>();
        String userDir = System.getProperty("user.dir");
        if (userDir != null) {
            File ud = new File(userDir).getAbsoluteFile();
            bases.add(ud);
            if (ud.getParentFile() != null) bases.add(ud.getParentFile());
        }
        // 运行时代码位置：build/classes/java/main（目录）或 classes.jar（文件）
        try {
            java.security.CodeSource cs = SystemVolumeControl.class.getProtectionDomain().getCodeSource();
            if (cs != null && cs.getLocation() != null) {
                File code = new File(cs.getLocation().toURI()).getAbsoluteFile();
                File dir = code.isDirectory() ? code : code.getParentFile();
                // 从代码位置向上回溯 5 层，覆盖 build/classes/java/main → 项目根
                for (int i = 0; i < 5 && dir != null; i++) {
                    bases.add(dir);
                    dir = dir.getParentFile();
                }
            }
        } catch (Throwable ignore) {}

        for (File base : bases) {
            File exe = new File(base, EXE_RELATIVE);
            if (exe.isFile()) {
                resolvedExe = exe;
                return exe;
            }
        }
        return null;
    }

    private static String invoke(String... args) throws Exception {
        File exe = resolveExe();
        if (exe == null) {
            throw new IllegalStateException("volctl.exe 未找到（相对路径 " + EXE_RELATIVE + "，已尝试 user.dir 及运行目录）");
        }

        java.util.List<String> cmd = new java.util.ArrayList<>();
        cmd.add(exe.getAbsolutePath());
        for (String a : args) cmd.add(a);

        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(false);
        Process p = pb.start();
        p.getOutputStream().close();  // 无 stdin 输入，立即关闭避免子进程等待

        StringBuilder out = new StringBuilder();
        StringBuilder err = new StringBuilder();
        Thread errReader = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getErrorStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) err.append(line);
            } catch (Throwable ignore) {}
        }, "volctl-stderr");
        errReader.setDaemon(true);
        errReader.start();

        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) out.append(line);
        }

        boolean done = p.waitFor(3, TimeUnit.SECONDS);
        if (!done) { p.destroyForcibly(); throw new IllegalStateException("volctl.exe 超时"); }
        errReader.join(200);

        String stdout = out.toString();
        String stderr = err.toString();

        if (p.exitValue() != 0) {
            String msg = stderr.isEmpty() ? stdout : stderr;
            if (msg.startsWith("ERR::")) return msg;
            throw new IllegalStateException("volctl.exe exit=" + p.exitValue() + " msg=" + msg);
        }
        return stdout;
    }
}
