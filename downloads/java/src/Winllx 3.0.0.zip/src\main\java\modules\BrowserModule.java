package modules;

import org.cef.CefClient;
import org.cef.browser.CefBrowser;
import org.cef.browser.CefFrame;
import org.cef.handler.CefDisplayHandlerAdapter;
import org.cef.handler.CefLoadHandlerAdapter;
import ui.BrowserSettingsFrame;
import ui.GlassBrowserPanel;
import ui.GlassFrame;
import utils.BrowserPrefs;
import utils.LangManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * 浏览器模块（JCEF / Chromium 内核）。
 *
 *  - 顶部 Edge 式多标签：可新建 / 切换 / 关闭标签，标签标题跟随网页标题；
 *  - 工具栏：后退 / 前进 / 刷新 / 主页 + 地址栏 + 前往 + 设置；
 *  - 地址栏支持直接输入网址（自动补全 https://）或关键词（走所选搜索引擎）；
 *  - 设置内容由 ui.BrowserSettingsFrame 承载，参数持久化在 utils.BrowserPrefs。
 */
public class BrowserModule {

    /** 看起来像域名的输入（如 www.example.com / example.com/path） */
    private static final Pattern DOMAIN = Pattern.compile("^[\\w-]+(\\.[\\w-]+)+(:\\d+)?(/.*)?$");
    private static final String BLANK = "about:blank";

    private JFrame frame;
    private JPanel content;
    private JPanel tabStrip;
    private JButton plusBtn;
    private JTextField addressBar;
    private NavButton backBtn;
    private NavButton forwardBtn;

    private final List<Tab> tabs = new ArrayList<>();
    private int activeIndex = -1;

    /** 单个标签：一个独立 CefClient 的浏览器面板 + 顶部标签头 */
    private static class Tab {
        GlassBrowserPanel panel;
        TabHeader header;
        boolean canBack;
        boolean canForward;
    }

    public BrowserModule() {
        GlassBrowserPanel.setDownloadDir(BrowserPrefs.getDownloadDir());

        frame = new GlassFrame(LangManager.getString("module.browser"));
        frame.setSize(1180, 780);
        frame.setMinimumSize(new Dimension(760, 520));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(createTabStrip(), BorderLayout.NORTH);
        top.add(createToolbar(), BorderLayout.SOUTH);
        frame.add(top, BorderLayout.NORTH);

        content = new JPanel(new BorderLayout());
        content.setOpaque(false);
        frame.add(content, BorderLayout.CENTER);

        // 启动标签：恢复上次会话，否则打开主页
        List<String> start = new ArrayList<>();
        if (BrowserPrefs.isRestoreSession()) {
            String s = BrowserPrefs.getSession();
            if (s != null) {
                for (String u : s.split("\\n")) if (!u.trim().isEmpty()) start.add(u.trim());
            }
        }
        if (start.isEmpty()) start.add(homeUrl());
        for (String u : start) newTab(u);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                saveSession();
                for (Tab t : new ArrayList<>(tabs)) {
                    try { t.panel.closeBrowser(); } catch (Throwable ignore) {}
                }
                tabs.clear();
            }
        });
        // 从设置窗口切回来时刷新标签栏外观（关闭按钮显隐等）
        frame.addWindowFocusListener(new WindowAdapter() {
            @Override
            public void windowGainedFocus(WindowEvent e) { refreshTabHeaders(); }
        });

        frame.setVisible(true);
        System.out.println("[Winllx] 浏览器窗口已启动 (JCEF, 多标签)");
    }

    // ========================================================================
    // 标签管理
    // ========================================================================

    private Tab newTab(String url) {
        Tab tab = new Tab();
        GlassBrowserPanel panel = new GlassBrowserPanel(url, true);
        tab.panel = panel;
        // JCEF 未就绪时浏览器会延后创建：下载、弹窗拦截、加载监听都需等创建完成后再注册
        panel.onBrowserReady(() -> {
            panel.enableDownloads();
            // 网页里 target=_blank / window.open 打开的新页面，改为在顶部新建标签，而不是弹窗
            panel.setPopupHandler(this::newTab);
            installTabHandlers(tab);
        });

        tab.header = new TabHeader(tab);
        tab.header.setTitle(displayName(url));
        tabs.add(tab);
        tabStrip.add(tab.header);

        tabStrip.revalidate();
        activateTab(tabs.size() - 1);
        return tab;
    }

    private void activateTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        activeIndex = index;
        Tab tab = tabs.get(index);

        content.removeAll();
        content.add(tab.panel, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
        SwingUtilities.invokeLater(tab.panel::forceLayoutRefresh);

        for (Tab t : tabs) t.header.setActive(t == tab);
        updateAddressBar(urlOf(tab.panel.getBrowser()));
        updateNavButtons();
        tabStrip.repaint();
        tab.panel.setBrowserFocus(true);
    }

    private void closeTab(Tab tab) {
        int idx = tabs.indexOf(tab);
        if (idx < 0) return;
        boolean wasActive = (idx == activeIndex);

        content.remove(tab.panel);
        tabStrip.remove(tab.header);
        tabs.remove(idx);
        try { tab.panel.closeBrowser(); } catch (Throwable ignore) {}
        tabStrip.revalidate();
        tabStrip.repaint();

        if (tabs.isEmpty()) {   // 最后一个标签关闭 → 关窗（与 Edge 一致）
            frame.dispose();
            return;
        }
        int next;
        if (wasActive) next = Math.min(idx, tabs.size() - 1);
        else if (idx < activeIndex) next = activeIndex - 1;
        else next = activeIndex;
        activateTab(Math.max(0, Math.min(next, tabs.size() - 1)));
    }

    private Tab activeTab() {
        return (activeIndex >= 0 && activeIndex < tabs.size()) ? tabs.get(activeIndex) : null;
    }

    private boolean isActive(Tab t) {
        return t == activeTab();
    }

    private void saveSession() {
        StringBuilder sb = new StringBuilder();
        for (Tab t : tabs) {
            String u = urlOf(t.panel.getBrowser());
            if (u == null || u.isEmpty() || u.startsWith("about:")) continue;
            if (sb.length() > 0) sb.append('\n');
            sb.append(u);
        }
        BrowserPrefs.setSession(sb.toString());
    }

    private void refreshTabHeaders() {
        boolean show = BrowserPrefs.isShowCloseButton();
        for (Tab t : tabs) t.header.refreshCloseVisible(show);
        tabStrip.revalidate();
        tabStrip.repaint();
    }

    /** 监听单个标签的加载状态 / 网页标题，驱动标签标题与导航按钮 */
    private void installTabHandlers(Tab tab) {
        try {
            CefClient client = tab.panel.getClient();
            if (client == null) return;
            final CefBrowser me = tab.panel.getBrowser();

            client.addLoadHandler(new CefLoadHandlerAdapter() {
                @Override
                public void onLoadingStateChange(CefBrowser b, boolean isLoading, boolean canBack, boolean canForward) {
                    if (b != me) return;
                    SwingUtilities.invokeLater(() -> {
                        tab.canBack = canBack;
                        tab.canForward = canForward;
                        if (isActive(tab)) {
                            updateNavButtons();
                            if (!isLoading) updateAddressBar(urlOf(b));
                        }
                    });
                }

                @Override
                public void onLoadEnd(CefBrowser b, CefFrame f, int rc) {
                    if (b != me || f == null || !f.isMain()) return;
                    final String u = f.getURL();
                    SwingUtilities.invokeLater(() -> {
                        tab.header.setTitle(displayName(u));
                        if (isActive(tab)) updateAddressBar(u);
                    });
                }
            });

            client.addDisplayHandler(new CefDisplayHandlerAdapter() {
                @Override
                public void onTitleChange(CefBrowser b, String title) {
                    if (b != me || title == null || title.startsWith("__BRIDGE__")) return;
                    final String s = title.trim();
                    SwingUtilities.invokeLater(() ->
                            tab.header.setTitle(s.isEmpty() ? displayName(urlOf(b)) : s));
                }
            });
        } catch (Throwable t) {
            System.err.println("[Browser] 标签监听安装失败: " + t.getMessage());
        }
    }

    // ========================================================================
    // 顶部标签栏
    // ========================================================================

    private JPanel createTabStrip() {
        tabStrip = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(255, 255, 255, 22));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(0, 0, 0, 26));
                g2.drawLine(0, getHeight() - 1, getWidth(), getHeight() - 1);
                g2.dispose();
            }
        };
        tabStrip.setOpaque(false);
        tabStrip.setPreferredSize(new Dimension(0, 36));
        tabStrip.setLayout(new TabStripLayout());

        plusBtn = new JButton() {
            private boolean hov;
            {
                setContentAreaFilled(false);
                setBorderPainted(false);
                setFocusPainted(false);
                setOpaque(false);
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                setToolTipText(LangManager.getString("browser.newtab"));
                addMouseListener(new MouseAdapter() {
                    @Override public void mouseEntered(MouseEvent e) { hov = true; repaint(); }
                    @Override public void mouseExited(MouseEvent e) { hov = false; repaint(); }
                });
            }
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2;
                if (hov) { g2.setColor(new Color(255, 255, 255, 110)); g2.fillOval(cx - 11, cy - 11, 22, 22); }
                g2.setColor(new Color(70, 70, 70));
                g2.setStroke(new BasicStroke(1.7f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawLine(cx - 5, cy, cx + 5, cy);
                g2.drawLine(cx, cy - 5, cx, cy + 5);
                g2.dispose();
            }
        };
        plusBtn.addActionListener(e -> newTab(newTabUrl()));
        tabStrip.add(plusBtn);
        return tabStrip;
    }

    /** 标签栏布局：标签等分/收缩铺满，加号固定在最右 */
    private class TabStripLayout implements LayoutManager {
        @Override public void addLayoutComponent(String name, Component comp) {}
        @Override public void removeLayoutComponent(Component comp) {}
        @Override public Dimension preferredLayoutSize(Container parent) { return new Dimension(0, 36); }
        @Override public Dimension minimumLayoutSize(Container parent) { return new Dimension(0, 36); }

        @Override
        public void layoutContainer(Container parent) {
            int w = parent.getWidth(), h = parent.getHeight();
            int plusW = 38;
            int avail = Math.max(0, w - plusW - 6);
            int n = tabs.size();
            if (n > 0) {
                int[] ps = new int[n];
                int sum = 0;
                for (int i = 0; i < n; i++) {
                    ps[i] = tabs.get(i).header.getPreferredSize().width;
                    sum += ps[i];
                }
                boolean fit = sum <= avail;
                int per = fit ? 0 : Math.max(46, avail / n);
                int x = 0;
                for (int i = 0; i < n; i++) {
                    int tw = fit ? ps[i] : per;
                    tabs.get(i).header.setBounds(x, 0, tw, h);
                    x += tw;
                }
            }
            if (plusBtn != null) plusBtn.setBounds(w - plusW, 2, plusW - 6, h - 6);
        }
    }

    /** 单个标签头：圆角上凸、悬停高亮、可关闭 */
    private class TabHeader extends JPanel {
        private final Tab tab;
        private final JLabel titleLabel;
        private final JButton closeBtn;
        private boolean hover;
        private boolean active;

        TabHeader(Tab tab) {
            this.tab = tab;
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(3, 12, 0, 6));
            setLayout(new BorderLayout(6, 0));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            titleLabel = new JLabel("");
            titleLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
            titleLabel.setForeground(new Color(90, 90, 90));
            titleLabel.setOpaque(false);

            closeBtn = new JButton() {
                private boolean ch;
                {
                    setContentAreaFilled(false);
                    setBorderPainted(false);
                    setFocusPainted(false);
                    setOpaque(false);
                    setPreferredSize(new Dimension(16, 16));
                    setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                    addMouseListener(new MouseAdapter() {
                        @Override public void mouseEntered(MouseEvent e) { ch = true; repaint(); }
                        @Override public void mouseExited(MouseEvent e) { ch = false; repaint(); }
                    });
                }
                @Override
                protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    int w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2;
                    if (ch) { g2.setColor(new Color(0, 0, 0, 30)); g2.fillOval(0, 0, w, h); }
                    g2.setColor(new Color(95, 95, 95));
                    g2.setStroke(new BasicStroke(1.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    g2.drawLine(cx - 4, cy - 4, cx + 4, cy + 4);
                    g2.drawLine(cx - 4, cy + 4, cx + 4, cy - 4);
                    g2.dispose();
                }
            };
            closeBtn.addActionListener(e -> closeTab(tab));

            add(titleLabel, BorderLayout.CENTER);
            add(closeBtn, BorderLayout.EAST);
            closeBtn.setVisible(BrowserPrefs.isShowCloseButton());

            MouseAdapter act = new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
                @Override public void mousePressed(MouseEvent e) {
                    if (SwingUtilities.isLeftMouseButton(e)) activateTab(tabs.indexOf(tab));
                }
                @Override public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && BrowserPrefs.isCloseOnDblClick()) closeTab(tab);
                }
            };
            addMouseListener(act);
            titleLabel.addMouseListener(act);
        }

        void setTitle(String t) {
            titleLabel.setText(t == null ? "" : t);
            titleLabel.setToolTipText(t);
            revalidate();
            repaint();
        }

        void setActive(boolean a) {
            active = a;
            titleLabel.setForeground(a ? new Color(20, 20, 20) : new Color(95, 95, 95));
            repaint();
        }

        void refreshCloseVisible(boolean show) {
            closeBtn.setVisible(show);
            revalidate();
            repaint();
        }

        @Override
        public Dimension getPreferredSize() {
            FontMetrics fm = titleLabel.getFontMetrics(titleLabel.getFont());
            String s = titleLabel.getText() == null ? "" : titleLabel.getText();
            int tw = fm.stringWidth(s);
            return new Dimension(Math.max(112, Math.min(232, tw + 64)), 36);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            Color bg = active ? new Color(255, 255, 255, 228)
                     : hover ? new Color(255, 255, 255, 130)
                     : new Color(255, 255, 255, 45);
            g2.setColor(bg);
            g2.fillRoundRect(0, 0, w, h + 14, 11, 11);   // 底部超出的部分被标签栏裁掉 → 顶部圆角
            g2.dispose();
            super.paintComponent(g);
        }
    }

    // ========================================================================
    // 工具栏
    // ========================================================================

    private JPanel createToolbar() {
        JPanel bar = new JPanel(new BorderLayout(8, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255, 26));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(0, 0, 0, 30));
                g2.drawLine(0, getHeight() - 1, getWidth(), getHeight() - 1);
                g2.dispose();
            }
        };
        bar.setOpaque(false);
        bar.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));

        JPanel nav = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        nav.setOpaque(false);
        backBtn = new NavButton(Icon.BACK);
        forwardBtn = new NavButton(Icon.FORWARD);
        NavButton reloadBtn = new NavButton(Icon.RELOAD);
        NavButton homeBtn = new NavButton(Icon.HOME);

        backBtn.setToolTipText(LangManager.getString("browser.back"));
        forwardBtn.setToolTipText(LangManager.getString("browser.forward"));
        reloadBtn.setToolTipText(LangManager.getString("browser.reload"));
        homeBtn.setToolTipText(LangManager.getString("browser.home"));

        backBtn.setEnabled(false);
        forwardBtn.setEnabled(false);
        backBtn.refreshColor();
        forwardBtn.refreshColor();

        backBtn.addActionListener(e -> { Tab t = activeTab(); if (t != null) t.panel.goBack(); });
        forwardBtn.addActionListener(e -> { Tab t = activeTab(); if (t != null) t.panel.goForward(); });
        reloadBtn.addActionListener(e -> { Tab t = activeTab(); if (t != null) t.panel.reloadPage(); });
        homeBtn.addActionListener(e -> navigate(homeUrl()));

        nav.add(backBtn);
        nav.add(forwardBtn);
        nav.add(reloadBtn);
        nav.add(homeBtn);

        addressBar = new JTextField() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0, 0, 0, 26));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        addressBar.setOpaque(false);
        addressBar.setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 12));
        addressBar.setFont(new Font("Microsoft YaHei", Font.PLAIN, 13));
        addressBar.setForeground(new Color(40, 40, 40));
        addressBar.addActionListener(e -> navigate(addressBar.getText()));
        // 地址栏编辑时让 Chromium 原生窗口交出焦点，避免键盘输入被网页输入框抢走
        addressBar.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                addressBar.requestFocusInWindow();
                Tab t = activeTab();
                if (t != null) t.panel.setBrowserFocus(false);
            }
        });
        addressBar.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                Tab t = activeTab();
                if (t != null) t.panel.setBrowserFocus(false);
            }

            @Override
            public void focusLost(FocusEvent e) {
                Tab t = activeTab();
                if (t != null) t.panel.setBrowserFocus(true);
            }
        });

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        right.setOpaque(false);

        NavButton goBtn = new NavButton(Icon.GO);
        goBtn.setToolTipText(LangManager.getString("browser.go"));
        goBtn.addActionListener(e -> navigate(addressBar.getText()));

        NavButton settingsBtn = new NavButton(Icon.SETTINGS);
        settingsBtn.setToolTipText(LangManager.getString("browser.settings"));
        settingsBtn.addActionListener(e -> new BrowserSettingsFrame());

        right.add(goBtn);
        right.add(settingsBtn);

        bar.add(nav, BorderLayout.WEST);
        bar.add(addressBar, BorderLayout.CENTER);
        bar.add(right, BorderLayout.EAST);
        return bar;
    }

    // ========================================================================
    // 导航
    // ========================================================================

    private void navigate(String input) {
        String url = normalize(input);
        if (url == null) return;
        Tab t = activeTab();
        if (t == null) return;
        updateAddressBar(url);
        t.panel.loadUrl(url);
    }

    private static String homeUrl() {
        return BrowserPrefs.getHomeUrl();
    }

    private static String newTabUrl() {
        return "blank".equals(BrowserPrefs.getNewTabContent()) ? BLANK : homeUrl();
    }

    /** 地址归一化：补全协议；非网址则走所配置的搜索引擎 */
    private static String normalize(String input) {
        if (input == null) return null;
        String s = input.trim();
        if (s.isEmpty()) return null;
        if (s.matches("(?i)^(https?|file|about|data|chrome|blob|view-source):.*")) return s;
        if (DOMAIN.matcher(s).matches()) return "https://" + s;
        String prefix = BrowserPrefs.getSearchUrlPrefix();
        try {
            return prefix + URLEncoder.encode(s, StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            return prefix + s;
        }
    }

    private void updateAddressBar(String url) {
        if (addressBar == null || url == null || url.isEmpty()) return;
        if (url.startsWith("about:") || url.startsWith("data:")) return;
        addressBar.setText(url);
        addressBar.setCaretPosition(0);
    }

    private void updateNavButtons() {
        Tab t = activeTab();
        backBtn.setEnabled(t != null && t.canBack);
        forwardBtn.setEnabled(t != null && t.canForward);
        backBtn.refreshColor();
        forwardBtn.refreshColor();
    }

    private static String urlOf(CefBrowser b) {
        try { return b == null ? null : b.getURL(); } catch (Throwable t) { return null; }
    }

    private static String displayName(String url) {
        if (url == null || url.isEmpty() || url.startsWith("about:")) {
            return LangManager.getString("browser.newtab");
        }
        return url;
    }

    /** 工具栏图标类型（用矢量绘制，避免依赖字体里的 Unicode 符号字形） */
    private enum Icon { BACK, FORWARD, RELOAD, HOME, GO, SETTINGS }

    /** 圆形悬停高亮的小导航按钮，图标由 Graphics2D 绘制 */
    private static class NavButton extends JButton {
        private final Icon icon;
        private boolean hover;

        NavButton(Icon icon) {
            this.icon = icon;
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setPreferredSize(new Dimension(30, 30));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        void refreshColor() { repaint(); }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            int cx = w / 2;
            int cy = h / 2;
            if (hover && isEnabled()) {
                g2.setColor(new Color(255, 255, 255, 90));
                g2.fillOval(0, 0, w, h);
            }
            g2.setColor(isEnabled() ? new Color(60, 60, 60) : new Color(175, 175, 175));
            g2.setStroke(new BasicStroke(1.7f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            switch (icon) {
                case BACK -> g2.fillPolygon(new int[]{cx + 3, cx - 4, cx + 3},
                                            new int[]{cy - 5, cy, cy + 5}, 3);
                case FORWARD -> g2.fillPolygon(new int[]{cx - 3, cx + 4, cx - 3},
                                               new int[]{cy - 5, cy, cy + 5}, 3);
                case GO -> {
                    g2.drawLine(cx - 6, cy, cx + 4, cy);
                    g2.drawLine(cx + 1, cy - 4, cx + 5, cy);
                    g2.drawLine(cx + 1, cy + 4, cx + 5, cy);
                }
                case RELOAD -> {
                    int r = 6;
                    g2.drawArc(cx - r, cy - r, r * 2, r * 2, 55, 285);
                    g2.fillPolygon(new int[]{cx + 7, cx + 2, cx + 8},
                                   new int[]{cy - 6, cy - 4, cy - 1}, 3);
                }
                case HOME -> {
                    g2.drawLine(cx - 6, cy, cx, cy - 6);
                    g2.drawLine(cx, cy - 6, cx + 6, cy);
                    g2.drawLine(cx - 4, cy - 1, cx - 4, cy + 5);
                    g2.drawLine(cx + 4, cy - 1, cx + 4, cy + 5);
                    g2.drawLine(cx - 4, cy + 5, cx + 4, cy + 5);
                }
                case SETTINGS -> {
                    int r = 5;
                    g2.drawOval(cx - r, cy - r, r * 2, r * 2);
                    for (int i = 0; i < 8; i++) {
                        double a = Math.PI * 2 * i / 8;
                        int x1 = cx + (int) Math.round(Math.cos(a) * 6.6);
                        int y1 = cy + (int) Math.round(Math.sin(a) * 6.6);
                        int x2 = cx + (int) Math.round(Math.cos(a) * 8.4);
                        int y2 = cy + (int) Math.round(Math.sin(a) * 8.4);
                        g2.drawLine(x1, y1, x2, y2);
                    }
                }
            }
            g2.dispose();
        }
    }
}
