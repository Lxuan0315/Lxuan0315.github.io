package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * 可拖拽桌面按钮 —— 现在基于 LiquidButton 绘制（无黑边、无黑色投影，纯玻璃高光边）。
 *
 * 之前继承 GlassButton（Swing 手绘液态玻璃按钮，带多层黑色阴影 → 导致"黑边"），
 * 现改为继承 LiquidButton（32px 圆角玻璃面、135° 斜向扫光、白色高光描边 + 柔和外投影），
 * 视觉规格与「液态玻璃」应用（web/glass）里的演示按钮一致。
 */
public class DraggableButton extends LiquidButton {

    /** 流式布局模式下为 false：禁用拖拽后的网格吸附动画（因为位置由流式规则管理）。 */
    public static boolean gridSnapEnabled = true;

    private boolean isDragging = false;
    private boolean hasMoved = false;
    private int dragOffsetX;
    private int dragOffsetY;
    private int pressX, pressY;
    private GridLayoutManager gridManager;
    private Runnable onPositionChanged;
    private java.util.function.BiPredicate<Integer, Integer> onCollisionCheck;

    private int gridX = -1;              // 当前网格列索引
    private int gridY = -1;              // 当前网格行索引
    private Timer snapAnimTimer = null;  // 吸附动画 Timer

    // DraggableButton 内部用的"被拖动过"标记（原本继承自 GlassButton.wasDragMoved，现在自己存）
    protected boolean wasDragMoved = false;

    private static final int DRAG_THRESHOLD = 5;
    private long lastDragTime = 0;
    private int lastDragX = -1;
    private int lastDragY = -1;
    private static final long DRAG_THROTTLE_MS = 16;
    private static final int DRAG_THROTTLE_PX = 5;

    public DraggableButton(String text, int width, int height) {
        super(text);
        // LiquidButton 组件尺寸 == 视觉尺寸，直接按传入 size 画
        Dimension d = new Dimension(width, height);
        setPreferredSize(d);
        setSize(d);
        // 桌面按钮字体稍大
        setFont(new Font("Microsoft YaHei", Font.BOLD, 15));
        setupDragListeners();
    }

    public DraggableButton(String text, Font font, Color textColor, int width, int height) {
        super(text);
        Dimension d = new Dimension(width, height);
        setPreferredSize(d);
        setSize(d);
        if (font != null) setFont(font);
        if (textColor != null) setForeground(textColor);
        setupDragListeners();
    }

    /** 兼容 GlassButton.setTextColor 调用 */
    public void setTextColor(Color color) {
        setForeground(color);
    }

    private void setupDragListeners() {
        MouseAdapter ma = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    // 停止可能正在运行的吸附动画，避免新旧拖动冲突导致抽动
                    if (snapAnimTimer != null && snapAnimTimer.isRunning()) {
                        snapAnimTimer.stop();
                        snapAnimTimer = null;
                    }
                    isDragging = true;
                    hasMoved = false;
                    lastDragTime = 0;
                    lastDragX = -1;
                    lastDragY = -1;
                    pressX = e.getXOnScreen();
                    pressY = e.getYOnScreen();
                    dragOffsetX = e.getX();
                    dragOffsetY = e.getY();
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (isDragging) {
                    isDragging = false;
                    if (hasMoved) {
                        snapToGrid();
                    }
                }
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                if (isDragging) {
                    int dx = e.getXOnScreen() - pressX;
                    int dy = e.getYOnScreen() - pressY;

                    if (!hasMoved && (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD)) {
                        hasMoved = true;
                        wasDragMoved = true;
                    }

                    if (hasMoved) {
                        int newX = e.getXOnScreen() - getParent().getLocationOnScreen().x - dragOffsetX;
                        int newY = e.getYOnScreen() - getParent().getLocationOnScreen().y - dragOffsetY;

                        newX = Math.max(0, Math.min(newX, getParent().getWidth() - getWidth()));
                        newY = Math.max(0, Math.min(newY, getParent().getHeight() - getHeight()));

                        long now = System.currentTimeMillis();
                        boolean timeOk = (now - lastDragTime) >= DRAG_THROTTLE_MS;
                        boolean distOk = lastDragX < 0
                                || Math.abs(newX - lastDragX) >= DRAG_THROTTLE_PX
                                || Math.abs(newY - lastDragY) >= DRAG_THROTTLE_PX;

                        if (timeOk || distOk) {
                            lastDragTime = now;
                            lastDragX = newX;
                            lastDragY = newY;
                            setBounds(newX, newY, getWidth(), getHeight());
                            getParent().repaint(newX - 20, newY - 20, getWidth() + 40, getHeight() + 40);
                        }
                    }
                }
            }
        };
        
        addMouseListener(ma);
        addMouseMotionListener(ma);
    }

    public void setGridManager(GridLayoutManager gridManager) {
        this.gridManager = gridManager;
    }

    public void setOnPositionChanged(Runnable listener) {
        this.onPositionChanged = listener;
    }

    public void setOnCollisionCheck(java.util.function.BiPredicate<Integer, Integer> checker) {
        this.onCollisionCheck = checker;
    }

    public boolean hasMoved() {
        return hasMoved;
    }

    public void snapToGrid() {
        if (!gridSnapEnabled || gridManager == null) {
            // 流式模式：不吸附，松手后由父容器的 updateLayout 按流式规则重新定位
            // 这里什么都不做，等待 resizeTimer/WindowStateListener 触发 updateLayout 覆盖位置。
            // 但如果用户没触发 resize/状态切换，位置就乱了——所以在父容器上主动触发一次重排。
            Component parent = getParent();
            if (parent != null) parent.revalidate();
            if (parent != null) parent.repaint();
            return;
        }

        Point targetPos = gridManager.getNearestGridPoint(this);
        Point gridIndex = gridManager.getGridIndex(targetPos.x, targetPos.y);
        int targetGx = gridIndex.x;
        int targetGy = gridIndex.y;

        // 碰撞检测：目标位置已被占用则回到原位置
        if (onCollisionCheck != null && onCollisionCheck.test(targetGx, targetGy)) {
            if (gridX >= 0 && gridY >= 0) {
                Point oldPos = gridManager.getGridPosition(gridX, gridY);
                animateToPosition(oldPos.x, oldPos.y);
            }
            return;
        }

        this.gridX = targetGx;
        this.gridY = targetGy;
        animateToPosition(targetPos.x, targetPos.y);
    }

    private void animateToPosition(int targetX, int targetY) {
        int startX = getX();
        int startY = getY();
        int dx = targetX - startX;
        int dy = targetY - startY;
        
        if (Math.abs(dx) < 1 && Math.abs(dy) < 1) {
            if (onPositionChanged != null) {
                onPositionChanged.run();
            }
            return;
        }

        int[] dxArr = {dx};
        int[] dyArr = {dy};
        
        // 先停止之前的动画（防御性代码）
        if (snapAnimTimer != null && snapAnimTimer.isRunning()) {
            snapAnimTimer.stop();
        }

        snapAnimTimer = new Timer(8, e -> {
            int currentX = getX();
            int currentY = getY();
            
            int newX = currentX + (int) (dxArr[0] * 0.5);
            int newY = currentY + (int) (dyArr[0] * 0.5);
            
            dxArr[0] = targetX - newX;
            dyArr[0] = targetY - newY;
            
            if (Math.abs(dxArr[0]) < 1 && Math.abs(dyArr[0]) < 1) {
                setBounds(targetX, targetY, getWidth(), getHeight());
                ((Timer) e.getSource()).stop();
                snapAnimTimer = null;
                if (onPositionChanged != null) {
                    onPositionChanged.run();
                }
            } else {
                setBounds(newX, newY, getWidth(), getHeight());
            }
            Rectangle bounds = getBounds();
            getParent().repaint(bounds.x - 20, bounds.y - 20, bounds.width + 40, bounds.height + 40);
        });
        snapAnimTimer.start();
    }

    public boolean isDragging() {
        return isDragging;
    }

    public int getGridX() { return gridX; }
    public int getGridY() { return gridY; }
    public void setGridPosition(int gx, int gy) {
        this.gridX = gx;
        this.gridY = gy;
    }
}
