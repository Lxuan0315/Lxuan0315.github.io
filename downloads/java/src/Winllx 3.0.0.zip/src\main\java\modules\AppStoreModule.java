package modules;

import ui.GlassBrowserPanel;
import ui.GlassFrame;
import utils.LangManager;

import javax.swing.*;
import org.cef.CefClient;
import org.cef.browser.CefBrowser;
import org.cef.handler.CefDisplayHandlerAdapter;

import java.awt.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 应用商店模块（JCEF + 网页版液态玻璃）。
 *
 * 目前只是一个空框架：窗口与网页已就位，但商店里还没有任何应用。
 * 应用列表与安装逻辑预留在本类中，等你在 GitHub 上维护好索引后启用。
 *
 * 通信协议与 FileManagerModule 一致（标题桥）：
 *   store.html 的 window.__storeBridge.call() →
 *   document.title = '__STOREBRIDGE__' + base64(JSON{seq,method,args}) →
 *   本类在后台线程处理后，经 executeJavaScript 回传 window.__storeBridge.onResult(seq, b64)。
 */
public class AppStoreModule {

    private static final String REL = "store/store.html";

    /* ==================================================================
     * 数据源配置（TODO）
     *
     * 商店的应用索引计划放在 GitHub 上，例如仓库根目录的 apps.json：
     *   [{ "id":"notes", "name":"便笺", "description":"...", "version":"1.0.0",
     *      "asset":"https://github.com/<owner>/<repo>/releases/download/v1.0.0/notes.zip",
     *      "sha256":"..." }]
     * 把下面的占位地址替换成你自己的仓库地址，再在 fetchApps() 里打开请求即可。
     * ================================================================== */
    private static final String STORE_INDEX_URL =
            "https://raw.githubusercontent.com/<owner>/<repo>/main/apps.json"; // TODO: 换成你的仓库

    private JFrame frame;
    private GlassBrowserPanel browserPanel;
    private final ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "store-bridge");
        t.setDaemon(true);
        return t;
    });

    public AppStoreModule() {
        frame = new GlassFrame(LangManager.getString("module.store"));
        frame.setSize(980, 660);
        frame.setMinimumSize(new Dimension(640, 420));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        browserPanel = new GlassBrowserPanel(REL, true);
        frame.add(browserPanel, BorderLayout.CENTER);

        // JCEF 未就绪时浏览器会延后创建，桥接需等浏览器创建完成后再装
        browserPanel.onBrowserReady(this::installBridge);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                try { if (browserPanel != null) browserPanel.closeBrowser(); } catch (Throwable ignored) {}
                try { exec.shutdownNow(); } catch (Throwable ignored) {}
            }
        });
        frame.setVisible(true);
        System.out.println("[Winllx8] 应用商店窗口已启动 (JCEF + store.html)");
    }

    public GlassBrowserPanel getBrowserPanel() {
        return browserPanel;
    }

    /* ==================================================================
     * 标题桥：store.html 的 window.__storeBridge.call() → 本方法
     * ================================================================== */
    private void installBridge() {
        try {
            CefClient client = browserPanel.getClient();
            if (client == null) return;
            client.addDisplayHandler(new CefDisplayHandlerAdapter() {
                @Override
                public void onTitleChange(CefBrowser browser, String title) {
                    if (browser == null || browser != browserPanel.getBrowser()) return;
                    if (title != null && title.startsWith("__STOREBRIDGE__")) {
                        final String payload = title.substring("__STOREBRIDGE__".length());
                        exec.execute(() -> handleRequest(payload));
                    }
                }
            });
        } catch (Throwable t) {
            System.err.println("[Winllx8] 标题桥安装失败: " + t.getMessage());
        }
    }

    private void handleRequest(String payload) {
        long seq = -1;
        try {
            String json = new String(Base64.getDecoder().decode(payload), StandardCharsets.UTF_8);
            Map<String, Object> req = Json.parseObject(json);
            seq = (req.get("seq") instanceof Number) ? ((Number) req.get("seq")).longValue() : -1L;
            String method = String.valueOf(req.get("method"));
            sendResult(seq, dispatch(method));
        } catch (Throwable t) {
            System.err.println("[Winllx8] 桥请求处理失败: " + t.getMessage());
            sendResult(seq, Json.obj("ok", false, "error", "内部错误: " + t.getMessage()));
        }
    }

    private void sendResult(long seq, Map<String, Object> result) {
        try {
            String resJson = Json.stringify(result);
            final String b64 = Base64.getEncoder().encodeToString(resJson.getBytes(StandardCharsets.UTF_8));
            final long fSeq = seq;
            SwingUtilities.invokeLater(() -> {
                try {
                    browserPanel.executeJavaScript("window.__storeBridge.onResult(" + fSeq + ",'" + b64 + "')");
                } catch (Throwable t) {
                    System.err.println("[Winllx8] 回传失败: " + t.getMessage());
                }
            });
        } catch (Throwable t) {
            System.err.println("[Winllx8] 结果编码失败: " + t.getMessage());
        }
    }

    /* ==================================================================
     * 请求分发
     * ================================================================== */
    private Map<String, Object> dispatch(String method) {
        if ("list".equals(method) || "refresh".equals(method)) {
            List<Map<String, Object>> apps = fetchApps();
            return Json.obj("ok", true, "apps", apps);
        }
        if ("install".equals(method)) {
            // TODO: 从 GitHub Releases 下载应用包并安装到本地
            return Json.obj("ok", false, "error", "安装功能尚未实现");
        }
        if ("open".equals(method)) {
            // TODO: 启动已安装的应用
            return Json.obj("ok", false, "error", "启动功能尚未实现");
        }
        return Json.obj("ok", false, "error", "未知方法: " + method);
    }

    /**
     * 拉取 GitHub 上的应用列表。
     *
     * TODO: 待仓库与 apps.json 就绪后，用 HttpURLConnection 请求 STORE_INDEX_URL 并解析。
     * 现在仓库还是占位地址，因此固定返回空列表，商店显示"还没有应用"。
     */
    private List<Map<String, Object>> fetchApps() {
        return java.util.Collections.emptyList();
    }

    /* ==================================================================
     * 极简 JSON 读写（与 FileManagerModule 内部实现同风格）
     * ================================================================== */
    private static class Json {

        static Map<String, Object> obj(Object... kv) {
            Map<String, Object> m = new LinkedHashMap<>();
            for (int i = 0; i + 1 < kv.length; i += 2) {
                m.put(String.valueOf(kv[i]), kv[i + 1]);
            }
            return m;
        }

        static String stringify(Object o) {
            StringBuilder sb = new StringBuilder();
            write(sb, o);
            return sb.toString();
        }

        private static void write(StringBuilder sb, Object o) {
            if (o == null) { sb.append("null"); return; }
            if (o instanceof Map) {
                sb.append('{');
                boolean first = true;
                for (Map.Entry<?, ?> e : ((Map<?, ?>) o).entrySet()) {
                    if (!first) sb.append(',');
                    first = false;
                    writeString(sb, String.valueOf(e.getKey()));
                    sb.append(':');
                    write(sb, e.getValue());
                }
                sb.append('}');
                return;
            }
            if (o instanceof List) {
                sb.append('[');
                boolean first = true;
                for (Object it : (List<?>) o) {
                    if (!first) sb.append(',');
                    first = false;
                    write(sb, it);
                }
                sb.append(']');
                return;
            }
            if (o instanceof Number || o instanceof Boolean) { sb.append(o); return; }
            writeString(sb, String.valueOf(o));
        }

        private static void writeString(StringBuilder sb, String s) {
            sb.append('"');
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                switch (c) {
                    case '"': sb.append("\\\""); break;
                    case '\\': sb.append("\\\\"); break;
                    case '\n': sb.append("\\n"); break;
                    case '\r': sb.append("\\r"); break;
                    case '\t': sb.append("\\t"); break;
                    default:
                        if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                        else sb.append(c);
                }
            }
            sb.append('"');
        }

        /** 只解析本商店用到的扁平对象 {"method":"list","seq":1,"args":{...}}。 */
        static Map<String, Object> parseObject(String s) {
            Map<String, Object> m = new LinkedHashMap<>();
            int i = s.indexOf('{');
            if (i < 0) return m;
            i++;
            while (i < s.length()) {
                int k = s.indexOf('"', i);
                if (k < 0) break;
                int kEnd = s.indexOf('"', k + 1);
                if (kEnd < 0) break;
                String key = s.substring(k + 1, kEnd);
                int colon = s.indexOf(':', kEnd);
                if (colon < 0) break;
                int v = colon + 1;
                while (v < s.length() && Character.isWhitespace(s.charAt(v))) v++;
                if (v < s.length() && s.charAt(v) == '"') {
                    int vEnd = s.indexOf('"', v + 1);
                    if (vEnd < 0) break;
                    m.put(key, s.substring(v + 1, vEnd));
                    i = vEnd + 1;
                } else if (v < s.length() && (s.charAt(v) == '{' || s.charAt(v) == '[')) {
                    // 嵌套结构对商店骨架无用，跳过其全部内容
                    i = s.length();
                } else {
                    int vEnd = v;
                    while (vEnd < s.length() && "},]".indexOf(s.charAt(vEnd)) < 0) vEnd++;
                    String raw = s.substring(v, vEnd).trim();
                    m.put(key, raw.matches("-?\\d+") ? (Object) Long.parseLong(raw) : raw);
                    i = vEnd;
                }
            }
            return m;
        }
    }
}