package modules;

import ui.GlassBrowserPanel;
import ui.GlassFrame;
import utils.LangManager;

import javax.swing.*;
import java.awt.*;

/**
 * 待办清单模块（JCEF + 网页版液态玻璃）。
 *
 * 加载 web/todo/todo.html：任务的增删改、完成勾选、优先级、截止日期、筛选，
 * 数据由页面自身通过 localStorage 持久化（GlassBrowserPanel 已设置 cache_path）。
 */
public class TodoModule {

    private static final String REL = "todo/todo.html";

    private JFrame frame;
    private GlassBrowserPanel browserPanel;

    public TodoModule() {
        frame = new GlassFrame(LangManager.getString("module.todo"));
        frame.setSize(680, 640);
        frame.setMinimumSize(new Dimension(460, 400));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        browserPanel = new GlassBrowserPanel(REL, true);
        frame.add(browserPanel, BorderLayout.CENTER);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                if (browserPanel != null) browserPanel.closeBrowser();
            }
        });
        frame.setVisible(true);
        System.out.println("[WinllxTodo] 待办清单窗口已启动 (JCEF + todo.html)");
    }

    public GlassBrowserPanel getBrowserPanel() {
        return browserPanel;
    }
}
