"use strict";
/* ============================================================
   共享液态玻璃按钮创建器 —— 从 notes.html 抽取，供各模块页面复用。
   依赖：<script src="../notes/liquid-glass-native.js"></script>
   提供 window.applyLiquidGlassParams / window.createLiquidGlassButton
   ============================================================ */
(function () {

  // ====== 液态玻璃参数 ======
  // 默认值 = 液态玻璃应用（web/glass，官方 LiquidGlass 演示）的初始值，
  // 保证程序内各窗口按钮与「液态玻璃」应用里的预览完全一致。
  let LG = {
    blurAmount: 0.5,           // 模糊系数
    saturation: 140,           // 饱和度 %
    displacementScale: 100,    // 折射位移
    aberrationIntensity: 2,    // 色差强度
    elasticity: 0.15,          // 弹性系数（组件原版默认值：鼠标靠近时玻璃会跟随/拉伸）
    activationZone: 200,       // 激活区域 px
    activeScale: 0.96,         // 按下缩放
    mode: 'standard',          // 折射模式
    overLight: false,          // 亮底加深
    cornerRadius: 32           // 圆角
  };
  const LG_KEY = 'lgParams';
  // 一次性迁移：旧默认值与演示预览不一致，清掉历史遗留值让外观回到演示预览的样子。
  (function migrateLgDefaults() {
    try {
      if (localStorage.getItem('winllx.glass.defaultsV4')) return;
      localStorage.removeItem(LG_KEY);
      localStorage.setItem('winllx.glass.defaultsV4', '1');
    } catch (e) {}
  })();

  // ====== displacement map base64 (from React utils.ts) ======
  const DISPLACEMENT_MAP = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAZABkAAD/2wCEAAQDAwMDAwQDAwQGBAMEBgcFBAQFBwgHBwcHBwgLCAkJCQkICwsMDAwMDAsNDQ4ODQ0SEhISEhQUFBQUFBQUFBQBBQUFCAgIEAsLEBQODg4UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFP/CABEIAQABAAMBEQACEQEDEQH/xAAxAAEBAQEBAQAAAAAAAAAAAAADAgQIAQYBAQEBAQEBAQAAAAAAAAAAAAMCBAEACAf/2gAMAwEAAhADEAAAAPjPor6kOgOiKhKgKhKgOhKhOhKxKgKhOgKhKhKgKxOhKhOgKhKhKgKwKhKgKgKwG841nns9J/nn2KVCdCdCVAVCVCVAdCVCdiVAVidCVAVCVAdiVCVCdAVCVCVAVCVAVAViVZxsBrPPY6R/NvsY6E6ErEqAqE6ErAqE6E7E7ErA0ErArAqAqEuiVAXRLol0S6J0JUBWBUI0BXnG88djpH81+xjoToSoSoCoTsSoYQTsTsTQSsCsCsCsCsCoC6A0JeAuiXSLwn0SoioCoCoBsBrPFH0j+a/Yx0J0JUJUJ2BUMIR2MIRoBoJIBXnJAK840BUA0BdAegXhLpF4S8R+IuiVgVANAV546fSH5r9jHRHQFQlYxYnZQgnYwhQokgEgEmckzjecazlYD3OPQHoD0S8JcI/EXiPxF0SoSvONBFF0j+a/YxdI7EqA6KLGEKEKEGFI0AlA0AUzimYbzjecazjWce5w6BdEeCXhPhFwz8R+MuiVgVAdF0j+a/Yp0RUJ0MWUIUWUIUKUIJqBoArnJM4pmBMw3nCsw1mCs4+AegPBLxHwi4Z8KPGXSPojYH0ukfzX7FOiKhiyiylDiylDhBNRNQJAJcwpnBMopmC84XlCswdzj3OPQHwlwS8R8M+HHDPxl0ioDoukfzT7GOhOyiimzmzhDlShBNBNBJc4rmFMwJlBMwXlC82esoVmHucOgXgHxH4j4Zyccg/GfiOiKh6R/NPsY6GLOKObOUObOUI0KEAlEkzimYFygmUEyheXPeULzZ6yhWce5x8BeEuGfCj0HyI5EdM/EdD0h+a/Yx0U0cUflxNnNnCHCCdgSiSZgTMK5c6ZQvLnTLnvJnvKFZgrMHc5dAeiXijhn445E8g/RHTPpdI/mn2KdlFR5RzcTUTZxZwglYGgCmcEzAuUEyZ0y57yZ0yZ7yheUKzh3OPc5dEvEfij0RyI9E+iPGfT6T/NPsQ6OKiKmajy4ijmyOyKwNAFM4JlBMudMmdMue8mdMme8me8wVmGsw0A9A+kfjjxx6J9EememfT6W/MvsMqOamKiamKmKOKM7ErErAUzAmYLyZ0y50yZ0yZkyZ7yBeULzBeYazl0T6R9KPRPYj0T2J9B9Ppj8x+wjo4qY7M9iKmKg6MrIrErALzBeYEyZ0y50yZkyZ7x50yheXPeUbzjWcqA6I+lHYnsT6J7E9iOx0z+YfYBUc1MdmexHZjsHRlRBRDYBecEzZ7yAmXNeTOmTOmPOmXOmULyjeYbzlYnQxRx057E9mexPYij6a/L/r86OOzPpjsR6Y7B9MqIaILDPYZ7zZ0y57y50yZ0x5kyAmXPeUEyjeYUznQnYnRTUTUT2JqJ7EUfTn5d9fFRx2Z9EdmPTHjLsF0h6I2OegzXmzJmzplz3lzJjzpkBMudMoplBM5JnOwOyiimzmomomonsHRdO/l318VFHYj0x6I9McgumXiHpDQ56DPebMmbNebMmXMmQEy50yguQEzCmYkA7GLGEKaObibiaOKOKPp38s+vCsj7EeiPTHIP0Hwx6ReMKDP0M95895syZ815cy5c6ZQTKCZRXMKZiQDQYQYsps5uJs5qIsjounvyz68KyLpx4z9Mcg+GXoLxl4g6IUGes+a8+e82ZM2dMuZMoJmBcwrlJM5IBoMKMoUWc2c3E0cWRUXT/wCV/XQ2R0RdiPQfDPkFwy9BeIOiHQz0Ges+e82dM2ZM2dMwLmBcwpmJc5qBoMIUIUoU2c2cWZ0R0PT/AOV/XQ2RUJdM+wfDL0Hwy5A+EfEHQz0AUGe8+dM2e82dcwJnFcwrnJc5IEKUIMIUoUWc2cWRUJ0PT/5V9dFYjZFRF0z8ZeM+QPDLxD4Q6OfoBQhefPeYEz50ziucUzCoEuclCEKFGUKEKLOLI7E6EqHqD8o+uhsRsisSoi6ZeM+QPiHhj0R8IUIdALALzgmcEzimcVAlzioGomgyhQgwhRZHZFQHQlQ9Qfk/10NiVkNiNiVGXiPxj4x8Q9IfCFCPRCwC84oA3nFQFM5KBKJIMKEIUWRoUUJWJUJ0BUPUH5L9dDZFYigjYjZHRF0x8Q9IvEHRHojQjQhecUAUAkEkziomgGgkoxZGgxZFQFQlYnQHRdPfj/10KCSCKESCNiVkViPSLpD0h6I0Q0I0A2IoBWBIJIBKBIJoJIJ2R2J0JWBUJ0JUB0XTv479dFZDYiglYigkhEgjZFQjRFQjRFQjQigFYigHYigmgEgmglYlYnQlQlYlQHQlQnQ9P/kf1yVkNiNCNkNiVENiNiViNEViNkVCVgKCViViViSCViSCVgdCViVCViVCdgVCVCdD1D+U/XBWQ2I0I2Q2JUQ2I0JWQ0I2JUQ2JUI2JUI2J0JWJWJWA2R0BWJ0I2JUJ2BUJUJ0P//EABkQAQEBAQEBAAAAAAAAAAAAAAECABEDEP/aAAgBAQABAgB1atWrVq1atWrVq1atWrVq1atWrVq1atWrVq+OrVq1atWrVq1atWrVq1atWrVq1atWrVq1atXxVppppppdWrVq1atWrVq1NNNNNNNNNNNPVWmmmmms6tWrVq1atWpppppppppppppp6q0000uc51atWrVq1ammmmmmmmmmmmmt1Vpppc5znVq1atWrVqaaaaaaaaaaaaaeqtNLnOc51atWrVq1ammmmmmmmmmmmmnqrS5znOc6tWrVq16222mmmmmmlVppp6tKuc5znOrVq1a9TbbbbTTTTTSq000qtLnOc5zq1atWrW0222200000qqqtKqrnOc5zq1atTbbbbbbbbTTTSqqqqqq5znOc6tTTTbbbbbbbbTTTSqqqqrlVznOctNNNtttttttttNNNNKqqqrqznKqrTTTTbbbbbbbbbTTTSqqqqrqznOc5aaaabbbbbbbbbaaaaVVVVVdWc5znVq1NNttttttttttNNKqqqqudWc5znVq16tbbbbbbbbbbTTSqqqq5XVnOc6tWrVrb1tttttttttNNKqqqqrWrK5VWmmm2230bbbbbbaaaXOc5zlVa1KuVVppptttt9G22222mmlzlVznK6tWVVWmmmm2222222222mlznOc5znLWppVVWmmm22222229bTWrOc5znOcq1qaaVpWmm222222229erVqznOc5znKtatStK0rTbTTbbbberXr1as5znOc5aVpppppWlabaabbbb1ta9WrVnOc5znU0rTTTTTTTTTbTTbbbTWvVq1as5znOdTTStNNNNNNNNNtNNtttN6tWvVq1ZznOrU00rTTTTTTTTTTTTTbTWvVq1atWrOc6tTTTStNNNNNNNNNNtNNtNa9WrVq1Z1Z1NNNNNK1q1NNNNNNNNNNNtNatWrVq1atWrU00000rWrVq1atWrVq1alaaa1atWrVq1NNNammmmla1atWrVq1aterVq16tWrVnVqa1NK1qaaaVX/xAAWEAADAAAAAAAAAAAAAAAAAAAhgJD/2gAIAQEAAz8AaExf/8QAGhEBAQEBAQEBAAAAAAAAAAAAAQISEQADEP/aAAgBAgEBAgDx48ePHjx48ePHjx48ePHjx48ePHjx48ePHj86IiIiIiInjx48ePHjx48IiIiIj0oooooooooRERER73ve60UUUUUUVrWiiiiiihERERER73ve97ooooorRWiiiiihKERERER73ve973RRRRWtFFFFFFCIiIiIiPe973ve60UUVrRRRRRRQiIlCIiI973ve973pRRWiiiiiiiiiiiiiiihEe973ve973RRWtFFFFFFFFFFFFFFFFFFa13ve973WitaKKKKKKKKKKKKKKKKKK1rWtd1rutFa1oooooooooooosssooorWta1rWta1rRRRRRRRRRRZZZZZZZZZWta1rWta1rRRRRRRRRZZZZZZZZZZZZe9a1rWta1rWitaKLLLLLLLLLLLLLLLLL3rWta1rWtFbLLLLLLLLLLLLLLLLLLLL3vWta1rWita1ssssssss+hZZZZZZZZe961rWta0Vre97LLLLLLLLLLLPoWWWWWXrWta1oorWta3ssss+hZZZZ9Cyyyyyyyyiita1orWta1ve9llllllllllllllllFFa0VorWta1ve9llllllllllllllllllFFFaK1rWta1rWiyyyyyyyyyyyyiiiiiiitFFa1rWta1oosoosssssoooosoooorRRRWta1rWta0UUUUUWUUUUUUUUUUUVoooorWta1rWtaKKKKKKmiiiiiiiiiiiiiiitd73ve61oSiiipoqaKKKKKKKKKK0UUUVrve973vREREZoSihEooooorRRRRWtd73ve9EREREREoSiiiiitFllllla73ve9ERERERESiiiiiitH0PoWWWWVrXe96IiIiMoiJRRRRRRWjwlFFllllFFd6IiIiIlCUUUUUUUUUePHjx48ePCIiIiIiIiUUUUUUUUUUUePHjx48ePHjx48ePHjx48IiUUUUUUJRRRX//xAAWEQADAAAAAAAAAAAAAAAAAAABYJD/2gAIAQIBAz8AtEV7/8QAFxEBAQEBAAAAAAAAAAAAAAAAAAECEP/aAAgBAwEBAgCtNNNNNNNNNNNNNNNNNNNNNNNNNNNNNcrTTTTTTTTTTTTTTTTTTTTTTTTTTTTTXKrTTTTTTTU000000000000000000001FVpppppqampqaaaaaaaaaaaaaaaaaaaa5Vaaaaampqampqammmmmmmmmmmlaaaaaaiq0001NTU1NTU1NTTTTTTTTTTSqqtNNNcqtNNSyzU1LNTU1NTTTTTTTTTSqqq001ytNLLLLNTU1NTU1NTbbbTTTTTSqqq001ytNLLLLLNTU1NTU3NttttNNNNNKqq001KrSyyyyyzU1NTU3Nzc02220000qqqqrSqqyyyyyzU1NTU3Nzc3NttttNNNKqqqqqqssssss1NTU3Nzc3NzbbbbTTTSqqqqqqrLLLLLNTU1Nzc3Nzc22220000qqqqqqqqssss1NTU3Nzc3NzbbbbbTTSqqqqqqqqqqzU1NTc3Nzc3Nzbc22000qqqqqqqqqqqtTU3Nzc3Nzc3NtzbTTSqqqqrKqqqqqtNNzc23Nzc3Nzc3NTU1KqqqrKqqqqqtNNNNttzc3Nzc3NzU1NLLLLLKqqqqqqqq0022223Nzc3NzU1NSyyyyyyqqqqqqqrTTbbbbc3Nzc3NTU1LLLLLLKsqqqqqqrTTTTbbbc3Nzc1NTUsssssssqqqqqqrTTTTTbbbTc3NTU1NTUsssssqqqqqqqq0000222023NTU1NTUsssssqqqqqqqq000000003NTU1NTU1LLLLLNKrTSqqqqtNNNNNNtNNTU1NSzUssss00qq0qqqqrTTTTTTTTTU1NTUs1LLLNNNKrTTTSqqq00000000001NTU1LNTU0000qtNNNKqqqtNNNNNNNNTU1NTUs1NNNNNKss1NNNK00qtK0000001NNTU0s000000qq000001NKrStNNNNK1NNNNStNNNNNKqtNNNNNNNK0000000rU0000rTTTTTSq00000rTTTTTTTTTTTTTTTTStNNNNKr/xAAUEQEAAAAAAAAAAAAAAAAAAACg/9oACAEDAQM/AAAf/9k=";

  // ====== SVG 滤镜注入 ======
  (function injectGlassFilter() {
    try {
      if (document.getElementById('liquid-glass-filter')) return;
      const NS = 'http://www.w3.org/2000/svg';
      const svg = document.createElementNS(NS, 'svg');
      svg.setAttribute('style', 'position:absolute;width:0;height:0');
      svg.setAttribute('aria-hidden', 'true');
      svg.innerHTML =
        '<defs>' +
        '<filter id="liquid-glass-filter" x="-35%" y="-35%" width="170%" height="170%" color-interpolation-filters="sRGB">' +
        '<feImage id="fe-dm" x="0" y="0" width="100%" height="100%" result="DISPLACEMENT_MAP" preserveAspectRatio="xMidYMid slice"/>' +
        '<feColorMatrix in="DISPLACEMENT_MAP" type="matrix" values="0.3 0.3 0.3 0 0  0.3 0.3 0.3 0 0  0.3 0.3 0.3 0 0  0 0 0 1 0" result="EDGE_INTENSITY"/>' +
        '<feComponentTransfer in="EDGE_INTENSITY" result="EDGE_MASK"><feFuncA id="fe-edge-mask" type="discrete" tableValues="0 0.1 1"/></feComponentTransfer>' +
        '<feOffset in="SourceGraphic" dx="0" dy="0" result="CENTER_ORIGINAL"/>' +
        '<feDisplacementMap id="feDispRed" in="SourceGraphic" in2="DISPLACEMENT_MAP" scale="-70" xChannelSelector="R" yChannelSelector="B" result="RED_DISPLACED"/>' +
        '<feColorMatrix in="RED_DISPLACED" type="matrix" values="1 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0" result="RED_CHANNEL"/>' +
        '<feDisplacementMap id="feDispGreen" in="SourceGraphic" in2="DISPLACEMENT_MAP" scale="-70.1" xChannelSelector="R" yChannelSelector="B" result="GREEN_DISPLACED"/>' +
        '<feColorMatrix in="GREEN_DISPLACED" type="matrix" values="0 0 0 0 0  0 1 0 0 0  0 0 0 0 0  0 0 0 1 0" result="GREEN_CHANNEL"/>' +
        '<feDisplacementMap id="feDispBlue" in="SourceGraphic" in2="DISPLACEMENT_MAP" scale="-70.2" xChannelSelector="R" yChannelSelector="B" result="BLUE_DISPLACED"/>' +
        '<feColorMatrix in="BLUE_DISPLACED" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 1 0 0  0 0 0 1 0" result="BLUE_CHANNEL"/>' +
        '<feBlend in="GREEN_CHANNEL" in2="BLUE_CHANNEL" mode="screen" result="GB_COMBINED"/>' +
        '<feBlend in="RED_CHANNEL" in2="GB_COMBINED" mode="screen" result="RGB_COMBINED"/>' +
        '<feGaussianBlur id="feAberBlur" in="RGB_COMBINED" stdDeviation="0.3" result="ABERRATED_BLURRED"/>' +
        '<feComposite in="ABERRATED_BLURRED" in2="EDGE_MASK" operator="in" result="EDGE_ABERRATION"/>' +
        '<feComponentTransfer in="EDGE_MASK" result="INVERTED_MASK"><feFuncA type="table" tableValues="1 0"/></feComponentTransfer>' +
        '<feComposite in="CENTER_ORIGINAL" in2="INVERTED_MASK" operator="in" result="CENTER_CLEAN"/>' +
        '<feComposite in="EDGE_ABERRATION" in2="CENTER_CLEAN" operator="over"/>' +
        '</filter>' +
        '</defs>';
      document.body.appendChild(svg);
      const feImg = svg.querySelector('#fe-dm');
      if (feImg) feImg.setAttribute('href', DISPLACEMENT_MAP);
    } catch (e) {}
  })();

  // ====== 原生 React LiquidGlass 挂载 ======
  const __lgMounts = new Set();
  const LG_MOUSE_CONTAINER = { current: document.body || document.documentElement };

  // 合并应用参数：更新 LG、持久化，并重渲染所有已挂载按钮
  function applyLiquidGlassParams(params) {
    if (params && typeof params === 'object') {
      Object.keys(params).forEach(function (k) {
        if (LG[k] === undefined) return;
        if (k === 'mode') {
          if (typeof params[k] === 'string') LG[k] = params[k];
        } else if (k === 'overLight') {
          if (typeof params[k] === 'boolean' || params[k] === 'true' || params[k] === 'false') LG[k] = params[k] === true || params[k] === 'true';
        } else if (isFinite(Number(params[k]))) {
          LG[k] = Number(params[k]);
        }
      });
    }
    __lgMounts.forEach(function (render) { try { render(); } catch (e) {} });
    try { localStorage.setItem(LG_KEY, JSON.stringify(LG)); } catch (e) {}
  }
  window.applyLiquidGlassParams = applyLiquidGlassParams;

  // 启动时读取全局设置写入的同源 localStorage
  (function () {
    let saved = null;
    try { saved = JSON.parse(localStorage.getItem(LG_KEY) || 'null'); } catch (e) {}
    applyLiquidGlassParams(saved);
  })();

  // ====== 渲染模式 ======
  // 只有一种按钮：React 完整版。纯 CSS 胶囊已彻底移除，不存在任何降级路径。
  // 清掉历史遗留的 localStorage['winllx.glass.mode']，避免旧值（'css'）把按钮打回 CSS 胶囊。
  (function clearLegacyGlassMode() {
    try { localStorage.removeItem('winllx.glass.mode'); } catch (e) {}
  })();

  // ====== native 是否就绪（React/ReactDOM/LiquidGlass 由 liquid-glass-native.js 提供）=====
  // liquid-glass-native.js 用 defer 加载（不进关键渲染路径）：按钮创建时若 native 尚未就绪，
  // 先不渲染任何内容，native 就绪后由 watcher 统一重渲染成真实 React 液态玻璃按钮。
  function nativeReady() {
    return typeof React !== 'undefined' && typeof ReactDOM !== 'undefined'
      && typeof LiquidGlass !== 'undefined';
  }
  if (!window.__lgNativeWatcher) {
    window.__lgNativeWatcher = true;
    (function watch() {
      if (nativeReady()) return;
      const iv = setInterval(function () {
        if (!nativeReady()) return;
        clearInterval(iv);
        __lgMounts.forEach(function (r) { try { r(); } catch (e) {} });
      }, 25);
    })();
  }

  // ====== 主创建器 ======
  // 只有一种按钮：React 完整版液态玻璃。纯 CSS 胶囊已彻底移除，不存在任何降级路径。
  // native（liquid-glass-native.js）用 defer 加载，未就绪时先不渲染，就绪后由 watcher 自动补齐。
  function createLiquidGlassButton(text, onClick, opts) {
    opts = opts || {};
    const wrapper = document.createElement('span');
    wrapper.className = 'lg-wrapper' + (opts.icon ? ' lg-icon' : '');
    const isIcon = !!opts.icon;

    let root = null;       // React root（native 就绪后挂载）
    // 组件内部的边框/高光层与折射位移贴图都按 glassSize 生成，
    // 必须等于按钮的实际像素尺寸，否则折射环套不到按钮上（表现为没有折射/扭曲很弱）。
    let glassSize = opts.glassSize || null;

    function render() {
      try {
        if (nativeReady()) {
          root = root || ReactDOM.createRoot(wrapper);
          root.render(
            React.createElement(LiquidGlass, {
              ...LG,
              centered: false,
              mouseContainer: LG_MOUSE_CONTAINER,
              cornerRadius: opts.cornerRadius != null ? opts.cornerRadius : (LG.cornerRadius != null ? LG.cornerRadius : 999),
              padding: isIcon ? '0px' : (opts.padding || '10px 24px'),
              // 组件按 glassSize 生成边框/高光层与折射位移贴图；必须等于按钮实际尺寸，
              // 否则可见轮廓与折射层是两个不同大小的盒子 → 折射环套不上按钮。
              glassSize: glassSize || { width: 270, height: 69 },
              style: {
                position: 'relative',
                display: 'inline-flex',
                // 用 stretch（默认值）而不是 center：内层 .glass 才会被撑到按钮的整个高度。
                // 若用 center，.glass 会缩成“文字高度”，玻璃层(inset:0)只剩一条窄缝 →
                // 按钮看起来完全透明、没有模糊和折射。
                alignItems: 'stretch',
                justifyContent: 'center',
                minWidth: isIcon ? 38 : 50,
                height: opts.height || 38,
                width: opts.width || undefined,
                cursor: 'pointer',
              },
              onClick: function () { if (onClick) onClick(); },
            },
              React.createElement('span', {
                style: {
                  display: 'inline-block',
                  whiteSpace: 'nowrap',
                  color: '#fff',
                  fontSize: isIcon ? 18 : 13,
                  lineHeight: 1,
                  fontWeight: 600,
                },
              }, text + '')
            )
          );
          // 首帧渲染后测量 .glass 真实尺寸，回填 glassSize 并重渲染一次（尺寸不符时）。
          // 组件把 glassSize 用在边框/高光层与位移贴图上，量准了折射环才会贴着按钮。
          if (!glassSize) {
            requestAnimationFrame(function () {
              try {
                const g = wrapper.querySelector('.glass');
                if (!g) return;
                const r = g.getBoundingClientRect();
                const w = Math.round(r.width), h = Math.round(r.height);
                if (!w || !h) return;
                glassSize = { width: w, height: h };
                render();
              } catch (e) {}
            });
          }
        }
      } catch (e) {}
    }
    render();
    wrapper.__lgRender = render;
    __lgMounts.add(render);
    return wrapper;
  }

  window.createLiquidGlassButton = createLiquidGlassButton;

  // ====== 通用工具 ======
  // 显示提示条（页面需含 .toast 元素）
  window.showGlassToast = function (msg) {
    let t = document.getElementById('toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'toast';
      t.className = 'toast';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t.__timer);
    t.__timer = setTimeout(function () { t.classList.remove('show'); }, 2200);
  };

  // 确认框（页面需含 .modal-overlay 结构）
  window.confirmGlass = function (title, msg, onConfirm) {
    let ov = document.getElementById('modalOverlay');
    if (!ov) {
      ov = document.createElement('div');
      ov.id = 'modalOverlay';
      ov.className = 'modal-overlay';
      ov.innerHTML = '<div class="modal"><h3 id="__mTitle"></h3><p id="__mMsg"></p><div class="modal-btns" id="__mBtns"></div></div>';
      ov.addEventListener('click', function (e) { if (e.target === ov) hide(); });
      document.body.appendChild(ov);
    }
    const hide = function () { ov.classList.remove('show'); };
    ov.querySelector('#__mTitle').textContent = title;
    ov.querySelector('#__mMsg').textContent = msg;
    const btns = ov.querySelector('#__mBtns');
    btns.innerHTML = '';
    btns.appendChild(createLiquidGlassButton('取消', function () { hide(); }));
    btns.appendChild(createLiquidGlassButton('确定', function () { hide(); if (onConfirm) onConfirm(); }));
    ov.classList.add('show');
  };

})();
