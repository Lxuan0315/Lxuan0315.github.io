"use strict";
/* ============================================================
   Winllx 主界面脚本
   - 桌面按钮：HTML+CSS 液态玻璃（真实 backdrop-filter），拖动 / 网格吸附在 JS 里重做
   - 时钟 / 日期：每秒更新，文字深浅跟随桌面底色
   - 右下角状态名片：GitHub 原版 React 组件 LiquidGlass 渲染整张卡 + 三个图标（网络 / 音量 / 电池）
     玻璃参数取「设置 → 液态玻璃」面板（与程序内按钮同一套），页面不复制任何材质
     窗口化 → 竖排（自下而上），收起只露网络、悬停向上长出
     最大化 → 横排（自左向右），收起只露网络、悬停向左上展开成三个并排
   - 与 Java 的通道：GET /api/state | /api/status | /api/icon | /api/action
   ============================================================ */

/* Java 端桌面按钮的固定顺序（与 Winllx.java 的 allButtons 一致，决定网格位置） */
const BTNS = [
  { name: 'note',      label: 'note'      },
  { name: 'calc',      label: 'calc'      },
  { name: 'file',      label: 'file'      },
  { name: 'mind',      label: 'mind'      },
  { name: 'sysmon',    label: 'sysmon'    },
  { name: 'board',     label: 'board'     },
  { name: 'clock',     label: 'clock'     },
  { name: 'weather',   label: 'weather'   },
  { name: 'store',     label: 'store'     },
  { name: 'browser',   label: 'browser'   },
  { name: 'settings',  label: 'settings'  },
  { name: 'exit',      label: 'exit'      },
  { name: 'minimize',  label: 'minimize'  },
  { name: 'glass',     label: 'glass'     },
  { name: 'todo',      label: 'todo'      },
  { name: 'clipboard', label: 'clipboard' },
  { name: 'calendar',  label: 'calendar'  }
];

/* 流式布局参数（窗口化时用，与 Java 端 windowedMode 分支一致） */
const FLOW = { padX: 30, top: 100, gapX: 16, gapY: 20 };

const GRID_KEY = 'winllx.desk.grid';
const LG_KEY   = 'lgParams';

let S = null;                     // /api/state 快照
const els = {};                   // name → 按钮元素
let gridSaved = {};               // name → {x, y}（用户拖拽后保存的网格坐标）

/* ---------------- 与 Java 通信 ---------------- */
async function api(path) {
  const r = await fetch(path, { cache: 'no-store' });
  if (!r.ok) throw new Error(path + ' → ' + r.status);
  return r.json();
}

/* ---------------- 状态应用 ---------------- */
function applyState(st) {
  S = st;
  document.documentElement.style.setProperty('--cell-w', st.cellW + 'px');
  document.documentElement.style.setProperty('--cell-h', st.cellH + 'px');
  document.documentElement.style.setProperty('--pad-x', st.padX + 'px');
  document.documentElement.style.setProperty('--pad-y', st.padY + 'px');

  const wall = document.getElementById('wallpaper');
  wall.style.background = st.bgColor;
  if (st.hasImage) {
    wall.style.backgroundImage = 'url("/api/wallpaper?v=' + encodeURIComponent(st.imageVersion || '0') + '")';
    wall.style.backgroundSize =
      st.bgFit === 2 ? '100% 100%' :
      st.bgFit === 1 ? 'contain' :
      st.bgFit === 3 ? 'auto' : 'cover';
  } else {
    wall.style.backgroundImage = 'none';
  }
  wall.style.opacity = String(st.bgOpacity == null ? 1 : st.bgOpacity);

  // 文字色（时钟 / 日期）：跟随桌面底色深浅
  const isWhite = (st.textColor || '').toLowerCase() === '#ffffff';
  document.body.classList.toggle('light-text', isWhite);
  document.body.classList.toggle('dark-text', !isWhite);
  document.documentElement.style.setProperty('--text', st.textColor || '#ffffff');
  document.documentElement.style.setProperty('--grid-alpha', (st.gridAlpha > 0 ? (st.gridAlpha / 100) : 0).toFixed(3));

  // 文案（语言切换后即时生效）
  BTNS.forEach(b => {
    const el = els[b.name];
    if (!el) return;
    const t = st.labels && st.labels[b.label];
    if (t) el.querySelector('.label').textContent = t;
  });

  // 名片布局：最大化 → 三个图标并排（始终全部显示）；窗口化 → 竖排、收起只显网络、悬停向上长出
  const dockEl = document.getElementById('dock');
  if (dockEl) dockEl.classList.toggle('max', !!st.maximized);
  // 卡片本体交给原版组件渲染（玻璃参数随 st 一起下发，设置里的滑块一动这里就重渲染）
  renderDock();
  if (volOpen) positionVolPanel();   // 布局（最大化切换等）变化后，卡片仍贴在音量图标正上方

  layout();
}

/* ---------------- 按钮定位 ---------------- */
function loadGrid() {
  try {
    const s = JSON.parse(localStorage.getItem(GRID_KEY) || '{}');
    gridSaved = (s && typeof s === 'object') ? s : {};
  } catch (e) { gridSaved = {}; }
}
function saveGrid() {
  try { localStorage.setItem(GRID_KEY, JSON.stringify(gridSaved)); } catch (e) {}
}

function place(el, x, y) {
  el.style.left = x + 'px';
  el.style.top = y + 'px';
}

function layout() {
  if (!S) return;
  const W = window.innerWidth;
  const { cellW, cellH, padX, padY, maximized } = S;

  if (maximized) {
    const perRow = Math.max(1, Math.floor((W - padX * 2) / cellW));
    BTNS.forEach((b, i) => {
      const el = els[b.name];
      if (!el) return;
      const g = gridSaved[b.name];
      const gx = (g && g.x >= 0) ? g.x : (i % perRow);
      const gy = (g && g.y >= 0) ? g.y : Math.floor(i / perRow);
      place(el, padX + gx * cellW, padY + gy * cellH);
    });
  } else {
    const perRow = Math.max(1, Math.floor((W - FLOW.padX * 2 + FLOW.gapX) / (cellW + FLOW.gapX)));
    BTNS.forEach((b, i) => {
      const el = els[b.name];
      if (!el) return;
      place(el, FLOW.padX + (i % perRow) * (cellW + FLOW.gapX),
                 FLOW.top + Math.floor(i / perRow) * (cellH + FLOW.gapY));
    });
  }
}

/* ---------------- 拖动 + 吸附 ---------------- */
function cellOf(name) {
  const el = els[name];
  if (!el || !S) return null;
  const g = gridSaved[name];
  if (g && g.x >= 0) return { x: g.x, y: g.y };
  const x = parseFloat(el.style.left || '0');
  const y = parseFloat(el.style.top || '0');
  return {
    x: Math.round((x - S.padX) / S.cellW),
    y: Math.round((y - S.padY) / S.cellH)
  };
}

function occupiedBy(name, gx, gy) {
  return BTNS.some(b => b.name !== name && (() => {
    const c = cellOf(b.name);
    return c && c.x === gx && c.y === gy;
  })());
}

/** 找离目标格最近的一个空格（避免叠在一起） */
function nearestFree(name, tx, ty) {
  let best = null, bestD = Infinity;
  for (let r = 0; r <= 8; r++) {
    for (let dx = -r; dx <= r; dx++) {
      for (let dy = -r; dy <= r; dy++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        const gx = tx + dx, gy = ty + dy;
        if (gx < 0 || gy < 0) continue;
        if (occupiedBy(name, gx, gy)) continue;
        const d = dx * dx + dy * dy;
        if (d < bestD) { bestD = d; best = { x: gx, y: gy }; }
      }
    }
    if (best) return best;
  }
  return { x: tx, y: ty };
}

function snapTo(elName) {
  const el = els[elName];
  const x = parseFloat(el.style.left || '0');
  const y = parseFloat(el.style.top || '0');
  let gx = Math.round((x - S.padX) / S.cellW);
  let gy = Math.round((y - S.padY) / S.cellH);
  gx = Math.max(0, gx); gy = Math.max(0, gy);
  const cell = occupiedBy(elName, gx, gy) ? nearestFree(elName, gx, gy) : { x: gx, y: gy };
  gridSaved[elName] = cell;
  saveGrid();
  place(el, S.padX + cell.x * S.cellW, S.padY + cell.y * S.cellH);
}

function bindDrag(el, name) {
  let dragging = false, moved = false, sx = 0, sy = 0, ox = 0, oy = 0;

  el.addEventListener('pointerdown', e => {
    if (e.button !== 0) return;
    dragging = true; moved = false;
    sx = e.clientX; sy = e.clientY;
    ox = parseFloat(el.style.left || '0');
    oy = parseFloat(el.style.top || '0');
    try { el.setPointerCapture(e.pointerId); } catch (err) {}   // 捕获失败也能正常拖
  });

  el.addEventListener('pointermove', e => {
    if (!dragging) return;
    const dx = e.clientX - sx, dy = e.clientY - sy;
    if (!moved && Math.abs(dx) + Math.abs(dy) < 5) return;   // 小位移算点击
    if (!moved) {
      moved = true;
      el.classList.add('dragging');
      if (S && S.maximized) document.body.classList.add('grid-hot');
    }
    place(el, ox + dx, oy + dy);
  });

  el.addEventListener('pointerup', e => {
    if (!dragging) return;
    dragging = false;
    try { el.releasePointerCapture(e.pointerId); } catch (err) {}
    document.body.classList.remove('grid-hot');
    if (moved) {
      el.classList.remove('dragging');
      if (S && S.maximized) snapTo(name);
      else layout();
    } else {
      // 未拖动 → 视为点击：交给 Java 打开模块
      fetch('/api/action?name=' + encodeURIComponent(name)).catch(() => {});
    }
  });

  el.addEventListener('pointercancel', () => {
    if (!dragging) return;
    dragging = false;
    el.classList.remove('dragging');
    document.body.classList.remove('grid-hot');
    layout();
  });
}

function buildButtons() {
  const frag = document.createDocumentFragment();
  BTNS.forEach(b => {
    const el = document.createElement('div');
    el.className = 'dbtn';
    el.dataset.name = b.name;
    el.innerHTML = '<span class="face"></span><span class="ring"></span><span class="label"></span>';
    bindDrag(el, b.name);
    els[b.name] = el;
    frag.appendChild(el);
  });
  document.getElementById('desktop').appendChild(frag);
}

/* ---------------- 时钟 / 日期 ---------------- */
const WEEK = ['日', '一', '二', '三', '四', '五', '六'];
function tickClock() {
  const d = new Date();
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  document.getElementById('time').textContent = hh + ':' + mm;
  document.getElementById('date').textContent =
    (d.getMonth() + 1) + '月' + d.getDate() + '日 星期' + WEEK[d.getDay()];
}

/* ---------------- 右下角状态名片：GitHub 原版 React 组件渲染 ---------------- */
/* 卡片本体不是页面写的 CSS，而是 ../notes/liquid-glass-native.js 里那个原版组件
   LiquidGlass（rdev/liquid-glass-react），材质全部来自组件源码。
   这里只做三件事：把「设置 → 液态玻璃」那套参数透传给它、把三个图标作为 children 传进去、
   档位变化时换图。尺寸/展开动画由 main.css 的 #dock 负责。 */
const DOCK_SIZE = { windowed: { width: 68, height: 144 }, max: { width: 144, height: 96 } };
const DOCK_MOUSE = { current: document.body };   // 组件的 mouseContainer（弹性为 0 时不跟随鼠标）
let dockRoot = null;     // ReactDOM root（挂在 #dockStage）
let dockSig = '';        // 上次渲染的参数指纹：没变就不重复渲染

// 三个图标当前状态：重新渲染卡片时用它还原 img 的 src
const ICON_STATE = {
  wifi:    { level: 0, theme: 'dark', charging: false },
  volume:  { level: 0, theme: 'dark', charging: false },
  battery: { level: 0, theme: 'dark', charging: false }
};

function iconSrc(type) {
  const i = ICON_STATE[type];
  return '/api/icon?type=' + type + '&level=' + (i.level | 0) + '&theme=' + i.theme
       + (i.charging ? '&charging=1' : '');
}

/** 卡片玻璃参数：优先 /api/state（Java 持久化的权威值，设置面板改完会重新下发），
    缺这个字段时退回同源 localStorage.lgParams（设置面板把同一套值也写在那里），
    都没有才用演示默认值 —— 三种情况下名片都跟着「设置 → 液态玻璃」面板走。 */
function dockParams() {
  const s = S || {};
  let ls = null;
  try { ls = JSON.parse(localStorage.getItem(LG_KEY) || 'null'); } catch (e) {}
  const pick = function (key, d) {
    const a = Number(s[key]);
    if (s[key] !== undefined && s[key] !== null && isFinite(a)) return a;
    const b = ls ? Number(ls[key]) : NaN;
    return isFinite(b) ? b : d;
  };
  const pickBool = function (key, d) {
    if (s[key] !== undefined && s[key] !== null) return s[key] === true || s[key] === 'true';
    if (ls && ls[key] !== undefined && ls[key] !== null) return ls[key] === true || ls[key] === 'true';
    return d;
  };
  return {
    displacementScale:   pick('displacementScale', 100),   // 折射位移
    blurAmount:          pick('blurAmount', 0.5),          // 模糊系数
    saturation:          pick('saturation', 140),          // 饱和度 %
    aberrationIntensity: pick('aberrationIntensity', 2),   // 色差强度
    elasticity:          pick('elasticity', 0),            // 弹性
    activationZone:      pick('activationZone', 200),      // 激活区域
    activeScale:         pick('activeScale', 0.96),        // 按下缩放
    cornerRadius:        Math.round(pick('cornerRadius', 32)),
    mode:                s.mode || (ls && ls.mode) || 'standard',
    overLight:           pickBool('overLight', false)
  };
}

/** 原版组件由 liquid-glass-native.js（defer）提供，未就绪前不渲染 */
function nativeReady() {
  return typeof React !== 'undefined' && typeof ReactDOM !== 'undefined'
      && typeof LiquidGlass !== 'undefined';
}

function renderDock() {
  const stage = document.getElementById('dockStage');
  if (!stage || !nativeReady()) return;

  const lg = dockParams();
  const size = (S && S.maximized) ? DOCK_SIZE.max : DOCK_SIZE.windowed;
  const sig = JSON.stringify([lg, size, volOpen]);
  if (sig === dockSig) return;      // 参数与尺寸都没变，跳过这次渲染
  dockSig = sig;

  dockRoot = dockRoot || ReactDOM.createRoot(stage);
  // 三个图标，顺序固定：网络 → 音量 → 电池（竖排时第一个贴底，横排时最左）
  // 网络图标可点：调 Java 的 /api/netcheck 做一次真实联网检测
  // 音量图标可点：展开音量名片（图标上移到卡片顶部 + 竖直拖动条）
  const rows = ['wifi', 'volume', 'battery'].map(type =>
    React.createElement('div', {
      className: 'dock-row'
        + (type === 'wifi' || type === 'volume' ? ' dock-row-clickable' : '')
        // 音量名片展开时，音量图标"上移"到卡片顶部，这里的位置只隐藏不塌陷
        + (type === 'volume' && volOpen ? ' dock-row-lifted' : ''),
      key: type,
      'data-row': type,          // 音量名片靠这个读到音量图标的原位置（正上方定位）
      onClick: type === 'wifi' ? onNetIconClick
             : (type === 'volume' ? onVolumeIconClick : undefined)
    },
      React.createElement('img', {
        id: type + 'Icon', className: 'dock-icon', alt: type,
        'data-icon': type,               // 面板里的同款图标也按这个属性一起换图
        draggable: false, src: iconSrc(type)
      })
    )
  );
  dockRoot.render(React.createElement(LiquidGlass, {
    ...lg,
    centered: false,
    mouseContainer: DOCK_MOUSE,
    glassSize: size,             // 展开态尺寸：组件据此生成滤镜与描边层
    padding: '0px',              // 内部排列交给 main.css，组件只管材质
    style: { position: 'relative', width: '100%', height: '100%' }
  }, React.createElement('div', { className: 'dock-content' }, rows)));
}

/** 悬停展开：加 / 去掉 .open（展开过程指针始终在卡片内，不会来回抖） */
function bindDock() {
  const dock = document.getElementById('dock');
  dock.addEventListener('pointerenter', () => dock.classList.add('open'));
  dock.addEventListener('pointerleave', () => dock.classList.remove('open'));
}

/**
 * 换图标：type = wifi | volume | battery
 * level：wifi 0~4 档、volume 0~3 档（0=静音）、battery 为实际电量 0~100
 * charging：只有 battery 用；true 时 Java 端会在电量格上叠一枚闪电
 */
function setIcon(type, level, theme, charging) {
  const prev = ICON_STATE[type];
  const key = level + ':' + theme + (charging ? ':c' : '');
  if (key === prev.level + ':' + prev.theme + (prev.charging ? ':c' : '')) return;
  prev.level = level | 0;
  prev.theme = theme;
  prev.charging = !!charging;
  const src = iconSrc(type);
  // 同名图标可能同时存在（音量展开时：名片里的隐藏了，音量名片顶部那个在显示）
  document.querySelectorAll('img[data-icon="' + type + '"]').forEach(el => { el.src = src; });
}

/* ---------------- 音量名片：点音量图标 → 图标上移 + 竖直拖动条 ----------------
   点音量图标 → 音量图标从名片里"上移"到一张竖长方形玻璃卡的顶部，卡本体从图标
   原位置向上伸长；卡里一条竖直的条上下拖动即调系统音量，下面的数值可点击直接输入。
   收起：再点一次音量图标 / 点卡片与名片以外的任何地方 / 按 Esc。 */
let volOpen = false;     // 音量名片是否展开
let volPct = 50;         // 当前音量 0~100（拖动/输入时即时更新，每 2 秒由 /api/status 校准）
let volPanelRoot = null;
let volPanelSig = '';
let volDragging = false; // 拖动中不让轮询结果覆盖手指位置
let volSliderRect = null; // 开始拖动那一刻量下的轨道位置（拖动期间轨道不会动，用它换算最稳）
let volEditing = false;  // 数值框聚焦中，不让轮询覆盖用户输入
let volSendTimer = null; // 发往 /api/volume 的节流（60ms）
let volPendingSend = -1;
let iconTheme = 'dark';  // 图标深浅（跟桌面文字色，pollStatus 里更新）
/* 卡片尺寸：默认值在这里，实际值由「设置 → 液态玻璃 → 状态名片与音量名片」的四个滑块
   经 localStorage.lgParams 下发（volCardParams / applyCardGeometry 负责读回并覆盖）。 */
const VOL_SIZE = { width: 76, height: 164 };   // 会被 applyCardGeometry 改写
let VOL_GAP = 6;         // 卡片底边与名片顶边之间的间隙
let VOL_INSET = 3;       // 白色填充相对灰色轨道四周的内缩量

/** 从 /api/state 或 localStorage.lgParams 读音量名片的四个尺寸参数（与设置页同一套值） */
function volCardParams() {
  const s = S || {};
  let ls = null;
  try { ls = JSON.parse(localStorage.getItem(LG_KEY) || 'null'); } catch (e) {}
  const pick = function (key, d) {
    const a = Number(s[key]);
    if (s[key] !== undefined && s[key] !== null && isFinite(a) && a >= 0) return a;
    const b = ls ? Number(ls[key]) : NaN;
    return isFinite(b) && b >= 0 ? b : d;
  };
  return {
    w:     Math.max(40, Math.round(pick('volW', 76))),
    h:     Math.max(80, Math.round(pick('volH', 164))),
    gap:   Math.max(0, Math.round(pick('volGap', 6))),
    inset: Math.max(1, Math.round(pick('volInset', 3)))
  };
}

/** 把设置页的四个尺寸参数落到 CSS 变量与 JS 变量上；已展开的卡片当场重排 */
function applyCardGeometry() {
  const g = volCardParams();
  VOL_SIZE.width = g.w;
  VOL_SIZE.height = g.h;
  VOL_GAP = g.gap;
  VOL_INSET = g.inset;
  const r = document.documentElement.style;
  r.setProperty('--vol-w', g.w + 'px');
  r.setProperty('--vol-h', g.h + 'px');
  r.setProperty('--vol-inset', g.inset + 'px');
  renderVolPanel();
  if (volOpen) { positionVolPanel(); requestAnimationFrame(volSyncDom); }
}

/** 音量档位：与 Java 的 volumeLevel() 同规则（0 = 静音档） */
function volLevelOf(pct) {
  const v = pct | 0;
  return v <= 0 ? 0 : (v <= 33 ? 1 : (v <= 66 ? 2 : 3));
}

/** 把音量填充高度 / 输入框数值同步到 DOM（拖动时不走 React 重渲染，避免卡顿）
    填充高度按轨道的"内缩后的实际高度"用像素算，白色就是灰色形状内缩一圈的小胶囊：
    100% 时顶边落在轨道内 3px（不会顶出灰圈），0% 时不和底部脱开（保留一小段可见）。 */
function volSyncDom() {
  const slider = document.querySelector('#volPanelStage .vol-slider');
  const fill = document.querySelector('#volPanelStage .vol-slider-fill');
  if (fill && slider) {
    const inner = Math.max(0, slider.clientHeight - VOL_INSET * 2);
    const pct = Math.max(0, Math.min(100, volPct));
    const h = pct <= 0 ? 0 : Math.min(inner, Math.max(6, Math.round(inner * pct / 100)));
    fill.style.height = h + 'px';
  }
  if (volEditing) return;     // 正在输入时不要打断用户
  const val = document.querySelector('#volPanelStage .vol-value');
  if (val) val.value = String(Math.round(volPct));
}

/** 节流上报：Java 侧 SystemVolumeControl 本身也是 async + 去抖，这里少发点请求即可 */
function sendVolume(pct) {
  volPendingSend = pct | 0;
  if (volSendTimer) return;
  volSendTimer = setTimeout(() => {
    volSendTimer = null;
    const v = volPendingSend;
    if (v < 0) return;
    fetch('/api/volume?v=' + v, { cache: 'no-store' })
      .then(r => (r.ok ? r.json() : null)).catch(() => {});
  }, 60);
}

/** 按指针的 Y 算音量（轨道底 = 0，顶 = 100） */
function volApplyAtY(clientY) {
  if (!volSliderRect || !volSliderRect.height) return;
  applyVolume(Math.round(100 * (volSliderRect.bottom - clientY) / volSliderRect.height));
}

/** 立即应用一个新音量：填充 / 数值 / 图标一起更新，并按需上报系统 */
function applyVolume(pct, report) {
  const v = Math.max(0, Math.min(100, pct | 0));
  if (v === volPct) { if (report !== false) sendVolume(v); return; }
  volPct = v;
  volSyncDom();
  setIcon('volume', volLevelOf(v), iconTheme);   // 名片里的音量图标立即跟着换档
  if (report !== false) sendVolume(v);
}

/* 拖动全程挂在 window 上：指针拖到轨道外面 / 卡片外面 / 卡片边界上都不会丢事件，
   不会被边界"卡住"（原来靠元素上的 pointermove + 指针捕获，出界后就容易断）。 */
function onVolDragMove(e) {
  if (!volDragging) return;
  if (e.pointerType === 'mouse' && e.buttons === 0) { endVolDrag(); return; }   // 按键已松开
  volApplyAtY(e.clientY);
}
function onVolDragEnd() { endVolDrag(); }

function endVolDrag() {
  if (!volDragging) return;
  volDragging = false;
  window.removeEventListener('pointermove', onVolDragMove);
  window.removeEventListener('pointerup', onVolDragEnd);
  window.removeEventListener('pointercancel', onVolDragEnd);
  window.removeEventListener('blur', onVolDragEnd);
  sendVolume(volPct);        // 松手补发一次，确保最终值一定写到系统
}

function onVolSliderDown(e) {
  if (e.button !== 0) return;
  e.preventDefault();
  volSliderRect = e.currentTarget.getBoundingClientRect();
  volDragging = true;
  volApplyAtY(e.clientY);
  window.addEventListener('pointermove', onVolDragMove);
  window.addEventListener('pointerup', onVolDragEnd);
  window.addEventListener('pointercancel', onVolDragEnd);
  window.addEventListener('blur', onVolDragEnd);
}

/** 数值框：只允许数字，输入即时生效（大小 / 位置与原 div 版一致） */
function onVolValueInput(e) {
  const el = e.currentTarget;
  const digits = String(el.value).replace(/[^0-9]/g, '').slice(0, 3);
  if (digits !== el.value) el.value = digits;
  if (digits === '') return;                 // 清空：不算 0，失焦时还原
  applyVolume(parseInt(digits, 10));
}

/** 卡片顶部的音量图标可点：切换系统静音（音量本身就是 0 时不操作） */
async function onVolPanelIconClick(e) {
  if (e) e.stopPropagation();
  if (volPct <= 0) return;
  try {
    const r = await api('/api/volume?toggle=1');
    if (!r || r.ok === false) return;
    if (isFinite(Number(r.volume))) volPct = Math.max(0, Math.min(100, Number(r.volume) | 0));
    setIcon('volume', r.volumeLevel | 0, iconTheme);
    volSyncDom();
  } catch (err) {}
}

/** 卡片贴在音量图标正上方：水平对齐图标中心，底边落在名片顶边上沿上方 VOL_GAP */
function positionVolPanel() {
  const panel = document.getElementById('volPanel');
  const row = document.querySelector('#dockStage .dock-row[data-row="volume"]');
  if (!panel || !row) return;
  const rr = row.getBoundingClientRect();
  const dock = document.getElementById('dock');
  let topEdge = rr.top;
  if (dock) {
    // 读展开态名片顶边：临时关掉过渡，避免量到收起 / 动画中的中间值
    const saved = dock.style.transition;
    dock.style.transition = 'none';
    void dock.offsetHeight;
    topEdge = dock.getBoundingClientRect().top;
    dock.style.transition = saved;
  }
  const w = panel.offsetWidth || VOL_SIZE.width;
  panel.style.right = 'auto';
  panel.style.left = Math.round(rr.left + rr.width / 2 - w / 2) + 'px';
  panel.style.bottom = Math.round(window.innerHeight - topEdge + VOL_GAP) + 'px';
}

/** 展开音量名片：卡本体从图标原位置向上伸长，图标与下半段一起上移到指定位置 */
function openVolPanel() {
  volOpen = true;
  const dock = document.getElementById('dock');
  if (dock) dock.classList.add('vol-open');   // 拖动时鼠标会离开卡片，靠这个保持展开
  renderDock();                               // 音量那一格隐藏（图标已经"上移"到卡片顶部）
  renderVolPanel();
  const panel = document.getElementById('volPanel');
  if (!panel) return;
  panel.classList.remove('show');             // 先排到"未展开"（高度 0），下一帧再加 .show
  positionVolPanel();
  // 双 rAF：等布局稳定后再加 .show，高度 / 图标位移动画才会真正播出来
  requestAnimationFrame(() => requestAnimationFrame(() => {
    positionVolPanel();
    panel.classList.add('show');
  }));
}

/** 收起音量名片 */
function closeVolPanel() {
  volOpen = false;
  volEditing = false;
  endVolDrag();               // 拖动途中收起也要把 window 上的监听摘掉
  const dock = document.getElementById('dock');
  if (dock) dock.classList.remove('vol-open');
  const panel = document.getElementById('volPanel');
  if (panel) panel.classList.remove('show');
  renderDock();
}

/** 点音量图标：开 / 关音量名片 */
function onVolumeIconClick(e) {
  if (e) e.stopPropagation();
  if (volOpen) closeVolPanel(); else openVolPanel();
}

/** 收起入口：点卡片与名片以外的任何地方，或按 Esc */
function bindVolPanelDismiss() {
  document.addEventListener('pointerdown', e => {
    if (!volOpen) return;
    const t = e.target;
    if (t && t.closest && (t.closest('#dock') || t.closest('#volPanel'))) return;
    closeVolPanel();
  }, true);
  document.addEventListener('keydown', e => {
    if (volOpen && e.key === 'Escape') closeVolPanel();
  });
}

/** 渲染音量名片（材质同样来自原版组件，参数与名片共用一套） */
function renderVolPanel() {
  const stage = document.getElementById('volPanelStage');
  if (!stage || !nativeReady()) return;
  const lg = dockParams();
  const sig = JSON.stringify([lg, VOL_SIZE]);
  if (sig === volPanelSig) { volSyncDom(); return; }   // 参数没变：只同步数值，不重渲染
  volPanelSig = sig;

  volPanelRoot = volPanelRoot || ReactDOM.createRoot(stage);
  volPanelRoot.render(React.createElement(LiquidGlass, {
    ...lg,
    centered: false,
    mouseContainer: DOCK_MOUSE,
    glassSize: VOL_SIZE,
    padding: '0px',
    style: { position: 'relative', width: '100%', height: '100%' }
  }, React.createElement('div', { className: 'vol-body' },
    // 顶部：从名片里"上移"过来的音量图标（可点 → 切换静音）
    React.createElement('div', { className: 'vol-icon-slot', onClick: onVolPanelIconClick },
      React.createElement('img', {
        id: 'volumeIconPanel', className: 'vol-icon', alt: 'volume',
        'data-icon': 'volume', draggable: false, src: iconSrc('volume')
      })
    ),
    React.createElement('div', {
      className: 'vol-slider',
      // 只在这里起手：move / up / cancel 都挂在 window 上（见 onVolSliderDown），出界也不会断
      onPointerDown: onVolSliderDown
    }, React.createElement('div', { className: 'vol-slider-fill' })),
    // 数值：改成可直接点击输入的框（大小 / 位置与原 div 版一致，输入即时生效）
    React.createElement('input', {
      className: 'vol-value',
      type: 'text',
      inputMode: 'numeric',
      maxLength: 3,
      spellCheck: false,
      autoComplete: 'off',
      defaultValue: String(Math.round(volPct)),
      onChange: onVolValueInput,
      onFocus: () => { volEditing = true; },
      onBlur: () => { volEditing = false; volSyncDom(); },
      onKeyDown: e => { if (e.key === 'Enter') e.currentTarget.blur(); }
    })
  )));
  requestAnimationFrame(volSyncDom);   // 组件渲染完成后同步一次填充高度/数值
}

/* ---------------- 联网图标：档位 + 点击联网检测 ---------------- */
let netOnline = true;   // Java 侧在线探测结果（/api/status 的 online）

/** 联网图标档位 0~4：断网 = 0，在线 = 满格。
    格数只表示"通不通"：Java 侧 /api/status 的 online 是真实连一次 baidu:443 的探测结果，
    这才是 Windows 那个图标想表达的语义。之前用 navigator.connection.downlink 折算带宽当信号格，
    在桌面 Wi-Fi 上 Chromium 常报 1.5~4Mbps，就渲染成两格（Windows 明明是满格），已经去掉。 */
function netBars() {
  if (navigator.onLine === false || !netOnline) return 0;
  return 4;
}

/** 点击联网图标：让 Java 现场做一次真实联网操作（网卡 / 延迟 / 在线），结果用小气泡回报。 */
async function onNetIconClick() {
  showDockToast('联网检测中…');
  try {
    const r = await api('/api/netcheck');
    netOnline = r.online === true;
    pollStatus();
    const where = (r.ifName ? r.ifName : '') + (r.ip ? ' ' + r.ip : '');
    showDockToast(r.online
      ? '已联网 · 延迟 ' + r.latencyMs + 'ms' + (where ? '\n' + where : '')
      : '未联网：探测不通' + (where ? '\n' + where : ''));
  } catch (e) {
    showDockToast('联网检测失败：' + (e && e.message ? e.message : e));
  }
}

/** 名片上方的小气泡（1.5 秒后淡出） */
let toastTimer = null;
function showDockToast(text) {
  const el = document.getElementById('dockToast');
  if (!el) return;
  el.textContent = text;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 1500);
}

async function pollStatus() {
  try {
    const st = await api('/api/status');
    // 图标深浅跟"桌面文字色"走 —— 就是时钟/日期变黑变白用的同一个信号（textColor 是桌面底色的对比色）：
    //   桌面浅 → 文字黑 → 用深色图标（light-theme）；
    //   桌面深 → 文字白 → 用白色图标（dark-theme）。
    const isWhiteText = ((S && S.textColor) || '#ffffff').toLowerCase() === '#ffffff';
    const theme = isWhiteText ? 'dark' : 'light';
    iconTheme = theme;
    netOnline = st.online !== false;          // Java 侧对 baidu:443 的真实探测结果
    if (!volDragging && !volEditing && isFinite(Number(st.volume))) {   // 没在拖动/输入时用系统真值校准
      volPct = Math.max(0, Math.min(100, Number(st.volume) | 0));
      volSyncDom();
    }
    setIcon('wifi', netBars(), theme);
    setIcon('volume', st.volumeLevel | 0, theme);
    setIcon('battery', st.batteryLevel | 0, theme, !!st.charging);
  } catch (e) {}
}

/* ---------------- 液态玻璃参数（设置页滑块 → localStorage.lgParams） ---------------- */
function applyGlassParams() {
  let p = null;
  try { p = JSON.parse(localStorage.getItem(LG_KEY) || 'null'); } catch (e) {}
  const r = document.documentElement.style;
  if (!p) {
    r.setProperty('--lg-radius', '32px');
    r.setProperty('--lg-blur', '20px');
    r.setProperty('--lg-sat', '140%');
    applyCardGeometry();
    return;
  }
  const radius = Number(p.cornerRadius);
  // 与应用内按钮同一套公式（notes/liquid-glass-native.js）：
  // 模糊 = (overLight ? 12 : 4) + blurAmount * 32，圆角直接用滑块的 px 值
  const blur = (p.overLight ? 12 : 4) + Number(p.blurAmount) * 32;
  const sat = Number(p.saturation);
  r.setProperty('--lg-radius', (radius > 0 ? Math.round(Math.min(radius, 40)) : 32) + 'px');
  r.setProperty('--lg-blur', (blur > 0 ? Math.round(blur) : 20) + 'px');
  r.setProperty('--lg-sat', (sat > 0 ? Math.round(sat) : 140) + '%');
  // 同一份 lgParams 里的名片尺寸参数（设置页也在改它们，这里跟着一起刷新）
  applyCardGeometry();
}

/* ---------------- 启动 ---------------- */
async function boot() {
  loadGrid();
  buildButtons();
  bindDock();
  bindVolPanelDismiss();
  applyGlassParams();
  tickClock();
  setInterval(tickClock, 1000);
  setInterval(pollStatus, 2000);

  try { applyState(await api('/api/state')); } catch (e) { layout(); }
  pollStatus();

  // 原版组件是 defer 加载的：就绪后立刻把名片渲染出来（未就绪时 renderDock 自己会跳过）
  (function waitDockNative() {
    if (nativeReady()) { renderDock(); renderVolPanel(); return; }
    const iv = setInterval(() => {
      if (!nativeReady()) return;
      clearInterval(iv);
      renderDock();
      renderVolPanel();
    }, 25);
  })();

  // 预热图标（网络 5 档 / 音量 4 档）× 深浅两套，切换档位时不出白闪。
  // 电池是按实际电量实时绘制的（连续值），没有固定档位，只预热几档常见的（含充电版）。
  ['light', 'dark'].forEach(t => {
    for (let i = 0; i <= 4; i++) { const im = new Image(); im.src = '/api/icon?type=wifi&level=' + i + '&theme=' + t; }
    for (let i = 0; i <= 3; i++) { const im = new Image(); im.src = '/api/icon?type=volume&level=' + i + '&theme=' + t; }
    [0, 20, 50, 80, 100].forEach(l => [0, 1].forEach(c => {
      const im = new Image();
      im.src = '/api/icon?type=battery&level=' + l + '&theme=' + t + (c ? '&charging=1' : '');
    }));
  });

  window.addEventListener('resize', () => { layout(); positionVolPanel(); });

  // 联网状态 / 连接质量变化（拔网线、切 Wi-Fi、断网）→ 立刻刷新联网图标
  window.addEventListener('online', pollStatus);
  window.addEventListener('offline', pollStatus);
  if (navigator.connection && navigator.connection.addEventListener) {
    navigator.connection.addEventListener('change', pollStatus);
  }

  // 设置面板拖动滑块会写同源 localStorage.lgParams：桌面按钮、名片与音量名片立刻跟着变
  window.addEventListener('storage', e => {
    if (e.key !== LG_KEY) return;
    applyGlassParams();
    renderDock();
    renderVolPanel();
  });
}

/** Java 端在背景 / 网格 / 语言 / 主题 / 玻璃参数变化后调用：重新拉一次状态 */
window.__winllxRefresh = async function () {
  applyGlassParams();
  renderDock();
  renderVolPanel();
  try { applyState(await api('/api/state')); } catch (e) {}
};

boot();
