@echo off
cd /d "%~dp0"

set "JAVA_HOME=%~dp0..\lib\jbr"
set "CLASSPATH="

if not exist "out\mc\Main.class" (
    call "%~dp0build.bat"
)

"%JAVA_HOME%\bin\java.exe" -cp out mc.Main
if %errorlevel% neq 0 pause
