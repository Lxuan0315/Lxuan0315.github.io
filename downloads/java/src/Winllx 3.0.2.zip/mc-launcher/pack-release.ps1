﻿<#
  mc-launcher 发布打包脚本
  ====================================================================
  产出一个可上传 GitHub Release 的 zip，让「Winllx 应用商店」下载安装后能直接启动。

  用法：
      powershell -ExecutionPolicy Bypass -File pack-release.ps1 -Version 1.0.0

  产出（项目根目录下 dist\）：
      mc-launcher-<版本>.zip   上传到 GitHub Release 的资产（资产名必须与 apps.json 里一致）
      apps.json                应用商店索引，已填好实测的 size 与 sha256

  为什么包内要带 start-mc-launcher.bat 和 config.properties：
  商店会把应用装到 Winllx/apps/<id>/，该目录下
    1) 默认游戏目录会被算成 Winllx/apps/Winllx/minecraft（多了一层 apps）；
    2) mc-launcher 只向上找两层 lib/jbr，而 lib/jbr 在项目根（第 3 层），找不到内置 JBR。
  因此启动脚本改成「cd 到自己目录 + 向上探测 lib/jbr」，并用只进 zip 的 config.properties
  把 gameDir 指回 <项目根>/Winllx/minecraft（与主程序共用同一份 Minecraft 版本库）。
  这些都不改动 mc-launcher 源码，开发时 run.bat 的行为完全不变。
#>
param(
    [string]$Version = "1.0.0"
)

$ErrorActionPreference = "Stop"

$mcDir     = $PSScriptRoot
$root      = Split-Path -Parent $mcDir
$javac     = Join-Path $root "lib\jbr\bin\javac.exe"
$outDir    = Join-Path $mcDir "out"
$stage     = Join-Path $env:TEMP ("mc-launcher-stage-" + $Version)
$distDir   = Join-Path $root "dist"
$zipName   = "mc-launcher-" + $Version + ".zip"
$zipPath   = Join-Path $distDir $zipName
$indexPath = Join-Path $distDir "apps.json"
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)

if (-not (Test-Path $javac)) { throw ("未找到内置 JDK: " + $javac) }

# ===== 1/4 编译 =====
Write-Host "== 1/4 编译 mc-launcher ==" -ForegroundColor Cyan
Remove-Item -Recurse -Force $outDir -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force $outDir | Out-Null
$srcDir = Join-Path $mcDir "src\mc"
$sources = @(Get-ChildItem -Path $srcDir -Filter *.java | ForEach-Object { $_.FullName })
if ($sources.Count -eq 0) { throw ("未找到源码: " + $srcDir) }
& $javac -encoding UTF-8 -d $outDir $sources
if ($LASTEXITCODE -ne 0) { throw "编译失败" }
Write-Host ("   编译 OK -> " + $outDir)

# ===== 2/4 组装发布目录 =====
Write-Host "== 2/4 组装发布目录 ==" -ForegroundColor Cyan
Remove-Item -Recurse -Force $stage -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force $stage | Out-Null
Copy-Item -Recurse $outDir (Join-Path $stage "app")

# 启动脚本：ASCII 内容，避免批处理在不同代码页下解析出错
$bat = @'
@echo off
setlocal
cd /d "%~dp0"

rem look upward for the bundled JBR (%~dp0 already ends with a backslash)
set "JBR="
if exist "%~dp0lib\jbr\bin\java.exe" set "JBR=%~dp0lib\jbr"
if not defined JBR if exist "%~dp0..\lib\jbr\bin\java.exe" set "JBR=%~dp0..\lib\jbr"
if not defined JBR if exist "%~dp0..\..\lib\jbr\bin\java.exe" set "JBR=%~dp0..\..\lib\jbr"
if not defined JBR if exist "%~dp0..\..\..\lib\jbr\bin\java.exe" set "JBR=%~dp0..\..\..\lib\jbr"

if defined JBR (
    set "JAVA_HOME=%JBR%"
    set "JAVA=%JBR%\bin\java.exe"
) else (
    if defined JAVA_HOME (
        set "JAVA=%JAVA_HOME%\bin\java.exe"
    ) else (
        set "JAVA=java"
    )
)

if not exist "app\mc\Main.class" (
    echo [ERROR] app\mc\Main.class not found - package looks broken.
    pause
    exit /b 1
)

echo Starting mc-launcher ...
"%JAVA%" -cp app mc.Main
if errorlevel 1 (
    echo.
    echo [ERROR] mc-launcher exited abnormally.
    pause
    exit /b 1
)
'@
$bat = $bat -replace "`r?`n", "`r`n"
[System.IO.File]::WriteAllText((Join-Path $stage "start-mc-launcher.bat"), $bat, (New-Object System.Text.ASCIIEncoding))

# 包内配置：gameDir 必须用正斜杠（.properties 里反斜杠是转义字符）
$config = "gameDir=../../minecraft`r`n"
[System.IO.File]::WriteAllText((Join-Path $stage "config.properties"), $config, (New-Object System.Text.ASCIIEncoding))

Write-Host ("   发布目录 -> " + $stage)

# ===== 3/4 压缩 =====
# 不用 Compress-Archive：PS 5.1 会写出反斜杠分隔的条目名（非标准），改用 ZipArchive 手写正斜杠
Write-Host "== 3/4 压缩 zip ==" -ForegroundColor Cyan
New-Item -ItemType Directory -Force $distDir | Out-Null
Remove-Item -Force $zipPath -ErrorAction SilentlyContinue
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$stageFull = (Get-Item $stage).FullName
$zip = [System.IO.Compression.ZipFile]::Open($zipPath, [System.IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($f in (Get-ChildItem -Path $stage -Recurse -File | Sort-Object FullName)) {
        $rel = $f.FullName.Substring($stageFull.Length).TrimStart('\', '/').Replace('\', '/')
        $entry = $zip.CreateEntry($rel, [System.IO.Compression.CompressionLevel]::Optimal)
        $entry.LastWriteTime = $f.LastWriteTime
        $out = $entry.Open()
        try {
            $in = [System.IO.File]::OpenRead($f.FullName)
            try { $in.CopyTo($out) } finally { $in.Dispose() }
        } finally { $out.Dispose() }
    }
} finally {
    $zip.Dispose()
}
$size = (Get-Item $zipPath).Length
$sha  = (Get-FileHash $zipPath -Algorithm SHA256).Hash.ToLower()
Write-Host ("   " + $zipPath)
Write-Host ("   size = " + $size + " 字节")
Write-Host ("   sha256 = " + $sha)

# ===== 4/4 生成应用商店索引 =====
Write-Host "== 4/4 生成 apps.json ==" -ForegroundColor Cyan
$desc = "Minecraft 启动器：版本与加载器（Fabric/Quilt/Forge/NeoForge）下载、多实例管理、Mod 更新检查"
$assetUrl = "https://github.com/<owner>/<repo>/releases/download/v" + $Version + "/" + $zipName
$homeUrl  = "https://github.com/<owner>/<repo>"
$apps = @"
[
  {
    "id": "mc-launcher",
    "name": "Minecraft 启动器",
    "description": "$desc",
    "version": "$Version",
    "asset": "$assetUrl",
    "sha256": "$sha",
    "size": $size,
    "homepage": "$homeUrl"
  }
]
"@
[System.IO.File]::WriteAllText($indexPath, $apps, $utf8NoBom)
Write-Host ("   " + $indexPath)

Write-Host ""
Write-Host "完成。上传步骤：" -ForegroundColor Green
Write-Host ("  1) 把 " + $zipName + " 上传到 GitHub Release，tag 用 v" + $Version + "，资产名保持 " + $zipName)
Write-Host "  2) 把 apps.json 里的 <owner>/<repo> 换成你的仓库"
Write-Host "  3) 把 apps.json 放到仓库根目录（RAW 可访问），或在商店「加速」面板填写它的地址"
