package mc;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** 单窗口启动器外壳：顶部导航（启动 / 下载 / Mod / 设置）+ 共用底部日志与状态栏。 */
public final class LauncherUI {

    private static final String CARD_LAUNCH = "启动";
    private static final String CARD_DOWNLOAD = "下载";
    private static final String CARD_INSTANCES = "实例";
    private static final String CARD_MODS = "Mod";
    private static final String CARD_SETTINGS = "设置";

    private final JFrame frame = new JFrame("Minecraft 启动器");
    private final Settings settings = Settings.load();

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel cards = new JPanel(cardLayout);

    /** 两个下拉共用同一个模型，切换页面时选择保持同步。 */
    private final DefaultComboBoxModel<Installer.VersionEntry> versionModel = new DefaultComboBoxModel<>();
    private final JComboBox<Installer.VersionEntry> launchVersionCombo = new JComboBox<>(versionModel);
    private final JComboBox<Installer.VersionEntry> downloadVersionCombo = new JComboBox<>(versionModel);

    private final JTextField nameField = new JTextField(16);
    private final JLabel gameDirLabel = new JLabel(" ");
    private final JLabel accountLabel = new JLabel(" ");
    private final JLabel requireLabel = new JLabel(" ");
    private final JLabel downloadRequireLabel = new JLabel(" ");
    /** 最近一次启动的耗时摘要（准备 / 启动 / 总计）。 */
    private final JLabel launchStatsLabel = new JLabel(" ");

    private final JCheckBox snapshotBox = new JCheckBox("显示快照版本");
    private final JCheckBox ancientBox = new JCheckBox("显示远古版本（Alpha / Beta）");
    private final JCheckBox aprilBox = new JCheckBox("只看愚人节版本");
    private final JTextField versionSearchField = new JTextField(12);
    private final JButton downloadBtn = new JButton("下载 / 更新");
    private final JButton launchBtn = new JButton("启动游戏");
    private final JButton refreshBtn = new JButton("刷新版本列表");

    // 加载器（Fabric / Quilt / Legacy Fabric / Forge / NeoForge）
    private final JComboBox<LoaderInstaller.Loader> loaderCombo = new JComboBox<>(LoaderInstaller.Loader.values());
    private final JComboBox<LoaderInstaller.Option> loaderVersionCombo = new JComboBox<>();
    private final JLabel loaderStatus = new JLabel(" ");
    private boolean loaderVersionsLoading;
    /** 程序化改动加载器下拉时抑制事件，避免重复触发版本列表请求。 */
    private boolean pickingLoader;

    private final JProgressBar bar = new JProgressBar();
    private final JLabel statusLabel = new JLabel("就绪");
    private final JTextArea logArea = new JTextArea();

    private final Installer.Progress progress = new Installer.Progress();
    private final ArrayDeque<String> logQueue = new ArrayDeque<>();
    private final Map<String, VersionMeta> metaCache = new HashMap<>();
    /** 最近一次拉到的版本清单；筛选 / 搜索时据此离线重建下拉，不重复请求。 */
    private Installer.Manifest lastManifest;
    private boolean currentUnsupported;
    private boolean javaBusy;

    private Installer installer;
    private File installerDir;
    private JavaRuntime.Java jre;
    /** 已探测到的所有 Java 运行时，供实例级 Java 覆盖直接命中。 */
    private List<JavaRuntime.Java> detectedJava = new ArrayList<>();
    /** 实例指定但不在探测列表里的 Java 路径 → 现场探测结果缓存，避免重复起进程。 */
    private final Map<String, JavaRuntime.Java> instanceJavaCache = new HashMap<>();
    /** 正在运行的游戏进程（支持多开，逐个记录）。 */
    private final Map<Long, Process> runningGames = new HashMap<>();
    private SettingsPanel settingsPanel;
    private ModsPanel modsPanel;
    private InstancesPanel instancesPanel;

    public LauncherUI() {
        buildUi();
        restoreAccountAsync();
        detectJavaAsync();
        loadManifestAsync(false);

        new Timer(200, e -> {
            drainLog();
            updateProgress();
        }).start();
    }

    public void show() {
        frame.setVisible(true);
    }

    // ===== 界面骨架 =====

    private void buildUi() {
        settingsPanel = new SettingsPanel(settings, settingsListener, this::log);
        // 「默认实例」未设置时跟随启动页当前选中的版本
        modsPanel = new ModsPanel(settings, this::log, () -> {
            Installer.VersionEntry e = selected();
            return e == null ? null : e.id;
        });
        instancesPanel = new InstancesPanel(settings, this::log, new InstancesPanel.Listener() {
            @Override
            public void onInstanceSettingsChanged(String id) {
                // 实例设置会影响启动参数（Java / 内存 / 窗口 / 追加参数 / 游戏目录）
                Installer.VersionEntry e = selected();
                if (e != null && e.id.equals(id)) {
                    updateGameDirLabel();
                    refreshRequirement(e.id, metaCache.get(e.id));
                }
            }

            @Override
            public void onInstancesChanged() {
                // 导入实例后在 versions 目录多了一个版本，需要重新扫描版本列表
                loadManifestAsync(true);
            }
        }, () -> {
            Installer.VersionEntry e = selected();
            return e == null ? null : e.id;
        });

        JPanel nav = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 8));
        nav.setBorder(new EmptyBorder(0, 8, 0, 8));
        ButtonGroup group = new ButtonGroup();
        addNav(nav, group, CARD_LAUNCH, true, null);
        addNav(nav, group, CARD_DOWNLOAD, false, null);
        addNav(nav, group, CARD_INSTANCES, false, instancesPanel::onShown);
        addNav(nav, group, CARD_MODS, false, modsPanel::onShown);
        addNav(nav, group, CARD_SETTINGS, false, settingsPanel::refreshInstances);

        cards.setBorder(new EmptyBorder(0, 8, 0, 8));
        cards.add(buildLaunchPage(), CARD_LAUNCH);
        cards.add(buildDownloadPage(), CARD_DOWNLOAD);
        cards.add(instancesPanel, CARD_INSTANCES);
        cards.add(modsPanel, CARD_MODS);
        cards.add(settingsPanel, CARD_SETTINGS);

        logArea.setEditable(false);
        logArea.setFont(logFont());
        JScrollPane logScroll = new JScrollPane(logArea);
        logScroll.setPreferredSize(new Dimension(980, 210));
        logScroll.setBorder(null);

        JPanel statusRow = new JPanel(new BorderLayout(8, 4));
        statusRow.add(bar, BorderLayout.CENTER);
        statusRow.add(statusLabel, BorderLayout.EAST);

        JPanel bottom = new JPanel(new BorderLayout(8, 4));
        bottom.setBorder(new EmptyBorder(4, 8, 8, 8));
        bottom.add(logScroll, BorderLayout.CENTER);
        bottom.add(statusRow, BorderLayout.SOUTH);

        frame.setLayout(new BorderLayout());
        frame.add(nav, BorderLayout.NORTH);
        frame.add(cards, BorderLayout.CENTER);
        frame.add(bottom, BorderLayout.SOUTH);
        frame.setSize(1020, 800);
        frame.setMinimumSize(new Dimension(760, 560));
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                saveConfig();
                if (!runningGames.isEmpty()) {
                    log("启动器退出，但仍有 " + runningGames.size() + " 个游戏进程在运行（PID "
                            + String.join(", ", runningGames.keySet().stream().map(String::valueOf).toList()) + "）");
                }
                frame.dispose();
                System.exit(0);
            }
        });

        // 玩家名：实时写回设置（关闭窗口时统一落盘）
        nameField.getDocument().addDocumentListener(simple(() -> settings.username = nameField.getText()));
        nameField.setText(settings.username);

        snapshotBox.setSelected(settings.showSnapshots);
        snapshotBox.addActionListener(e -> {
            settings.showSnapshots = snapshotBox.isSelected();
            settings.save();
            reloadFromCache();
        });

        aprilBox.setSelected(settings.aprilOnly);
        aprilBox.addActionListener(e -> {
            settings.aprilOnly = aprilBox.isSelected();
            settings.save();
            reloadFromCache();
        });

        ancientBox.setSelected(settings.showAncient);
        ancientBox.addActionListener(e -> {
            settings.showAncient = ancientBox.isSelected();
            settings.save();
            reloadFromCache();
        });

        versionSearchField.getDocument().addDocumentListener(simple(this::reloadFromCache));

        refreshBtn.addActionListener(e -> loadManifestAsync(true));
        downloadBtn.addActionListener(e -> doInstall());
        launchBtn.addActionListener(e -> doLaunch());

        launchVersionCombo.addActionListener(e -> onVersionChanged());
        downloadVersionCombo.addActionListener(e -> onVersionChanged());

        // 加载器选择：恢复上次的选择，切换加载器或目标版本时重新拉取可用版本列表
        pickingLoader = true;
        loaderCombo.setSelectedItem(LoaderInstaller.Loader.bySlug(settings.loader));
        pickingLoader = false;
        loaderCombo.addActionListener(e -> {
            if (!pickingLoader) loadLoaderVersionsAsync();
        });
        onLoaderChanged();
    }

    private void addNav(JPanel nav, ButtonGroup group, String name, boolean selected, Runnable onShow) {
        JToggleButton b = new JToggleButton(name);
        b.setFocusPainted(false);
        b.setSelected(selected);
        b.setPreferredSize(new Dimension(92, 30));
        b.addActionListener(e -> {
            cardLayout.show(cards, name);
            if (onShow != null) onShow.run();
        });
        group.add(b);
        nav.add(b);
    }

    private JPanel buildLaunchPage() {
        JPanel p = page();

        JPanel row1 = row();
        row1.add(new JLabel("版本："));
        launchVersionCombo.setPreferredSize(new Dimension(300, 26));
        row1.add(launchVersionCombo);
        row1.add(requireLabel);
        p.add(row1);

        JPanel row2 = row();
        row2.add(new JLabel("玩家名："));
        nameField.setPreferredSize(new Dimension(200, 26));
        row2.add(nameField);
        row2.add(accountLabel);
        p.add(row2);

        JPanel row3 = row();
        gameDirLabel.setForeground(new Color(110, 110, 110));
        row3.add(gameDirLabel);
        p.add(row3);

        JPanel row4 = row();
        launchBtn.setPreferredSize(new Dimension(140, 32));
        row4.add(launchBtn);
        JButton statsBtn = new JButton("启动耗时记录");
        statsBtn.setToolTipText("查看每次启动的「准备 / 启动 / 总计」耗时历史");
        statsBtn.addActionListener(e -> showLaunchStats());
        row4.add(statsBtn);
        p.add(row4);

        JPanel row4b = row();
        launchStatsLabel.setForeground(new Color(60, 110, 60));
        row4b.add(launchStatsLabel);
        p.add(row4b);

        JPanel row5 = row();
        JLabel tip = new JLabel("提示：Java、内存、窗口大小、实例隔离等均在「设置」页调整；单实例的 Java / 内存 / 参数在「实例」页。");
        tip.setForeground(new Color(110, 110, 110));
        row5.add(tip);
        p.add(row5);

        p.add(Box.createVerticalGlue());
        return p;
    }

    private JPanel buildDownloadPage() {
        JPanel p = page();

        JPanel row1 = row();
        row1.add(new JLabel("版本："));
        downloadVersionCombo.setPreferredSize(new Dimension(300, 26));
        row1.add(downloadVersionCombo);
        row1.add(refreshBtn);
        row1.add(snapshotBox);
        snapshotBox.setToolTipText("显示 type=snapshot 的快照版本（加载器实例不受此项限制）");
        row1.add(ancientBox);
        ancientBox.setToolTipText("显示 2010 年以前的 Alpha / Beta 远古版本");
        row1.add(aprilBox);
        aprilBox.setToolTipText("愚人节版本都是快照，混在近千个快照里很难翻；勾选后只显示这些版本");
        p.add(row1);

        JPanel row1b = row();
        row1b.add(new JLabel("搜索："));
        versionSearchField.setPreferredSize(new Dimension(180, 26));
        versionSearchField.setToolTipText("按版本号模糊匹配，例如 1.20、1.7.10、fabric、forge");
        row1b.add(versionSearchField);
        JButton clearSearch = new JButton("清除");
        clearSearch.addActionListener(e -> {
            versionSearchField.setText("");
            reloadFromCache();
        });
        row1b.add(clearSearch);
        JLabel searchTip = new JLabel("匹配版本号中的任意片段，大小写不敏感；已安装的本地实例永远显示。");
        searchTip.setForeground(new Color(110, 110, 110));
        row1b.add(searchTip);
        p.add(row1b);

        JPanel row2 = row();
        row2.add(new JLabel("加载器："));
        loaderCombo.setPreferredSize(new Dimension(190, 26));
        loaderCombo.setToolTipText("下载原版之外再安装一个 mod 加载器；加载器实例会带上原版的全部依赖与资源");
        row2.add(loaderCombo);
        loaderVersionCombo.setPreferredSize(new Dimension(200, 26));
        loaderVersionCombo.setToolTipText("该加载器支持的版本；列表按所选 Minecraft 版本过滤");
        row2.add(loaderVersionCombo);
        row2.add(loaderStatus);
        p.add(row2);

        JPanel row3 = row();
        downloadRequireLabel.setForeground(new Color(110, 110, 110));
        row3.add(downloadRequireLabel);
        p.add(row3);

        JPanel row4 = row();
        downloadBtn.setPreferredSize(new Dimension(140, 32));
        row4.add(downloadBtn);
        JLabel tip = new JLabel("下载包含客户端、依赖库、原生库解压与游戏资源，已存在的文件会自动跳过。");
        tip.setForeground(new Color(110, 110, 110));
        row4.add(tip);
        p.add(row4);

        JPanel row5 = row();
        JLabel tip2 = new JLabel("加载器说明：Fabric / Quilt / Legacy Fabric 直接生成实例；"
                + "Forge / NeoForge 调用官方安装器（会为客户端打补丁），需要可用的 Java。");
        tip2.setForeground(new Color(110, 110, 110));
        row5.add(tip2);
        p.add(row5);

        p.add(Box.createVerticalGlue());
        return p;
    }

    private static JPanel page() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(new EmptyBorder(14, 8, 8, 8));
        p.setOpaque(false);
        return p;
    }

    private static JPanel row() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 3));
        p.setOpaque(false);
        p.setAlignmentX(Component.LEFT_ALIGNMENT);
        return p;
    }

    /**
     * 日志区字体必须含中文字形。
     * 等宽字体（Consolas / Courier New）在 Windows 上普遍没有汉字，会把中文显示成方框问号。
     */
    private static Font logFont() {
        Font base = UIManager.getFont("TextArea.font");
        if (base != null) return base.deriveFont(12f);
        return new Font(Font.DIALOG, Font.PLAIN, 12);
    }

    /** 弹窗内文本区字体（同样必须含中文字形）。 */
    private static Font reportFont() {
        Font base = UIManager.getFont("TextArea.font");
        return base != null ? base.deriveFont(12f) : new Font(Font.DIALOG, Font.PLAIN, 12);
    }

    private static javax.swing.event.DocumentListener simple(Runnable r) {
        return new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
        };
    }

    // ===== 设置页回调 =====

    private final SettingsPanel.Listener settingsListener = new SettingsPanel.Listener() {
        @Override
        public void onChanged() {
            updateGameDirLabel();
        }

        @Override
        public void onGameDirChanged() {
            installer = null;
            installerDir = null;
            metaCache.clear();
            setLaunchEnabled(false);
            loadManifestAsync(false);
        }

        @Override
        public void onJavaPathChanged() {
            detectJavaAsync();
        }

        @Override
        public void onLoginRequested() {
            doLogin();
        }

        @Override
        public void onLogoutRequested() {
            doLogout();
        }
    };

    // ===== 账号（正版验证） =====

    /** 本次会话的登录凭据；为空表示使用离线模式。 */
    private MsAuth.Account account;
    private boolean loginBusy;
    private JDialog deviceDialog;

    /** 启动时用保存的刷新令牌免密登录。 */
    private void restoreAccountAsync() {
        updateAccountUi();
        if (!settings.isMsa()) return;
        new Thread(() -> {
            try {
                MsAuth.Account acc = MsAuth.refresh(settings.clientIdOr(), settings.msaRefreshToken, this::log);
                SwingUtilities.invokeLater(() -> {
                    applyAccount(acc, true);
                    statusLabel.setText("已自动登录微软账号：" + acc.name);
                });
            } catch (Exception ex) {
                final String msg = ex.getMessage() == null ? ex.toString() : ex.getMessage();
                SwingUtilities.invokeLater(() -> {
                    log("自动登录失败：" + msg);
                    // 令牌被撤销 / 过期时清理掉，避免每次启动都失败
                    if (msg.contains("invalid_grant") || msg.contains("重新登录")) {
                        clearAccount();
                        log("已清除失效的登录凭据，请在设置页重新登录");
                    }
                    updateAccountUi();
                });
            }
        }, "msa-restore").start();
    }

    private void doLogin() {
        if (loginBusy) return;
        loginBusy = true;
        settingsPanel.setLoginBusy(true);
        final String clientId = settings.clientIdOr();
        new Thread(() -> {
            try {
                MsAuth.Account acc = MsAuth.login(clientId, this::log,
                        dc -> SwingUtilities.invokeLater(() -> showDeviceCode(dc)));
                SwingUtilities.invokeLater(() -> {
                    loginBusy = false;
                    settingsPanel.setLoginBusy(false);
                    closeDeviceDialog();
                    applyAccount(acc, true);
                    statusLabel.setText("已登录微软账号：" + acc.name);
                });
            } catch (Exception ex) {
                final String msg = ex.getMessage() == null ? ex.toString() : ex.getMessage();
                SwingUtilities.invokeLater(() -> {
                    loginBusy = false;
                    settingsPanel.setLoginBusy(false);
                    closeDeviceDialog();
                    log("登录失败：" + msg);
                    statusLabel.setText("登录失败");
                    JOptionPane.showMessageDialog(frame, msg, "登录失败", JOptionPane.ERROR_MESSAGE);
                });
            }
        }, "msa-login").start();
    }

    private void doLogout() {
        clearAccount();
        log("已退出微软账号，切换为离线模式");
        statusLabel.setText("已退出登录");
        updateAccountUi();
    }

    private void clearAccount() {
        account = null;
        settings.accountMode = "offline";
        settings.msaRefreshToken = "";
        settings.msaUuid = "";
        settings.msaName = "";
        settings.msaXuid = "";
        settings.save();
    }

    /** 登录成功：写入设置并刷新界面。 */
    private void applyAccount(MsAuth.Account acc, boolean persist) {
        account = acc;
        settings.accountMode = "msa";
        if (persist) {
            settings.msaRefreshToken = acc.refreshToken == null ? "" : acc.refreshToken;
            settings.msaUuid = acc.uuid == null ? "" : acc.uuid;
            settings.msaName = acc.name == null ? "" : acc.name;
            settings.msaXuid = acc.xuid == null ? "" : acc.xuid;
            settings.save();
        }
        updateAccountUi();
    }

    private void updateAccountUi() {
        boolean msa = settings.isMsa();
        boolean live = account != null;
        if (live) {
            accountLabel.setText("  账号：正版 " + account.name);
            accountLabel.setForeground(new Color(20, 128, 60));
        } else if (msa) {
            accountLabel.setText("  账号：微软账号待登录（见「设置 → 账号」）");
            accountLabel.setForeground(new Color(190, 60, 40));
        } else {
            accountLabel.setText("  账号：离线模式");
            accountLabel.setForeground(new Color(110, 110, 110));
        }
        // 正版模式下玩家名由账号决定，禁止手工填写
        nameField.setEnabled(!live);
        if (live) nameField.setText(account.name);
        if (settingsPanel != null) settingsPanel.refreshAccount();
    }

    /** 设备码对话框：非模态，登录完成后自动关闭。 */
    private void showDeviceCode(MsAuth.DeviceCode dc) {
        closeDeviceDialog();
        JDialog d = new JDialog(frame, "微软账号登录", false);
        d.setLayout(new BorderLayout(0, 10));

        JLabel tip = new JLabel("<html><body style='width:420px'>请在浏览器中打开 <b>" + dc.verificationUri
                + "</b><br>并输入下面的代码完成授权（" + (dc.expiresIn / 60) + " 分钟内有效）：</body></html>");
        tip.setBorder(new EmptyBorder(14, 14, 0, 14));

        JTextField codeField = new JTextField(dc.userCode);
        codeField.setEditable(false);
        codeField.setHorizontalAlignment(JTextField.CENTER);
        codeField.setFont(codeField.getFont().deriveFont(Font.BOLD, 22f));
        codeField.setBorder(new EmptyBorder(8, 8, 8, 8));

        JButton copy = new JButton("复制代码并打开浏览器");
        copy.addActionListener(e -> {
            Toolkit.getDefaultToolkit().getSystemClipboard()
                    .setContents(new java.awt.datatransfer.StringSelection(dc.userCode), null);
            browse(dc.verificationUri);
            log("已复制设备码 " + dc.userCode + " 并打开浏览器");
        });
        JPanel south = new JPanel(new FlowLayout(FlowLayout.CENTER));
        south.add(copy);

        d.add(tip, BorderLayout.NORTH);
        d.add(codeField, BorderLayout.CENTER);
        d.add(south, BorderLayout.SOUTH);
        d.setSize(500, 200);
        d.setLocationRelativeTo(frame);
        d.setVisible(true);
        deviceDialog = d;
    }

    private void closeDeviceDialog() {
        if (deviceDialog != null) {
            deviceDialog.dispose();
            deviceDialog = null;
        }
    }

    private static void browse(String url) {
        try {
            if (Desktop.isDesktopSupported()) Desktop.getDesktop().browse(java.net.URI.create(url));
        } catch (Exception ignore) {
            // 打不开浏览器时用户可手动访问，设备码已复制到剪贴板
        }
    }

    // ===== 日志与进度 =====

    private void log(String message) {
        String line = "[" + java.time.LocalTime.now().withNano(0) + "] " + message;
        synchronized (logQueue) {
            logQueue.addLast(line);
        }
    }

    private void drainLog() {
        List<String> batch = new ArrayList<>();
        synchronized (logQueue) {
            while (!logQueue.isEmpty() && batch.size() < 200) batch.add(logQueue.pollFirst());
        }
        if (batch.isEmpty()) return;
        for (String s : batch) logArea.append(s + "\n");
        if (logArea.getDocument().getLength() > 400_000) {
            try {
                logArea.getDocument().remove(0, 200_000);
            } catch (Exception ignore) {
                // 截断失败不影响后续输出
            }
        }
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    private void updateProgress() {
        if (progress.total > 0) {
            bar.setIndeterminate(false);
            bar.setMaximum((int) Math.min(Integer.MAX_VALUE, progress.total));
            bar.setValue((int) Math.min(Integer.MAX_VALUE, progress.done));
        } else {
            bar.setIndeterminate(progress.running);
            if (!progress.running) {
                bar.setMaximum(100);
                bar.setValue(0);
            }
        }
        StringBuilder sb = new StringBuilder();
        if (progress.running) {
            sb.append(progress.stage);
            if (progress.total > 0) sb.append("  ").append(progress.done).append("/").append(progress.total);
            if (progress.bytes > 0) sb.append("  ").append(progress.bytes / 1024 / 1024).append(" MB");
            if (progress.detail != null && !progress.detail.isEmpty()) sb.append("（").append(progress.detail).append("）");
            statusLabel.setText(sb.toString());
        }
    }

    private void setBusy(boolean busy) {
        downloadBtn.setEnabled(!busy && !currentUnsupported);
        refreshBtn.setEnabled(!busy);
        snapshotBox.setEnabled(!busy);
        launchVersionCombo.setEnabled(!busy);
        downloadVersionCombo.setEnabled(!busy);
        launchBtn.setEnabled(!busy && installer != null && installer.isReady());
    }

    /** 版本信息不完整（例如加载器实例缺少父版本）时禁掉下载按钮并给出说明。 */
    private void applyUnsupported(boolean unsupported) {
        currentUnsupported = unsupported;
        downloadBtn.setEnabled(!unsupported && !progress.running);
        downloadBtn.setToolTipText(unsupported
                ? "该版本的版本信息不完整（缺少所继承的原版版本），请先在「下载」页下载对应的原版版本"
                : null);
    }

    private Installer.VersionEntry selected() {
        return (Installer.VersionEntry) launchVersionCombo.getSelectedItem();
    }

    /** 取得与当前安装目录绑定的安装器；目录变化时重建，否则复用（保留已下载状态）。 */
    private Installer installer() {
        File dir = settings.baseDir();
        if (installer == null || !dir.equals(installerDir)) {
            installer = new Installer(dir, progress, this::log);
            installerDir = dir;
        }
        return installer;
    }

    private void updateGameDirLabel() {
        Installer.VersionEntry e = selected();
        File dir = settings.instanceDir(e == null ? null : e.id);
        gameDirLabel.setText("游戏目录：" + dir.getAbsolutePath()
                + (settings.instanceIsolation ? "（实例隔离已开启）" : ""));
    }

    // ===== Java 检测 =====

    private void detectJavaAsync() {
        if (javaBusy) return;
        javaBusy = true;
        if (settingsPanel != null) settingsPanel.setJavaBusy(true);
        final String configured = settings.javaPath;
        new Thread(() -> {
            List<JavaRuntime.Java> found = JavaRuntime.detectAll(configured, this::log);
            SwingUtilities.invokeLater(() -> {
                javaBusy = false;
                detectedJava = found;
                jre = found.isEmpty() ? null : found.get(0);
                if (settingsPanel != null) settingsPanel.setJavaList(found);
                if (instancesPanel != null) instancesPanel.setJavaList(found);
                log(jre == null ? "未找到可用的 Java（已检查指定路径 / 内置 lib/jbr / JAVA_HOME / PATH / 系统安装目录）"
                        : "当前使用 " + jre.describe());
                Installer.VersionEntry cur = selected();
                if (cur != null) refreshRequirement(cur.id, metaCache.get(cur.id));
            });
        }, "detect-java").start();
    }

    // ===== 版本列表 =====

    private void loadManifestAsync(boolean force) {
        refreshBtn.setEnabled(false);
        launchVersionCombo.setEnabled(false);
        downloadVersionCombo.setEnabled(false);
        Installer inst = installer();
        new Thread(() -> {
            try {
                Installer.Manifest m = inst.loadManifest(force);
                SwingUtilities.invokeLater(() -> applyManifest(m));
            } catch (Exception ex) {
                log("版本列表加载失败：" + ex.getMessage());
                SwingUtilities.invokeLater(() -> statusLabel.setText("版本列表加载失败"));
            } finally {
                SwingUtilities.invokeLater(() -> {
                    refreshBtn.setEnabled(true);
                    launchVersionCombo.setEnabled(true);
                    downloadVersionCombo.setEnabled(true);
                });
            }
        }, "manifest-load").start();
    }

    private void reloadFromCache() {
        // 已经拿到清单时只重建列表，不再重复请求（搜索框每敲一个字都走这里）
        if (lastManifest != null) {
            rebuildVersionModel();
            return;
        }
        loadManifestAsync(false);
    }

    private void applyManifest(Installer.Manifest m) {
        lastManifest = m;
        rebuildVersionModel();
        log("版本列表就绪：显示 " + versionModel.getSize() + " 个" + filterSummary()
                + "，最新正式版 " + m.latestRelease + "，最新快照 " + m.latestSnapshot);
        onVersionChanged();
    }

    /** 当前生效的筛选条件说明，用于日志与状态提示。 */
    private String filterSummary() {
        List<String> parts = new ArrayList<>();
        if (aprilBox.isSelected()) parts.add("仅愚人节版本");
        else if (snapshotBox.isSelected()) parts.add("含快照版本");
        else parts.add("仅正式版");
        if (ancientBox.isSelected()) parts.add("含远古版本");
        String q = searchQuery();
        if (!q.isEmpty()) parts.add("搜索「" + q + "」");
        return "（" + String.join(" · ", parts) + "）";
    }

    private String searchQuery() {
        return versionSearchField.getText() == null ? "" : versionSearchField.getText().trim().toLowerCase();
    }

    /** 按勾选项与搜索框重建版本下拉（本地已安装实例始终显示）。 */
    private void rebuildVersionModel() {
        Installer.Manifest m = lastManifest;
        if (m == null) return;
        boolean showSnapshots = snapshotBox.isSelected();
        boolean showAncient = ancientBox.isSelected();
        boolean aprilOnly = aprilBox.isSelected();
        String query = searchQuery();

        Installer.VersionEntry previous = selected();
        String previousId = previous == null ? null : previous.id;
        versionModel.removeAllElements();
        for (Installer.VersionEntry e : m.versions) {
            // 本地已安装的实例永远显示：用户必须能看到自己刚装好的加载器实例
            if (e.local) {
                if (query.isEmpty() || e.id.toLowerCase().contains(query)) versionModel.addElement(e);
                continue;
            }
            if (aprilOnly) {
                // 愚人节筛选优先：愚人节版本本身就是快照，不再受「显示快照版本」影响
                if (Installer.isAprilFools(e.id) && matchesQuery(e.id, query)) versionModel.addElement(e);
                continue;
            }
            boolean typeOk = "release".equals(e.type)
                    || (showSnapshots && "snapshot".equals(e.type))
                    || (showAncient && isAncient(e.type));
            if (typeOk && matchesQuery(e.id, query)) versionModel.addElement(e);
        }
        // 优先恢复上次选择，否则定位到最新正式版（愚人节筛选下没有"最新正式版"，直接停在第 0 项）
        Installer.VersionEntry target = null;
        for (int i = 0; i < versionModel.getSize(); i++) {
            Installer.VersionEntry e = versionModel.getElementAt(i);
            if (e.id.equals(previousId)) {
                target = e;
                break;
            }
            if (target == null && !aprilOnly && e.id.equals(m.latestRelease)) target = e;
        }
        if (target != null) launchVersionCombo.setSelectedItem(target);
    }

    private static boolean matchesQuery(String id, String query) {
        return query.isEmpty() || id.toLowerCase().contains(query);
    }

    private static boolean isAncient(String type) {
        return "old_beta".equals(type) || "old_alpha".equals(type);
    }

    private void onVersionChanged() {
        Installer.VersionEntry e = selected();
        updateGameDirLabel();
        // 加载器版本列表是按 Minecraft 版本过滤的，切换版本后必须重新拉取
        if (e != null && selectedLoader() != LoaderInstaller.Loader.VANILLA) loadLoaderVersionsAsync();
        if (e == null) {
            requireLabel.setText(" ");
            downloadRequireLabel.setText(" ");
            setLaunchEnabled(false);
            applyUnsupported(false);
            return;
        }
        setLaunchEnabled(false);
        Installer inst = installer();

        VersionMeta cached = metaCache.get(e.id);
        if (cached != null) {
            refreshRequirement(e.id, cached);
            applyUnsupported(!cached.launchable());
            // 已缓存时仍要判断本地是否已下载完整
            new Thread(() -> {
                boolean ready = checkReady(inst, e, cached);
                SwingUtilities.invokeLater(() -> applyReadyState(e.id, cached, ready));
            }, "version-local").start();
        } else {
            requireLabel.setText("需要 Java：查询中…");
            downloadRequireLabel.setText("需要 Java：查询中…");
            downloadBtn.setEnabled(false);
            new Thread(() -> {
                VersionMeta vm;
                try {
                    File local = new File(inst.gameDir(), "versions/" + e.id + "/" + e.id + ".json");
                    // 本地版本要走"带继承合并"的读取，否则加载器实例拿不到 Java 版本要求、主类等信息
                    vm = local.isFile() ? inst.readMeta(e.id) : VersionMeta.parse(Net.getString(e.url));
                    if (vm == null) throw new IOException("本地版本信息解析失败");
                    metaCache.put(e.id, vm);
                } catch (Exception ex) {
                    SwingUtilities.invokeLater(() -> {
                        requireLabel.setText("需要 Java：查询失败");
                        downloadRequireLabel.setText("需要 Java：查询失败");
                    });
                    return;
                }
                boolean ready = checkReady(inst, e, vm);
                SwingUtilities.invokeLater(() -> {
                    refreshRequirement(e.id, vm);
                    applyUnsupported(!vm.launchable());
                    applyReadyState(e.id, vm, ready);
                });
            }, "version-meta").start();
        }
    }

    private boolean checkReady(Installer inst, Installer.VersionEntry e, VersionMeta vm) {
        if (progress.running || !vm.launchable()) return false;
        try {
            return inst.loadLocal(e);
        } catch (Exception ex) {
            log("读取已下载版本信息失败：" + ex.getMessage());
            return false;
        }
    }

    private void applyReadyState(String versionId, VersionMeta vm, boolean ready) {
        Installer.VersionEntry cur = selected();
        if (cur == null || !cur.id.equals(versionId)) return;
        setLaunchEnabled(ready);
        if (!vm.launchable()) {
            statusLabel.setText("版本 " + versionId + " 的版本信息不完整，无法启动");
        } else if (ready) {
            statusLabel.setText("版本 " + versionId + " 已就绪，可直接启动");
        } else {
            statusLabel.setText("版本 " + versionId + " 尚未下载");
        }
        applyUnsupported(!vm.launchable());
    }

    /** 刷新"需要 Java N"提示；版本元数据尚未取回时 vm 为 null。 */
    private void refreshRequirement(String versionId, VersionMeta vm) {
        if (vm == null) return;
        Installer.VersionEntry cur = selected();
        if (cur == null || !cur.id.equals(versionId)) return;
        if (!vm.launchable()) {
            requireLabel.setText("版本信息不完整（缺少所继承的原版版本）");
            downloadRequireLabel.setText("版本信息不完整，请先下载对应的原版版本");
            return;
        }
        boolean ok = jre != null && jre.major >= vm.javaVersionMajor;
        String text = "需要 Java " + vm.javaVersionMajor + (ok ? "（已满足）" : "（当前不满足）");
        requireLabel.setText(text);
        downloadRequireLabel.setText(text);
    }

    // ===== 加载器 =====

    /** 当前选择的加载器。 */
    private LoaderInstaller.Loader selectedLoader() {
        Object o = loaderCombo.getSelectedItem();
        return o instanceof LoaderInstaller.Loader l ? l : LoaderInstaller.Loader.VANILLA;
    }

    /** 加载器下拉变化：原版时禁用版本下拉，否则按当前选中的 Minecraft 版本拉取可用加载器版本。 */
    private void onLoaderChanged() {
        LoaderInstaller.Loader loader = selectedLoader();
        boolean vanilla = loader == LoaderInstaller.Loader.VANILLA;
        loaderVersionCombo.setEnabled(!vanilla && !loaderVersionsLoading);
        loaderVersionCombo.removeAllItems();
        if (vanilla) {
            loaderStatus.setText("仅下载原版");
            return;
        }
        loaderStatus.setText("查询 " + loader.label + " 可用版本…");
        loadLoaderVersionsAsync();
    }

    private void loadLoaderVersionsAsync() {
        final LoaderInstaller.Loader loader = selectedLoader();
        if (loader == LoaderInstaller.Loader.VANILLA) {
            onLoaderChanged();
            return;
        }
        final Installer.VersionEntry entry = selected();
        if (entry == null) {
            loaderStatus.setText("请先选择版本");
            return;
        }
        final String mc = entry.id;
        loaderVersionsLoading = true;
        loaderVersionCombo.setEnabled(false);
        loaderStatus.setText("查询 " + loader.label + " 可用版本…");
        new Thread(() -> {
            List<LoaderInstaller.Option> options = null;
            String error = null;
            try {
                options = LoaderInstaller.versions(loader, mc);
            } catch (Exception ex) {
                error = ex.getMessage() == null ? ex.toString() : ex.getMessage();
            }
            final List<LoaderInstaller.Option> list = options;
            final String err = error;
            SwingUtilities.invokeLater(() -> {
                loaderVersionsLoading = false;
                loaderVersionCombo.removeAllItems();
                if (err != null) {
                    loaderStatus.setText("加载器版本查询失败");
                    log("查询 " + loader.label + " 版本失败：" + err);
                    return;
                }
                for (LoaderInstaller.Option o : list) loaderVersionCombo.addItem(o);
                if (list.isEmpty()) {
                    loaderVersionCombo.setEnabled(false);
                    loaderStatus.setText("该版本没有可用的 " + loader.label);
                    return;
                }
                // 优先恢复上次选的加载器版本，否则用最新版
                LoaderInstaller.Option target = list.get(0);
                for (LoaderInstaller.Option o : list) {
                    if (o.id.equals(settings.loaderVersion)) target = o;
                }
                loaderVersionCombo.setSelectedItem(target);
                loaderVersionCombo.setEnabled(true);
                loaderStatus.setText(list.size() + " 个可用版本");
            });
        }, "loader-versions").start();
    }

    // ===== 下载 / 启动 =====

    private void doInstall() {
        Installer.VersionEntry entry = selected();
        if (entry == null) {
            statusLabel.setText("请先选择版本");
            return;
        }
        if (progress.running) {
            statusLabel.setText("已有任务在运行");
            return;
        }
        Installer inst = installer();
        LoaderInstaller.Loader loader = selectedLoader();
        LoaderInstaller.Option loaderOption =
                (LoaderInstaller.Option) loaderVersionCombo.getSelectedItem();

        // 加载器选择会持久化，下次打开启动器自动恢复
        settings.loader = loader.slug;
        settings.loaderVersion = loaderOption == null ? "" : loaderOption.id;
        settings.save();

        if (loader != LoaderInstaller.Loader.VANILLA && loaderOption == null) {
            statusLabel.setText("请先等待加载器版本列表加载完成");
            return;
        }

        setBusy(true);
        new Thread(() -> {
            boolean installed = false;
            try {
                if (loader == LoaderInstaller.Loader.VANILLA) {
                    inst.install(entry);
                } else {
                    log("=== 开始安装 " + loader.label + " " + loaderOption.id + "（Minecraft " + entry.id + "）===");
                    String id = LoaderInstaller.install(loader, entry.id, loaderOption.id,
                            inst.gameDir(), jre, inst, this::log);
                    log("=== " + loader.label + " 安装完成，实例：" + id + " ===");
                    installed = true;
                }
            } catch (Exception ex) {
                log("安装失败：" + ex.getMessage());
                progress.stage = "安装失败：" + ex.getMessage();
            } finally {
                progress.running = false;
                final boolean ok = installed || inst.isReady();
                final boolean viaLoader = installed;
                SwingUtilities.invokeLater(() -> {
                    setBusy(false);
                    setLaunchEnabled(inst.isReady());
                    // 下载后 versions 目录多了一个可选的 mod 安装目标
                    settingsPanel.refreshInstances();
                    modsPanel.refreshInstances();
                    instancesPanel.refreshInstances();
                    if (viaLoader && ok) {
                        // 刷新版本列表，让新实例出现在最前面并自动选中
                        loadManifestAsync(true);
                    }
                });
            }
        }, "install").start();
    }

    private void doLaunch() {
        Installer inst = installer();
        if (inst == null || !inst.isReady()) {
            statusLabel.setText("请先下载该版本");
            return;
        }
        // 耗时统计从"点击启动"这一刻开始计
        long clickTime = System.currentTimeMillis();
        Installer.VersionEntry entry = selected();
        String versionId = entry == null ? inst.meta().id : entry.id;

        // 正版模式：玩家名与凭据来自微软账号；离线模式：使用输入的玩家名
        final String username;
        if (settings.isMsa()) {
            if (account == null) {
                statusLabel.setText("微软账号尚未登录，请到「设置 → 账号」完成登录");
                return;
            }
            username = account.name;
        } else {
            username = nameField.getText().trim();
            if (username.isEmpty()) {
                statusLabel.setText("请填写玩家名");
                return;
            }
            settings.username = username;
        }

        VersionMeta meta = inst.meta();

        // 实例（版本）级覆盖：Java / 内存 / 窗口 / 追加参数 / 游戏目录 / 自动进服 / 全屏
        InstSettings is = InstSettings.load(settings.baseDir(), versionId);

        JavaRuntime.Java java = resolveJava(is, versionId);
        if (java == null) {
            statusLabel.setText("未找到可用的 Java");
            log("启动被拒绝：未找到可用的 Java（实例指定路径为空且全局也没有可用运行时）");
            return;
        }
        if (java.major < meta.javaVersionMajor) {
            String msg = "需要 Java " + meta.javaVersionMajor + "，当前只有 Java " + java.major + "（" + java.describe() + "）"
                    + (is.javaPath.isBlank() ? "，可在「实例 → 版本设置」为本版本单独指定 Java"
                                             : "，实例指定的 Java 版本过低");
            statusLabel.setText(msg);
            log("启动被拒绝：" + msg);
            return;
        }

        // 启动前完整性检查：loadLocal 会静默跳过缺失的依赖库，这里补一次显式校验
        List<String> problems = inst.checkIntegrity();
        if (!problems.isEmpty()) {
            String msg = "依赖不完整，已取消启动：\n  - " + String.join("\n  - ", problems)
                    + "\n\n请在「下载」页对该版本执行一次「下载 / 更新」补齐文件。";
            log("启动被拒绝：" + problems.size() + " 项依赖问题");
            for (String p : problems) log("  - " + p);
            statusLabel.setText("依赖不完整，请先补齐文件");
            JOptionPane.showMessageDialog(frame, msg, "启动前检查未通过", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 游戏目录：实例覆盖 >「实例隔离」规则
        File gameDir = is.gameDir.isBlank()
                ? settings.instanceDir(versionId)
                : new File(is.gameDir);
        try {
            Files.createDirectories(gameDir.toPath());
        } catch (IOException ex) {
            statusLabel.setText("无法创建游戏目录：" + ex.getMessage());
            log("无法创建游戏目录 " + gameDir + "：" + ex.getMessage());
            return;
        }

        if (!is.gameDir.isBlank()) log("实例 " + versionId + " 使用自定义游戏目录 " + gameDir.getAbsolutePath());
        else if (settings.instanceIsolation) log("实例隔离已开启，本次游戏目录 " + gameDir.getAbsolutePath());

        // 全屏：原版没有 --fullscreen 参数，只能改写该实例 options.txt 的 fullscreen 项
        if (!is.fullscreenMode.isBlank()) {
            try {
                InstanceTools.writeOptionLine(gameDir, "fullscreen", is.fullscreenMode);
                log("已按实例设置写入 options.txt：fullscreen:" + is.fullscreenMode);
            } catch (IOException ex) {
                log("写入 options.txt 的 fullscreen 项失败（不影响启动）：" + ex.getMessage());
            }
        }

        // 内存：实例覆盖 > 全局
        int memoryGb = settings.resolvedMemoryGb();
        if ("auto".equals(is.memoryMode)) memoryGb = Settings.autoMemoryGb();
        else if ("custom".equals(is.memoryMode)) memoryGb = Math.max(1, Math.min(64, is.memoryGb));

        // 窗口：实例覆盖 > 全局
        boolean customResolution = settings.customResolution;
        int width = settings.windowWidth;
        int height = settings.windowHeight;
        if ("custom".equals(is.resolutionMode)) {
            customResolution = true;
            width = is.width;
            height = is.height;
        } else if ("default".equals(is.resolutionMode)) {
            customResolution = false;
        }

        GameProcess.Options opt = new GameProcess.Options();
        opt.installDir = inst.gameDir();
        opt.gameDir = gameDir;
        opt.clientJar = inst.clientJar();
        opt.classpath = inst.classpath();
        opt.nativesDir = inst.nativesDir();
        opt.username = username;
        opt.maxMemoryGb = memoryGb;
        opt.customResolution = customResolution;
        opt.width = width;
        opt.height = height;
        opt.ipPreference = settings.ipPreference;
        opt.launcherName = settings.brandOr(GameProcess.LAUNCHER_NAME);
        opt.launcherVersion = settings.brandVersionOr(GameProcess.LAUNCHER_VERSION);
        if (account != null) {
            opt.authUuid = account.uuid;
            opt.authAccessToken = account.accessToken;
            opt.authXuid = account.xuid == null ? "0" : account.xuid;
            opt.userType = "msa";
        }

        // 追加 JVM / 游戏参数
        opt.extraJvmArgs = InstSettings.splitArgs(is.jvmArgs);
        opt.extraGameArgs = InstSettings.splitArgs(is.gameArgs);
        if (!opt.extraJvmArgs.isEmpty()) log("实例追加 JVM 参数：" + String.join(" ", opt.extraJvmArgs));
        if (!opt.extraGameArgs.isEmpty()) log("实例追加游戏参数：" + String.join(" ", opt.extraGameArgs));

        // 自动进服：转成 --server / --port（游戏本体的 game args 里没有这两项，直接追加即可）
        String[] server = InstSettings.splitServer(is.serverAddress);
        if (server != null) {
            opt.extraGameArgs.add("--server");
            opt.extraGameArgs.add(server[0]);
            if (server[1] != null) {
                opt.extraGameArgs.add("--port");
                opt.extraGameArgs.add(server[1]);
            }
            log("启动后自动进入服务器 " + is.serverAddress);
        }

        log("启动参数：Java " + java.major + "（" + java.describe() + "），内存 " + memoryGb + " GB"
                + (customResolution ? "，窗口 " + width + "×" + height : "，窗口使用游戏默认"));

        List<String> cmd = GameProcess.buildCommand(java, meta, opt);

        // 启动耗时统计：准备阶段到此结束，进程输出行由 LineListener 喂给同一份记录
        LaunchStats.Record stat = new LaunchStats.Record();
        stat.versionId = versionId;
        stat.startedAt = clickTime;

        setLaunchEnabled(false);
        try {
            Process p = GameProcess.start(cmd, gameDir, this::log, code -> onGameExit(versionId, stat, code),
                    line -> onGameLine(stat, line));
            stat.processStartedAt = System.currentTimeMillis();
            stat.prepareMs = Math.max(1, stat.processStartedAt - clickTime);
            runningGames.put(p.pid(), p);
            updateRunningLabel();
            statusLabel.setText("游戏运行中（" + versionId + "，准备 " + LaunchStats.sec(stat.prepareMs) + "）");
            GameProcess.applyPriority(p.pid(), settings.processPriority, this::log);
            applyVisibility();
        } catch (Exception ex) {
            log("启动失败：" + ex.getMessage());
            statusLabel.setText("启动失败：" + ex.getMessage());
            setLaunchEnabled(true);
        }
    }

    /**
     * 游戏输出行的耗时统计回调（输出线程，非 EDT）。
     * 第一次识别到「进入游戏」里程碑时立刻落盘并写日志 —— 即使游戏随后崩溃，这次数据也已经保住了。
     */
    private void onGameLine(LaunchStats.Record stat, String line) {
        if (!stat.onGameLine(line)) return;
        stat.markSaved();
        LaunchStats.save(settings.baseDir(), stat);
        final String summary = stat.summary();
        log(summary);
        SwingUtilities.invokeLater(() -> launchStatsLabel.setText(summary));
    }

    /** 打开启动耗时历史弹窗。 */
    private void showLaunchStats() {
        String text = LaunchStats.report(settings.baseDir());
        JTextArea area = new JTextArea(text);
        area.setEditable(false);
        area.setFont(reportFont());
        area.setCaretPosition(0);
        JScrollPane sp = new JScrollPane(area);
        sp.setPreferredSize(new Dimension(720, 380));
        JOptionPane.showMessageDialog(frame, sp, "启动耗时记录", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * 解析本次启动要用的 Java：实例指定了路径就用实例的（不在已探测列表里则现场探测并缓存），
     * 否则回退到全局探测结果。
     */
    private JavaRuntime.Java resolveJava(InstSettings is, String versionId) {
        if (is.javaPath.isBlank()) return jre;
        for (JavaRuntime.Java j : detectedJava) {
            if (matchesJavaPath(j, is.javaPath)) return j;
        }
        JavaRuntime.Java cached = instanceJavaCache.get(is.javaPath);
        if (cached != null) return cached;
        log("探测实例指定的 Java：" + is.javaPath);
        JavaRuntime.Java probed = JavaRuntime.probe(new File(is.javaPath), "实例 " + versionId);
        if (probed != null) instanceJavaCache.put(is.javaPath, probed);
        return probed == null ? jre : probed;
    }

    private static boolean matchesJavaPath(JavaRuntime.Java j, String path) {
        String want = path.replace('\\', '/').toLowerCase();
        if (j.exe != null && j.exe.getAbsolutePath().replace('\\', '/').toLowerCase().equals(want)) return true;
        return j.home != null && j.home.getAbsolutePath().replace('\\', '/').toLowerCase().equals(want);
    }

    private void updateRunningLabel() {
        int n = runningGames.size();
        if (n == 0) return;
        StringBuilder sb = new StringBuilder("正在运行 ").append(n).append(" 个游戏");
        sb.append("（PID ").append(String.join(", ", runningGames.keySet().stream().map(String::valueOf).toList()))
          .append("）");
        log(sb.toString());
    }

    /** 游戏退出后的收尾（在输出线程回调，需要切回 EDT）。 */
    private void onGameExit(String versionId, LaunchStats.Record stat, int code) {
        // 未识别到里程碑时在这里补写一条，让"启动失败 / 提前退出"也有记录可查
        if (!stat.isSaved()) {
            stat.markSaved();
            stat.exitCode = code;
            LaunchStats.save(settings.baseDir(), stat);
            log(stat.summary());
        }
        SwingUtilities.invokeLater(() -> {
            runningGames.entrySet().removeIf(e -> !e.getValue().isAlive());
            if ("hide".equals(settings.launcherVisibility)) {
                frame.setVisible(true);
                frame.setExtendedState(frame.getExtendedState() & ~Frame.ICONIFIED);
                frame.toFront();
            }
            statusLabel.setText(versionId + " 已退出（退出码 " + code
                    + (runningGames.isEmpty() ? "" : "），仍有 " + runningGames.size() + " 个游戏在运行") + "）");
            if (stat.reachedGame()) launchStatsLabel.setText(stat.summary());
            setLaunchEnabled(true);
        });
    }

    /** 启动器可见性：启动游戏后保持 / 最小化 / 隐藏。 */
    private void applyVisibility() {
        switch (settings.launcherVisibility) {
            case "minimize" -> frame.setExtendedState(frame.getExtendedState() | Frame.ICONIFIED);
            case "hide" -> frame.setVisible(false);
            default -> {
                // 保持不变
            }
        }
    }

    private void setLaunchEnabled(boolean enabled) {
        launchBtn.setEnabled(enabled);
    }

    private void saveConfig() {
        settings.username = nameField.getText().trim();
        settings.showSnapshots = snapshotBox.isSelected();
        settings.aprilOnly = aprilBox.isSelected();
        settings.save();
    }
}
