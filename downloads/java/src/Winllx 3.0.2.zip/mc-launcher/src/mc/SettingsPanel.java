package mc;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * 设置页：左侧分类子菜单 + 右侧内容区（CardLayout）。
 * 所有控件都会立即把值写回 {@link Settings} 并保存到 config.properties，
 * 这里不放置"写了 UI 但不生效"的假设置。
 */
public final class SettingsPanel extends JPanel {

    /** 设置变更回调，由外层（LauncherUI）处理依赖刷新。 */
    public interface Listener {
        /** 任意设置被修改并已保存。 */
        void onChanged();

        /** 安装目录变化：需要重建 Installer 并重新加载版本清单。 */
        void onGameDirChanged();

        /** Java 选择 / Java 环境变化：需要重新检测并刷新启动页提示。 */
        void onJavaPathChanged();

        /** 用户点击了「登录微软账号」。 */
        void onLoginRequested();

        /** 用户点击了「退出登录」。 */
        void onLogoutRequested();
    }

    private static final String AUTO = "自动（按顺序查找：内置 JBR → JAVA_HOME → PATH）";
    private static final String BROWSE = "浏览 java.exe…";
    private static final String CUSTOM_PREFIX = "自定义：";
    private static final String FOLLOW = "跟随启动页当前选中的版本";
    private static final Color MUTED = new Color(110, 110, 110);
    private static final Color PANEL_BG = new Color(250, 250, 252);

    private final Settings st;
    private final Listener listener;
    private final Consumer<String> log;

    private final DefaultListModel<String> categoryModel = new DefaultListModel<>();
    private final JList<String> categoryList = new JList<>(categoryModel);
    private final JPanel cards = new JPanel(new CardLayout());

    // 常规
    private final JTextField dirField = new JTextField(38);
    private final JCheckBox instanceBox = new JCheckBox("为每个版本使用独立游戏目录（存档 / 设置 / 截图互不影响）");
    private final JComboBox<Object> defaultInstanceCombo = new JComboBox<>();

    // Java
    private final List<JavaRuntime.Java> javaList = new ArrayList<>();
    private final JComboBox<Object> javaCombo = new JComboBox<>();
    private final JButton javaDetectBtn = new JButton("重新检测");
    private final JLabel javaInfoLabel = new JLabel("正在检测已安装的 Java…");
    private boolean updatingJava;
    /** 载入设置期间为 true：抑制控件事件触发的保存与回调，避免构造阶段就写盘。 */
    private boolean loading;
    /** 重建「默认实例」下拉期间为 true：抑制程序化选中触发的保存。 */
    private boolean updatingInstances;
    /** 微软账号登录进行中。 */
    private boolean msaLaunching;

    // 内存与性能
    private final JRadioButton memAuto = new JRadioButton("自动配置（按系统内存分档）");
    private final JRadioButton memCustom = new JRadioButton("自定义");
    private final JSpinner memSpinner = new JSpinner(new SpinnerNumberModel(4, 1, 64, 1));
    private final JLabel memHint = new JLabel(" ");
    private final JComboBox<String> priorityCombo = new JComboBox<>(
            new String[]{"普通", "低于普通", "高于普通", "高", "实时"});

    // 游戏窗口
    private final JCheckBox resolutionBox = new JCheckBox("自定义游戏窗口大小");
    private final JSpinner widthSpinner = new JSpinner(new SpinnerNumberModel(854, 320, 7680, 1));
    private final JSpinner heightSpinner = new JSpinner(new SpinnerNumberModel(480, 240, 4320, 1));

    // 网络
    private final JComboBox<String> ipCombo = new JComboBox<>(
            new String[]{"默认（由系统决定）", "优先 IPv4", "优先 IPv6"});

    // 启动与外观
    private final JComboBox<String> visibilityCombo = new JComboBox<>(
            new String[]{"保持不变", "启动游戏后最小化", "启动游戏后隐藏（游戏退出时恢复）"});
    private final JTextField brandField = new JTextField(18);
    private final JTextField brandVersionField = new JTextField(10);

    // 账号（正版验证）
    private final JRadioButton accOffline = new JRadioButton("离线模式（不需要账号，以本地玩家名进入）");
    private final JRadioButton accMsa = new JRadioButton("微软账号（正版验证，可进入正版服务器）");
    private final JLabel accStatusLabel = new JLabel(" ");
    private final JButton loginBtn = new JButton("登录微软账号");
    private final JButton logoutBtn = new JButton("退出登录");
    private final JTextField clientIdField = new JTextField(38);

    public SettingsPanel(Settings settings, Listener listener, Consumer<String> log) {
        this.st = settings;
        this.listener = listener;
        this.log = log;

        setLayout(new BorderLayout());
        setBackground(PANEL_BG);
        buildCategoryList();
        buildCards();
        loadFromSettings();
    }

    // ===== 左侧分类子菜单 =====

    private void buildCategoryList() {
        categoryModel.addElement("账号");
        categoryModel.addElement("常规");
        categoryModel.addElement("游戏窗口");
        categoryModel.addElement("内存与性能");
        categoryModel.addElement("Java 运行时");
        categoryModel.addElement("网络");
        categoryModel.addElement("启动与外观");

        categoryList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        categoryList.setFixedCellHeight(34);
        categoryList.setFont(categoryList.getFont().deriveFont(Font.PLAIN, 13f));
        categoryList.setBorder(new EmptyBorder(8, 6, 8, 6));
        categoryList.setBackground(new Color(243, 243, 246));
        categoryList.addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            ((CardLayout) cards.getLayout()).show(cards, categoryModel.getElementAt(categoryList.getSelectedIndex()));
        });

        JScrollPane leftScroll = new JScrollPane(categoryList);
        leftScroll.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, new Color(225, 225, 230)));
        leftScroll.setPreferredSize(new Dimension(148, 100));
        add(leftScroll, BorderLayout.WEST);
    }

    private void buildCards() {
        addCategory("账号", buildAccount());
        addCategory("常规", buildGeneral());
        addCategory("游戏窗口", buildWindow());
        addCategory("内存与性能", buildMemory());
        addCategory("Java 运行时", buildJava());
        addCategory("网络", buildNetwork());
        addCategory("启动与外观", buildAppearance());
        cards.setBackground(PANEL_BG);
        add(cards, BorderLayout.CENTER);
        categoryList.setSelectedIndex(0);
    }

    private void addCategory(String title, JComponent content) {
        JScrollPane sp = new JScrollPane(content);
        sp.setBorder(null);
        sp.getVerticalScrollBar().setUnitIncrement(16);
        sp.getViewport().setBackground(PANEL_BG);
        cards.add(sp, title);
    }

    private JPanel category() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(new EmptyBorder(14, 18, 18, 18));
        p.setBackground(PANEL_BG);
        return p;
    }

    private JLabel title(String text) {
        JLabel l = new JLabel(text);
        l.setFont(l.getFont().deriveFont(Font.BOLD, 15f));
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JPanel row(String label, JComponent field) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        p.setOpaque(false);
        p.setAlignmentX(LEFT_ALIGNMENT);
        JLabel l = new JLabel(label);
        l.setPreferredSize(new Dimension(118, 22));
        p.add(l);
        p.add(field);
        return p;
    }

    private JLabel hint(String text) {
        JLabel l = new JLabel("<html><body style='width:560px'>" + text + "</body></html>");
        l.setForeground(MUTED);
        l.setBorder(new EmptyBorder(2, 126, 8, 0));
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    // ===== 各分类内容 =====

    private JPanel buildGeneral() {
        JPanel p = category();
        p.add(title("常规"));
        p.add(Box.createVerticalStrut(10));

        dirField.setEditable(false);
        JButton pick = new JButton("选择…");
        pick.addActionListener(e -> pickGameDir());
        JPanel dirRow = row("安装目录", dirField);
        dirRow.add(pick);
        p.add(dirRow);
        p.add(hint("存放 versions / libraries / assets 的基础目录；版本隔离开启后，各版本的存档另存于该目录下的 instances 中。"));

        instanceBox.setOpaque(false);
        instanceBox.setAlignmentX(LEFT_ALIGNMENT);
        instanceBox.setBorder(new EmptyBorder(4, 118, 4, 0));
        instanceBox.addActionListener(e -> {
            st.instanceIsolation = instanceBox.isSelected();
            commit(false, false);
        });
        p.add(instanceBox);
        p.add(hint("开启后每个版本使用独立的 --gameDir，世界存档与选项互不干扰；共享的依赖库和资源不会重复下载。"));

        defaultInstanceCombo.setPreferredSize(new Dimension(420, 26));
        defaultInstanceCombo.addActionListener(e -> {
            if (loading || updatingInstances) return;
            Object sel = defaultInstanceCombo.getSelectedItem();
            st.defaultInstance = sel instanceof ModScan.Instance i ? i.id : "";
            commit(false, false);
        });
        p.add(row("默认实例", defaultInstanceCombo));
        p.add(hint("在「Mod」页点安装时，弹窗最上面的「默认实例」就指向这里选择的版本，选它即自动装到该实例；"
                + "选择「" + FOLLOW + "」则跟随启动页当前选中的版本。这里只列出已下载到 versions 目录的版本。"));
        refreshInstances();
        return p;
    }

    private JPanel buildWindow() {
        JPanel p = category();
        p.add(title("游戏窗口"));
        p.add(Box.createVerticalStrut(10));

        resolutionBox.setOpaque(false);
        resolutionBox.setAlignmentX(LEFT_ALIGNMENT);
        resolutionBox.setBorder(new EmptyBorder(4, 118, 4, 0));
        resolutionBox.addActionListener(e -> {
            st.customResolution = resolutionBox.isSelected();
            widthSpinner.setEnabled(resolutionBox.isSelected());
            heightSpinner.setEnabled(resolutionBox.isSelected());
            commit(false, false);
        });
        p.add(resolutionBox);

        JPanel sizeRow = row("窗口大小", widthSpinner);
        sizeRow.add(new JLabel("×"));
        sizeRow.add(heightSpinner);
        sizeRow.add(new JLabel("像素"));
        p.add(sizeRow);
        widthSpinner.addChangeListener(e -> {
            st.windowWidth = (Integer) widthSpinner.getValue();
            commit(false, false);
        });
        heightSpinner.addChangeListener(e -> {
            st.windowHeight = (Integer) heightSpinner.getValue();
            commit(false, false);
        });
        p.add(hint("通过版本 JSON 的 has_custom_resolution 特性传入 --width/--height，游戏首次启动即按该尺寸打开窗口。"));
        return p;
    }

    private JPanel buildMemory() {
        JPanel p = category();
        p.add(title("内存与性能"));
        p.add(Box.createVerticalStrut(10));

        ButtonGroup g = new ButtonGroup();
        g.add(memAuto);
        g.add(memCustom);
        memAuto.setOpaque(false);
        memCustom.setOpaque(false);
        memAuto.setAlignmentX(LEFT_ALIGNMENT);
        memCustom.setAlignmentX(LEFT_ALIGNMENT);
        memAuto.setBorder(new EmptyBorder(4, 118, 4, 0));
        memCustom.setBorder(new EmptyBorder(4, 118, 4, 0));
        p.add(memAuto);
        p.add(hint("自动档会按下方检测到的系统内存分档分配（≤4G→1G，≤8G→2G，≤16G→4G，更大→最多 8G）。"));
        p.add(memCustom);

        JPanel memRow = row("内存上限", memSpinner);
        memRow.add(new JLabel("GB"));
        p.add(memRow);
        memHint.setForeground(MUTED);
        memHint.setBorder(new EmptyBorder(2, 126, 8, 0));
        memHint.setAlignmentX(LEFT_ALIGNMENT);
        p.add(memHint);

        memAuto.addActionListener(e -> {
            st.memoryMode = "auto";
            updateMemoryControls();
            commit(false, false);
        });
        memCustom.addActionListener(e -> {
            st.memoryMode = "custom";
            updateMemoryControls();
            commit(false, false);
        });
        memSpinner.addChangeListener(e -> {
            st.customMemoryGb = (Integer) memSpinner.getValue();
            updateMemoryHint();
            if ("custom".equals(st.memoryMode)) commit(false, false);
        });

        p.add(Box.createVerticalStrut(10));
        priorityCombo.addActionListener(e -> {
            st.processPriority = priorityKey();
            commit(false, false);
        });
        p.add(row("进程优先级", priorityCombo));
        p.add(hint("游戏进程启动后通过 Windows 的 PriorityClass 调整优先级，可在任务管理器中看到变化。"));
        return p;
    }

    private JPanel buildJava() {
        JPanel p = category();
        p.add(title("Java 运行时"));
        p.add(Box.createVerticalStrut(10));

        javaCombo.setPreferredSize(new Dimension(600, 26));
        javaCombo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                          boolean selected, boolean focus) {
                Object shown = value instanceof JavaRuntime.Java j ? j.label() : value;
                return super.getListCellRendererComponent(list, shown, index, selected, focus);
            }
        });
        javaCombo.addActionListener(e -> onJavaSelected());

        JPanel rowJava = row("Java", javaCombo);
        rowJava.add(javaDetectBtn);
        p.add(rowJava);
        p.add(hint("选择启动游戏所用的 Java。自动模式按 内置 JBR → JAVA_HOME → PATH 顺序查找；也可以直接指定某个 java.exe。"));

        javaInfoLabel.setForeground(MUTED);
        javaInfoLabel.setAlignmentX(LEFT_ALIGNMENT);
        javaInfoLabel.setBorder(new EmptyBorder(2, 118, 8, 0));
        p.add(javaInfoLabel);

        javaDetectBtn.addActionListener(e -> listener.onJavaPathChanged());
        return p;
    }

    private JPanel buildNetwork() {
        JPanel p = category();
        p.add(title("网络"));
        p.add(Box.createVerticalStrut(10));
        ipCombo.addActionListener(e -> {
            st.ipPreference = ipKey();
            commit(false, false);
        });
        p.add(row("IP 协议偏好", ipCombo));
        p.add(hint("通过 -Djava.net.preferIPv4Stack / -Djava.net.preferIPv6Addresses 控制 JVM 的地址族选择，" +
                "影响连接服务器时使用的协议。"));
        return p;
    }

    private JPanel buildAppearance() {
        JPanel p = category();
        p.add(title("启动与外观"));
        p.add(Box.createVerticalStrut(10));

        visibilityCombo.addActionListener(e -> {
            st.launcherVisibility = visibilityKey();
            commit(false, false);
        });
        p.add(row("启动器可见性", visibilityCombo));
        p.add(hint("游戏成功启动后对启动器窗口的处理方式；“隐藏”会在游戏退出时自动恢复显示。"));

        JPanel brandRow = row("启动器名称", brandField);
        brandRow.add(new JLabel("版本"));
        brandRow.add(brandVersionField);
        p.add(brandRow);
        brandField.getDocument().addDocumentListener(simple(() -> {
            st.launcherBrand = brandField.getText().trim();
            commit(false, false);
        }));
        brandVersionField.getDocument().addDocumentListener(simple(() -> {
            st.launcherBrandVersion = brandVersionField.getText().trim();
            commit(false, false);
        }));
        p.add(hint("自定义信息：作为 launcher_name / launcher_version 写入游戏环境（影响 -Dminecraft.launcher.brand、" +
                "-Dminecraft.launcher.version 与调试信息），但不会替换原版窗口标题。"));
        return p;
    }

    private JPanel buildAccount() {
        JPanel p = category();
        p.add(title("账号与正版验证"));
        p.add(Box.createVerticalStrut(10));

        ButtonGroup g = new ButtonGroup();
        g.add(accOffline);
        g.add(accMsa);
        accOffline.setOpaque(false);
        accMsa.setOpaque(false);
        accOffline.setAlignmentX(LEFT_ALIGNMENT);
        accMsa.setAlignmentX(LEFT_ALIGNMENT);
        accOffline.setBorder(new EmptyBorder(4, 118, 4, 0));
        accMsa.setBorder(new EmptyBorder(4, 118, 4, 0));
        p.add(accOffline);
        p.add(hint("离线模式：使用启动页填写的玩家名进入游戏，只能游玩单机与被配置为离线验证的服务器。"));
        p.add(accMsa);
        p.add(hint("微软账号：走 OAuth 设备码流程完成正版验证，登录后可加入正版验证服务器；令牌会保存到配置文件，重启免登录。"));

        accStatusLabel.setFont(accStatusLabel.getFont().deriveFont(Font.BOLD));
        accStatusLabel.setAlignmentX(LEFT_ALIGNMENT);
        accStatusLabel.setBorder(new EmptyBorder(6, 118, 2, 0));
        p.add(accStatusLabel);

        JPanel rowBtns = row("", loginBtn);
        rowBtns.add(logoutBtn);
        p.add(rowBtns);

        p.add(Box.createVerticalStrut(12));
        p.add(row("客户端 ID", clientIdField));
        p.add(hint("Azure 应用（公共客户端）ID，默认值是一个公开的第一方 ID，开箱可用；" +
                "若被限流可在 Azure 门户注册自己的应用并填入此处。"));

        accOffline.addActionListener(e -> {
            if (loading) return;
            st.accountMode = "offline";
            refreshAccount();
            commit(false, false);
        });
        accMsa.addActionListener(e -> {
            if (loading) return;
            st.accountMode = "msa";
            refreshAccount();
            commit(false, false);
        });
        loginBtn.addActionListener(e -> listener.onLoginRequested());
        logoutBtn.addActionListener(e -> listener.onLogoutRequested());
        clientIdField.getDocument().addDocumentListener(simple(() -> {
            if (loading) return;
            st.msaClientId = clientIdField.getText().trim();
            commit(false, false);
        }));
        return p;
    }

    /** 登录状态变化（登录成功 / 退出登录）后由外层调用，刷新本页显示。 */
    public void refreshAccount() {
        boolean prev = loading;
        loading = true;
        try {
            boolean msa = "msa".equals(st.accountMode);
            accMsa.setSelected(msa);
            accOffline.setSelected(!msa);
            loginBtn.setEnabled(!msaLaunching);
            boolean logged = st.isMsa();
            if (logged) {
                accStatusLabel.setText("已登录：" + st.msaName + "（" + st.msaUuid + "）");
                accStatusLabel.setForeground(new Color(20, 128, 60));
            } else if (msa) {
                accStatusLabel.setText("未登录：点击「登录微软账号」完成授权");
                accStatusLabel.setForeground(new Color(190, 60, 40));
            } else {
                accStatusLabel.setText("离线模式：以玩家名进入游戏");
                accStatusLabel.setForeground(MUTED);
            }
            logoutBtn.setEnabled(logged);
            clientIdField.setText(st.clientIdOr());
        } finally {
            loading = prev;
        }
    }

    /** 登录进行中：禁用按钮防止重复点击。 */
    public void setLoginBusy(boolean busy) {
        msaLaunching = busy;
        loginBtn.setEnabled(!busy);
        if (busy) {
            accStatusLabel.setText("正在等待浏览器授权…");
            accStatusLabel.setForeground(MUTED);
        }
    }

    // ===== 默认实例下拉 =====

    /** 重建「默认实例」列表（versions 目录里已下载的版本）。外层在下载/删除版本后调用。 */
    public void refreshInstances() {
        List<ModScan.Instance> found = new ArrayList<>(ModScan.listInstances(st));
        updatingInstances = true;
        try {
            defaultInstanceCombo.removeAllItems();
            defaultInstanceCombo.addItem(FOLLOW);
            ModScan.Instance target = null;
            for (ModScan.Instance i : found) {
                defaultInstanceCombo.addItem(i);
                if (i.id.equals(st.defaultInstance)) target = i;
            }
            if (target == null) {
                defaultInstanceCombo.setSelectedItem(FOLLOW);
                // 配置里的 id 已不存在（版本被删）时同步清理，避免默认实例指向空
                if (!st.defaultInstance.isBlank() && !loading) {
                    st.defaultInstance = "";
                    st.save();
                }
            } else {
                defaultInstanceCombo.setSelectedItem(target);
            }
        } finally {
            updatingInstances = false;
        }
    }

    // ===== 载入 / 保存 =====

    private void loadFromSettings() {
        loading = true;
        try {
            dirField.setText(st.baseDir().getAbsolutePath());
            instanceBox.setSelected(st.instanceIsolation);

            resolutionBox.setSelected(st.customResolution);
            widthSpinner.setValue(st.windowWidth);
            heightSpinner.setValue(st.windowHeight);
            widthSpinner.setEnabled(st.customResolution);
            heightSpinner.setEnabled(st.customResolution);

            boolean auto = !"custom".equals(st.memoryMode);
            memAuto.setSelected(auto);
            memCustom.setSelected(!auto);
            memSpinner.setValue(st.customMemoryGb);
            updateMemoryControls();

            priorityCombo.setSelectedIndex(priorityIndex(st.processPriority));
            ipCombo.setSelectedIndex(ipIndex(st.ipPreference));
            visibilityCombo.setSelectedIndex(visibilityIndex(st.launcherVisibility));
            brandField.setText(st.launcherBrand);
            brandVersionField.setText(st.launcherBrandVersion);
        } finally {
            loading = false;
        }
        refreshAccount();
    }

    /** 统一提交：落盘 + 通知外层刷新受影响的依赖。 */
    private void commit(boolean javaChanged, boolean dirChanged) {
        if (loading) return;
        st.save();
        if (dirChanged) listener.onGameDirChanged();
        if (javaChanged) listener.onJavaPathChanged();
        listener.onChanged();
    }

    private void pickGameDir() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setDialogTitle("选择 Minecraft 安装目录");
        File cur = st.baseDir();
        if (cur.isDirectory()) chooser.setCurrentDirectory(cur);
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            st.gameDir = chooser.getSelectedFile().getAbsolutePath();
            dirField.setText(st.gameDir);
            log.accept("安装目录已切换为 " + st.gameDir);
            commit(false, true);
        }
    }

    // ===== 内存控件联动 =====

    private void updateMemoryControls() {
        boolean custom = "custom".equals(st.memoryMode);
        memCustom.setSelected(custom);
        memAuto.setSelected(!custom);
        memSpinner.setEnabled(custom);
        updateMemoryHint();
    }

    private void updateMemoryHint() {
        memHint.setText("检测到系统内存约 " + Settings.totalRamGb() + " GB；当前将分配 "
                + st.resolvedMemoryGb() + " GB（-Xmx）");
    }

    // ===== Java 列表（由外层扫描后回填） =====

    /** 由 LauncherUI 在扫描完成后回填可用 Java 列表。 */
    public void setJavaList(List<JavaRuntime.Java> list) {
        javaList.clear();
        javaList.addAll(list);
        javaInfoLabel.setText(list.isEmpty()
                ? "未找到可用的 Java，请检查内置 JBR 或手动指定 java.exe"
                : "共发现 " + list.size() + " 个可用的 Java");
        rebuildJavaCombo();
    }

    /** 扫描期间禁用按钮并提示进度。 */
    public void setJavaBusy(boolean busy) {
        javaDetectBtn.setEnabled(!busy);
        if (busy) javaInfoLabel.setText("正在检测已安装的 Java…");
    }

    private void rebuildJavaCombo() {
        updatingJava = true;
        javaCombo.removeAllItems();
        javaCombo.addItem(AUTO);
        for (JavaRuntime.Java j : javaList) javaCombo.addItem(j);

        Object selected = AUTO;
        if (!st.javaPath.isBlank()) {
            for (JavaRuntime.Java j : javaList) {
                if (samePath(j.exe, st.javaPath) || samePath(j.home, st.javaPath)) {
                    selected = j;
                    break;
                }
            }
            if (selected == AUTO) {
                String custom = CUSTOM_PREFIX + st.javaPath;
                javaCombo.addItem(custom);
                selected = custom;
            }
        }
        javaCombo.addItem(BROWSE);
        javaCombo.setSelectedItem(selected);
        updatingJava = false;
    }

    private void onJavaSelected() {
        if (updatingJava) return;
        Object sel = javaCombo.getSelectedItem();
        if (sel == AUTO) {
            setJavaPath("");
        } else if (sel == BROWSE) {
            browseJava();
        } else if (sel instanceof JavaRuntime.Java j) {
            setJavaPath(j.exe != null ? j.exe.getAbsolutePath()
                    : (j.home != null ? j.home.getAbsolutePath() : ""));
        }
        // 自定义项：路径未变化，无需处理
    }

    private void browseJava() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("选择 java 可执行文件");
        String base = st.javaPath;
        if (!base.isBlank()) {
            File f = new File(base);
            File dir = f.isDirectory() ? f : f.getParentFile();
            if (dir != null && dir.isDirectory()) chooser.setCurrentDirectory(dir);
        }
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            setJavaPath(chooser.getSelectedFile().getAbsolutePath());
        } else {
            rebuildJavaCombo();
        }
    }

    private void setJavaPath(String path) {
        if (samePath(new File(path), st.javaPath) || (path.isEmpty() && st.javaPath.isEmpty())) return;
        st.javaPath = path;
        log.accept(path.isEmpty() ? "Java 选择已恢复为自动查找" : "Java 选择已指定为 " + path);
        commit(true, false);
        rebuildJavaCombo();
    }

    private static boolean samePath(File a, String b) {
        if (a == null || b == null || b.isBlank()) return false;
        return samePath(a, new File(b));
    }

    private static boolean samePath(File a, File b) {
        if (a == null || b == null) return false;
        try {
            return a.getCanonicalPath().equalsIgnoreCase(b.getCanonicalPath());
        } catch (Exception e) {
            return a.getAbsolutePath().equalsIgnoreCase(b.getAbsolutePath());
        }
    }

    // ===== 枚举 <-> 控件 映射 =====

    private String priorityKey() {
        return switch (priorityCombo.getSelectedIndex()) {
            case 1 -> "below";
            case 2 -> "above";
            case 3 -> "high";
            case 4 -> "realtime";
            default -> "normal";
        };
    }

    private static int priorityIndex(String key) {
        return switch (key == null ? "" : key) {
            case "below" -> 1;
            case "above" -> 2;
            case "high" -> 3;
            case "realtime" -> 4;
            default -> 0;
        };
    }

    private String ipKey() {
        return switch (ipCombo.getSelectedIndex()) {
            case 1 -> "ipv4";
            case 2 -> "ipv6";
            default -> "default";
        };
    }

    private static int ipIndex(String key) {
        return switch (key == null ? "" : key) {
            case "ipv4" -> 1;
            case "ipv6" -> 2;
            default -> 0;
        };
    }

    private String visibilityKey() {
        return switch (visibilityCombo.getSelectedIndex()) {
            case 1 -> "minimize";
            case 2 -> "hide";
            default -> "keep";
        };
    }

    private static int visibilityIndex(String key) {
        return switch (key == null ? "" : key) {
            case "minimize" -> 1;
            case "hide" -> 2;
            default -> 0;
        };
    }

    /** 文档监听器适配（避免引入 DocumentListener 的样板代码）。 */
    private static javax.swing.event.DocumentListener simple(Runnable r) {
        return new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
        };
    }
}
