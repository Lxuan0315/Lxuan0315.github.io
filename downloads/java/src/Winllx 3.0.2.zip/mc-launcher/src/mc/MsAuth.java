package mc;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * 微软账号（正版）登录：OAuth 设备码 → Xbox Live 用户认证 → XSTS 授权 → Minecraft 服务登录 → 游戏档案。
 * 全部走公开 API，零第三方依赖。
 *
 * 客户端 ID 说明：这里默认使用一个公开的第一方 Azure 客户端 ID（Azure CLI），
 * 因为启动器本身无法携带私有的 Azure 应用注册；设置页允许填入自己注册的客户端 ID。
 */
public final class MsAuth {

    public static final String DEFAULT_CLIENT_ID = "04b07795-8ddb-461a-bbee-02f9e1bf7b46";

    private static final String DEVICE_CODE_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode";
    private static final String TOKEN_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token";
    private static final String XBL_URL = "https://user.auth.xboxlive.com/user/authenticate";
    private static final String XSTS_URL = "https://xsts.auth.xboxlive.com/xsts/authorize";
    private static final String MC_LOGIN_URL = "https://api.minecraftservices.com/authentication/login_with_xbox";
    private static final String MC_PROFILE_URL = "https://api.minecraftservices.com/minecraft/profile";
    private static final String SCOPE = "XboxLive.signin offline_access";

    private MsAuth() {}

    /** 设备码：用户需要在浏览器里输入 user_code 完成授权。 */
    public static final class DeviceCode {
        public String userCode;
        public String deviceCode;
        public String verificationUri = "https://www.microsoft.com/link";
        public String message;
        public int interval = 5;
        public int expiresIn = 900;
    }

    /** 登录结果：Minecraft 启动凭据 + 下次免登录所需的刷新令牌。 */
    public static final class Account {
        public String uuid;
        public String name;
        public String xuid;
        public String accessToken;
        public String refreshToken;

        public String describe() {
            return name + "（" + uuid + "）";
        }
    }

    // ===== 对外入口 =====

    /**
     * 完整登录：申请设备码 → 交给 onCode 展示给用户 → 轮询直到授权完成 → 换取 Minecraft 凭据。
     *
     * @param onCode 拿到设备码时的回调（用来在界面上展示 user_code 与验证地址）
     */
    public static Account login(String clientId, Consumer<String> log, Consumer<DeviceCode> onCode) throws IOException {
        DeviceCode dc = requestDeviceCode(clientId);
        if (log != null) log.accept("请在浏览器打开 " + dc.verificationUri + " 并输入代码 " + dc.userCode);
        if (onCode != null) onCode.accept(dc);
        String[] tokens = pollTokens(clientId, dc, dc.expiresIn, log);
        return finishLogin(tokens[0], tokens[1], log);
    }

    /** 用已保存的刷新令牌免密登录（启动器重启后使用）。 */
    public static Account refresh(String clientId, String refreshToken, Consumer<String> log) throws IOException {
        if (refreshToken == null || refreshToken.isBlank()) throw new IOException("没有可用的刷新令牌");
        Map<String, String> form = new HashMap<>();
        form.put("grant_type", "refresh_token");
        form.put("client_id", clientId);
        form.put("refresh_token", refreshToken);
        form.put("scope", SCOPE);

        Net.Response r = Net.postForm(TOKEN_URL, form);
        if (!r.ok()) {
            throw new IOException("刷新令牌失败（HTTP " + r.code + "）：" + errorText(r.body)
                    + "，请重新登录微软账号");
        }
        Object root = Json.parse(r.body);
        String access = Json.str(root, "access_token");
        if (access == null) throw new IOException("刷新响应缺少 access_token");
        String newRefresh = Json.str(root, "refresh_token");
        if (log != null) log.accept("已用保存的凭据刷新微软账号令牌");
        return finishLogin(access, newRefresh == null ? refreshToken : newRefresh, log);
    }

    // ===== 设备码流程 =====

    public static DeviceCode requestDeviceCode(String clientId) throws IOException {
        Map<String, String> form = new HashMap<>();
        form.put("client_id", clientId);
        form.put("scope", SCOPE);
        Net.Response r = Net.postForm(DEVICE_CODE_URL, form);
        if (!r.ok()) {
            throw new IOException("获取设备码失败（HTTP " + r.code + "）：" + errorText(r.body)
                    + "。可在设置页改用自己注册的 Azure 客户端 ID。");
        }
        Object root = Json.parse(r.body);
        DeviceCode dc = new DeviceCode();
        dc.userCode = Json.str(root, "user_code");
        dc.deviceCode = Json.str(root, "device_code");
        dc.message = Json.str(root, "message");
        String uri = Json.str(root, "verification_uri");
        if (uri != null && !uri.isBlank()) dc.verificationUri = uri;
        dc.interval = (int) Json.num(root, "interval", 5);
        dc.expiresIn = (int) Json.num(root, "expires_in", 900);
        if (dc.userCode == null || dc.deviceCode == null) throw new IOException("设备码响应缺少必要字段");
        return dc;
    }

    /** 轮询令牌端点，直到用户完成授权或超时；返回 {msa access_token, refresh_token}。 */
    private static String[] pollTokens(String clientId, DeviceCode dc, int timeoutSec, Consumer<String> log)
            throws IOException {
        long deadline = System.currentTimeMillis() + Math.max(60, timeoutSec) * 1000L;
        int interval = Math.max(2, dc.interval);
        while (System.currentTimeMillis() < deadline) {
            sleep(interval);
            Map<String, String> form = new HashMap<>();
            form.put("grant_type", "urn:ietf:params:oauth:grant-type:device_code");
            form.put("client_id", clientId);
            form.put("device_code", dc.deviceCode);

            Net.Response r = Net.postForm(TOKEN_URL, form);
            if (r.ok()) {
                Object root = Json.parse(r.body);
                String access = Json.str(root, "access_token");
                if (access == null) throw new IOException("令牌响应缺少 access_token");
                if (log != null) log.accept("微软账号授权成功，正在换取游戏凭据");
                return new String[]{access, Json.str(root, "refresh_token")};
            }

            String err = Json.str(Json.parse(r.body), "error");
            if ("authorization_pending".equals(err)) continue;
            if ("slow_down".equals(err)) {
                interval += 5;
                continue;
            }
            if ("expired_token".equals(err)) throw new IOException("设备码已过期，请重新点击登录");
            if ("authorization_declined".equals(err)) throw new IOException("授权被拒绝");
            throw new IOException("登录失败：" + errorText(r.body));
        }
        throw new IOException("登录超时：在有效期内未完成浏览器授权");
    }

    // ===== Xbox Live / XSTS / Minecraft 服务 =====

    private static Account finishLogin(String msaToken, String refreshToken, Consumer<String> log) throws IOException {
        // 1) Xbox Live 用户认证
        String xblBody = "{\"Properties\":{\"AuthMethod\":\"RPS\",\"SiteName\":\"user.auth.xboxlive.com\","
                + "\"RpsTicket\":\"d=" + msaToken + "\"},\"RelyingParty\":\"http://auth.xboxlive.com\","
                + "\"TokenType\":\"JWT\"}";
        String xblText = postJsonOrFail(XBL_URL, xblBody, null, "Xbox Live 认证失败");
        Object xbl = Json.parse(xblText);
        String xblToken = Json.str(xbl, "Token");
        String uhs = firstUhs(xbl);
        if (xblToken == null || uhs == null) throw new IOException("Xbox Live 认证响应缺少 Token / uhs");

        // 2) XSTS 授权（错误码含具体原因）
        String xstsBody = "{\"Properties\":{\"SandboxId\":\"RETAIL\",\"UserTokens\":[\"" + xblToken + "\"]},"
                + "\"RelyingParty\":\"rp://api.minecraftservices.com/\",\"TokenType\":\"JWT\"}";
        Net.Response xstsResp = Net.postJson(XSTS_URL, xstsBody, null);
        if (!xstsResp.ok()) throw new IOException(xstsMessage(xstsResp));
        Object xsts = Json.parse(xstsResp.body);
        String xstsToken = Json.str(xsts, "Token");
        String xstsUhs = firstUhs(xsts);
        if (xstsToken == null) throw new IOException("XSTS 授权响应缺少 Token");
        if (xstsUhs != null) uhs = xstsUhs;

        // 3) 换取 Minecraft 访问令牌
        String identity = "XBL3.0 x=" + uhs + ";" + xstsToken;
        String mcBody = "{\"identityToken\":\"" + identity + "\"}";
        String mcText = postJsonOrFail(MC_LOGIN_URL, mcBody, null, "Minecraft 服务登录失败");
        String mcAccess = Json.str(Json.parse(mcText), "access_token");
        if (mcAccess == null) throw new IOException("Minecraft 服务响应缺少 access_token");

        // 4) 读取游戏档案（同时校验是否拥有游戏）
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + mcAccess);
        Net.Response prof = Net.get(MC_PROFILE_URL, headers);
        if (prof.code == 404) {
            throw new IOException("该微软账号未拥有 Minecraft（未购买或未开通 Game Pass）");
        }
        if (!prof.ok()) throw new IOException("读取游戏档案失败（HTTP " + prof.code + "）：" + errorText(prof.body));
        Object profile = Json.parse(prof.body);
        String uuid = Json.str(profile, "id");
        String name = Json.str(profile, "name");
        if (uuid == null || name == null) throw new IOException("游戏档案缺少 id / name");

        Account acc = new Account();
        acc.uuid = uuid.replace("-", "");
        acc.name = name;
        acc.xuid = uhs;
        acc.accessToken = mcAccess;
        acc.refreshToken = refreshToken;
        if (log != null) log.accept("登录成功：" + acc.name + "（正版验证通过）");
        return acc;
    }

    private static String firstUhs(Object node) {
        Object xui = Json.get(Json.get(node, "DisplayClaims"), "xui");
        List<Object> list = Json.asList(xui);
        if (list == null || list.isEmpty()) return null;
        return Json.str(list.get(0), "uhs");
    }

    private static String postJsonOrFail(String url, String body, Map<String, String> headers, String what)
            throws IOException {
        Net.Response r = Net.postJson(url, body, headers);
        if (!r.ok()) throw new IOException(what + "（HTTP " + r.code + "）：" + errorText(r.body));
        return r.body;
    }

    /** XSTS 的 XErr 错误码对应的中文原因。 */
    private static String xstsMessage(Net.Response r) {
        long xerr = 0;
        try {
            Object root = Json.parse(r.body);
            xerr = Json.num(root, "XErr", 0);
        } catch (RuntimeException ignore) {
            // 解析失败时退回原始文本
        }
        // XErr 是大整数（约 2.1e9），超出 int 范围，而 Java 的 switch 不支持 long，因此用 if 链
        String reason;
        if (xerr == 2148916233L) {
            reason = "该微软账号没有 Xbox 档案，请先在 xbox.com 创建档案";
        } else if (xerr == 2148916235L) {
            reason = "该账号所在地区不支持 Xbox Live";
        } else if (xerr == 2148916236L || xerr == 2148916237L) {
            reason = "该账号需要完成成人验证";
        } else if (xerr == 2148916238L) {
            reason = "未成年账号需要先被添加到家庭组";
        } else {
            reason = null;
        }
        String detail = errorText(r.body);
        return "XSTS 授权失败" + (reason == null ? "" : "：" + reason)
                + "（HTTP " + r.code + (xerr == 0 ? "" : "，XErr=" + xerr) + "：" + detail + "）";
    }

    /** 从 OAuth 错误体里提取 error / error_description；非 JSON 时退回截断的原文。 */
    private static String errorText(String body) {
        if (body == null || body.isBlank()) return "无响应内容";
        try {
            Object root = Json.parse(body);
            String err = Json.str(root, "error");
            String desc = Json.str(root, "error_description");
            if (err != null) return desc == null ? err : err + " - " + desc;
        } catch (RuntimeException ignore) {
            // 不是 JSON，按原文处理
        }
        return body.length() > 300 ? body.substring(0, 300) + "…" : body;
    }

    private static void sleep(int seconds) throws IOException {
        try {
            Thread.sleep(seconds * 1000L);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("登录已取消");
        }
    }
}
