package mc;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/** 定位用于运行 Minecraft 的 Java，并判定其主版本号。 */
public final class JavaRuntime {

    private static final boolean WINDOWS = System.getProperty("os.name", "").toLowerCase().contains("win");

    public static final class Java {
        public final File exe;
        public final File home;
        public final int major;
        public final String source;

        Java(File exe, File home, int major, String source) {
            this.exe = exe;
            this.home = home;
            this.major = major;
            this.source = source;
        }

        public String describe() {
            String p = exe != null ? exe.getAbsolutePath() : (home != null ? home.getAbsolutePath() : "java");
            return "Java " + major + "（来源：" + source + "）" + p;
        }

        /** 用于下拉列表的一行文本：Java 21（来源）— 路径。 */
        public String label() {
            String p = exe != null ? exe.getAbsolutePath() : (home != null ? home.getAbsolutePath() : "java");
            return "Java " + major + "  ·  " + source + "  ·  " + p;
        }
    }

    private JavaRuntime() {}

    /** 解析顺序：配置路径 → 仓库内置 lib/jbr → JAVA_HOME → PATH。全部失败返回 null。 */
    public static Java resolve(String configuredPath) {
        if (configuredPath != null && !configuredPath.isBlank()) {
            Java j = probe(new File(configuredPath.trim()), "配置路径");
            if (j != null) return j;
        }
        for (File base : repoCandidates()) {
            Java j = probe(new File(base, "lib/jbr"), "内置 JBR");
            if (j != null) return j;
        }
        String javaHome = System.getenv("JAVA_HOME");
        if (javaHome != null && !javaHome.isBlank()) {
            Java j = probe(new File(javaHome), "JAVA_HOME");
            if (j != null) return j;
        }
        return probe(null, "PATH");
    }

    /** 探测一个 java 主页目录或 java 可执行文件；一次调用同时拿到版本与 java.home。 */
    public static Java probe(File homeOrExe, String source) {
        File exe = null;
        if (homeOrExe != null) {
            if (homeOrExe.isFile()) {
                exe = homeOrExe;
            } else {
                File e = new File(homeOrExe, WINDOWS ? "bin/java.exe" : "bin/java");
                if (!e.isFile()) return null;
                exe = e;
            }
        }

        List<String> cmd = new ArrayList<>();
        cmd.add(exe != null ? exe.getAbsolutePath() : "java");
        cmd.add("-XshowSettings:properties");
        cmd.add("-version");

        String text;
        try {
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(true);
            Process p = pb.start();
            text = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            if (!p.waitFor(20, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                return null;
            }
        } catch (Exception e) {
            return null;
        }

        String version = null;
        String home = null;
        for (String raw : text.split("\n")) {
            String line = raw.trim();
            if (version == null && line.startsWith("java.version = ")) {
                version = line.substring("java.version = ".length()).trim();
            }
            if (home == null && line.startsWith("java.home = ")) {
                home = line.substring("java.home = ".length()).trim();
            }
        }
        if (version == null) {
            int q = text.indexOf("version \"");
            if (q >= 0) {
                int end = text.indexOf('"', q + 9);
                if (end > q) version = text.substring(q + 9, end);
            }
        }
        if (version == null) return null;

        File homeDir = home != null && !home.isBlank() ? new File(home) : null;
        if (homeDir == null && exe != null) {
            File parent = exe.getParentFile();
            homeDir = parent != null ? parent.getParentFile() : null;
        }
        if (exe == null && homeDir != null) {
            File e = new File(homeDir, WINDOWS ? "bin/java.exe" : "bin/java");
            if (e.isFile()) exe = e;
        }
        return new Java(exe, homeDir, parseMajor(version), source);
    }

    /** "25.0.3" -> 25；"1.8.0_292" -> 8。 */
    public static int parseMajor(String version) {
        try {
            String v = version.trim();
            int end = 0;
            while (end < v.length() && (Character.isDigit(v.charAt(end)) || v.charAt(end) == '.')) end++;
            String numeric = v.substring(0, end);
            String[] parts = numeric.split("\\.");
            if (parts.length == 0 || parts[0].isEmpty()) return -1;
            int first = Integer.parseInt(parts[0]);
            if (first == 1 && parts.length > 1) return Integer.parseInt(parts[1]);
            return first;
        } catch (Exception e) {
            return -1;
        }
    }

    /**
     * 扫描所有可用的 Java：配置路径 → 内置 JBR → JAVA_HOME → PATH → 系统常见安装目录。
     * 按 java 可执行文件路径去重；每个候选都会真实执行一次 java -version，较慢，请放后台线程。
     */
    public static List<Java> detectAll(String configuredPath, Consumer<String> log) {
        List<Candidate> homes = new ArrayList<>();
        if (configuredPath != null && !configuredPath.isBlank()) {
            homes.add(new Candidate(new File(configuredPath.trim()), "指定路径"));
        }
        for (File base : repoCandidates()) homes.add(new Candidate(new File(base, "lib/jbr"), "内置 JBR"));
        String javaHome = System.getenv("JAVA_HOME");
        if (javaHome != null && !javaHome.isBlank()) homes.add(new Candidate(new File(javaHome), "JAVA_HOME"));
        homes.add(new Candidate(null, "PATH"));
        if (WINDOWS) {
            for (File root : windowsJavaRoots()) {
                for (File d : subDirs(root)) homes.add(new Candidate(d, "系统安装"));
            }
        }

        List<Java> found = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (Candidate c : homes) {
            Java j = probe(c.file, c.source);
            if (j == null) continue;
            String key = j.exe != null ? canonical(j.exe).getPath()
                    : (c.file == null ? "PATH" : canonical(c.file).getPath());
            if (!seen.add(key)) continue;
            found.add(j);
            if (log != null) log.accept("发现可用 Java：" + j.label());
        }
        if (log != null && found.isEmpty()) log.accept("未找到任何可用的 Java");
        return found;
    }

    private static final class Candidate {
        final File file;
        final String source;

        Candidate(File file, String source) {
            this.file = file;
            this.source = source;
        }
    }

    private static List<File> windowsJavaRoots() {
        List<File> roots = new ArrayList<>();
        String pf = System.getenv("ProgramFiles");
        String pf86 = System.getenv("ProgramFiles(x86)");
        String local = System.getenv("LOCALAPPDATA");
        for (String base : new String[]{pf, pf86}) {
            if (base == null || base.isBlank()) continue;
            File b = new File(base);
            roots.add(new File(b, "Java"));
            roots.add(new File(b, "Eclipse Adoptium"));
            roots.add(new File(b, "Eclipse Foundation"));
            roots.add(new File(b, "Microsoft"));
            roots.add(new File(b, "Amazon Corretto"));
            roots.add(new File(b, "Zulu"));
            roots.add(new File(b, "BellSoft"));
            roots.add(new File(b, "Semeru"));
            roots.add(new File(b, "JetBrains"));
        }
        if (local != null && !local.isBlank()) {
            File b = new File(local, "Programs");
            roots.add(new File(b, "Eclipse Adoptium"));
            roots.add(new File(b, "Microsoft"));
            roots.add(new File(b, "Zulu"));
            roots.add(new File(b, "Amazon Corretto"));
            roots.add(new File(b, "BellSoft"));
        }
        return roots;
    }

    /** 只把确实含 bin/java.exe 的子目录当作候选，避免对无关目录做无效探测。 */
    private static List<File> subDirs(File root) {
        List<File> out = new ArrayList<>();
        File[] kids = root.listFiles(File::isDirectory);
        if (kids == null) return out;
        for (File k : kids) {
            if (new File(k, WINDOWS ? "bin/java.exe" : "bin/java").isFile()) out.add(k);
        }
        return out;
    }

    private static List<File> repoCandidates() {
        Set<File> set = new LinkedHashSet<>();
        File cwd = canonical(new File(System.getProperty("user.dir", ".")));
        set.add(cwd);
        set.add(canonical(new File(cwd, "..")));
        set.add(canonical(new File(cwd, "../..")));
        return new ArrayList<>(set);
    }

    private static File canonical(File f) {
        try {
            return f.getCanonicalFile();
        } catch (IOException e) {
            return f.getAbsoluteFile();
        }
    }
}
