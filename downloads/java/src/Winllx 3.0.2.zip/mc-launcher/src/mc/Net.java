package mc;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.function.LongConsumer;

/**
 * HTTP 工具：GET 文本 / 下载文件（size + sha1 校验、.tmp 分片文件、断点续传、失败指数退避重试）。
 *
 * 断点续传：传输中断时保留 {@code <目标名>.tmp}，下次尝试对该分片发 {@code Range} 请求接着写。
 * 若服务器不支持（返回 200 而非 206）则从头重下；若分片已完整（416）直接视为完成。
 * 校验失败（大小 / sha1 不符）说明分片不可信，会先删除分片再重下。
 */
public final class Net {

    private static final String UA = "mc-launcher/1.0 (standalone)";
    private static final int CONNECT_TIMEOUT_MS = 15_000;
    private static final int READ_TIMEOUT_MS = 60_000;
    private static final int MAX_ATTEMPTS = 3;

    private Net() {}

    // 游戏资源有六万个小文件，全部走同一台主机；提高每个主机的长连接上限，避免每个文件都重新握手
    static {
        System.setProperty("http.maxConnections", "24");
    }

    /** GET 一个文本资源（失败重试）。 */
    public static String getString(String url) throws IOException {
        IOException last = null;
        for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            try (InputStream in = open(url).getInputStream()) {
                return new String(in.readAllBytes(), StandardCharsets.UTF_8);
            } catch (IOException e) {
                last = e;
                backoff(attempt);
            }
        }
        throw new IOException("请求失败：" + url + "（" + (last == null ? "未知错误" : last.getMessage()) + "）", last);
    }

    /**
     * 下载 url 到 dest。
     *
     * @param expectedSize 期望字节数，<=0 表示不校验
     * @param expectedSha1 期望 sha1，null 表示不校验
     * @param verifySha1   是否做 sha1 校验（海量 asset 小文件只按大小跳过，避免逐文件哈希）
     * @param onBytes      每读取一块的回调（用于累计进度），可为 null
     * @return 实际传输的字节数；目标已存在且校验通过时返回 0（表示跳过）
     */
    public static long download(String url, File dest, long expectedSize, String expectedSha1,
                                boolean verifySha1, LongConsumer onBytes, Consumer<String> log) throws IOException {
        if (dest.isFile()
                && (expectedSize <= 0 || dest.length() == expectedSize)
                && (!verifySha1 || expectedSha1 == null || expectedSha1.equalsIgnoreCase(sha1(dest)))) {
            return 0;
        }

        File parent = dest.getParentFile();
        if (parent != null) Files.createDirectories(parent.toPath());
        File tmp = new File(parent, dest.getName() + ".tmp");

        IOException last = null;
        for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            try {
                long n = transfer(url, tmp, true, onBytes, log);
                if (expectedSize > 0 && n != expectedSize) {
                    throw new VerificationException("字节数不符：期望 " + expectedSize + "，实际 " + n);
                }
                if (verifySha1 && expectedSha1 != null) {
                    String got = sha1(tmp);
                    if (!expectedSha1.equalsIgnoreCase(got)) {
                        throw new VerificationException("sha1 校验失败：期望 " + expectedSha1 + "，实际 " + got);
                    }
                }
                move(tmp, dest);
                return n;
            } catch (IOException e) {
                last = e;
                if (e instanceof VerificationException) {
                    // 已有分片与期望不符（可能来自别的版本或已损坏），继续续传只会一直失败，必须丢弃重下
                    try {
                        Files.deleteIfExists(tmp.toPath());
                    } catch (IOException ignore) {
                        // 分片清理失败不影响重试
                    }
                }
                // 网络类错误刻意保留 .tmp，下次尝试可以从断点继续
                if (attempt < MAX_ATTEMPTS && log != null) {
                    log.accept("下载失败（第 " + attempt + " 次）：" + url + " - " + e.getMessage() + "，准备重试");
                }
                backoff(attempt);
            }
        }
        throw new IOException("下载失败：" + url + "（" + (last == null ? "未知错误" : last.getMessage()) + "）", last);
    }

    /** 校验失败（大小 / sha1 不符）：此时已下载的分片不可信，不能用于续传。 */
    private static final class VerificationException extends IOException {
        VerificationException(String message) {
            super(message);
        }
    }

    /** 计算文件 sha1（十六进制小写）。 */
    public static String sha1(File f) throws IOException {
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("SHA-1");
        } catch (Exception e) {
            throw new IOException("SHA-1 摘要不可用", e);
        }
        byte[] buf = new byte[64 * 1024];
        try (InputStream in = Files.newInputStream(f.toPath())) {
            int r;
            while ((r = in.read(buf)) > 0) md.update(buf, 0, r);
        }
        StringBuilder sb = new StringBuilder(40);
        for (byte b : md.digest()) {
            sb.append(Character.forDigit((b >> 4) & 0xF, 16)).append(Character.forDigit(b & 0xF, 16));
        }
        return sb.toString();
    }

    // ===== 认证类请求 =====

    /**
     * 带状态码的响应。
     * 登录相关接口（设备码轮询、XSTS 等）需要用错误体里的 error / XErr 字段判断分支，
     * 所以不能像 {@link #getString} 那样把非 2xx 直接当异常抛出。
     */
    public static final class Response {
        public final int code;
        public final String body;

        Response(int code, String body) {
            this.code = code;
            this.body = body;
        }

        public boolean ok() {
            return code >= 200 && code < 300;
        }
    }

    public static Response get(String url, Map<String, String> headers) throws IOException {
        return request("GET", url, null, null, headers);
    }

    public static Response postForm(String url, Map<String, String> form) throws IOException {
        return request("POST", url, formEncode(form), "application/x-www-form-urlencoded", null);
    }

    public static Response postJson(String url, String jsonBody, Map<String, String> headers) throws IOException {
        return request("POST", url, jsonBody, "application/json", headers);
    }

    private static Response request(String method, String url, String body, String contentType,
                                    Map<String, String> headers) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) java.net.URI.create(url).toURL().openConnection();
        try {
            conn.setRequestMethod(method);
            conn.setRequestProperty("User-Agent", UA);
            conn.setRequestProperty("Accept", "application/json");
            if (contentType != null) conn.setRequestProperty("Content-Type", contentType);
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    conn.setRequestProperty(e.getKey(), e.getValue());
                }
            }
            conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
            conn.setReadTimeout(READ_TIMEOUT_MS);
            conn.setInstanceFollowRedirects(true);

            if (body != null) {
                byte[] data = body.getBytes(StandardCharsets.UTF_8);
                conn.setDoOutput(true);
                conn.setFixedLengthStreamingMode(data.length);
                try (OutputStream out = conn.getOutputStream()) {
                    out.write(data);
                }
            }

            int code = conn.getResponseCode();
            InputStream in = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
            String text = in == null ? "" : new String(in.readAllBytes(), StandardCharsets.UTF_8);
            return new Response(code, text);
        } finally {
            conn.disconnect();
        }
    }

    private static String formEncode(Map<String, String> form) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : form.entrySet()) {
            if (sb.length() > 0) sb.append('&');
            sb.append(URLEncoder.encode(e.getKey(), StandardCharsets.UTF_8))
              .append('=')
              .append(URLEncoder.encode(e.getValue(), StandardCharsets.UTF_8));
        }
        return sb.toString();
    }

    /**
     * 把 url 的内容写入 {@code tmp}，支持从已有分片继续。
     *
     * @param resume  是否允许利用已有分片（true 时会先发 Range 请求）
     * @return 写入后的分片总长度（含续传前已有的部分）
     */
    private static long transfer(String url, File tmp, boolean resume, LongConsumer onBytes, Consumer<String> log)
            throws IOException {
        long already = resume && tmp.isFile() ? tmp.length() : 0;

        HttpURLConnection conn = (HttpURLConnection) java.net.URI.create(url).toURL().openConnection();
        conn.setRequestProperty("User-Agent", UA);
        conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
        conn.setReadTimeout(READ_TIMEOUT_MS);
        conn.setInstanceFollowRedirects(true);
        if (already > 0) conn.setRequestProperty("Range", "bytes=" + already + "-");

        int code = conn.getResponseCode();
        if (already > 0 && code == HttpURLConnection.HTTP_PARTIAL) {
            if (log != null) log.accept("断点续传：" + tmp.getName() + " 从 " + human(already) + " 继续");
        } else if (already > 0 && code == HttpURLConnection.HTTP_OK) {
            // 服务器不支持范围请求：丢弃已有分片从头下载
            already = 0;
            if (log != null) log.accept("服务器不支持断点续传，重新下载：" + tmp.getName());
        } else if (already > 0 && code == 416) {
            // Range 越界说明分片长度已达到目标长度，直接当作下载完成
            conn.disconnect();
            return already;
        } else if (code < 200 || code >= 300) {
            conn.disconnect();
            throw new IOException("HTTP " + code + " - " + url);
        }

        long total = already;
        try (InputStream in = new BufferedInputStream(conn.getInputStream(), 128 * 1024);
             OutputStream out = new BufferedOutputStream(already > 0
                     ? Files.newOutputStream(tmp.toPath(), StandardOpenOption.APPEND, StandardOpenOption.WRITE)
                     : Files.newOutputStream(tmp.toPath(), StandardOpenOption.CREATE,
                             StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE), 128 * 1024)) {
            byte[] buf = new byte[128 * 1024];
            int r;
            while ((r = in.read(buf)) > 0) {
                out.write(buf, 0, r);
                total += r;
                if (onBytes != null) onBytes.accept(r);
            }
        } catch (IOException e) {
            // 只在失败时断开，成功时把连接还给连接池以便复用（资源下载有六万个小文件，握手开销是大头）
            conn.disconnect();
            throw e;
        }
        return total;
    }

    private static HttpURLConnection open(String url) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) java.net.URI.create(url).toURL().openConnection();
        conn.setRequestProperty("User-Agent", UA);
        conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
        conn.setReadTimeout(READ_TIMEOUT_MS);
        conn.setInstanceFollowRedirects(true);
        int code = conn.getResponseCode();
        if (code < 200 || code >= 300) {
            conn.disconnect();
            throw new IOException("HTTP " + code + " - " + url);
        }
        return conn;
    }

    // ===== 并行下载 =====

    /** 一个待下载项。失败详情写在 {@link #error}，便于调用方汇总。 */
    public static final class Task {
        public final String url;
        public final File dest;
        public final long size;
        public final String sha1;
        public final boolean verifySha1;
        /** 每读到一块数据时回调（可为 null；并行调用，注意线程安全）。 */
        public LongConsumer onBytes;
        /** 该任务结束（成功 / 失败 / 跳过）后调用一次（可为 null）。 */
        public Runnable onFinish;
        public String error;

        public Task(String url, File dest, long size, String sha1, boolean verifySha1) {
            this.url = url;
            this.dest = dest;
            this.size = size;
            this.sha1 = sha1;
            this.verifySha1 = verifySha1;
        }
    }

    /**
     * 并行下载一批文件。每个文件各有独立线程与独立 {@code .tmp}，因此天然支持断点续传，
     * 且互不干扰。调用方若关心顺序（如 classpath 顺序），应在下载完成后再按原顺序读取结果文件。
     *
     * @return 失败的任务数
     */
    public static int downloadAll(List<Task> tasks, int threads, Consumer<String> log) {
        if (tasks == null || tasks.isEmpty()) return 0;
        int poolSize = Math.max(1, Math.min(tasks.size(), threads));
        AtomicInteger failed = new AtomicInteger();
        CountDownLatch latch = new CountDownLatch(tasks.size());
        ExecutorService pool = Executors.newFixedThreadPool(poolSize, r -> {
            Thread t = new Thread(r, "mc-download");
            t.setDaemon(true);
            return t;
        });
        try {
            for (Task task : tasks) {
                pool.execute(() -> {
                    try {
                        download(task.url, task.dest, task.size, task.sha1, task.verifySha1, task.onBytes, log);
                    } catch (Exception ex) {
                        failed.incrementAndGet();
                        task.error = ex.getMessage() == null ? ex.toString() : ex.getMessage();
                    } finally {
                        if (task.onFinish != null) task.onFinish.run();
                        latch.countDown();
                    }
                });
            }
            latch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            pool.shutdownNow();
        }
        return failed.get();
    }

    private static String human(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return (bytes / 1024) + " KB";
        return String.format("%.1f MB", bytes / 1024.0 / 1024);
    }

    private static void move(File tmp, File dest) throws IOException {
        Path from = tmp.toPath();
        Path to = dest.toPath();
        try {
            Files.move(from, to, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            Files.move(from, to, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static void backoff(int attempt) {
        if (attempt >= MAX_ATTEMPTS) return;
        long ms = 500L * (long) Math.pow(3, attempt - 1);  // 500ms / 1500ms
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
