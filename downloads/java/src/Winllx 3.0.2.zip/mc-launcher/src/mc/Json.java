package mc;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 极简递归下降 JSON 解析器。
 * 解析结果：Map（对象）/ List（数组）/ String / Long（整数）/ Double（小数）/ Boolean / null。
 * 自己写的原因：本启动器沿用仓库「零第三方依赖」的约定。
 *
 * 说明：Unicode 转义（反斜杠 + u + 4 位十六进制）按 UTF-16 码元逐个追加，
 * 代理对以两个连续转义序列出现时会自然拼成正确字符。
 */
public final class Json {

    private final String src;
    private int pos;

    private Json(String src) {
        this.src = src;
    }

    public static Object parse(String text) {
        if (text == null) throw new IllegalArgumentException("JSON 解析失败：内容为空");
        Json p = new Json(text);
        p.skipWs();
        Object v = p.readValue();
        p.skipWs();
        if (p.pos != p.src.length()) {
            throw new IllegalArgumentException("JSON 解析失败：位置 " + p.pos + " 之后存在多余内容");
        }
        return v;
    }

    // ===== 取值辅助 =====

    @SuppressWarnings("unchecked")
    public static Map<String, Object> asMap(Object node) {
        return node instanceof Map ? (Map<String, Object>) node : null;
    }

    @SuppressWarnings("unchecked")
    public static List<Object> asList(Object node) {
        return node instanceof List ? (List<Object>) node : null;
    }

    public static Object get(Object node, String key) {
        Map<String, Object> m = asMap(node);
        return m == null ? null : m.get(key);
    }

    public static String str(Object node, String key) {
        Object v = get(node, key);
        return v == null ? null : String.valueOf(v);
    }

    public static long num(Object node, String key, long def) {
        Object v = get(node, key);
        return v instanceof Number n ? n.longValue() : def;
    }

    public static int intVal(Object node, String key, int def) {
        Object v = get(node, key);
        return v instanceof Number n ? n.intValue() : def;
    }

    // ===== 解析实现 =====

    private Object readValue() {
        char c = peek();
        switch (c) {
            case '{': return readObject();
            case '[': return readArray();
            case '"': return readString();
            case 't': expect("true"); return Boolean.TRUE;
            case 'f': expect("false"); return Boolean.FALSE;
            case 'n': expect("null"); return null;
            default: return readNumber();
        }
    }

    private Map<String, Object> readObject() {
        Map<String, Object> map = new LinkedHashMap<>();
        pos++; // '{'
        skipWs();
        if (peek() == '}') {
            pos++;
            return map;
        }
        while (true) {
            skipWs();
            if (peek() != '"') throw error("期望对象键名（字符串）");
            String key = readString();
            skipWs();
            if (peek() != ':') throw error("期望 ':'");
            pos++;
            skipWs();
            map.put(key, readValue());
            skipWs();
            char c = peek();
            if (c == ',') {
                pos++;
                continue;
            }
            if (c == '}') {
                pos++;
                return map;
            }
            throw error("期望 ',' 或 '}'");
        }
    }

    private List<Object> readArray() {
        List<Object> list = new ArrayList<>();
        pos++; // '['
        skipWs();
        if (peek() == ']') {
            pos++;
            return list;
        }
        while (true) {
            skipWs();
            list.add(readValue());
            skipWs();
            char c = peek();
            if (c == ',') {
                pos++;
                continue;
            }
            if (c == ']') {
                pos++;
                return list;
            }
            throw error("期望 ',' 或 ']'");
        }
    }

    private String readString() {
        pos++; // '"'
        StringBuilder sb = new StringBuilder(24);
        while (true) {
            if (pos >= src.length()) throw error("字符串未闭合");
            char c = src.charAt(pos++);
            if (c == '"') return sb.toString();
            if (c != '\\') {
                sb.append(c);
                continue;
            }
            if (pos >= src.length()) throw error("转义符未闭合");
            char e = src.charAt(pos++);
            switch (e) {
                case '"': sb.append('"'); break;
                case '\\': sb.append('\\'); break;
                case '/': sb.append('/'); break;
                case 'b': sb.append('\b'); break;
                case 'f': sb.append('\f'); break;
                case 'n': sb.append('\n'); break;
                case 'r': sb.append('\r'); break;
                case 't': sb.append('\t'); break;
                case 'u':
                    if (pos + 4 > src.length()) throw error("\\u 转义不完整");
                    sb.append((char) Integer.parseInt(src.substring(pos, pos + 4), 16));
                    pos += 4;
                    break;
                default: throw error("未知转义符 \\" + e);
            }
        }
    }

    private Object readNumber() {
        int start = pos;
        boolean isDouble = false;
        while (pos < src.length()) {
            char c = src.charAt(pos);
            if (c == '-' || c == '+' || (c >= '0' && c <= '9')) {
                pos++;
                continue;
            }
            if (c == '.' || c == 'e' || c == 'E') {
                isDouble = true;
                pos++;
                continue;
            }
            break;
        }
        String s = src.substring(start, pos);
        if (s.isEmpty()) throw error("期望数字");
        try {
            return isDouble ? (Object) Double.valueOf(s) : (Object) Long.valueOf(s);
        } catch (NumberFormatException ex) {
            throw error("非法数字 '" + s + "'");
        }
    }

    private char peek() {
        if (pos >= src.length()) throw error("内容意外结束");
        return src.charAt(pos);
    }

    private void expect(String literal) {
        if (!src.startsWith(literal, pos)) throw error("期望 " + literal);
        pos += literal.length();
    }

    private void skipWs() {
        while (pos < src.length()) {
            char c = src.charAt(pos);
            if (c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == '\uFEFF') pos++;
            else break;
        }
    }

    private IllegalArgumentException error(String msg) {
        return new IllegalArgumentException("JSON 解析失败（位置 " + pos + "）：" + msg);
    }
}
