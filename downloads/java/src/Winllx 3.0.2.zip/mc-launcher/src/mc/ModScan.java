package mc;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipFile;

/**
 * mod 侧的本地分析：实例发现（含加载器识别）、jar 内元数据读取、依赖与冲突判定。
 *
 * 元数据来源完全是 jar 自带的描述文件，因此对「从 Modrinth 装的」和「手动丢进 mods 的」一视同仁：
 * fabric.mod.json（Fabric）、quilt.mod.json（Quilt）、META-INF/neoforge.mods.toml、META-INF/mods.toml（Forge/NeoForge）、mcmod.info（旧版）。
 */
public final class ModScan {

    /** 属于游戏或加载器自身的依赖 id，不需要额外安装。 */
    private static final Set<String> BUILTIN = Set.of(
            "minecraft", "java", "fabricloader", "quilt_loader", "forge", "neoforge", "minecraftforge");

    private ModScan() {}

    // ===== 实例 =====

    /** 一个本地实例（= versions 目录下的一个已安装版本）。 */
    public static final class Instance {
        public String id;
        public String mcVersion;
        /** vanilla / fabric / forge / neoforge / quilt */
        public String loader = "vanilla";
        public File installDir;
        public File gameDir;
        public File modsDir;

        public String label() {
            return id + "（" + loaderLabel(loader) + " · MC " + mcVersion + "）";
        }

        @Override
        public String toString() {
            return label();
        }
    }

    /**
     * 扫描 baseDir/versions 下所有本地已安装版本作为可选实例。
     * 加载器从版本 JSON 的 libraries 里识别，因此外部安装器装的 Forge/Fabric 也能被认出来。
     */
    public static List<Instance> listInstances(Settings st) {
        List<Instance> out = new ArrayList<>();
        File versions = new File(st.baseDir(), "versions");
        File[] dirs = versions.listFiles(File::isDirectory);
        if (dirs == null) return out;

        for (File dir : dirs) {
            File jar = new File(dir, dir.getName() + ".jar");
            File json = new File(dir, dir.getName() + ".json");
            if (!json.isFile()) continue;

            Instance inst = new Instance();
            inst.id = dir.getName();
            inst.installDir = dir;
            inst.mcVersion = inst.id;
            try {
                Object root = Json.parse(java.nio.file.Files.readString(json.toPath(), StandardCharsets.UTF_8));
                String declared = Json.str(root, "id");
                if (declared != null && !declared.isBlank()) inst.id = declared;
                String parent = Json.str(root, "inheritsFrom");
                if (parent != null && !parent.isBlank()) inst.mcVersion = parent;
                else inst.mcVersion = guessMcVersion(inst.id);

                // 加载器识别：优先看 libraries 的 group，再看主类
                String mainClass = Json.str(root, "mainClass");
                inst.loader = detectLoader(Json.asList(Json.get(root, "libraries")), mainClass);
            } catch (Exception e) {
                // 版本 JSON 读不出来时按原版处理，仍然可以作为安装目标
                inst.loader = "vanilla";
            }
            File base = st.baseDir();
            inst.gameDir = st.instanceIsolation ? new File(new File(base, "instances"), inst.id) : base;
            inst.modsDir = new File(inst.gameDir, "mods");
            out.add(inst);
        }
        out.sort(Comparator.comparing((Instance i) -> i.id).reversed());
        return out;
    }

    private static String detectLoader(List<Object> libraries, String mainClass) {
        if (libraries != null) {
            for (Object lib : libraries) {
                String name = Json.str(lib, "name");
                if (name == null) continue;
                String g = name.toLowerCase();
                if (g.startsWith("net.fabricmc") && g.contains("fabric-loader")) return "fabric";
                if (g.startsWith("net.neoforged")) return "neoforge";
                if (g.startsWith("net.minecraftforge")) return "forge";
                if (g.startsWith("org.quiltmc")) return "quilt";
            }
        }
        if (mainClass != null) {
            String m = mainClass.toLowerCase();
            if (m.contains("fabricmc")) return "fabric";
            if (m.contains("neoforged")) return "neoforge";
            if (m.contains("minecraftforge")) return "forge";
            if (m.contains("quiltmc")) return "quilt";
        }
        return "vanilla";
    }

    /** 从形如 fabric-loader-0.16.9-1.21.1 / 1.21.1-forge-51.0.0 的 id 里抠出 MC 版本号。 */
    static String guessMcVersion(String id) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+\\.\\d+(?:\\.\\d+)?)").matcher(id == null ? "" : id);
        String best = null;
        while (m.find()) {
            String v = m.group(1);
            if (best == null || compare(v, best) < 0) best = v;   // 取最小的一段，通常是 MC 版本
        }
        return best == null ? id : best;
    }

    public static String loaderLabel(String loader) {
        return switch (loader == null ? "vanilla" : loader) {
            case "fabric" -> "Fabric";
            case "forge" -> "Forge";
            case "neoforge" -> "NeoForge";
            case "quilt" -> "Quilt";
            default -> "原版";
        };
    }

    /** 该实例的加载器允许装载哪些 jar 类型。 */
    static List<String> acceptableKinds(String loader) {
        return switch (loader == null ? "vanilla" : loader) {
            case "fabric" -> List.of("fabric");
            case "quilt" -> List.of("quilt", "fabric");
            case "forge" -> List.of("forge");
            case "neoforge" -> List.of("neoforge");
            default -> List.of();      // 原版客户端不加载任何 mod
        };
    }

    // ===== jar 元数据 =====

    /** 一个已安装 mod 的信息（来自它自己的描述文件）。 */
    public static final class Mod {
        public File file;
        public String modId;
        public String name;
        public String version;
        /** fabric / quilt / forge / neoforge / legacy；null 表示识别不出 */
        public String kind;
        /** 声明的 Minecraft 版本范围 */
        public String mcRange;
        public String error;
        public final List<Dep> requires = new ArrayList<>();
        public final List<String> provides = new ArrayList<>();
        public final List<String> incompatible = new ArrayList<>();

        public String display() {
            String n = name != null && !name.isBlank() ? name : (modId == null ? file.getName() : modId);
            return n + (version == null || version.isBlank() ? "" : " " + version) + "   [" + kindLabel(kind) + "]";
        }

        public String fileName() {
            return file.getName();
        }

        @Override
        public String toString() {
            String s = display() + "   (" + fileName() + ")";
            if (error != null) s += "  ← " + error;
            return s;
        }
    }

    /** 依赖声明：modId + 版本范围 + 是否必需。 */
    public static final class Dep {
        public final String modId;
        public final String range;
        public final boolean mandatory;

        public Dep(String modId, String range, boolean mandatory) {
            this.modId = modId;
            this.range = range;
            this.mandatory = mandatory;
        }
    }

    public static String kindLabel(String kind) {
        if (kind == null) return "未知";
        return switch (kind) {
            case "fabric" -> "Fabric";
            case "quilt" -> "Quilt";
            case "forge" -> "Forge";
            case "neoforge" -> "NeoForge";
            case "legacy" -> "旧版";
            default -> kind;
        };
    }

    /** 读取 mods 目录下所有 .jar 的元数据（目录不存在时返回空列表）。 */
    public static List<Mod> scan(File modsDir) {
        List<Mod> out = new ArrayList<>();
        File[] jars = modsDir.isDirectory() ? modsDir.listFiles(
                f -> f.isFile() && f.getName().toLowerCase().endsWith(".jar")) : null;
        if (jars == null) return out;
        java.util.Arrays.sort(jars, Comparator.comparing(File::getName));
        for (File jar : jars) out.add(readJar(jar));
        return out;
    }

    /** 读取单个 jar 的描述文件。识别失败的 jar 仍会返回（kind 为 null 并带 error）。 */
    public static Mod readJar(File jar) {
        Mod m = new Mod();
        m.file = jar;
        try (ZipFile zip = new ZipFile(jar)) {
            String fabric = readEntry(zip, "fabric.mod.json");
            String quilt = readEntry(zip, "quilt.mod.json");
            String neo = readEntry(zip, "META-INF/neoforge.mods.toml");
            String forge = readEntry(zip, "META-INF/mods.toml");
            String legacy = readEntry(zip, "mcmod.info");

            if (fabric != null) {
                m.kind = "fabric";
                parseFabric(m, fabric);
                collectNestedProvides(m, zip);
            } else if (quilt != null) {
                m.kind = "quilt";
                parseQuilt(m, quilt);
                collectNestedProvides(m, zip);
            } else if (neo != null) {
                m.kind = "neoforge";
                parseToml(m, neo);
            } else if (forge != null) {
                m.kind = "forge";
                parseToml(m, forge);
            } else if (legacy != null) {
                m.kind = "legacy";
                parseLegacy(m, legacy);
            } else {
                m.error = "不是 mod（缺少描述文件）";
            }
        } catch (Exception e) {
            m.error = "读取失败：" + e.getMessage();
        }
        return m;
    }

    private static String readEntry(ZipFile zip, String name) throws IOException {
        java.util.zip.ZipEntry e = zip.getEntry(name);
        if (e == null) return null;
        try (InputStream in = zip.getInputStream(e)) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    /**
     * 收集 jar-in-jar 内嵌模块（Fabric API 的各子模块就打包在其 META-INF/jars/ 下）的 id 与 provides。
     * 不加这一步，任何依赖 fabric-renderer-api-v1 之类的 mod 都会被误报成"缺少必需的前置"。
     */
    private static void collectNestedProvides(Mod m, ZipFile zip) {
        java.util.Enumeration<? extends java.util.zip.ZipEntry> en = zip.entries();
        while (en.hasMoreElements()) {
            java.util.zip.ZipEntry e = en.nextElement();
            if (e.isDirectory()) continue;
            String name = e.getName();
            if (!name.startsWith("META-INF/jars/") || !name.toLowerCase().endsWith(".jar")) continue;
            try (InputStream in = zip.getInputStream(e)) {
                readNestedDescriptor(m, in.readAllBytes());
            } catch (Exception ignore) {
                // 内嵌模块读不出来不影响顶层 mod 的判定
            }
        }
    }

    private static void readNestedDescriptor(Mod m, byte[] jarBytes) {
        try (java.util.zip.ZipInputStream zin =
                     new java.util.zip.ZipInputStream(new java.io.ByteArrayInputStream(jarBytes))) {
            java.util.zip.ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                String n = e.getName();
                boolean isFabric = n.equals("fabric.mod.json");
                boolean isQuilt = n.equals("quilt.mod.json");
                if (!isFabric && !isQuilt) {
                    zin.closeEntry();
                    continue;
                }
                String text = new String(zin.readAllBytes(), StandardCharsets.UTF_8);
                Object root = Json.parse(text);
                String id;
                if (isFabric) {
                    id = Json.str(root, "id");
                    addProvides(m, Json.get(root, "provides"));
                } else {
                    Object ql = Json.get(root, "quilt_loader");
                    id = Json.str(ql, "id");
                    addProvides(m, Json.get(ql, "provides"));
                }
                if (id != null && !id.isBlank()) m.provides.add(id);
                return;
            }
        } catch (Exception ignore) {
            // 内嵌模块的描述文件不合法时忽略
        }
    }

    // ----- Fabric -----

    private static void parseFabric(Mod m, String text) {
        Object root = Json.parse(text);
        m.modId = Json.str(root, "id");
        m.name = Json.str(root, "name");
        m.version = Json.str(root, "version");
        addProvides(m, Json.get(root, "provides"));

        Map<String, Object> depends = Json.asMap(Json.get(root, "depends"));
        if (depends != null) {
            for (Map.Entry<String, Object> e : depends.entrySet()) {
                String range = flattenRange(e.getValue());
                m.requires.add(new Dep(e.getKey(), range, true));
                if ("minecraft".equalsIgnoreCase(e.getKey())) m.mcRange = range;
            }
        }
        addKeysAsIncompatible(m, Json.get(root, "breaks"));
        addKeysAsIncompatible(m, Json.get(root, "conflicts"));
    }

    // ----- Quilt -----

    private static void parseQuilt(Mod m, String text) {
        Object root = Json.parse(text);
        Object ql = Json.get(root, "quilt_loader");
        m.modId = Json.str(ql, "id");
        m.version = Json.str(ql, "version");
        Object meta = Json.get(ql, "metadata");
        m.name = Json.str(meta, "name");

        List<Object> deps = Json.asList(Json.get(ql, "depends"));
        if (deps != null) {
            for (Object d : deps) {
                String id = Json.str(d, "id");
                if (id == null) continue;
                boolean optional = Boolean.TRUE.equals(Json.get(d, "optional"));
                String range = Json.str(d, "versions");
                m.requires.add(new Dep(id, range, !optional));
                if ("minecraft".equalsIgnoreCase(id)) m.mcRange = range;
            }
        }
        addProvides(m, Json.get(ql, "provides"));
        List<Object> breaks = Json.asList(Json.get(ql, "breaks"));
        if (breaks != null) {
            for (Object b : breaks) {
                String id = Json.str(b, "id");
                if (id != null) m.incompatible.add(id);
            }
        }
    }

    // ----- Forge / NeoForge（mods.toml） -----

    private static void parseToml(Mod m, String text) {
        Toml toml = Toml.parse(text);
        Map<String, String> modTable = toml.firstTable("mods");
        if (modTable != null) {
            m.modId = modTable.get("modId");
            m.name = modTable.get("displayName");
            m.version = modTable.get("version");
        }
        for (Map<String, String> dep : toml.tablesStartingWith("dependencies")) {
            String id = dep.get("modId");
            if (id == null || id.isBlank()) continue;
            boolean mandatory = !"false".equalsIgnoreCase(String.valueOf(dep.getOrDefault("mandatory", "true")));
            String range = dep.get("versionRange");
            m.requires.add(new Dep(id, range, mandatory));
            if ("minecraft".equalsIgnoreCase(id)) m.mcRange = range;
        }
    }

    // ----- 旧版 mcmod.info -----

    private static void parseLegacy(Mod m, String text) {
        List<Object> arr = Json.asList(Json.parse(text));
        if (arr == null || arr.isEmpty()) return;
        Object first = arr.get(0);
        m.modId = Json.str(first, "modid");
        if (m.modId == null) m.modId = Json.str(first, "modId");
        m.name = Json.str(first, "name");
        m.version = Json.str(first, "version");
        m.mcRange = Json.str(first, "mcversion");
    }

    // ----- 公共小工具 -----

    /** depends 的值可能是字符串，也可能是字符串数组（数组表示可择一满足）。 */
    static String flattenRange(Object value) {
        List<Object> arr = Json.asList(value);
        if (arr == null) return value == null ? null : String.valueOf(value);
        StringBuilder sb = new StringBuilder();
        for (Object o : arr) {
            if (sb.length() > 0) sb.append(" || ");
            sb.append(o);
        }
        return sb.toString();
    }

    private static void addProvides(Mod m, Object node) {
        List<Object> arr = Json.asList(node);
        if (arr == null) return;
        for (Object o : arr) {
            if (o != null) m.provides.add(String.valueOf(o));
        }
    }

    private static void addKeysAsIncompatible(Mod m, Object node) {
        Map<String, Object> map = Json.asMap(node);
        if (map == null) return;
        for (String k : map.keySet()) m.incompatible.add(k);
    }

    // ===== 冲突分析 =====

    public static final class Finding {
        public static final int ERROR = 0;
        public static final int WARN = 1;
        public static final int INFO = 2;
        public final int severity;
        public final String title;
        public final String detail;

        Finding(int severity, String title, String detail) {
            this.severity = severity;
            this.title = title;
            this.detail = detail;
        }
    }

    /** 一个实例的分析结果。 */
    public static final class Report {
        public final Instance instance;
        public final List<Mod> mods;
        public final List<Finding> findings = new ArrayList<>();
        /** 因为加载器不匹配等问题，jar 里的 mod 数量 */
        public final List<Mod> unknown = new ArrayList<>();
        /** 去重键：同一个问题被多个副本触发时只报告一次。 */
        private final Set<String> seen = new LinkedHashSet<>();

        Report(Instance instance, List<Mod> mods) {
            this.instance = instance;
            this.mods = mods;
        }

        void add(int severity, String title, String detail) {
            if (!seen.add(severity + "\u0000" + title + "\u0000" + detail)) return;
            findings.add(new Finding(severity, title, detail));
        }

        public int errorCount() {
            int n = 0;
            for (Finding f : findings) if (f.severity == Finding.ERROR) n++;
            return n;
        }

        public int warnCount() {
            int n = 0;
            for (Finding f : findings) if (f.severity == Finding.WARN) n++;
            return n;
        }

        public boolean blocking() {
            return errorCount() > 0;
        }

        /** 结论 + 问题清单 + 正确启动步骤，直接给弹窗显示。 */
        public String format() {
            StringBuilder sb = new StringBuilder();
            sb.append("实例：").append(instance.id)
              .append("（加载器 ").append(loaderLabel(instance.loader))
              .append("，Minecraft ").append(instance.mcVersion).append("）\n");
            sb.append("mods 目录：").append(instance.modsDir.getAbsolutePath()).append("\n");
            sb.append("已安装 mod：").append(mods.size()).append(" 个");
            if (!unknown.isEmpty()) sb.append("（其中 ").append(unknown.size()).append(" 个无法识别）");
            sb.append("\n\n");

            if (errorCount() > 0) {
                sb.append("结论：存在 ").append(errorCount()).append(" 个会导致启动失败的问题，需要先处理后才能正常进入游戏。\n");
            } else if (warnCount() > 0) {
                sb.append("结论：可以启动，但有 ").append(warnCount()).append(" 处需要注意。\n");
            } else {
                sb.append("结论：没有发现冲突，可以直接启动游戏。\n");
            }

            if (!findings.isEmpty()) {
                sb.append("\n──────── 问题清单 ────────\n");
                int i = 1;
                for (Finding f : findings) {
                    sb.append(i++).append(". ");
                    switch (f.severity) {
                        case Finding.ERROR -> sb.append("【会阻止启动】");
                        case Finding.WARN -> sb.append("【注意】");
                        default -> sb.append("【提示】");
                    }
                    sb.append(f.title).append("\n   ").append(f.detail).append("\n");
                }
            }

            List<String> steps = steps();
            if (!steps.isEmpty()) {
                sb.append("\n──────── 应该怎么做才能正确启动 ────────\n");
                int i = 1;
                for (String s : steps) sb.append(i++).append(". ").append(s).append("\n");
            }

            sb.append("\n──────── 已安装的 mod ────────\n");
            for (Mod m : mods) {
                sb.append("· ").append(m.display()).append("   (").append(m.fileName()).append(")");
                if (m.error != null) sb.append("  ← ").append(m.error);
                sb.append("\n");
            }
            return sb.toString();
        }

        /** 按当前问题推导出的处置步骤（同一处置只出现一次）。 */
        List<String> steps() {
            Set<String> uniq = new LinkedHashSet<>();
            for (Finding f : findings) {
                if (f.severity != Finding.ERROR) continue;
                String s = stepFor(f);
                if (s != null) uniq.add(s);
            }
            List<String> out = new ArrayList<>(uniq);
            if (!out.isEmpty()) out.add("处理完回到这个窗口再点一次「检查冲突」复验。");
            return out;
        }

        private static String stepFor(Finding f) {
            if (f.title.startsWith("实例是原版")) {
                return "先给这个实例安装一个 mod 加载器（Fabric / Forge / NeoForge），或者改用一个已装好加载器的实例。"
                        + "本启动器目前只提供原版下载，加载器需要用官方安装器装好后放进 versions 目录。";
            }
            if (f.title.contains("类型的 mod 无法")) {
                return "把上面列出的 jar 换成与该实例加载器匹配的版本（在 Modrinth 下载页选择对应加载器），或改装到匹配的实例里。";
            }
            if (f.title.startsWith("加载器混装")) {
                return "同一个实例只能混用「兼容的」加载器（如 Quilt 可以加载 Fabric mod）。请把不匹配的 jar 删掉或移到别的实例。";
            }
            if (f.title.startsWith("同一个 mod 装了多个版本")) {
                return "同一个 mod 只保留一个 jar（建议留最新版），其余删除；重复的 mod 一定会导致加载失败。";
            }
            if (f.title.startsWith("缺少必需的前置")) {
                return "在「Mod」页搜索并安装上面列出的前置 mod（名称即 modid，Fabric 系大多是 Fabric API），装到同一个实例里。";
            }
            if (f.title.startsWith("需要的 Minecraft 版本")) {
                return "换成与该实例 MC 版本匹配的 mod 版本，或者改用一个 MC 版本相符的实例。";
            }
            if (f.title.startsWith("存在被声明为不兼容")) {
                return "这两个 mod 的作者明确声明互相不兼容，只能二选一，删掉其中一个。";
            }
            return null;
        }
    }

    /** 分析某个实例的 mods 目录：加载器、依赖、版本、重复等。 */
    public static Report analyze(Instance instance) {
        return analyze(instance, scan(instance.modsDir));
    }

    public static Report analyze(Instance instance, List<Mod> mods) {
        Report rep = new Report(instance, mods);
        if (mods.isEmpty()) {
            rep.add(Finding.INFO, "mods 目录为空", "这个实例还没有安装任何 mod，直接启动即可。");
            return rep;
        }

        // 0) 识别失败的 jar
        for (Mod m : mods) {
            if (m.kind == null) rep.unknown.add(m);
        }
        if (!rep.unknown.isEmpty()) {
            StringBuilder names = new StringBuilder();
            for (Mod m : rep.unknown) {
                if (names.length() > 0) names.append("、");
                names.append(m.fileName());
            }
            rep.add(Finding.WARN, "有 " + rep.unknown.size() + " 个 jar 不是可识别的 mod",
                    names + "。可能是前置库、非 mod 文件或下载不完整的文件；它们不会被当成 mod 分析。");
        }

        List<Mod> known = new ArrayList<>();
        for (Mod m : mods) if (m.kind != null) known.add(m);
        if (known.isEmpty()) return rep;

        // 1) 原版实例装不了 mod
        List<String> allowed = acceptableKinds(instance.loader);
        if (allowed.isEmpty()) {
            rep.add(Finding.ERROR, "实例是原版，无法加载任何 mod",
                    "原版客户端不会读取 mods 目录（已装入 " + known.size() + " 个 mod）。");
        } else {
            // 2) 逐个加载器类型检查
            Map<String, List<String>> badByKind = new LinkedHashMap<>();
            for (Mod m : known) {
                if (!allowed.contains(m.kind)) {
                    badByKind.computeIfAbsent(m.kind, k -> new ArrayList<>()).add(m.fileName());
                }
            }
            for (Map.Entry<String, List<String>> e : badByKind.entrySet()) {
                rep.add(Finding.ERROR,
                        kindLabel(e.getKey()) + " 类型的 mod 无法在 " + loaderLabel(instance.loader) + " 实例中加载",
                        String.join("、", e.getValue()));
            }
            // 3) 混装检测：即使各自都被允许，也要看是否出现多种类型
            Set<String> kinds = new LinkedHashSet<>();
            for (Mod m : known) kinds.add(m.kind);
            if (kinds.size() > 1 && !"quilt".equals(instance.loader) && badByKind.isEmpty()) {
                rep.add(Finding.ERROR, "加载器混装",
                        "同一个 mods 目录里同时出现了 " + kinds.size() + " 种加载器格式的 mod，游戏无法同时加载。");
            }
        }

        // 4) 同一个 modId 装了多个版本
        Map<String, List<Mod>> byId = new LinkedHashMap<>();
        for (Mod m : known) {
            if (m.modId != null) byId.computeIfAbsent(m.modId.toLowerCase(), k -> new ArrayList<>()).add(m);
        }
        for (Map.Entry<String, List<Mod>> e : byId.entrySet()) {
            if (e.getValue().size() <= 1) continue;
            StringBuilder names = new StringBuilder();
            for (Mod m : e.getValue()) {
                if (names.length() > 0) names.append("、");
                names.append(m.fileName());
            }
            rep.add(Finding.ERROR, "同一个 mod 装了多个版本：" + e.getKey(),
                    "共 " + e.getValue().size() + " 份：" + names + "。必须只保留其中一份。");
        }

        // 已被提供的 modId（含 provides 别名）
        Set<String> provided = new LinkedHashSet<>();
        for (Mod m : known) {
            if (m.modId != null) provided.add(m.modId.toLowerCase());
            for (String p : m.provides) provided.add(p.toLowerCase());
        }

        // 5) 缺失的必需前置 / 6) 版本范围不满足
        for (Mod m : known) {
            for (Dep d : m.requires) {
                String id = d.modId == null ? "" : d.modId.toLowerCase();
                if (BUILTIN.contains(id)) {
                    // minecraft 单独查版本范围
                    if ("minecraft".equals(id) && d.range != null && !satisfies(d.range, instance.mcVersion)) {
                        rep.add(Finding.ERROR, "需要的 Minecraft 版本与实例不符",
                                m.display() + " 需要 Minecraft " + d.range + "，当前实例是 " + instance.mcVersion + "。");
                    }
                    continue;
                }
                if (!provided.contains(id)) {
                    if (d.mandatory) {
                        rep.add(Finding.ERROR, "缺少必需的前置：" + friendlyDep(id),
                                "被 " + m.display() + " 依赖（要求版本 " + (d.range == null ? "不限" : d.range) + "），但 mods 目录里没有它。");
                    } else {
                        rep.add(Finding.INFO, "缺少可选依赖：" + friendlyDep(id),
                                "被 " + m.display() + " 声明为可选，不装也能启动，但相关功能会不可用。");
                    }
                } else if (d.range != null) {
                    Mod provider = findProvider(known, id);
                    // 只有「真正的同名 mod」才能拿版本号比对；
                    // 通过 provides 别名命中的（如 Fabric API 提供的 fabric-renderer-api-v1）
                    // 其自身版本与模块版本不是一回事，比对只会误报。
                    boolean exact = provider != null && provider.modId != null
                            && provider.modId.equalsIgnoreCase(id);
                    if (exact && provider.version != null && !satisfies(d.range, provider.version)) {
                        rep.add(Finding.WARN, "前置版本可能不满足：" + friendlyDep(id),
                                m.display() + " 要求 " + d.range + "，已安装的是 " + provider.version + "。");
                    }
                }
            }
        }

        // 7) 声明不兼容
        for (Mod m : known) {
            for (String bad : m.incompatible) {
                String id = bad.toLowerCase();
                if (provided.contains(id)) {
                    rep.add(Finding.ERROR, "存在被声明为不兼容的 mod：" + m.display() + " ⇄ " + friendlyDep(id),
                            "其中一个 mod 的作者明确声明它们不能共存（列在 " + m.fileName() + " 的 breaks/incompatible 中）。");
                }
            }
        }
        return rep;
    }

    private static Mod findProvider(List<Mod> mods, String id) {
        for (Mod m : mods) {
            if (m.modId != null && m.modId.equalsIgnoreCase(id)) return m;
            for (String p : m.provides) if (p.equalsIgnoreCase(id)) return m;
        }
        return null;
    }

    /** 把 modid 翻译成人能看懂的提示名（Fabric 的模块 id 归到 Fabric API）。 */
    static String friendlyDep(String modId) {
        if ("fabric".equals(modId) || modId.startsWith("fabric-")) return modId + "（属于 Fabric API）";
        return modId;
    }

    /** 是否是可搜索的 modid（用于提示去哪找前置）。 */
    static boolean searchable(String modId) {
        return modId != null && !modId.isBlank() && !BUILTIN.contains(modId.toLowerCase());
    }

    // ===== 版本比较与范围匹配 =====

    /** 判断 version 是否落在 range 内。空 / * / any 视为不限。 */
    public static boolean satisfies(String range, String version) {
        if (range == null) return true;
        String r = range.trim();
        if (r.isEmpty() || "*".equals(r) || "any".equalsIgnoreCase(r)) return true;
        if (version == null || version.isBlank()) return true;

        // 择一满足（Fabric 数组写法被拍平成 "a || b"）。
        // 必须先于空格 AND 处理，否则 "||" 会被当成一个普通条件去匹配版本号而永远不满足。
        if (r.contains("||")) {
            for (String part : r.split("\\|\\|")) {
                if (satisfies(part.trim(), version)) return true;
            }
            return false;
        }
        // 多条件（如 ">=1.16 <1.20"）
        if (r.indexOf(' ') >= 0) {
            for (String part : r.split("\\s+")) {
                if (!part.isBlank() && !satisfies(part, version)) return false;
            }
            return true;
        }
        if (r.startsWith("^") || r.startsWith("~")) {
            return sameMajor(r.substring(1).trim(), version);
        }
        if (r.startsWith("[") || r.startsWith("(")) {
            return inInterval(r, version);
        }
        for (String op : new String[]{">=", "<=", ">", "<", "="}) {
            if (r.startsWith(op)) {
                int c = compare(version, r.substring(op.length()).trim());
                return switch (op) {
                    case ">=" -> c >= 0;
                    case "<=" -> c <= 0;
                    case ">" -> c > 0;
                    case "<" -> c < 0;
                    default -> c == 0;
                };
            }
        }
        if (r.endsWith(".*") || r.endsWith(".x") || r.endsWith(".X")) {
            String p = r.substring(0, r.length() - 2);
            return version.equals(p) || version.startsWith(p + ".");
        }
        // 普通版本号：允许 "1.20" 匹配 "1.20.1"
        return version.equals(r) || version.startsWith(r + ".");
    }

    private static boolean inInterval(String r, String v) {
        boolean loIncl = r.startsWith("[");
        int close = Math.max(r.lastIndexOf(']'), r.lastIndexOf(')'));
        if (close <= 0) return true;
        boolean hiIncl = r.charAt(close) == ']';
        String body = r.substring(1, close);
        int comma = body.indexOf(',');
        if (comma < 0) return body.trim().equals(v);
        String lo = body.substring(0, comma).trim();
        String hi = body.substring(comma + 1).trim();
        if (!lo.isEmpty()) {
            int c = compare(v, lo);
            if (c < 0 || (c == 0 && !loIncl)) return false;
        }
        if (!hi.isEmpty()) {
            int c = compare(v, hi);
            if (c > 0 || (c == 0 && !hiIncl)) return false;
        }
        return true;
    }

    private static boolean sameMajor(String base, String version) {
        String[] a = base.split("[.\\-+]");
        String[] b = version.split("[.\\-+]");
        return a.length > 0 && b.length > 0 && a[0].equals(b[0]);
    }

    /** 逐段比较版本号：纯数字按数值，其余按字符串，缺段补 0。 */
    static int compare(String a, String b) {
        String[] x = (a == null ? "" : a).split("[.\\-+]");
        String[] y = (b == null ? "" : b).split("[.\\-+]");
        int n = Math.max(x.length, y.length);
        for (int i = 0; i < n; i++) {
            String p = i < x.length ? x[i] : "0";
            String q = i < y.length ? y[i] : "0";
            int c;
            Long pn = asLong(p);
            Long qn = asLong(q);
            if (pn != null && qn != null) c = Long.compare(pn, qn);
            else c = p.compareTo(q);
            if (c != 0) return c;
        }
        return 0;
    }

    private static Long asLong(String s) {
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    // ===== Forge mods.toml 的受限解析 =====

    /**
     * 只解析 mods.toml / neoforge.mods.toml 用到的 TOML 子集：
     * 键值对、[section]、以及 mod 与依赖所用的 [[array of tables]]。
     */
    static final class Toml {
        final Map<String, String> root = new LinkedHashMap<>();
        final List<String> tableNames = new ArrayList<>();
        final List<Map<String, String>> tables = new ArrayList<>();

        static Toml parse(String text) {
            Toml t = new Toml();
            Map<String, String> cur = t.root;
            for (String raw : text.split("\r?\n")) {
                String line = stripComment(raw).trim();
                if (line.isEmpty()) continue;
                if (line.startsWith("[[") && line.endsWith("]]")) {
                    String name = line.substring(2, line.length() - 2).trim();
                    cur = new LinkedHashMap<>();
                    t.tables.add(cur);
                    t.tableNames.add(name);
                    continue;
                }
                if (line.startsWith("[") && line.endsWith("]")) {
                    cur = t.root;
                    continue;
                }
                int eq = line.indexOf('=');
                if (eq <= 0) continue;
                cur.put(line.substring(0, eq).trim(), unquote(line.substring(eq + 1).trim()));
            }
            return t;
        }

        Map<String, String> firstTable(String base) {
            for (int i = 0; i < tables.size(); i++) {
                String name = tableNames.get(i);
                if (name.equals(base) || name.startsWith(base + ".")) return tables.get(i);
            }
            return null;
        }

        List<Map<String, String>> tablesStartingWith(String base) {
            List<Map<String, String>> out = new ArrayList<>();
            for (int i = 0; i < tables.size(); i++) {
                String name = tableNames.get(i);
                if (name.equals(base) || name.startsWith(base + ".")) out.add(tables.get(i));
            }
            return out;
        }

        /** 去掉行尾注释（引号内的 # 不算注释）。 */
        private static String stripComment(String s) {
            boolean quote = false;
            char q = 0;
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (quote) {
                    if (c == q) quote = false;
                } else if (c == '"' || c == '\'') {
                    quote = true;
                    q = c;
                } else if (c == '#') {
                    return s.substring(0, i);
                }
            }
            return s;
        }

        /** 去掉包裹的引号（支持 ''' 与 """ 多行字符串）。 */
        private static String unquote(String v) {
            if (v.length() >= 6 && ((v.startsWith("'''") && v.endsWith("'''"))
                    || (v.startsWith("\"\"\"") && v.endsWith("\"\"\"")))) {
                return v.substring(3, v.length() - 3).trim();
            }
            if (v.length() >= 2 && ((v.startsWith("\"") && v.endsWith("\""))
                    || (v.startsWith("'") && v.endsWith("'")))) {
                return v.substring(1, v.length() - 1);
            }
            return v;
        }
    }
}
