package mc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * 单个实例（版本）的独立设置：Java、内存、窗口、追加 JVM / 游戏参数、独立游戏目录、自动进服。
 *
 * 与全局 {@link Settings} 的关系是「覆盖」：字段留空表示跟随全局，填写后只影响本实例。
 * 落盘位置：&lt;安装目录&gt;/launcher/instances/&lt;版本 id&gt;.properties。
 * 每个字段都真实参与启动流程，不含写了不生效的假设置。
 */
public final class InstSettings {

    /** 覆盖全局 Java 可执行文件 / 主页；空表示跟随全局。 */
    public String javaPath = "";
    /** "" 跟随全局 / auto 自动 / custom 自定义。 */
    public String memoryMode = "";
    public int memoryGb = 4;
    /** "" 跟随全局 / custom 自定义尺寸 / default 强制不传宽高（让游戏用自己的全屏或默认窗口）。 */
    public String resolutionMode = "";
    public int width = 854;
    public int height = 480;
    /** 追加到 JVM 的额外参数（空格式：-XX:+UseG1GC -Dfoo=bar）。 */
    public String jvmArgs = "";
    /** 追加到游戏命令行的额外参数（如 --server 8.8.8.8 或自定义参数）。 */
    public String gameArgs = "";
    /** 该实例专用的游戏目录；空表示按全局规则（实例隔离时为 instances/&lt;id&gt;，否则为安装目录）。 */
    public String gameDir = "";
    /** 启动后自动进入的服务器地址（host 或 host:port），空表示不进服。 */
    public String serverAddress = "";
    /**
     * 全屏："" 不修改（沿用游戏自己的 options.txt）/ "true" 强制全屏 / "false" 强制窗口化。
     * 原版没有 --fullscreen 启动参数，全屏只能通过 options.txt 的 fullscreen 项控制。
     */
    public String fullscreenMode = "";

    // ===== 读写 =====

    /** 版本 id → 安全的文件名（版本号里可能有空格与点，个别加载器实例名可能带特殊字符）。 */
    static String safeId(String id) {
        if (id == null || id.isBlank()) return "_";
        return id.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    public static File fileFor(File baseDir, String id) {
        return new File(new File(new File(baseDir, "launcher"), "instances"), safeId(id) + ".properties");
    }

    public static InstSettings load(File baseDir, String id) {
        InstSettings s = new InstSettings();
        File f = fileFor(baseDir, id);
        if (!f.isFile()) return s;
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(f)) {
            p.load(in);
        } catch (IOException e) {
            return s;
        }
        s.javaPath = p.getProperty("javaPath", "").trim();
        s.memoryMode = p.getProperty("memoryMode", "").trim();
        s.memoryGb = intVal(p, "memoryGb", 4);
        s.resolutionMode = p.getProperty("resolutionMode", "").trim();
        s.width = intVal(p, "width", 854);
        s.height = intVal(p, "height", 480);
        s.jvmArgs = p.getProperty("jvmArgs", "").trim();
        s.gameArgs = p.getProperty("gameArgs", "").trim();
        s.gameDir = p.getProperty("gameDir", "").trim();
        s.serverAddress = p.getProperty("serverAddress", "").trim();
        s.fullscreenMode = p.getProperty("fullscreenMode", "").trim();
        return s;
    }

    public void save(File baseDir, String id) {
        Properties p = new Properties();
        p.setProperty("javaPath", nz(javaPath));
        p.setProperty("memoryMode", nz(memoryMode));
        p.setProperty("memoryGb", String.valueOf(clamp(memoryGb, 1, 64)));
        p.setProperty("resolutionMode", nz(resolutionMode));
        p.setProperty("width", String.valueOf(clamp(width, 320, 7680)));
        p.setProperty("height", String.valueOf(clamp(height, 240, 4320)));
        p.setProperty("jvmArgs", nz(jvmArgs));
        p.setProperty("gameArgs", nz(gameArgs));
        p.setProperty("gameDir", nz(gameDir));
        p.setProperty("serverAddress", nz(serverAddress));
        p.setProperty("fullscreenMode", nz(fullscreenMode));
        File f = fileFor(baseDir, id);
        File parent = f.getParentFile();
        if (parent != null && !parent.isDirectory() && !parent.mkdirs()) return;
        try (FileOutputStream out = new FileOutputStream(f)) {
            p.store(out, "实例设置 " + id);
        } catch (IOException ignore) {
            // 写入失败不阻塞使用
        }
    }

    /** 该实例是否做过任何覆盖（用于列表里标记「已自定义」）。 */
    public boolean customized() {
        return !nz(javaPath).isEmpty() || !nz(memoryMode).isEmpty() || !nz(resolutionMode).isEmpty()
                || !nz(jvmArgs).isEmpty() || !nz(gameArgs).isEmpty() || !nz(gameDir).isEmpty()
                || !nz(serverAddress).isEmpty() || !nz(fullscreenMode).isEmpty();
    }

    // ===== 参数切分 =====

    /**
     * 把一行参数文本切成参数列表：按空白切分，双引号包裹的片段保留为一个参数。
     * 例：{@code -Dfoo="a b" -XX:+UseG1GC} → ["-Dfoo=a b", "-XX:+UseG1GC"]。
     */
    public static List<String> splitArgs(String text) {
        List<String> out = new ArrayList<>();
        if (text == null) return out;
        StringBuilder cur = new StringBuilder();
        boolean quote = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '"') {
                quote = !quote;
                continue;
            }
            if (!quote && Character.isWhitespace(c)) {
                if (cur.length() > 0) {
                    out.add(cur.toString());
                    cur.setLength(0);
                }
                continue;
            }
            cur.append(c);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    /**
     * 把「自动进服」地址拆成 --server / --port。
     * 支持 host、host:port、以及带端口的 IPv6（[::1]:25565）。
     */
    public static String[] splitServer(String address) {
        String a = nz(address);
        if (a.isEmpty()) return null;
        String host = a;
        String port = null;
        if (a.startsWith("[")) {
            int close = a.indexOf(']');
            if (close > 0) {
                host = a.substring(1, close);
                if (close + 1 < a.length() && a.charAt(close + 1) == ':') port = a.substring(close + 2);
            }
        } else {
            int colon = a.lastIndexOf(':');
            if (colon > 0 && colon < a.length() - 1 && a.indexOf(':') == colon) {
                host = a.substring(0, colon);
                port = a.substring(colon + 1);
            }
        }
        if (port != null && !port.matches("\\d+")) port = null;
        return new String[]{host, port};
    }

    // ===== 小工具 =====

    private static String nz(String s) {
        return s == null ? "" : s.trim();
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static int intVal(Properties p, String key, int def) {
        try {
            String v = p.getProperty(key);
            return v == null ? def : Integer.parseInt(v.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
