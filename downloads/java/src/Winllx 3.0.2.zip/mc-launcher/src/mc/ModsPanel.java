package mc;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Mod 页：从 Modrinth 搜索并安装 mod。
 *
 * 安装流程：选中结果 → 弹出「装到哪个实例」选择窗（首项固定为「默认实例」）→
 * 按目标实例的加载器与 Minecraft 版本挑选匹配的发布 → 下载到该实例的 mods 目录 →
 * 自动做冲突分析并弹窗告知「应该怎么做才能正确启动」。
 */
public final class ModsPanel extends JPanel {

    private static final String ANY_LOADER = "不限定加载器";
    private static final String[] LOADERS = {ANY_LOADER, "fabric", "forge", "neoforge", "quilt"};
    private static final Color MUTED = new Color(110, 110, 110);

    private final Settings st;
    private final Consumer<String> log;
    /** 启动页当前选中的版本 id；默认实例未设置时用它兜底。 */
    private final Supplier<String> currentVersionId;

    // ===== 在线搜索 =====
    private final JTextField queryField = new JTextField(22);
    private final JComboBox<String> loaderCombo = new JComboBox<>(LOADERS);
    private final JTextField versionField = new JTextField(10);
    private final JButton searchBtn = new JButton("搜索");
    private final DefaultListModel<Mods.Hit> resultModel = new DefaultListModel<>();
    private final JList<Mods.Hit> resultList = new JList<>(resultModel);
    private final JButton installBtn = new JButton("安装到实例…");
    private final JLabel searchStatus = new JLabel(" ");

    // ===== 本地实例与已装 mod =====
    private final JComboBox<ModScan.Instance> instanceCombo = new JComboBox<>();
    private final DefaultListModel<ModScan.Mod> localModel = new DefaultListModel<>();
    private final JList<ModScan.Mod> localList = new JList<>(localModel);
    private final JButton checkBtn = new JButton("检查冲突");
    private final JButton updateCheckBtn = new JButton("检查更新");
    private final JButton refreshLocalBtn = new JButton("刷新");
    private final JButton openBtn = new JButton("打开 mods 文件夹");
    private final JLabel localStatus = new JLabel(" ");

    private boolean searching;
    private boolean installing;
    private boolean checkingUpdates;
    private boolean updatingMods;
    private boolean prefilled;
    /** 程序化改动 instanceCombo 时抑制事件。 */
    private boolean pickingInstance;

    public ModsPanel(Settings settings, Consumer<String> log, Supplier<String> currentVersionId) {
        this.st = settings;
        this.log = log;
        this.currentVersionId = currentVersionId;

        setLayout(new BorderLayout());
        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, buildSearchArea(), buildLocalArea());
        split.setResizeWeight(0.56);
        split.setBorder(null);
        split.setDividerSize(6);
        add(split, BorderLayout.CENTER);

        JLabel tip = new JLabel("搜索结果来自 Modrinth；安装时先选目标实例（首项为「默认实例」，可在 设置 → 常规 修改），"
                + "装入后会自动分析 mod 冲突并给出正确启动的做法。");
        tip.setForeground(MUTED);
        tip.setBorder(new EmptyBorder(2, 2, 4, 2));
        add(tip, BorderLayout.SOUTH);

        searchBtn.addActionListener(e -> doSearch());
        queryField.addActionListener(e -> doSearch());
        resultList.addListSelectionListener(e -> updateInstallBtn());
        installBtn.addActionListener(e -> doInstall());
        checkBtn.addActionListener(e -> doCheck());
        updateCheckBtn.addActionListener(e -> doUpdateCheck());
        refreshLocalBtn.addActionListener(e -> refreshLocal());
        openBtn.addActionListener(e -> openModsFolder());
        instanceCombo.addActionListener(e -> {
            if (!pickingInstance) refreshLocal();
        });

        refreshInstances();
    }

    /** 切到本页时调用：本地实例列表可能因下载/删除版本而变化。 */
    public void onShown() {
        refreshInstances();
        if (!prefilled) {
            prefillFromDefault();
            prefilled = true;
        }
    }

    // ===== 界面 =====

    private JPanel buildSearchArea() {
        JPanel p = new JPanel(new BorderLayout(0, 6));
        p.setBorder(new EmptyBorder(6, 2, 4, 2));

        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 3));
        bar.add(new JLabel("搜索 Modrinth："));
        queryField.setPreferredSize(new Dimension(240, 26));
        bar.add(queryField);
        bar.add(new JLabel("加载器"));
        bar.add(loaderCombo);
        bar.add(new JLabel("MC 版本"));
        versionField.setPreferredSize(new Dimension(90, 26));
        versionField.setToolTipText("留空表示不限定；填 1.20.1 这类版本号只列出兼容该版本的 mod");
        bar.add(versionField);
        bar.add(searchBtn);
        p.add(bar, BorderLayout.NORTH);

        resultList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        resultList.setCellRenderer(new HitRenderer());
        resultList.setFixedCellHeight(40);
        p.add(new JScrollPane(resultList), BorderLayout.CENTER);

        JPanel south = new JPanel(new BorderLayout(8, 2));
        JPanel ops = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        installBtn.setEnabled(false);
        ops.add(installBtn);
        south.add(ops, BorderLayout.WEST);
        searchStatus.setForeground(MUTED);
        south.add(searchStatus, BorderLayout.CENTER);
        p.add(south, BorderLayout.SOUTH);
        return p;
    }

    private JPanel buildLocalArea() {
        JPanel p = new JPanel(new BorderLayout(0, 6));
        p.setBorder(new EmptyBorder(4, 2, 2, 2));

        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 3));
        bar.add(new JLabel("本地实例："));
        instanceCombo.setPreferredSize(new Dimension(340, 26));
        bar.add(instanceCombo);
        bar.add(checkBtn);
        bar.add(updateCheckBtn);
        bar.add(refreshLocalBtn);
        bar.add(openBtn);
        p.add(bar, BorderLayout.NORTH);

        p.add(new JScrollPane(localList), BorderLayout.CENTER);

        localStatus.setForeground(MUTED);
        localStatus.setBorder(new EmptyBorder(0, 2, 0, 0));
        p.add(localStatus, BorderLayout.SOUTH);
        return p;
    }

    // ===== 搜索 =====

    private void doSearch() {
        if (searching) return;
        final String query = queryField.getText().trim();
        String loader = loaderCombo.getSelectedIndex() <= 0 ? null : (String) loaderCombo.getSelectedItem();
        String gv = versionField.getText().trim();
        searching = true;
        searchBtn.setEnabled(false);
        searchStatus.setText("搜索中…");
        new Thread(() -> {
            try {
                List<Mods.Hit> hits = Mods.search(query, loader, gv.isEmpty() ? null : gv, 40);
                SwingUtilities.invokeLater(() -> {
                    searching = false;
                    searchBtn.setEnabled(true);
                    resultModel.clear();
                    for (Mods.Hit h : hits) resultModel.addElement(h);
                    searchStatus.setText(hits.isEmpty()
                            ? "没有找到结果，试试换个关键词或去掉加载器/版本限制"
                            : "共 " + hits.size() + " 个结果，选中一项后点「安装到实例…」");
                    log.accept("Modrinth 搜索「" + query + "」返回 " + hits.size() + " 个结果");
                    updateInstallBtn();
                });
            } catch (Exception ex) {
                final String msg = ex.getMessage() == null ? ex.toString() : ex.getMessage();
                SwingUtilities.invokeLater(() -> {
                    searching = false;
                    searchBtn.setEnabled(true);
                    searchStatus.setText("搜索失败");
                    log.accept("搜索失败：" + msg);
                });
            }
        }, "mod-search").start();
    }

    private void updateInstallBtn() {
        installBtn.setEnabled(!installing && resultList.getSelectedValue() != null);
    }

    // ===== 安装（含实例选择与冲突分析） =====

    private void doInstall() {
        Mods.Hit hit = resultList.getSelectedValue();
        if (hit == null || installing) return;
        String title = hit.title == null ? hit.slug : hit.title;

        ModScan.Instance target = pickInstance(title);
        if (target == null) return;

        if ("vanilla".equals(target.loader)) {
            int c = JOptionPane.showConfirmDialog(this,
                    "实例 " + target.id + " 是原版客户端，游戏不会加载 mods 目录里的任何 mod。\n\n"
                            + "正确做法：先用 Fabric / Forge / NeoForge 的官方安装器给这个实例装好加载器，再安装 mod。\n\n"
                            + "仍然要下载这个 mod 吗？",
                    "该实例没有 mod 加载器", JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
            if (c != JOptionPane.OK_OPTION) return;
        }

        installing = true;
        updateInstallBtn();
        searchStatus.setText("正在安装…");

        final String project = hit.projectId != null ? hit.projectId : hit.slug;
        final String loader = "vanilla".equals(target.loader) ? null : target.loader;
        final String gv = target.mcVersion;

        new Thread(() -> {
            try {
                log.accept("查询匹配版本：" + title + "（目标实例 " + target.id + " · "
                        + ModScan.loaderLabel(target.loader) + " · MC " + gv + "）");
                List<Mods.ModVersion> versions = Mods.versions(project, loader, gv);
                Mods.ModVersion v = Mods.pick(versions);
                if (v == null) {
                    SwingUtilities.invokeLater(() -> {
                        installing = false;
                        updateInstallBtn();
                        searchStatus.setText("没有匹配的版本");
                        JOptionPane.showMessageDialog(ModsPanel.this,
                                "没有找到与实例 " + target.id + " 匹配的版本。\n"
                                        + "该实例是 " + ModScan.loaderLabel(target.loader) + "、Minecraft " + gv + "。\n\n"
                                        + "可以换一个支持该加载器与版本的 mod，或先把实例换成加载器/版本相符的另一个。",
                                "没有兼容版本", JOptionPane.WARNING_MESSAGE);
                    });
                    return;
                }

                Mods.download(v, target.modsDir, log);
                ModScan.Report rep = ModScan.analyze(target);
                SwingUtilities.invokeLater(() -> {
                    installing = false;
                    updateInstallBtn();
                    searchStatus.setText("已安装 " + v.filename);
                    refreshLocal();
                    showReport(rep, "已安装 " + v.filename + " · 冲突分析", true);
                });
            } catch (Exception ex) {
                final String msg = ex.getMessage() == null ? ex.toString() : ex.getMessage();
                SwingUtilities.invokeLater(() -> {
                    installing = false;
                    updateInstallBtn();
                    searchStatus.setText("安装失败");
                    log.accept("安装 mod 失败：" + msg);
                    JOptionPane.showMessageDialog(ModsPanel.this, msg, "安装失败", JOptionPane.ERROR_MESSAGE);
                });
            }
        }, "mod-install").start();
    }

    /** 选择目标实例。返回 null 表示用户取消；实例列表为空时给出明确提示。 */
    private ModScan.Instance pickInstance(String modTitle) {
        List<ModScan.Instance> list = ModScan.listInstances(st);
        if (list.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "还没有任何本地实例。\n请先在「下载」页下载一个版本，或在 设置 → 常规 → 安装目录 里指向已有版本目录。",
                    "没有可用实例", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        String defaultId = resolveDefaultId(list);
        ModScan.Instance def = findById(list, defaultId);

        // 首项固定为「默认实例」，其余按版本列出
        DefaultListModel<Object> model = new DefaultListModel<>();
        model.addElement(new PickItem(true,
                def != null ? "默认实例（" + def.label() + "）" : "默认实例（未设置，或目标版本尚未下载）", def));
        for (ModScan.Instance i : list) model.addElement(new PickItem(false, i.label(), i));

        JList<Object> jlist = new JList<>(model);
        jlist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        jlist.setSelectedIndex(0);
        jlist.setVisibleRowCount(Math.min(8, model.size()));
        jlist.setFixedCellHeight(26);

        JLabel info = new JLabel();
        info.setForeground(MUTED);
        jlist.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) info.setText(infoHtml((PickItem) jlist.getSelectedValue()));
        });
        info.setText(infoHtml((PickItem) jlist.getSelectedValue()));

        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setBorder(new EmptyBorder(4, 4, 4, 4));
        panel.add(new JLabel("<html><body style='width:430px'>把 <b>" + escape(modTitle)
                + "</b> 安装到哪一个实例？</body></html>"), BorderLayout.NORTH);
        panel.add(new JScrollPane(jlist), BorderLayout.CENTER);
        panel.add(info, BorderLayout.SOUTH);

        while (true) {
            int ok = JOptionPane.showConfirmDialog(this, panel, "选择安装实例",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (ok != JOptionPane.OK_OPTION) return null;
            PickItem sel = (PickItem) jlist.getSelectedValue();
            if (sel != null && sel.instance != null) return sel.instance;
            JOptionPane.showMessageDialog(this,
                    "「默认实例」当前不可用：请先在「下载」页下载一个版本，或到 设置 → 常规 指定一个已下载的版本作为默认实例。",
                    "默认实例不可用", JOptionPane.WARNING_MESSAGE);
        }
    }

    private String infoHtml(PickItem item) {
        if (item == null || item.instance == null) {
            return "<html><body style='width:520px'><font color=#b03c28>默认实例不可用：尚未指定，或所指向的版本还没下载。</font></body></html>";
        }
        ModScan.Instance i = item.instance;
        StringBuilder sb = new StringBuilder("<html><body style='width:520px'>");
        sb.append("实例 <b>").append(escape(i.id)).append("</b>：")
          .append(ModScan.loaderLabel(i.loader)).append(" · Minecraft ").append(escape(i.mcVersion));
        sb.append("<br>mods 目录：").append(escape(i.modsDir.getAbsolutePath()));
        if (!st.instanceIsolation) {
            sb.append("<br><font color=#b03c28>实例隔离未开启：所有版本共用 ")
              .append(escape(new File(st.baseDir(), "mods").getAbsolutePath()))
              .append("，实际安装位置与这里选择的实例无关。</font>");
        }
        sb.append("</body></html>");
        return sb.toString();
    }

    /** 弹窗条目：isDefault 只是标签，instance 为 null 表示默认实例当前不可用。 */
    private static final class PickItem {
        final boolean isDefault;
        final String label;
        final ModScan.Instance instance;

        PickItem(boolean isDefault, String label, ModScan.Instance instance) {
            this.isDefault = isDefault;
            this.label = label;
            this.instance = instance;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    // ===== 本地检查 =====

    private void doCheck() {
        ModScan.Instance inst = (ModScan.Instance) instanceCombo.getSelectedItem();
        if (inst == null) {
            JOptionPane.showMessageDialog(this, "没有可检查的本地实例，请先在「下载」页下载一个版本。",
                    "没有可用实例", JOptionPane.WARNING_MESSAGE);
            return;
        }
        checkBtn.setEnabled(false);
        new Thread(() -> {
            ModScan.Report rep = ModScan.analyze(inst);
            SwingUtilities.invokeLater(() -> {
                checkBtn.setEnabled(true);
                showReport(rep, "实例 " + inst.id + " · 冲突分析", false);
            });
        }, "mod-check").start();
    }

    // ===== 更新检查 =====

    private void doUpdateCheck() {
        ModScan.Instance inst = (ModScan.Instance) instanceCombo.getSelectedItem();
        if (inst == null) {
            JOptionPane.showMessageDialog(this, "没有可检查的本地实例，请先在「下载」页下载一个版本。",
                    "没有可用实例", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (checkingUpdates || updatingMods) return;
        checkingUpdates = true;
        updateCheckBtn.setEnabled(false);
        localStatus.setText("正在检查更新（比对 Modrinth 上的最新版本）…");
        new Thread(() -> {
            try {
                ModUpdates.Report rep = ModUpdates.checkInstance(inst, log);
                SwingUtilities.invokeLater(() -> {
                    checkingUpdates = false;
                    updateCheckBtn.setEnabled(true);
                    refreshLocal();
                    showUpdateDialog(rep);
                });
            } catch (Exception ex) {
                final String msg = ex.getMessage() == null ? ex.toString() : ex.getMessage();
                SwingUtilities.invokeLater(() -> {
                    checkingUpdates = false;
                    updateCheckBtn.setEnabled(true);
                    localStatus.setText("检查更新失败");
                    log.accept("检查更新失败：" + msg);
                    JOptionPane.showMessageDialog(ModsPanel.this, msg, "检查更新失败", JOptionPane.ERROR_MESSAGE);
                });
            }
        }, "mod-update-check").start();
    }

    /** 展示检查结果：无可更新项时只给文本报告，有可更新项时给出可多选的更新清单。 */
    private void showUpdateDialog(ModUpdates.Report rep) {
        List<ModUpdates.Check> up = rep.updatable();
        if (up.isEmpty()) {
            showTextReport(rep.format(), "更新检查结果");
            return;
        }

        DefaultListModel<ModUpdates.Check> model = new DefaultListModel<>();
        for (ModUpdates.Check c : up) model.addElement(c);
        JList<ModUpdates.Check> list = new JList<>(model);
        list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        list.setFixedCellHeight(26);
        list.setVisibleRowCount(Math.min(10, model.size()));
        int[] all = new int[model.size()];
        for (int i = 0; i < model.size(); i++) all[i] = i;
        list.setSelectedIndices(all);

        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setBorder(new EmptyBorder(4, 4, 4, 4));
        panel.add(new JLabel("<html><body style='width:640px'>以下 " + up.size()
                + " 个 mod 在 Modrinth 上有适配当前实例（" + escape(ModScan.loaderLabel(rep.loader))
                + " · MC " + escape(rep.mcVersion) + "）的新版本。<br>"
                + "勾选要更新的一项或多项后点「更新选中」；旧文件会改名成 <b>.disabled</b> 保留，随时可改回。<br>"
                + "<font color=#888888>另有" + rep.unknownCount() + " 个 mod 无法检查（Modrinth 未收录，或没有适配当前加载器/版本）。</font>"
                + "</body></html>"), BorderLayout.NORTH);
        panel.add(new JScrollPane(list), BorderLayout.CENTER);

        int ok = JOptionPane.showConfirmDialog(this, panel, "发现可更新的 mod",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (ok != JOptionPane.OK_OPTION) return;

        List<ModUpdates.Check> selected = list.getSelectedValuesList();
        if (selected.isEmpty()) {
            JOptionPane.showMessageDialog(this, "没有勾选任何 mod，未做任何改动。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        applyUpdates(new ArrayList<>(selected));
    }

    private void applyUpdates(List<ModUpdates.Check> selected) {
        updatingMods = true;
        updateCheckBtn.setEnabled(false);
        refreshLocalBtn.setEnabled(false);
        localStatus.setText("正在更新 " + selected.size() + " 个 mod…");
        new Thread(() -> {
            int done = 0;
            List<String> errors = new ArrayList<>();
            for (ModUpdates.Check c : selected) {
                try {
                    ModUpdates.apply(c, log);
                    done++;
                } catch (Exception ex) {
                    String msg = ex.getMessage() == null ? ex.toString() : ex.getMessage();
                    errors.add(c.fileName() + "：" + msg);
                    log.accept("更新 " + c.fileName() + " 失败：" + msg);
                }
            }
            final int okCount = done;
            SwingUtilities.invokeLater(() -> {
                updatingMods = false;
                updateCheckBtn.setEnabled(true);
                refreshLocalBtn.setEnabled(true);
                refreshLocal();
                localStatus.setText("更新完成：成功 " + okCount + " 个"
                        + (errors.isEmpty() ? "" : "，失败 " + errors.size() + " 个"));
                if (errors.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "已成功更新 " + okCount + " 个 mod。\n"
                                    + "下次启动游戏即可生效；若游戏已在运行，请重启后再加载。",
                            "更新完成", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    StringBuilder sb = new StringBuilder("成功 " + okCount + " 个，失败 " + errors.size() + " 个：\n\n");
                    for (String e : errors) sb.append("· ").append(e).append("\n");
                    showTextReport(sb.toString(), "部分更新失败");
                }
            });
        }, "mod-update-apply").start();
    }

    private void showTextReport(String text, String title) {
        JTextArea area = new JTextArea(text);
        area.setEditable(false);
        area.setFont(reportFont());
        area.setCaretPosition(0);
        JScrollPane sp = new JScrollPane(area);
        sp.setPreferredSize(new Dimension(760, 470));
        JOptionPane.showMessageDialog(this, sp, title, JOptionPane.INFORMATION_MESSAGE);
    }

    public void refreshInstances() {
        List<ModScan.Instance> found = ModScan.listInstances(st);
        Object prev = instanceCombo.getSelectedItem();
        String prevId = prev instanceof ModScan.Instance p ? p.id : null;

        pickingInstance = true;
        try {
            instanceCombo.removeAllItems();
            for (ModScan.Instance i : found) instanceCombo.addItem(i);
            ModScan.Instance target = findById(found, prevId);
            if (target == null) target = findById(found, resolveDefaultId(found));
            if (target == null && !found.isEmpty()) target = found.get(0);
            instanceCombo.setSelectedItem(target);
        } finally {
            pickingInstance = false;
        }
        refreshLocal();
    }

    private void refreshLocal() {
        ModScan.Instance inst = (ModScan.Instance) instanceCombo.getSelectedItem();
        localModel.clear();
        if (inst == null) {
            localStatus.setText("没有可用的本地实例");
            return;
        }
        List<ModScan.Mod> mods = ModScan.scan(inst.modsDir);
        for (ModScan.Mod m : mods) localModel.addElement(m);
        localStatus.setText(inst.label() + " · mods 目录：" + inst.modsDir.getAbsolutePath()
                + " · 共 " + mods.size() + " 个 jar");
    }

    private void openModsFolder() {
        ModScan.Instance inst = (ModScan.Instance) instanceCombo.getSelectedItem();
        if (inst == null) {
            JOptionPane.showMessageDialog(this, "没有可用的本地实例。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        try {
            if (!inst.modsDir.isDirectory() && !inst.modsDir.mkdirs()) {
                throw new IOException("无法创建目录：" + inst.modsDir.getAbsolutePath());
            }
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                Desktop.getDesktop().open(inst.modsDir);
            } else {
                JOptionPane.showMessageDialog(this, "系统不支持打开文件夹，路径：\n" + inst.modsDir.getAbsolutePath(),
                        "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "打开失败", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ===== 冲突分析结果弹窗 =====

    private void showReport(ModScan.Report rep, String title, boolean silentIfClean) {
        log.accept("mod 冲突分析（" + rep.instance.id + "）：会阻止启动 " + rep.errorCount()
                + " 项，注意 " + rep.warnCount() + " 项，已装 mod " + rep.mods.size() + " 个");
        if (silentIfClean && rep.errorCount() == 0 && rep.warnCount() == 0) return;

        int type = rep.blocking() ? JOptionPane.ERROR_MESSAGE
                : (rep.warnCount() > 0 ? JOptionPane.WARNING_MESSAGE : JOptionPane.INFORMATION_MESSAGE);
        JTextArea area = new JTextArea(rep.format());
        area.setEditable(false);
        area.setFont(reportFont());
        area.setCaretPosition(0);
        JScrollPane sp = new JScrollPane(area);
        sp.setPreferredSize(new Dimension(760, 470));
        JOptionPane.showMessageDialog(this, sp, title, type);
    }

    /** 报告字体必须含中文字形，不能用等宽字体（Consolas 没有汉字，会显示成方框问号）。 */
    private static Font reportFont() {
        Font base = UIManager.getFont("TextArea.font");
        return base != null ? base.deriveFont(12f) : new Font(Font.DIALOG, Font.PLAIN, 12);
    }

    // ===== 默认实例解析 =====

    /** 默认实例：优先设置里的 defaultInstance，未设置时跟随启动页当前选中的版本，再兜底取第一个。 */
    private String resolveDefaultId(List<ModScan.Instance> list) {
        String id = st.defaultInstance;
        if (id == null || id.isBlank()) id = currentVersionId.get();
        if (id == null || id.isBlank()) return list.isEmpty() ? null : list.get(0).id;
        return id;
    }

    private static ModScan.Instance findById(List<ModScan.Instance> list, String id) {
        if (id == null) return null;
        for (ModScan.Instance i : list) if (id.equals(i.id)) return i;
        return null;
    }

    /** 默认实例与 MC 版本预填到搜索条件里，省去每次手填。 */
    private void prefillFromDefault() {
        List<ModScan.Instance> list = ModScan.listInstances(st);
        ModScan.Instance def = findById(list, resolveDefaultId(list));
        if (def == null) return;
        if (def.mcVersion != null && !def.mcVersion.isBlank()) versionField.setText(def.mcVersion);
        if (!"vanilla".equals(def.loader)) loaderCombo.setSelectedItem(def.loader);
    }

    // ===== 小工具 =====

    /** 搜索结果两行渲染：名称 + 加载器 / 简介。 */
    private static final class HitRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                      boolean selected, boolean focus) {
            super.getListCellRendererComponent(list, value, index, selected, focus);
            if (value instanceof Mods.Hit h) {
                String name = h.title == null ? h.slug : h.title;
                StringBuilder sb = new StringBuilder("<html>");
                sb.append("<b>").append(escape(name)).append("</b>");
                if (!h.loaders.isEmpty()) {
                    sb.append(" <font color=#888888>[").append(escape(String.join("/", h.loaders))).append("]</font>");
                }
                sb.append("<br><font size=-1 color=#666666>").append(escape(clip(h.description, 120))).append("</font>");
                sb.append("</html>");
                setText(sb.toString());
            }
            return this;
        }
    }

    private static String clip(String s, int max) {
        if (s == null) return "";
        String t = s.replace('\n', ' ').replace('\r', ' ').trim();
        return t.length() <= max ? t : t.substring(0, max) + "…";
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
