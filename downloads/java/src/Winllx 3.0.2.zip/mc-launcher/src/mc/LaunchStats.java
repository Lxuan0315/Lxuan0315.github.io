package mc;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 启动耗时统计：记录每次启动的三个时间点，并把历史落到磁盘。
 *
 * <pre>
 * 点击启动 ──prepareMs──▶ 进程创建 ──firstLineMs──▶ 第一条游戏输出 ──▶ readyMs──▶ 进入游戏里程碑
 * </pre>
 *
 * "进入游戏"没有官方信号，只能从游戏输出里识别里程碑行（见 {@link #MARKERS}）。
 * 识别不到时如实记 0，不会伪造一个时间。
 * 历史文件：&lt;安装目录&gt;/launcher/launch-stats.tsv（制表符分隔，最多保留 50 条）。
 */
public final class LaunchStats {

    private static final int MAX_KEEP = 50;
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("MM-dd HH:mm:ss");

    private LaunchStats() {}

    /** 里程碑行特征：needles 全部命中即算识别到，priority 越大越接近"可以玩了"。 */
    private static final class Marker {
        final String[] needles;
        final String label;
        final int priority;

        Marker(int priority, String label, String... needles) {
            this.priority = priority;
            this.label = label;
            this.needles = needles;
        }
    }

    private static final Marker[] MARKERS = {
            new Marker(6, "音频初始化完成（≈主菜单）", "sound engine started"),
            new Marker(5, "音频设备就绪", "openal initialized"),
            new Marker(4, "方块贴图集完成", "minecraft:textures/atlas/blocks.png"),
            new Marker(3, "配方加载完成", "loaded", "recipes"),
            new Marker(2, "LWJGL 就绪", "lwjgl version"),
            new Marker(1, "开始初始化（设置玩家）", "setting user"),
    };

    /** 一次启动的耗时记录。除 {@link #versionId} 外，字段由启动流程填充。 */
    public static final class Record {
        public String versionId = "";
        /** 点击"启动游戏"的时刻（毫秒时间戳）。 */
        public long startedAt;
        /** 进程创建成功的时刻。 */
        public long processStartedAt;
        /** 点击 → 进程创建（毫秒）。包含 Java 解析、依赖完整性检查、目录准备等。 */
        public long prepareMs;
        /** 进程创建 → 第一条游戏输出（毫秒）；0 表示还没出现。 */
        public long firstLineMs;
        /** 进程创建 → 进入游戏里程碑（毫秒）；0 表示未识别。 */
        public long readyMs;
        /** 命中的里程碑描述。 */
        public String milestone = "";
        public int exitCode = Integer.MIN_VALUE;

        /** 已识别到的里程碑优先级，避免后面的低优先级行把高优先级结果盖掉。 */
        private int bestPriority = -1;
        private boolean saved;

        /** 总计耗时（点击 → 里程碑 / 首条输出 / 当前时刻）。 */
        public long totalMs(long nowMs) {
            if (readyMs > 0) return prepareMs + readyMs;
            if (firstLineMs > 0) return prepareMs + firstLineMs;
            return processStartedAt > 0 ? nowMs - startedAt : 0;
        }

        /** 是否识别到"进入游戏"里程碑。 */
        public boolean reachedGame() {
            return readyMs > 0;
        }

        /**
         * 喂入一条游戏输出行。由输出线程调用，内部只在同步块里改状态，可安全并发调用。
         *
         * @return true 表示这一行让记录第一次具备了"进入游戏"里程碑
         */
        public synchronized boolean onGameLine(String line) {
            if (line == null) return false;
            boolean first = false;
            long now = System.currentTimeMillis();
            if (firstLineMs == 0 && processStartedAt > 0) {
                firstLineMs = Math.max(1, now - processStartedAt);
            }
            String lower = line.toLowerCase();
            for (Marker m : MARKERS) {
                if (m.priority <= bestPriority) continue;
                boolean all = true;
                for (String n : m.needles) {
                    if (!lower.contains(n)) {
                        all = false;
                        break;
                    }
                }
                if (!all) continue;
                bestPriority = m.priority;
                milestone = m.label;
                readyMs = processStartedAt > 0 ? Math.max(1, now - processStartedAt) : Math.max(1, now - startedAt);
                first = true;
                break;
            }
            return first;
        }

        public boolean isSaved() {
            return saved;
        }

        public void markSaved() {
            saved = true;
        }

        /** 一行可读摘要，用于启动完成后写日志。 */
        public String summary() {
            StringBuilder sb = new StringBuilder("启动耗时：" + versionId);
            sb.append("　准备 ").append(sec(prepareMs));
            if (firstLineMs > 0) sb.append("，首条输出 ").append(sec(firstLineMs));
            if (readyMs > 0) sb.append("，进入游戏 ").append(sec(readyMs));
            sb.append("，总计 ").append(sec(totalMs(System.currentTimeMillis())));
            if (readyMs > 0) sb.append("（里程碑：").append(milestone).append("）");
            else if (firstLineMs > 0) sb.append("（未识别到进入游戏里程碑，仅统计到首条输出）");
            else sb.append("（还没有游戏输出）");
            return sb.toString();
        }
    }

    // ===== 持久化 =====

    private static File fileFor(File baseDir) {
        return new File(new File(baseDir, "launcher"), "launch-stats.tsv");
    }

    /** 追加一条记录；同时把历史裁剪到最近 {@link #MAX_KEEP} 条。 */
    public static synchronized void save(File baseDir, Record rec) {
        List<String> lines = new ArrayList<>(loadLines(baseDir));
        lines.add(toLine(rec));
        if (lines.size() > MAX_KEEP) lines = new ArrayList<>(lines.subList(lines.size() - MAX_KEEP, lines.size()));
        File f = fileFor(baseDir);
        File parent = f.getParentFile();
        if (parent != null && !parent.isDirectory() && !parent.mkdirs()) return;
        try {
            Files.write(f.toPath(), lines, StandardCharsets.UTF_8);
        } catch (IOException ignore) {
            // 统计写不进去不影响启动与游戏
        }
    }

    /** 读取历史记录，最新的在前；最多 {@code max} 条。 */
    public static List<Record> load(File baseDir, int max) {
        List<String> lines = loadLines(baseDir);
        List<Record> out = new ArrayList<>();
        for (String line : lines) {
            Record r = fromLine(line);
            if (r != null) out.add(r);
        }
        out.sort(Comparator.comparingLong((Record r) -> r.startedAt).reversed());
        return out.size() > max ? out.subList(0, max) : out;
    }

    /** 给弹窗显示的历史报告：最近 10 次明细 + 平均值。 */
    public static String report(File baseDir) {
        List<Record> all = load(baseDir, MAX_KEEP);
        if (all.isEmpty()) {
            return "还没有启动耗时记录。\n\n启动一次游戏后，这里会显示每次的「准备 / 启动 / 总计」耗时。";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("启动耗时记录（准备 = 点击启动 → 进程创建；启动 = 进程创建 → 进入游戏）\n");
        sb.append("共 ").append(all.size()).append(" 条，最近 10 次：\n\n");
        sb.append(String.format("%-15s %-18s %8s %8s %8s  %s%n", "时间", "版本", "准备", "启动", "总计", "里程碑"));
        int shown = 0;
        long prepareSum = 0;
        long readySum = 0;
        int readyCount = 0;
        for (Record r : all) {
            prepareSum += r.prepareMs;
            if (r.readyMs > 0) {
                readySum += r.readyMs;
                readyCount++;
            }
            if (shown++ >= 10) continue;
            String time = r.startedAt > 0
                    ? Instant.ofEpochMilli(r.startedAt).atZone(ZoneId.systemDefault()).format(TIME_FMT) : "-";
            sb.append(String.format("%-15s %-18s %8s %8s %8s  %s%n",
                    time,
                    truncate(r.versionId, 16),
                    sec(r.prepareMs),
                    r.readyMs > 0 ? sec(r.readyMs) : "-",
                    sec(r.totalMs(r.startedAt + r.prepareMs + Math.max(r.readyMs, r.firstLineMs))),
                    r.readyMs > 0 ? r.milestone : (r.firstLineMs > 0 ? "未识别（仅到首条输出）" : "无游戏输出")));
        }
        sb.append("\n平均：准备 ").append(sec(prepareSum / all.size()));
        sb.append("，启动 ").append(readyCount > 0 ? sec(readySum / readyCount) : "无数据");
        sb.append("（").append(readyCount).append(" / ").append(all.size()).append(" 次识别到进入游戏）");
        sb.append("\n\n说明：不同版本、mod 数量与磁盘状态差异很大，这个数据只反映本机历史表现。");
        return sb.toString();
    }

    /** 磁盘上是否存在统计数据（用于 UI 决定是否显示入口）。 */
    public static boolean hasHistory(File baseDir) {
        File f = fileFor(baseDir);
        return f.isFile() && f.length() > 0;
    }

    // ===== 内部 =====

    private static List<String> loadLines(File baseDir) {
        File f = fileFor(baseDir);
        if (!f.isFile()) return new ArrayList<>();
        try {
            return new ArrayList<>(Files.readAllLines(f.toPath(), StandardCharsets.UTF_8));
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    private static String toLine(Record r) {
        return r.startedAt + "\t" + r.versionId.replace('\t', ' ') + "\t" + r.prepareMs + "\t"
                + r.firstLineMs + "\t" + r.readyMs + "\t" + r.milestone.replace('\t', ' ')
                + "\t" + (r.exitCode == Integer.MIN_VALUE ? -1 : r.exitCode);
    }

    private static Record fromLine(String line) {
        if (line == null || line.isBlank()) return null;
        String[] p = line.split("\t", -1);
        if (p.length < 7) return null;
        try {
            Record r = new Record();
            r.startedAt = Long.parseLong(p[0]);
            r.versionId = p[1];
            r.prepareMs = Long.parseLong(p[2]);
            r.firstLineMs = Long.parseLong(p[3]);
            r.readyMs = Long.parseLong(p[4]);
            r.milestone = p[5];
            r.exitCode = Integer.parseInt(p[6]);
            r.markSaved();
            return r;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    static String sec(long ms) {
        if (ms <= 0) return "0.0s";
        return String.format("%.1fs", ms / 1000.0);
    }

    private static String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }
}
