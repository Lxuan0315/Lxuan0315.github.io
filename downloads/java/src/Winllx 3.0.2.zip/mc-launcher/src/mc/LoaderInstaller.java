package mc;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Mod 加载器安装。
 *
 * 两类加载器的实现方式完全不同，这里分别处理：
 *
 * 1. 元数据型（Fabric / Quilt / Legacy Fabric）：meta 服务器直接给出"完整可用的 profile JSON"，
 *    它是一个继承原版的版本 JSON，写好即可当实例用。本启动器合并 inheritsFrom 后照常安装启动。
 *
 * 2. 安装器型（Forge / NeoForge）：官方安装器除了写版本 JSON，还会给客户端打补丁（生成新的 client jar）、
 *    下载并用二进制补丁处理一批特殊依赖，这些逻辑无法用 JSON 复刻。
 *    所以采用官方安装器的无人值守模式 <code>--installClient &lt;目标目录&gt;</code>，
 *    由它创建实例，再由本启动器补齐原生库解压等运行条件。
 *
 * 这也是为什么原版启动器必须支持 inheritsFrom 合并、旧式 minecraftArguments 和 maven 坐标推导依赖路径 ——
 * 加载器实例全部依赖这三点。
 */
public final class LoaderInstaller {

    private static final String MANIFEST = "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json";
    private static final String FORGE_MAVEN = "https://maven.minecraftforge.net/";
    private static final String NEOFORGE_MAVEN = "https://maven.neoforged.net/releases/";
    private static final Pattern XML_VERSION = Pattern.compile("<version>([^<]+)</version>");
    /** 下拉列表最多列出的版本数，避免几百项堆在一起。 */
    private static final int MAX_OPTIONS = 60;

    private LoaderInstaller() {}

    // ===== 加载器定义 =====

    public enum Loader {
        VANILLA("不安装加载器（仅原版）", "vanilla"),
        FABRIC("Fabric", "fabric"),
        QUILT("Quilt", "quilt"),
        LEGACY_FABRIC("Legacy Fabric", "legacyfabric"),
        FORGE("Forge", "forge"),
        NEOFORGE("NeoForge", "neoforge");

        public final String label;
        public final String slug;

        Loader(String label, String slug) {
            this.label = label;
            this.slug = slug;
        }

        /** 元数据型：meta 服务器直接给可用 profile，不需要官方安装器。 */
        public boolean metaBased() {
            return this == FABRIC || this == QUILT || this == LEGACY_FABRIC;
        }

        /** 安装器型：必须运行官方安装器（会打客户端补丁）。 */
        public boolean installerBased() {
            return this == FORGE || this == NEOFORGE;
        }

        /** 该加载器实例里能加载的 mod 类型（与 ModScan 的判定保持一致）。 */
        public String loaderKind() {
            return this == LEGACY_FABRIC ? "fabric" : slug;
        }

        public static Loader bySlug(String slug) {
            for (Loader l : values()) if (l.slug.equals(slug)) return l;
            return VANILLA;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    /** 下拉选项：加载器版本。 */
    public static final class Option {
        public final String id;
        public final String label;
        public final boolean recommended;

        Option(String id, String label, boolean recommended) {
            this.id = id;
            this.label = label;
            this.recommended = recommended;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    // ===== 可供选择的加载器版本 =====

    /** 列出某加载器支持指定 Minecraft 版本的版本号（新→旧，首个为最新）。 */
    public static List<Option> versions(Loader loader, String mcVersion) throws IOException {
        if (loader.metaBased()) return metaVersions(loader, mcVersion);
        if (loader == Loader.FORGE) return forgeVersions(mcVersion);
        if (loader == Loader.NEOFORGE) return neoforgeVersions(mcVersion);
        return new ArrayList<>();
    }

    private static String metaBase(Loader loader) {
        switch (loader) {
            case FABRIC: return "https://meta.fabricmc.net/v2";
            case QUILT: return "https://meta.quiltmc.org/v3";
            case LEGACY_FABRIC: return "https://meta.legacyfabric.net/v2";
            default: throw new IllegalArgumentException("不是元数据型加载器：" + loader.label);
        }
    }

    private static List<Option> metaVersions(Loader loader, String mc) throws IOException {
        String url = metaBase(loader) + "/versions/loader/" + mc;
        List<Object> arr = Json.asList(Json.parse(Net.getString(url)));
        List<Option> out = new ArrayList<>();
        if (arr == null) return out;
        boolean first = true;
        for (Object o : arr) {
            Object lo = Json.get(o, "loader");
            String v = Json.str(lo, "version");
            if (v == null) v = Json.str(o, "version");
            if (v == null || v.isBlank()) continue;
            boolean stable = Boolean.TRUE.equals(Json.get(lo, "stable"));
            out.add(new Option(v, v + (first ? "（最新）" : stable ? "（稳定）" : ""), first || stable));
            first = false;
        }
        return out;
    }

    private static List<Option> forgeVersions(String mc) throws IOException {
        String recommended = null;
        String latest = null;
        try {
            Object root = Json.parse(Net.getString(
                    "https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json"));
            Object promos = Json.get(root, "promos");
            recommended = Json.str(promos, mc + "-recommended");
            latest = Json.str(promos, mc + "-latest");
        } catch (IOException ignore) {
            // 推荐版信息拿不到不影响列出全部版本
        }
        List<Option> out = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        if (recommended != null) {
            out.add(new Option(recommended, recommended + "（推荐）", true));
            seen.add(recommended);
        }
        if (latest != null && !seen.contains(latest)) {
            out.add(new Option(latest, latest + "（最新）", true));
            seen.add(latest);
        }
        String xml = Net.getString(FORGE_MAVEN + "net/minecraftforge/forge/maven-metadata.xml");
        List<String> all = xmlVersions(xml);
        for (int i = all.size() - 1; i >= 0 && out.size() < MAX_OPTIONS; i--) {
            String full = all.get(i);
            if (!full.startsWith(mc + "-")) continue;
            String fv = full.substring(mc.length() + 1);
            if (seen.contains(fv)) continue;
            seen.add(fv);
            out.add(new Option(fv, fv, false));
        }
        return out;
    }

    private static List<Option> neoforgeVersions(String mc) throws IOException {
        String xml = Net.getString(NEOFORGE_MAVEN + "net/neoforged/neoforge/maven-metadata.xml");
        List<String> all = xmlVersions(xml);
        List<Option> out = new ArrayList<>();
        String latestForMc = null;
        for (String v : all) {
            if (!mc.equals(mcForNeoForge(v))) continue;
            latestForMc = v;   // 列表升序，最后一个就是该 MC 版本可用的最新 NeoForge
        }
        for (int i = all.size() - 1; i >= 0 && out.size() < MAX_OPTIONS; i--) {
            String v = all.get(i);
            if (!mc.equals(mcForNeoForge(v))) continue;
            boolean isLatest = v.equals(latestForMc);
            out.add(new Option(v, v + (isLatest ? "（最新）" : ""), isLatest));
        }
        return out;
    }

    /**
     * NeoForge 版本号 → 对应的 Minecraft 版本。
     * 21.1.72 → 1.21.1；21.0.x → 1.21；20.4.x → 1.20.4；
     * 早期的 47.x 沿用 Forge 的编号方式，对应 1.20.1。
     */
    static String mcForNeoForge(String version) {
        if (version.startsWith("47.")) return "1.20.1";
        String[] p = version.split("\\.");
        if (p.length < 2) return "";
        try {
            int major = Integer.parseInt(p[0]);
            int minor = Integer.parseInt(p[1]);
            return minor == 0 ? "1." + major : "1." + major + "." + minor;
        } catch (NumberFormatException e) {
            return "";
        }
    }

    private static List<String> xmlVersions(String xml) {
        List<String> out = new ArrayList<>();
        Matcher m = XML_VERSION.matcher(xml);
        while (m.find()) out.add(m.group(1).trim());
        return out;
    }

    // ===== 安装 =====

    /**
     * 安装指定加载器到指定 Minecraft 版本的实例。
     *
     * @param installer 已绑定游戏目录的安装器，用于完成后立即补齐实例（这样用户可以直接启动）
     * @return 新实例的版本 id
     */
    public static String install(Loader loader, String mcVersion, String loaderVersion, File gameDir,
                                 JavaRuntime.Java jre, Installer installer, Consumer<String> log) throws IOException {
        if (loader == Loader.VANILLA) throw new IOException("没有选择加载器");
        if (loader.metaBased()) {
            return installProfile(loader, mcVersion, loaderVersion, gameDir, installer, log);
        }
        return installViaInstaller(loader, mcVersion, loaderVersion, gameDir, jre, installer, log);
    }

    private static String installProfile(Loader loader, String mcVersion, String loaderVersion, File gameDir,
                                         Installer installer, Consumer<String> log) throws IOException {
        ensureParentJson(gameDir, mcVersion, log);

        String url = metaBase(loader) + "/versions/loader/" + mcVersion + "/" + loaderVersion + "/profile/json";
        log.accept("获取 " + loader.label + " profile：" + url);
        String profileJson = Net.getString(url);
        Object root = Json.parse(profileJson);
        String id = Json.str(root, "id");
        if (id == null || id.isBlank()) throw new IOException(loader.label + " 的 profile 缺少 id 字段");
        String parent = Json.str(root, "inheritsFrom");
        if (parent == null) throw new IOException(loader.label + " 的 profile 没有 inheritsFrom，无法确定它基于哪个原版版本");

        File dir = new File(gameDir, "versions/" + id);
        Files.createDirectories(dir.toPath());
        File json = new File(dir, id + ".json");
        // 先删掉旧文件，避免上一次残留的副本被当成"已存在"而复用
        Files.deleteIfExists(json.toPath());
        Files.writeString(json.toPath(), profileJson, StandardCharsets.UTF_8);
        log.accept("写入实例配置 versions/" + id + "/" + id + ".json（继承自 " + parent + "）");

        installer.installLoaderProfile(id);
        return id;
    }

    private static String installViaInstaller(Loader loader, String mcVersion, String loaderVersion, File gameDir,
                                              JavaRuntime.Java jre, Installer installer, Consumer<String> log)
            throws IOException {
        if (jre == null) {
            throw new IOException("需要可用的 Java 运行时才能运行 " + loader.label
                    + " 官方安装器，请先在「设置 → Java 运行时」里指定一个 Java 8 以上版本");
        }
        ensureParentJson(gameDir, mcVersion, log);

        String url = installerUrl(loader, mcVersion, loaderVersion);
        File cache = new File(cacheDir(), loader.slug + "-" + mcVersion + "-" + loaderVersion + "-installer.jar");
        log.accept("获取 " + loader.label + " 官方安装器：" + url);
        Net.download(url, cache, 0, null, false, null, log);

        Set<String> before = versionIds(gameDir);
        ensureLauncherProfile(gameDir);
        log.accept("运行官方安装器（无人值守模式，目标目录 " + gameDir.getAbsolutePath() + "）");
        runInstaller(loader, jre, cache, gameDir, log);

        String id = pickNewInstance(versionIds(gameDir), before, loader);
        if (id == null) {
            throw new IOException(loader.label + " 安装器没有生成新的实例目录，安装未完成；"
                    + "常见原因是安装器自身的依赖下载失败，可查看上方安装器输出");
        }
        log.accept("官方安装器已创建实例：" + id);

        installer.prepareLoaderInstance(id);
        return id;
    }

    /** 官方安装器的下载地址。 */
    static String installerUrl(Loader loader, String mcVersion, String loaderVersion) {
        if (loader == Loader.FORGE) {
            String artifact = "forge-" + mcVersion + "-" + loaderVersion;
            return FORGE_MAVEN + "net/minecraftforge/forge/" + mcVersion + "-" + loaderVersion + "/" + artifact + "-installer.jar";
        }
        if (loader == Loader.NEOFORGE) {
            // 1.20.1 时代的 NeoForge 沿用 Forge 的 groupId 与版本号形式
            if (loaderVersion.startsWith("47.")) {
                String artifact = "forge-" + mcVersion + "-" + loaderVersion;
                return NEOFORGE_MAVEN + "net/neoforged/forge/" + mcVersion + "-" + loaderVersion + "/" + artifact + "-installer.jar";
            }
            return NEOFORGE_MAVEN + "net/neoforged/neoforge/" + loaderVersion
                    + "/neoforge-" + loaderVersion + "-installer.jar";
        }
        throw new IllegalArgumentException("不是安装器型加载器：" + loader.label);
    }

    private static void runInstaller(Loader loader, JavaRuntime.Java jre, File jar, File gameDir,
                                     Consumer<String> log) throws IOException {
        List<String> cmd = new ArrayList<>();
        cmd.add(jre.exe.getAbsolutePath());
        cmd.add("-Dfile.encoding=UTF-8");
        cmd.add("-jar");
        cmd.add(jar.getAbsolutePath());
        cmd.add("--installClient");
        cmd.add(gameDir.getAbsolutePath());
        log.accept("执行：" + String.join(" ", cmd));

        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(true);
        pb.directory(gameDir);
        Process p = pb.start();

        // 安装器自己的输出对诊断最有价值（它会打印下载/补丁处理的每一步），原样回传到日志区
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (!line.isBlank()) log.accept("[安装器] " + line);
            }
        }
        int code;
        try {
            code = p.waitFor();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException(loader.label + " 安装器被中断");
        }
        if (code != 0) {
            throw new IOException(loader.label + " 安装器退出码 " + code + "，安装失败（详见上方安装器输出）");
        }
    }

    /**
     * 官方安装器（Forge / NeoForge）在安装前会检查目标目录里有没有"启动器配置文件"，
     * 缺失时直接报错 "There is no minecraft launcher profile ... you need to run the launcher first!" 并退出。
     * 这里按官方格式补一个最小可用的 launcher_profiles.json；已存在时保持原样不覆盖。
     */
    private static void ensureLauncherProfile(File gameDir) throws IOException {
        File file = new File(gameDir, "launcher_profiles.json");
        if (file.isFile()) return;
        String json = "{\"profiles\":{},\"selectedProfile\":\"\",\"clientToken\":\"\","
                + "\"authenticationDatabase\":{},\"launcherVersion\":{\"name\":\""
                + GameProcess.LAUNCHER_NAME + "\",\"format\":21}}";
        Files.writeString(file.toPath(), json, StandardCharsets.UTF_8);
    }

    /** 加载器安装器只放进临时目录，不污染游戏目录。 */
    private static File cacheDir() throws IOException {
        File dir = new File(System.getProperty("java.io.tmpdir"), "winllx-loader-cache");
        if (!dir.isDirectory() && !dir.mkdirs()) {
            throw new IOException("无法创建安装器缓存目录：" + dir.getAbsolutePath());
        }
        return dir;
    }

    /** 确保父版本的 JSON 在本地：加载器实例必须与它合并才能拿到客户端地址、资源索引和原版依赖库。 */
    private static void ensureParentJson(File gameDir, String mcVersion, Consumer<String> log) throws IOException {
        File json = new File(gameDir, "versions/" + mcVersion + "/" + mcVersion + ".json");
        if (json.isFile()) return;

        log.accept("本地没有 Minecraft " + mcVersion + " 的版本信息，先从官方清单获取（这是加载器实例的父版本）");
        File manifestFile = new File(gameDir, "versions/version_manifest_v2.json");
        if (!manifestFile.isFile()) {
            Net.download(MANIFEST, manifestFile, 0, null, false, null, log);
        }
        String url = manifestUrl(manifestFile, mcVersion);
        if (url == null) {
            throw new IOException("官方清单里找不到版本 " + mcVersion + "，请确认版本号是否正确");
        }
        Files.createDirectories(json.getParentFile().toPath());
        Net.download(url, json, 0, null, false, null, log);
    }

    private static String manifestUrl(File manifestFile, String id) {
        try {
            Object root = Json.parse(Files.readString(manifestFile.toPath(), StandardCharsets.UTF_8));
            List<Object> versions = Json.asList(Json.get(root, "versions"));
            if (versions == null) return null;
            for (Object o : versions) {
                if (id.equals(Json.str(o, "id"))) return Json.str(o, "url");
            }
        } catch (Exception ignore) {
            // 清单损坏时返回 null，调用方会给出"找不到版本"的提示
        }
        return null;
    }

    private static Set<String> versionIds(File gameDir) {
        Set<String> out = new LinkedHashSet<>();
        File[] dirs = new File(gameDir, "versions").listFiles(File::isDirectory);
        if (dirs == null) return out;
        for (File d : dirs) out.add(d.getName());
        return out;
    }

    /** 从安装前后的实例目录差异里找出这次新建的实例。 */
    private static String pickNewInstance(Set<String> after, Set<String> before, Loader loader) {
        List<String> fresh = new ArrayList<>();
        for (String id : after) if (!before.contains(id)) fresh.add(id);
        for (String id : fresh) if (looksLikeLoaderInstance(id, loader)) return id;
        if (!fresh.isEmpty()) return fresh.get(0);
        // 已经装过同一个加载器时安装器不会新建目录，此时复用现有实例
        for (String id : after) if (looksLikeLoaderInstance(id, loader)) return id;
        return null;
    }

    private static boolean looksLikeLoaderInstance(String id, Loader loader) {
        String s = id.toLowerCase();
        switch (loader) {
            case FORGE: return s.contains("forge") && !s.contains("neoforge");
            case NEOFORGE: return s.contains("neoforge");
            default: return true;
        }
    }
}
