package mc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.util.Properties;

/**
 * 启动器设置模型，读写 config.properties。
 * 这里的每个字段都真实参与启动流程（组装命令行 / 选择 Java / 选择目录），不含占位设置。
 */
public final class Settings {

    // ===== 常规 =====
    public String username = "Player";
    /** 基础安装目录：versions / libraries / assets 都落在这里，启用实例隔离时也不复制这些大文件。 */
    public String gameDir = "";
    /** 实例隔离：每个版本使用独立的游戏目录（存档 / 设置 / 截图互不影响）。 */
    public boolean instanceIsolation = false;
    public boolean showSnapshots = false;
    /** 是否在版本列表里显示 Alpha / Beta 远古版本（默认隐藏，数量少但很旧）。 */
    public boolean showAncient = false;
    /** 只显示愚人节版本：愚人节版本都是快照，混在近千个快照里不好翻。 */
    public boolean aprilOnly = false;
    /** 默认实例：Mod 安装弹窗首项「默认实例」指向哪个版本；空表示跟随启动页当前选中的版本。 */
    public String defaultInstance = "";
    /** 上次选择的 mod 加载器（LoaderInstaller.Loader 的 slug），下载页会记住这个选择。 */
    public String loader = "vanilla";
    /** 上次选择的加载器版本号；空表示跟随该加载器的最新版。 */
    public String loaderVersion = "";

    // ===== Java =====
    /** 指定的 java 可执行文件或 java 主页；空表示按 内置 JBR → JAVA_HOME → PATH 顺序自动查找。 */
    public String javaPath = "";

    // ===== 内存与性能 =====
    public String memoryMode = "auto";        // auto / custom
    public int customMemoryGb = 4;
    public String processPriority = "normal"; // normal / below / above / high / realtime

    // ===== 游戏窗口 =====
    public boolean customResolution = false;
    public int windowWidth = 854;
    public int windowHeight = 480;

    // ===== 网络 =====
    public String ipPreference = "default";   // default / ipv4 / ipv6

    // ===== 启动与外观 =====
    public String launcherVisibility = "keep";  // keep / minimize / hide
    public String launcherBrand = "mc-launcher";
    public String launcherBrandVersion = "1.0";

    // ===== 账号（正版验证） =====
    /** offline = 离线模式；msa = 微软账号（正版） */
    public String accountMode = "offline";
    public String msaClientId = MsAuth.DEFAULT_CLIENT_ID;
    /** 刷新令牌：保存后下次启动可免输入密码直接换取游戏凭据。 */
    public String msaRefreshToken = "";
    /** 上次登录的档案信息，仅用于界面显示与离线回退，启动时会重新校验。 */
    public String msaUuid = "";
    public String msaName = "";
    public String msaXuid = "";

    public boolean isMsa() {
        return "msa".equals(accountMode) && !safe(msaRefreshToken).isEmpty();
    }

    /** 实际用于登录的客户端 ID（为空时回落到默认公开 ID）。 */
    public String clientIdOr() {
        String s = safe(msaClientId);
        return s.isEmpty() ? MsAuth.DEFAULT_CLIENT_ID : s;
    }

    public static File configFile() {
        return new File(System.getProperty("user.dir"), "config.properties");
    }

    private static File defaultGameDir() {
        return new File(System.getProperty("user.dir"), "../Winllx/minecraft").getAbsoluteFile();
    }

    public static Settings load() {
        Settings s = new Settings();
        Properties p = new Properties();
        File f = configFile();
        if (f.isFile()) {
            try (FileInputStream in = new FileInputStream(f)) {
                p.load(in);
            } catch (IOException ignore) {
                // 读取失败时全部使用默认值
            }
        }
        s.username = p.getProperty("username", "Player").trim();
        if (s.username.isEmpty()) s.username = "Player";
        s.gameDir = p.getProperty("gameDir", "").trim();
        s.instanceIsolation = bool(p, "instanceIsolation", false);
        s.showSnapshots = bool(p, "showSnapshots", false);
        s.showAncient = bool(p, "showAncient", false);
        s.aprilOnly = bool(p, "aprilOnly", false);
        s.defaultInstance = p.getProperty("defaultInstance", "").trim();
        s.loader = p.getProperty("loader", "vanilla").trim();
        s.loaderVersion = p.getProperty("loaderVersion", "").trim();
        s.javaPath = p.getProperty("javaPath", "").trim();

        // 兼容旧配置：只有 maxMemory 而没有 memoryMode 时按自定义处理
        String mode = p.getProperty("memoryMode", "").trim();
        s.memoryMode = mode.isEmpty() ? (p.getProperty("maxMemory") != null ? "custom" : "auto") : mode;
        s.customMemoryGb = intVal(p, "maxMemory", intVal(p, "customMemoryGb", 4));
        s.processPriority = p.getProperty("processPriority", "normal").trim();

        s.customResolution = bool(p, "customResolution", false);
        s.windowWidth = intVal(p, "windowWidth", 854);
        s.windowHeight = intVal(p, "windowHeight", 480);

        s.ipPreference = p.getProperty("ipPreference", "default").trim();

        s.launcherVisibility = p.getProperty("launcherVisibility", "keep").trim();
        s.launcherBrand = p.getProperty("launcherBrand", "mc-launcher").trim();
        s.launcherBrandVersion = p.getProperty("launcherBrandVersion", "1.0").trim();

        s.accountMode = p.getProperty("accountMode", "offline").trim();
        s.msaClientId = p.getProperty("msaClientId", MsAuth.DEFAULT_CLIENT_ID).trim();
        s.msaRefreshToken = p.getProperty("msaRefreshToken", "").trim();
        s.msaUuid = p.getProperty("msaUuid", "").trim();
        s.msaName = p.getProperty("msaName", "").trim();
        s.msaXuid = p.getProperty("msaXuid", "").trim();
        return s;
    }

    public void save() {
        Properties p = new Properties();
        p.setProperty("username", safe(username));
        p.setProperty("gameDir", safe(gameDir));
        p.setProperty("instanceIsolation", String.valueOf(instanceIsolation));
        p.setProperty("showSnapshots", String.valueOf(showSnapshots));
        p.setProperty("showAncient", String.valueOf(showAncient));
        p.setProperty("aprilOnly", String.valueOf(aprilOnly));
        p.setProperty("defaultInstance", safe(defaultInstance));
        p.setProperty("loader", safe(loader));
        p.setProperty("loaderVersion", safe(loaderVersion));
        p.setProperty("javaPath", safe(javaPath));
        p.setProperty("memoryMode", safe(memoryMode));
        p.setProperty("maxMemory", String.valueOf(clamp(customMemoryGb, 1, 64)));
        p.setProperty("processPriority", safe(processPriority));
        p.setProperty("customResolution", String.valueOf(customResolution));
        p.setProperty("windowWidth", String.valueOf(clamp(windowWidth, 320, 7680)));
        p.setProperty("windowHeight", String.valueOf(clamp(windowHeight, 240, 4320)));
        p.setProperty("ipPreference", safe(ipPreference));
        p.setProperty("launcherVisibility", safe(launcherVisibility));
        p.setProperty("launcherBrand", safe(launcherBrand));
        p.setProperty("launcherBrandVersion", safe(launcherBrandVersion));
        p.setProperty("accountMode", safe(accountMode));
        p.setProperty("msaClientId", safe(msaClientId));
        p.setProperty("msaRefreshToken", safe(msaRefreshToken));
        p.setProperty("msaUuid", safe(msaUuid));
        p.setProperty("msaName", safe(msaName));
        p.setProperty("msaXuid", safe(msaXuid));
        try (FileOutputStream out = new FileOutputStream(configFile())) {
            p.store(out, "mc-launcher 配置");
        } catch (IOException ignore) {
            // 写入失败不阻塞使用
        }
    }

    // ===== 目录 =====

    /** 基础安装目录（绝对路径），启用实例隔离时也不复制 versions/libraries/assets。 */
    public File baseDir() {
        String s = safe(gameDir);
        return s.isEmpty() ? defaultGameDir() : new File(s);
    }

    /** 该版本实际作为 --gameDir 传入的游戏目录。 */
    public File instanceDir(String versionId) {
        if (!instanceIsolation || versionId == null || versionId.isBlank()) return baseDir();
        return new File(new File(baseDir(), "instances"), versionId);
    }

    // ===== 内存 =====

    public int resolvedMemoryGb() {
        if ("custom".equals(memoryMode)) return clamp(customMemoryGb, 1, 64);
        return autoMemoryGb();
    }

    /** 系统物理内存（字节）；取不到时用 JVM 最大堆（默认约为物理内存的 1/4）推算。 */
    public static long totalRamBytes() {
        try {
            java.lang.management.OperatingSystemMXBean os = ManagementFactory.getOperatingSystemMXBean();
            if (os instanceof com.sun.management.OperatingSystemMXBean sun) {
                long t = sun.getTotalMemorySize();
                if (t > 0) return t;
            }
        } catch (Throwable ignore) {
            // 模块不可用时退回下面的估算
        }
        return Runtime.getRuntime().maxMemory() * 4L;
    }

    public static int totalRamGb() {
        long gb = totalRamBytes() / (1L << 30);
        return (int) Math.max(1, gb);
    }

    /** 自动内存：按物理内存分档，避免小内存机器被压垮、大内存机器分配不足。 */
    public static int autoMemoryGb() {
        int gb = totalRamGb();
        if (gb <= 4) return 1;
        if (gb <= 8) return 2;
        if (gb <= 16) return 4;
        return (int) Math.min(8, Math.max(4, gb / 2));
    }

    /** 启动器品牌占位符：空值时回落到默认，避免 ${launcher_name} 被替换成空串。 */
    public String brandOr(String fallback) {
        String s = safe(launcherBrand);
        return s.isEmpty() ? fallback : s;
    }

    public String brandVersionOr(String fallback) {
        String s = safe(launcherBrandVersion);
        return s.isEmpty() ? fallback : s;
    }

    // ===== 小工具 =====

    private static String safe(String s) {
        return s == null ? "" : s.trim();
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static boolean bool(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        return v == null ? def : Boolean.parseBoolean(v.trim());
    }

    private static int intVal(Properties p, String key, int def) {
        try {
            String v = p.getProperty(key);
            return v == null ? def : Integer.parseInt(v.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
