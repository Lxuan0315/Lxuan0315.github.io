package mc;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * 「实例」页：面向单个实例（版本）的集中管理。
 *
 * 左侧分类：版本设置 / 存档 / 资源包 / 光影包 / 模组 / 导出导入 / 日志与崩溃。
 * 顶部选择一个本地实例，右侧所有操作都作用于该实例。
 * 所有控件都把值真实落到文件（实例设置 / options.txt / 存档 zip / mod 重命名），没有假设置。
 */
public final class InstancesPanel extends JPanel {

    /** 版本设置变化（可能影响启动参数）时通知外层。 */
    public interface Listener {
        void onInstanceSettingsChanged(String id);

        /** 实例列表发生变化（导入 / 删除实例目录内容后）。 */
        void onInstancesChanged();
    }

    private static final String FOLLOW = "跟随全局设置";
    private static final Color MUTED = new Color(110, 110, 110);
    private static final Color PANEL_BG = new Color(250, 250, 252);

    private final Settings st;
    private final Consumer<String> log;
    private final Listener listener;
    private final Supplier<String> currentVersionId;

    private final JComboBox<ModScan.Instance> instanceCombo = new JComboBox<>();
    private final JLabel instanceInfo = new JLabel(" ");
    private boolean pickingInstance;

    private final DefaultListModel<String> categoryModel = new DefaultListModel<>();
    private final JList<String> categoryList = new JList<>(categoryModel);
    private final JPanel cards = new JPanel(new CardLayout());

    // ===== 版本设置 =====
    private final JComboBox<Object> javaCombo = new JComboBox<>();
    private final List<JavaRuntime.Java> javaList = new ArrayList<>();
    private final JComboBox<String> memCombo = new JComboBox<>(new String[]{FOLLOW, "自动配置", "自定义"});
    private final JSpinner memSpinner = new JSpinner(new SpinnerNumberModel(4, 1, 64, 1));
    private final JComboBox<String> resCombo = new JComboBox<>(new String[]{FOLLOW, "自定义尺寸", "游戏默认（不传宽高）"});
    private final JSpinner widthSpinner = new JSpinner(new SpinnerNumberModel(854, 320, 7680, 1));
    private final JSpinner heightSpinner = new JSpinner(new SpinnerNumberModel(480, 240, 4320, 1));
    private final JComboBox<String> fullscreenCombo = new JComboBox<>(new String[]{"不修改", "全屏启动", "窗口化启动"});
    private final JTextField jvmArgsField = new JTextField(40);
    private final JTextField gameArgsField = new JTextField(40);
    private final JTextField serverField = new JTextField(18);
    private final JTextField gameDirField = new JTextField(40);

    // ===== 存档 =====
    private final DefaultListModel<InstanceTools.Save> saveModel = new DefaultListModel<>();
    private final JList<InstanceTools.Save> saveList = new JList<>(saveModel);
    private final JLabel saveStatus = new JLabel(" ");

    // ===== 资源包 / 光影包 =====
    private final DefaultListModel<InstanceTools.Pack> packModel = new DefaultListModel<>();
    private final JList<InstanceTools.Pack> packList = new JList<>(packModel);
    private final JLabel packStatus = new JLabel(" ");
    private final DefaultListModel<InstanceTools.Pack> shaderModel = new DefaultListModel<>();
    private final JList<InstanceTools.Pack> shaderList = new JList<>(shaderModel);
    private final JLabel shaderStatus = new JLabel(" ");

    // ===== 模组 =====
    private final DefaultListModel<ModScan.Mod> modModel = new DefaultListModel<>();
    private final JList<ModScan.Mod> modList = new JList<>(modModel);
    private final JLabel modStatus = new JLabel(" ");

    // ===== 日志 =====
    private final JTextArea logReport = new JTextArea();
    private final JLabel logStatus = new JLabel(" ");

    /** 载入实例设置期间抑制控件事件，避免程序化赋值触发落盘。 */
    private boolean loading;
    private boolean busy;

    public InstancesPanel(Settings settings, Consumer<String> log, Listener listener, Supplier<String> currentVersionId) {
        this.st = settings;
        this.log = log;
        this.listener = listener;
        this.currentVersionId = currentVersionId;

        setLayout(new BorderLayout(0, 6));
        setBackground(PANEL_BG);
        setBorder(new EmptyBorder(8, 8, 8, 8));

        add(buildTop(), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);

        instanceCombo.addActionListener(e -> {
            if (pickingInstance) return;
            loadInstance();
        });

        // 实例扫描涉及逐个解析版本 JSON，放到切到本页时再做，避免拖慢启动器启动
        instanceInfo.setText("打开本页后会自动扫描本地实例。");
    }

    /** 切到本页时调用：实例列表与文件内容可能已变化。 */
    public void onShown() {
        refreshInstances();
        refreshCurrentCategory();
    }

    // ============================================================
    // 骨架
    // ============================================================

    private JComponent buildTop() {
        JPanel p = new JPanel(new BorderLayout(0, 4));

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 3));
        row.add(new JLabel("实例："));
        instanceCombo.setPreferredSize(new Dimension(380, 26));
        row.add(instanceCombo);
        JButton refresh = new JButton("刷新列表");
        refresh.addActionListener(e -> refreshInstances());
        row.add(refresh);
        p.add(row, BorderLayout.NORTH);

        instanceInfo.setForeground(MUTED);
        p.add(instanceInfo, BorderLayout.SOUTH);
        return p;
    }

    private JComponent buildBody() {
        categoryModel.addElement("版本设置");
        categoryModel.addElement("存档");
        categoryModel.addElement("资源包");
        categoryModel.addElement("光影包");
        categoryModel.addElement("模组");
        categoryModel.addElement("导出导入");
        categoryModel.addElement("日志与崩溃");

        categoryList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        categoryList.setFixedCellHeight(34);
        categoryList.setFont(categoryList.getFont().deriveFont(Font.PLAIN, 13f));
        categoryList.setBorder(new EmptyBorder(8, 6, 8, 6));
        categoryList.setBackground(new Color(243, 243, 246));
        categoryList.addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            ((CardLayout) cards.getLayout()).show(cards, categoryModel.getElementAt(categoryList.getSelectedIndex()));
            refreshCurrentCategory();
        });
        JScrollPane left = new JScrollPane(categoryList);
        left.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, new Color(225, 225, 230)));
        left.setPreferredSize(new Dimension(126, 100));

        addCategory("版本设置", buildVersionSettings());
        addCategory("存档", buildSaves());
        addCategory("资源包", buildPacks(false));
        addCategory("光影包", buildPacks(true));
        addCategory("模组", buildMods());
        addCategory("导出导入", buildTransfer());
        addCategory("日志与崩溃", buildLogs());
        cards.setBackground(PANEL_BG);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, left, cards);
        split.setBorder(null);
        split.setDividerSize(5);
        split.setResizeWeight(0);
        categoryList.setSelectedIndex(0);
        return split;
    }

    private void addCategory(String title, JComponent content) {
        JScrollPane sp = new JScrollPane(content);
        sp.setBorder(null);
        sp.getVerticalScrollBar().setUnitIncrement(16);
        sp.getViewport().setBackground(PANEL_BG);
        cards.add(sp, title);
    }

    private JPanel category() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(new EmptyBorder(12, 16, 16, 16));
        p.setBackground(PANEL_BG);
        return p;
    }

    private JLabel title(String text) {
        JLabel l = new JLabel(text);
        l.setFont(l.getFont().deriveFont(Font.BOLD, 15f));
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JPanel row(String label, JComponent field) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        p.setOpaque(false);
        p.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel l = new JLabel(label);
        l.setPreferredSize(new Dimension(104, 22));
        p.add(l);
        p.add(field);
        return p;
    }

    private JLabel hint(String text) {
        JLabel l = new JLabel("<html><body style='width:600px'>" + text + "</body></html>");
        l.setForeground(MUTED);
        l.setBorder(new EmptyBorder(2, 112, 8, 0));
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    private JPanel buttons(JComponent... items) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 3));
        p.setOpaque(false);
        p.setAlignmentX(Component.LEFT_ALIGNMENT);
        for (JComponent c : items) p.add(c);
        return p;
    }

    private static Font reportFont() {
        Font base = UIManager.getFont("TextArea.font");
        return base != null ? base.deriveFont(12f) : new Font(Font.DIALOG, Font.PLAIN, 12);
    }

    // ============================================================
    // 版本设置
    // ============================================================

    private JComponent buildVersionSettings() {
        JPanel p = category();
        p.add(title("本实例独立设置"));
        p.add(Box.createVerticalStrut(6));
        p.add(hint("这里的每一项只影响当前实例；选择「" + FOLLOW + "」即沿用全局设置。修改后自动保存到 "
                + "&lt;安装目录&gt;/launcher/instances/&lt;版本 id&gt;.properties。"));

        javaCombo.setPreferredSize(new Dimension(560, 26));
        javaCombo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                          boolean selected, boolean focus) {
                Object shown = value instanceof JavaRuntime.Java j ? j.label() : value;
                return super.getListCellRendererComponent(list, shown, index, selected, focus);
            }
        });
        javaCombo.addActionListener(e -> onJavaPicked());
        JPanel javaRow = row("Java", javaCombo);
        javaRow.add(new JLabel("（全局设置见「设置 → Java 运行时」）"));
        p.add(javaRow);

        memCombo.addActionListener(e -> {
            updateMemEnabled();
            commitInstance();
        });
        JPanel memRow = row("内存", memCombo);
        memRow.add(memSpinner);
        memRow.add(new JLabel("GB（仅自定义档生效）"));
        p.add(memRow);
        memSpinner.addChangeListener(e -> {
            updateMemEnabled();
            commitInstance();
        });
        p.add(hint("自动档按系统内存分档；自定义档直接写入 -Xmx。系统内存约 " + Settings.totalRamGb() + " GB。"));

        resCombo.addActionListener(e -> {
            updateResEnabled();
            commitInstance();
        });
        JPanel resRow = row("窗口", resCombo);
        resRow.add(widthSpinner);
        resRow.add(new JLabel("×"));
        resRow.add(heightSpinner);
        p.add(resRow);
        widthSpinner.addChangeListener(e -> {
            updateResEnabled();
            commitInstance();
        });
        heightSpinner.addChangeListener(e -> {
            updateResEnabled();
            commitInstance();
        });

        fullscreenCombo.addActionListener(e -> commitInstance());
        p.add(row("全屏", fullscreenCombo));
        p.add(hint("原版没有 --fullscreen 启动参数，所以这里通过改写该实例 options.txt 的 fullscreen 项生效："
                + "「全屏启动」写 fullscreen:true，「窗口化启动」写 fullscreen:false，「不修改」则不动这个文件。"));
        p.add(hint("注意：游戏运行时会在退出时回写 options.txt，因此该项在游戏进行中不会被改，下次启动生效。"));

        JPanel jvmRow = row("追加 JVM 参数", jvmArgsField);
        p.add(jvmRow);
        jvmArgsField.getDocument().addDocumentListener(simple(this::commitInstance));
        p.add(hint("附加到 Java 命令行，如 -XX:+UseG1GC 或 -Dfile.encoding=UTF-8；用双引号保留空格。"));

        JPanel gameArgsRow = row("追加游戏参数", gameArgsField);
        p.add(gameArgsRow);
        gameArgsField.getDocument().addDocumentListener(simple(this::commitInstance));
        p.add(hint("附加到游戏命令行末尾，如 --server 1.2.3.4 或自定义参数。"));

        serverField.setPreferredSize(new Dimension(240, 26));
        serverField.getDocument().addDocumentListener(simple(this::commitInstance));
        p.add(row("自动进服", serverField));
        p.add(hint("填 host 或 host:port，启动后自动连接该服务器（会转成 --server / --port 参数）。"));

        gameDirField.setEditable(false);
        JButton pickDir = new JButton("选择…");
        pickDir.addActionListener(e -> pickInstanceGameDir());
        JButton clearDir = new JButton("恢复默认");
        clearDir.addActionListener(e -> {
            InstSettings s = loadCurrent();
            if (s == null) return;
            s.gameDir = "";
            s.save(st.baseDir(), currentId());
            loadInstance();
            commitInstance();
        });
        JPanel dirRow = row("游戏目录", gameDirField);
        dirRow.add(pickDir);
        dirRow.add(clearDir);
        p.add(dirRow);
        p.add(hint("为该实例单独指定存档 / 配置目录；留空则按全局「实例隔离」规则自动决定。"));

        p.add(buttons(mkButton("保存本实例设置", e -> {
            commitInstance();
            log.accept("实例 " + currentId() + " 的设置已保存");
        }), mkButton("重置为跟随全局", e -> resetInstance())));

        p.add(Box.createVerticalGlue());
        return p;
    }

    private JButton mkButton(String text, java.awt.event.ActionListener a) {
        JButton b = new JButton(text);
        b.addActionListener(a);
        return b;
    }

    private void onJavaPicked() {
        if (loading) return;
        Object sel = javaCombo.getSelectedItem();
        InstSettings s = loadCurrent();
        if (s == null) return;
        if (sel instanceof JavaRuntime.Java j) {
            s.javaPath = j.exe != null ? j.exe.getAbsolutePath() : (j.home != null ? j.home.getAbsolutePath() : "");
        } else if (sel instanceof String str && str.startsWith("自定义：")) {
            return;   // 自定义项：路径未变化（浏览时才写入）
        } else {
            s.javaPath = "";
        }
        s.save(st.baseDir(), currentId());
        listener.onInstanceSettingsChanged(currentId());
        updateOwnershipLabels();
    }

    private void updateMemEnabled() {
        memSpinner.setEnabled("自定义".equals(memCombo.getSelectedItem()));
    }

    private void updateResEnabled() {
        boolean custom = "自定义尺寸".equals(resCombo.getSelectedItem());
        widthSpinner.setEnabled(custom);
        heightSpinner.setEnabled(custom);
    }

    /** 把所有控件写回实例设置文件。 */
    private void commitInstance() {
        if (loading) return;
        String id = currentId();
        if (id == null) return;
        InstSettings s = InstSettings.load(st.baseDir(), id);
        Object js = javaCombo.getSelectedItem();
        if (js instanceof JavaRuntime.Java j) {
            s.javaPath = j.exe != null ? j.exe.getAbsolutePath() : (j.home != null ? j.home.getAbsolutePath() : "");
        } else if (!(js instanceof String str && str.startsWith("自定义：")) && js != null) {
            s.javaPath = "";
        }
        int mi = memCombo.getSelectedIndex();
        s.memoryMode = mi == 1 ? "auto" : mi == 2 ? "custom" : "";
        s.memoryGb = (Integer) memSpinner.getValue();
        int ri = resCombo.getSelectedIndex();
        s.resolutionMode = ri == 1 ? "custom" : ri == 2 ? "default" : "";
        s.width = (Integer) widthSpinner.getValue();
        s.height = (Integer) heightSpinner.getValue();
        s.fullscreenMode = switch (fullscreenCombo.getSelectedIndex()) {
            case 1 -> "true";
            case 2 -> "false";
            default -> "";
        };
        s.jvmArgs = jvmArgsField.getText().trim();
        s.gameArgs = gameArgsField.getText().trim();
        s.serverAddress = serverField.getText().trim();
        s.gameDir = gameDirField.getText().trim();
        s.save(st.baseDir(), id);
        listener.onInstanceSettingsChanged(id);
        updateOwnershipLabels();
    }

    private void resetInstance() {
        String id = currentId();
        if (id == null) return;
        File f = InstSettings.fileFor(st.baseDir(), id);
        if (f.isFile() && !f.delete()) {
            JOptionPane.showMessageDialog(this, "无法删除 " + f.getAbsolutePath(), "重置失败", JOptionPane.ERROR_MESSAGE);
            return;
        }
        log.accept("实例 " + id + " 的独立设置已重置为跟随全局");
        loadInstance();
        listener.onInstanceSettingsChanged(id);
    }

    private void pickInstanceGameDir() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setDialogTitle("选择该实例的游戏目录");
        ModScan.Instance inst = current();
        if (inst != null && inst.gameDir.isDirectory()) chooser.setCurrentDirectory(inst.gameDir);
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            gameDirField.setText(chooser.getSelectedFile().getAbsolutePath());
            commitInstance();
            log.accept("实例 " + currentId() + " 的游戏目录已设为 " + gameDirField.getText());
        }
    }

    private void updateOwnershipLabels() {
        ModScan.Instance inst = current();
        if (inst == null) {
            instanceInfo.setText(" ");
            return;
        }
        InstSettings s = InstSettings.load(st.baseDir(), inst.id);
        instanceInfo.setText("加载器 " + ModScan.loaderLabel(inst.loader) + " · Minecraft " + inst.mcVersion
                + " · 游戏目录 " + inst.gameDir.getAbsolutePath()
                + (s.customized() ? "   【该实例已自定义设置】" : ""));
    }

    // ============================================================
    // 存档
    // ============================================================

    private JComponent buildSaves() {
        JPanel p = category();
        p.add(title("存档（世界）"));
        p.add(Box.createVerticalStrut(6));

        saveList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        saveList.setFixedCellHeight(26);
        p.add(buttons(
                mkButton("刷新", e -> refreshSaves()),
                mkButton("备份为 zip", e -> backupSave()),
                mkButton("导入 zip…", e -> importSave()),
                mkButton("删除", e -> deleteSave()),
                mkButton("打开存档目录", e -> openDir(savesDir()))));
        p.add(Box.createVerticalStrut(4));

        JScrollPane sp = new JScrollPane(saveList);
        sp.setPreferredSize(new Dimension(720, 300));
        sp.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(sp);
        p.add(Box.createVerticalStrut(4));
        saveStatus.setForeground(MUTED);
        saveStatus.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(saveStatus);
        p.add(hint("备份会把整个存档目录打包成 zip（含 region / level.dat 等全部文件）；"
                + "导入时若压缩包里只有一个顶层目录，会按该目录名还原。"));
        p.add(Box.createVerticalGlue());
        return p;
    }

    private void refreshSaves() {
        ModScan.Instance inst = current();
        saveModel.clear();
        if (inst == null) {
            saveStatus.setText("没有可用的实例");
            return;
        }
        List<InstanceTools.Save> saves = InstanceTools.listSaves(inst.gameDir);
        for (InstanceTools.Save s : saves) saveModel.addElement(s);
        saveStatus.setText("存档目录：" + savesDir().getAbsolutePath() + " · 共 " + saves.size() + " 个世界");
    }

    private File savesDir() {
        ModScan.Instance inst = current();
        return inst == null ? new File(st.baseDir(), "saves") : new File(inst.gameDir, "saves");
    }

    private void backupSave() {
        InstanceTools.Save save = saveList.getSelectedValue();
        if (save == null) {
            JOptionPane.showMessageDialog(this, "请先选中一个存档。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("备份存档到 zip");
        chooser.setSelectedFile(new File(st.baseDir(), save.dir.getName() + ".zip"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        run("备份存档", () -> InstanceTools.backupSave(save.dir, chooser.getSelectedFile(), log));
    }

    private void importSave() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("选择要导入的存档 zip");
        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
        File zip = chooser.getSelectedFile();
        run("导入存档", () -> InstanceTools.importSave(zip, savesDir().getParentFile(), log));
    }

    private void deleteSave() {
        InstanceTools.Save save = saveList.getSelectedValue();
        if (save == null) {
            JOptionPane.showMessageDialog(this, "请先选中一个存档。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int c = JOptionPane.showConfirmDialog(this,
                "确定删除存档「" + (save.levelName != null ? save.levelName : save.dir.getName())
                        + "」吗？此操作不可撤销（建议先备份）。",
                "删除存档", JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
        if (c != JOptionPane.OK_OPTION) return;
        run("删除存档", () -> InstanceTools.deleteSave(save.dir));
    }

    // ============================================================
    // 资源包 / 光影包
    // ============================================================

    private JComponent buildPacks(boolean shader) {
        JPanel p = category();
        p.add(title(shader ? "光影包" : "资源包"));
        p.add(Box.createVerticalStrut(6));

        JList<InstanceTools.Pack> list = shader ? shaderList : packList;
        DefaultListModel<InstanceTools.Pack> model = shader ? shaderModel : packModel;
        JLabel status = shader ? shaderStatus : packStatus;

        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setFixedCellHeight(26);
        list.setCellRenderer(new PackRenderer());
        list.addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            ((JComponent) list).repaint();
        });

        p.add(buttons(
                mkButton("刷新", e -> refreshPacks(shader)),
                mkButton("启用", e -> setPackEnabled(shader, true)),
                mkButton("停用", e -> setPackEnabled(shader, false)),
                mkButton("删除", e -> deletePack(shader)),
                mkButton("打开目录", e -> openDir(new File(currentGameDir(), shader ? "shaderpacks" : "resourcepacks")))));
        p.add(Box.createVerticalStrut(4));

        JScrollPane sp = new JScrollPane(list);
        sp.setPreferredSize(new Dimension(720, 300));
        sp.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(sp);
        p.add(Box.createVerticalStrut(4));
        status.setForeground(MUTED);
        status.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(status);
        p.add(hint(shader
                ? "启用 / 停用会写入 options.txt 的 shaderPack（OptiFine 等光影模组读取该键）；若存在 config/iris.properties，会同步其中的 shaderPack 项。"
                : "启用 / 停用会写入 options.txt 的 resourcePacks 列表（原版即按此加载），"
                  + "启用时同时从 incompatibleResourcePacks 里移除，避免被标记为不兼容后不生效"));
        p.add(Box.createVerticalGlue());
        return p;
    }

    private void refreshPacks(boolean shader) {
        ModScan.Instance inst = current();
        DefaultListModel<InstanceTools.Pack> model = shader ? shaderModel : packModel;
        JLabel status = shader ? shaderStatus : packStatus;
        model.clear();
        if (inst == null) {
            status.setText("没有可用的实例");
            return;
        }
        List<InstanceTools.Pack> packs = InstanceTools.listPacks(inst.gameDir, shader ? "shaderpacks" : "resourcepacks");
        for (InstanceTools.Pack pk : packs) model.addElement(pk);
        int enabled = 0;
        for (InstanceTools.Pack pk : packs) if (pk.enabled) enabled++;
        status.setText((shader ? "光影目录：" : "资源包目录：")
                + new File(inst.gameDir, shader ? "shaderpacks" : "resourcepacks").getAbsolutePath()
                + " · 共 " + packs.size() + " 个，已启用 " + enabled + " 个");
    }

    private void setPackEnabled(boolean shader, boolean enabled) {
        InstanceTools.Pack pk = (shader ? shaderList : packList).getSelectedValue();
        if (pk == null) {
            JOptionPane.showMessageDialog(this, "请先选中一个" + (shader ? "光影包" : "资源包") + "。",
                    "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        ModScan.Instance inst = current();
        if (inst == null) return;
        run("切换启用状态", () -> {
            if (shader) InstanceTools.setShaderPackEnabled(inst.gameDir, pk, enabled, log);
            else InstanceTools.setResourcePackEnabled(inst.gameDir, pk, enabled, log);
        });
    }

    private void deletePack(boolean shader) {
        InstanceTools.Pack pk = (shader ? shaderList : packList).getSelectedValue();
        if (pk == null) {
            JOptionPane.showMessageDialog(this, "请先选中一个" + (shader ? "光影包" : "资源包") + "。",
                    "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int c = JOptionPane.showConfirmDialog(this, "确定删除 " + pk.file.getName() + " 吗？",
                "删除", JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
        if (c != JOptionPane.OK_OPTION) return;
        run("删除" + (shader ? "光影包" : "资源包"), () -> InstanceTools.deletePack(pk));
    }

    // ============================================================
    // 模组
    // ============================================================

    private JComponent buildMods() {
        JPanel p = category();
        p.add(title("模组（mods）"));
        p.add(Box.createVerticalStrut(6));

        modList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        modList.setFixedCellHeight(26);
        p.add(buttons(
                mkButton("刷新", e -> refreshMods()),
                mkButton("启用 / 停用", e -> toggleMod()),
                mkButton("删除", e -> deleteMod()),
                mkButton("检查冲突", e -> checkMods()),
                mkButton("打开 mods 目录", e -> openDir(new File(currentGameDir(), "mods")))));
        p.add(Box.createVerticalStrut(4));

        JScrollPane sp = new JScrollPane(modList);
        sp.setPreferredSize(new Dimension(720, 300));
        sp.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(sp);
        p.add(Box.createVerticalStrut(4));
        modStatus.setForeground(MUTED);
        modStatus.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(modStatus);
        p.add(hint("「启用 / 停用」通过给 jar 加上或去掉 .disabled 后缀实现——游戏与加载器都只加载 .jar 结尾的文件，"
                + "因此被停用的 mod 不会被加载，随时可以改回。"));
        p.add(Box.createVerticalGlue());
        return p;
    }

    private void refreshMods() {
        ModScan.Instance inst = current();
        modModel.clear();
        if (inst == null) {
            modStatus.setText("没有可用的实例");
            return;
        }
        List<ModScan.Mod> mods = ModScan.scan(inst.modsDir);
        for (ModScan.Mod m : mods) modModel.addElement(m);
        int disabled = 0;
        File[] kids = inst.modsDir.listFiles();
        if (kids != null) for (File f : kids) if (f.getName().toLowerCase().endsWith(".jar.disabled")) disabled++;
        modStatus.setText(ModScan.loaderLabel(inst.loader) + " 实例 · mods 目录：" + inst.modsDir.getAbsolutePath()
                + " · 共 " + mods.size() + " 个 jar" + (disabled > 0 ? "，已停用 " + disabled + " 个" : ""));
    }

    private void toggleMod() {
        ModScan.Mod m = modList.getSelectedValue();
        if (m == null) {
            JOptionPane.showMessageDialog(this, "请先选中一个 mod。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        File f = m.file;
        String name = f.getName();
        File target;
        if (name.toLowerCase().endsWith(".jar.disabled")) {
            target = new File(f.getParentFile(), name.substring(0, name.length() - ".disabled".length()));
        } else if (name.toLowerCase().endsWith(".jar")) {
            target = new File(f.getParentFile(), name + ".disabled");
        } else {
            JOptionPane.showMessageDialog(this, "只支持对 .jar 文件启用 / 停用。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        run("切换 mod 状态", () -> {
            java.nio.file.Files.move(f.toPath(), target.toPath());
            log.accept("mod " + name + " → " + target.getName());
        });
    }

    private void deleteMod() {
        ModScan.Mod m = modList.getSelectedValue();
        if (m == null) {
            JOptionPane.showMessageDialog(this, "请先选中一个 mod。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int c = JOptionPane.showConfirmDialog(this, "确定删除 " + m.file.getName() + " 吗？",
                "删除 mod", JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
        if (c != JOptionPane.OK_OPTION) return;
        run("删除 mod", () -> java.nio.file.Files.deleteIfExists(m.file.toPath()));
    }

    private void checkMods() {
        ModScan.Instance inst = current();
        if (inst == null) {
            JOptionPane.showMessageDialog(this, "没有可用的实例。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        busy = true;
        new Thread(() -> {
            ModScan.Report rep = ModScan.analyze(inst);
            SwingUtilities.invokeLater(() -> {
                busy = false;
                log.accept("mod 冲突分析（" + inst.id + "）：会阻止启动 " + rep.errorCount()
                        + " 项，注意 " + rep.warnCount() + " 项，已装 mod " + rep.mods.size() + " 个");
                JTextArea area = new JTextArea(rep.format());
                area.setEditable(false);
                area.setFont(reportFont());
                area.setCaretPosition(0);
                JScrollPane sp = new JScrollPane(area);
                sp.setPreferredSize(new Dimension(760, 460));
                int type = rep.blocking() ? JOptionPane.ERROR_MESSAGE
                        : (rep.warnCount() > 0 ? JOptionPane.WARNING_MESSAGE : JOptionPane.INFORMATION_MESSAGE);
                JOptionPane.showMessageDialog(this, sp, "实例 " + inst.id + " · 冲突分析", type);
            });
        }, "inst-mod-check").start();
    }

    // ============================================================
    // 导出导入
    // ============================================================

    private JComponent buildTransfer() {
        JPanel p = category();
        p.add(title("实例导出 / 导入"));
        p.add(Box.createVerticalStrut(6));
        p.add(hint("导出会把该实例的版本目录、mods、config、saves、resourcepacks、options.txt 等打成 zip，"
                + "但不含 libraries / assets（所有实例共享的公共资源，体积很大且可重新下载）。"));
        p.add(buttons(
                mkButton("导出当前实例为 zip…", e -> exportInstance()),
                mkButton("从 zip 导入实例…", e -> importInstance())));
        p.add(Box.createVerticalStrut(6));
        p.add(hint("导入时版本目录落到 versions/&lt;id&gt;；游戏目录内容按当前「实例隔离」设置，"
                + "落到 instances/&lt;id&gt;（开启隔离）或安装目录（未开启）。"));
        p.add(Box.createVerticalGlue());
        return p;
    }

    private void exportInstance() {
        ModScan.Instance inst = current();
        if (inst == null) {
            JOptionPane.showMessageDialog(this, "没有可用的实例。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("导出实例到 zip");
        chooser.setSelectedFile(new File(st.baseDir(), inst.id + "-instance.zip"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        File dest = chooser.getSelectedFile();
        run("导出实例", () -> InstanceTools.exportInstance(st, inst, dest, log));
    }

    private void importInstance() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("选择要导入的实例 zip");
        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
        File zip = chooser.getSelectedFile();
        run("导入实例", () -> {
            String id = InstanceTools.importInstance(zip, st, log);
            SwingUtilities.invokeLater(() -> {
                listener.onInstancesChanged();
                refreshInstances();
                selectInstance(id);
            });
        });
    }

    // ============================================================
    // 日志与崩溃
    // ============================================================

    private JComponent buildLogs() {
        JPanel p = category();
        p.add(title("日志与崩溃分析"));
        p.add(Box.createVerticalStrut(6));
        p.add(buttons(
                mkButton("分析最新日志", e -> refreshLogs()),
                mkButton("打开 logs 目录", e -> openDir(new File(currentGameDir(), "logs"))),
                mkButton("打开崩溃报告目录", e -> openDir(new File(currentGameDir(), "crash-reports")))));
        p.add(Box.createVerticalStrut(4));

        logReport.setEditable(false);
        logReport.setFont(reportFont());
        JScrollPane sp = new JScrollPane(logReport);
        sp.setPreferredSize(new Dimension(760, 360));
        sp.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(sp);
        p.add(Box.createVerticalStrut(4));
        logStatus.setForeground(MUTED);
        logStatus.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(logStatus);
        p.add(hint("分析 logs/latest.log 的最后 4000 行、最新的 crash-reports 报告，以及 hs_err_pid 崩溃日志，"
                + "给出常见故障（内存不足、Java 版本、natives、Mixin、重复 mod、驱动等）的可读结论。"));
        p.add(Box.createVerticalGlue());
        return p;
    }

    private void refreshLogs() {
        ModScan.Instance inst = current();
        if (inst == null) {
            logReport.setText("没有可用的实例。");
            logStatus.setText(" ");
            return;
        }
        busy = true;
        logStatus.setText("分析中…");
        new Thread(() -> {
            InstanceTools.LogReport rep = InstanceTools.analyzeLogs(inst.gameDir);
            SwingUtilities.invokeLater(() -> {
                busy = false;
                logReport.setText(rep.format());
                logReport.setCaretPosition(0);
                logStatus.setText("已分析 " + inst.id + "：" + (rep.logFile == null
                        ? "未找到 latest.log（先启动一次游戏）"
                        : rep.errorCount() + " 条报错线索 / " + rep.warnCount() + " 条警告"));
                log.accept("日志分析（" + inst.id + "）：报错线索 " + rep.errorCount() + " 条");
            });
        }, "inst-log-analyze").start();
    }

    // ============================================================
    // 实例列表与刷新
    // ============================================================

    private ModScan.Instance current() {
        Object o = instanceCombo.getSelectedItem();
        return o instanceof ModScan.Instance i ? i : null;
    }

    private String currentId() {
        ModScan.Instance i = current();
        return i == null ? null : i.id;
    }

    private File currentGameDir() {
        ModScan.Instance i = current();
        return i == null ? st.baseDir() : i.gameDir;
    }

    public void refreshInstances() {
        List<ModScan.Instance> found = ModScan.listInstances(st);
        Object prev = instanceCombo.getSelectedItem();
        String prevId = prev instanceof ModScan.Instance p ? p.id : null;

        pickingInstance = true;
        try {
            instanceCombo.removeAllItems();
            for (ModScan.Instance i : found) instanceCombo.addItem(i);
            ModScan.Instance target = findById(found, prevId);
            if (target == null) target = findById(found, defaultId(found));
            if (target == null && !found.isEmpty()) target = found.get(0);
            instanceCombo.setSelectedItem(target);
        } finally {
            pickingInstance = false;
        }
        loadInstance();
    }

    private void selectInstance(String id) {
        List<ModScan.Instance> found = ModScan.listInstances(st);
        ModScan.Instance target = findById(found, id);
        if (target != null) {
            pickingInstance = true;
            instanceCombo.setSelectedItem(target);
            pickingInstance = false;
            loadInstance();
        }
    }

    private String defaultId(List<ModScan.Instance> list) {
        String id = st.defaultInstance;
        if (id == null || id.isBlank()) id = currentVersionId.get();
        if (id == null || id.isBlank()) return list.isEmpty() ? null : list.get(0).id;
        return id;
    }

    private static ModScan.Instance findById(List<ModScan.Instance> list, String id) {
        if (id == null) return null;
        for (ModScan.Instance i : list) if (id.equals(i.id)) return i;
        return null;
    }

    /** 由 LauncherUI 在扫描完成后回填 Java 列表，供「版本设置」选择。 */
    public void setJavaList(List<JavaRuntime.Java> list) {
        javaList.clear();
        javaList.addAll(list);
        if (current() != null) loadInstance();
    }

    private void rebuildJavaComboInner() {
        javaCombo.removeAllItems();
        javaCombo.addItem(FOLLOW);
        for (JavaRuntime.Java j : javaList) javaCombo.addItem(j);
    }

    /** 载入当前实例的所有内容。 */
    private void loadInstance() {
        ModScan.Instance inst = current();
        loading = true;
        try {
            rebuildJavaComboInner();
            if (inst != null) {
                InstSettings s = InstSettings.load(st.baseDir(), inst.id);
                // Java：能对上已探测到的运行时就直接选它，否则作为一个「自定义：路径」项显示
                Object javaSel = FOLLOW;
                if (!s.javaPath.isBlank()) {
                    JavaRuntime.Java hit = null;
                    for (JavaRuntime.Java j : javaList) {
                        if (matches(j, s.javaPath)) {
                            hit = j;
                            break;
                        }
                    }
                    if (hit != null) {
                        javaSel = hit;
                    } else {
                        String label = "自定义：" + s.javaPath;
                        javaCombo.addItem(label);
                        javaSel = label;
                    }
                }
                javaCombo.setSelectedItem(javaSel);

                memCombo.setSelectedIndex("auto".equals(s.memoryMode) ? 1 : "custom".equals(s.memoryMode) ? 2 : 0);
                memSpinner.setValue(clamp(s.memoryGb, 1, 64));
                resCombo.setSelectedIndex("custom".equals(s.resolutionMode) ? 1 : "default".equals(s.resolutionMode) ? 2 : 0);
                widthSpinner.setValue(clamp(s.width, 320, 7680));
                heightSpinner.setValue(clamp(s.height, 240, 4320));
                fullscreenCombo.setSelectedIndex("true".equals(s.fullscreenMode) ? 1
                        : "false".equals(s.fullscreenMode) ? 2 : 0);
                jvmArgsField.setText(s.jvmArgs);
                gameArgsField.setText(s.gameArgs);
                serverField.setText(s.serverAddress);
                gameDirField.setText(s.gameDir);
            } else {
                javaCombo.setSelectedItem(FOLLOW);
            }
        } finally {
            loading = false;
        }
        updateMemEnabled();
        updateResEnabled();
        updateOwnershipLabels();
    }

    private static boolean matches(JavaRuntime.Java j, String path) {
        if (path == null || path.isBlank()) return false;
        String p = path.replace('\\', '/').toLowerCase();
        if (j.exe != null && j.exe.getAbsolutePath().replace('\\', '/').toLowerCase().equals(p)) return true;
        return j.home != null && j.home.getAbsolutePath().replace('\\', '/').toLowerCase().equals(p);
    }

    private InstSettings loadCurrent() {
        String id = currentId();
        return id == null ? null : InstSettings.load(st.baseDir(), id);
    }

    /** 当前分类切换后按需刷新内容。 */
    private void refreshCurrentCategory() {
        int idx = categoryList.getSelectedIndex();
        switch (idx) {
            case 1 -> refreshSaves();
            case 2 -> refreshPacks(false);
            case 3 -> refreshPacks(true);
            case 4 -> refreshMods();
            default -> {
                // 版本设置 / 导出导入 / 日志：无需自动刷新
            }
        }
    }

    // ============================================================
    // 通用
    // ============================================================

    private void run(String what, ThrowingRunnable task) {
        if (busy) {
            log.accept(what + "：已有任务在进行中，请稍候");
            return;
        }
        busy = true;
        new Thread(() -> {
            try {
                task.run();
                SwingUtilities.invokeLater(() -> {
                    busy = false;
                    refreshCurrentCategory();
                });
            } catch (Exception ex) {
                final String msg = ex.getMessage() == null ? ex.toString() : ex.getMessage();
                SwingUtilities.invokeLater(() -> {
                    busy = false;
                    log.accept(what + "失败：" + msg);
                    JOptionPane.showMessageDialog(this, msg, what + "失败", JOptionPane.ERROR_MESSAGE);
                    refreshCurrentCategory();
                });
            }
        }, "inst-task").start();
    }

    interface ThrowingRunnable {
        void run() throws Exception;
    }

    private void openDir(File dir) {
        try {
            if (!dir.isDirectory() && !dir.mkdirs()) throw new java.io.IOException("无法创建目录：" + dir);
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                Desktop.getDesktop().open(dir);
            } else {
                JOptionPane.showMessageDialog(this, "系统不支持打开文件夹，路径：\n" + dir.getAbsolutePath(),
                        "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "打开失败", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static javax.swing.event.DocumentListener simple(Runnable r) {
        return new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
        };
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** 资源包 / 光影包两行渲染：名称 + 启用状态 + 描述。 */
    private static final class PackRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                      boolean selected, boolean focus) {
            super.getListCellRendererComponent(list, value, index, selected, focus);
            if (value instanceof InstanceTools.Pack pk) {
                StringBuilder sb = new StringBuilder("<html>");
                sb.append(pk.enabled ? "<b>" : "");
                sb.append(escape(pk.file.getName()));
                sb.append(pk.enabled ? "</b>" : "");
                sb.append(" <font color=\"").append(pk.enabled ? "#1a8a3c" : "#888888").append("\">")
                  .append(pk.enabled ? "[已启用]" : "[未启用]").append("</font>");
                if (pk.directory) sb.append(" <font color=\"#888888\">[目录]</font>");
                if (!pk.description.isBlank()) {
                    sb.append("<br><font size=\"-1\" color=\"#666666\">").append(escape(pk.description)).append("</font>");
                }
                sb.append("</html>");
                setText(sb.toString());
            }
            return this;
        }
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
