package mc;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * 下载流水线：版本清单 → 版本 JSON → client.jar → 依赖库 → natives 解压 → 资源索引 → 资源对象 → 日志配置。
 * 所有方法都是阻塞的，调用方需放在后台线程；进度通过 {@link Progress} 快照暴露给 UI。
 */
public final class Installer {

    public static final String MANIFEST_URL = "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json";
    private static final String ASSET_BASE = "https://resources.download.minecraft.net/";
    private static final long MANIFEST_TTL_MS = 3_600_000L;
    /** 依赖库并行下载线程数。依赖库多为几十 MB 的大文件，并发太高等不到带宽收益反而更容易触发限速。 */
    private static final int DEFAULT_LIBRARY_THREADS = 8;

    /**
     * 愚人节版本的版本号（2015 起）。
     * 这些版本混在近千个快照里，没有单独的标记，只能按已知 id 白名单识别。
     * 注意 20w14a / 23w13a 是普通快照，不要误收。
     */
    private static final Set<String> APRIL_FOOLS = new HashSet<>(Arrays.asList(
            "25w14craftmine",
            "24w14potato",
            "23w13a_or_b",
            "22w13oneblockatatime",
            "20w14infinite",
            "3D Shareware v1.34",
            "1.RV-Pre1",
            "15w14a"));

    /** 是否愚人节版本。 */
    public static boolean isAprilFools(String id) {
        return id != null && APRIL_FOOLS.contains(id);
    }

    public static final class VersionEntry {
        public String id;
        public String type;
        public String url;
        public String sha1;
        public String releaseTime;
        /** 本地已有完整实例（含 Fabric / Forge / NeoForge 等加载器实例），而非仅出现在官方清单里。 */
        public boolean local;

        @Override
        public String toString() {
            return id + (local ? "  [已安装]" : "  [" + type + "]");
        }
    }

    public static final class Manifest {
        public String latestRelease;
        public String latestSnapshot;
        public final List<VersionEntry> versions = new ArrayList<>();
    }

    /** 待解压的原生库 jar 及其来源库名（库名决定落到哪个 natives 子目录）。 */
    public static final class NativeJar {
        public final File file;
        public final String libName;

        NativeJar(File file, String libName) {
            this.file = file;
            this.libName = libName;
        }
    }

    /** 进度快照：后台线程只写，UI 定时读。 */
    public static final class Progress {
        public volatile String stage = "空闲";
        public volatile String detail = "";
        public volatile long done;
        public volatile long total;
        public volatile long bytes;
        public volatile boolean running;
    }

    private final File gameDir;
    private final Progress progress;
    private final Consumer<String> log;

    private VersionMeta meta;
    private File clientJar;
    private File nativesDir;
    private final List<File> classpath = new ArrayList<>();
    private volatile boolean ready;

    public Installer(File gameDir, Progress progress, Consumer<String> log) {
        this.gameDir = gameDir;
        this.progress = progress;
        this.log = log;
    }

    /** 该版本是否已经完整就绪（下载成功或本地已有完整安装），只有为 true 时才能启动。 */
    public boolean isReady() {
        return ready;
    }

    public File gameDir() { return gameDir; }
    public VersionMeta meta() { return meta; }
    public File clientJar() { return clientJar; }
    public File nativesDir() { return nativesDir; }
    public List<File> classpath() { return classpath; }

    // ===== 版本清单 =====

    public Manifest loadManifest(boolean force) throws IOException {
        File cached = new File(gameDir, "versions/version_manifest_v2.json");
        String text = null;
        if (!force && cached.isFile() && System.currentTimeMillis() - cached.lastModified() < MANIFEST_TTL_MS) {
            try {
                text = Files.readString(cached.toPath(), StandardCharsets.UTF_8);
                log.accept("使用缓存的版本清单（1 小时内）");
            } catch (IOException ignore) {
                text = null;
            }
        }
        if (text == null) {
            log.accept("下载版本清单 " + MANIFEST_URL);
            text = Net.getString(MANIFEST_URL);
            Files.createDirectories(cached.getParentFile().toPath());
            Files.writeString(cached.toPath(), text, StandardCharsets.UTF_8);
        }

        Object root = Json.parse(text);
        Manifest m = new Manifest();
        Object latest = Json.get(root, "latest");
        m.latestRelease = Json.str(latest, "release");
        m.latestSnapshot = Json.str(latest, "snapshot");

        List<Object> versions = Json.asList(Json.get(root, "versions"));
        if (versions != null) {
            for (Object o : versions) {
                VersionEntry e = new VersionEntry();
                e.id = Json.str(o, "id");
                e.type = Json.str(o, "type");
                e.url = Json.str(o, "url");
                e.sha1 = Json.str(o, "sha1");
                e.releaseTime = Json.str(o, "releaseTime");
                if (e.id != null && e.url != null) m.versions.add(e);
            }
        }
        List<VersionEntry> merged = mergeLocalInstances(m.versions);
        m.versions.clear();
        m.versions.addAll(merged);
        return m;
    }

    /**
     * 把本地已安装的实例并进版本列表，放在最前面。
     *
     * 加载器实例（fabric-loader-x-y / 1.20.1-forge-x）不属于官方清单，
     * 不单独扫出来用户在版本下拉里就找不到自己刚装好的实例。
     * 若某实例同时在清单里（例如完整装过的原版），保留清单里的下载地址，"下载 / 更新"仍可用。
     */
    private List<VersionEntry> mergeLocalInstances(List<VersionEntry> manifestVersions) {
        List<VersionEntry> locals = scanLocalInstances();
        // 必须返回新列表：调用方紧接着会 clear() 原列表，若返回同一个对象会把结果一起清空
        if (locals.isEmpty()) return new ArrayList<>(manifestVersions);

        Map<String, VersionEntry> fromManifest = new HashMap<>();
        for (VersionEntry e : manifestVersions) fromManifest.put(e.id, e);

        Set<String> localIds = new HashSet<>();
        List<VersionEntry> out = new ArrayList<>(locals);
        for (VersionEntry e : locals) localIds.add(e.id);
        for (VersionEntry e : manifestVersions) {
            if (!localIds.contains(e.id)) out.add(e);
        }
        for (VersionEntry e : out) {
            VersionEntry m = fromManifest.get(e.id);
            if (m == null) continue;
            e.url = m.url;
            e.sha1 = m.sha1;
            e.releaseTime = m.releaseTime;
            e.type = m.type;
        }
        return out;
    }

    /** 扫 versions 目录，挑出 JSON 与"能解析到的客户端 jar"都齐全的实例。 */
    private List<VersionEntry> scanLocalInstances() {
        List<VersionEntry> out = new ArrayList<>();
        File[] dirs = new File(gameDir, "versions").listFiles(File::isDirectory);
        if (dirs == null) return out;
        Arrays.sort(dirs, Comparator.comparing(File::getName));
        for (File d : dirs) {
            String id = d.getName();
            if (!new File(d, id + ".json").isFile()) continue;
            // 加载器实例（Fabric / Quilt / Forge / NeoForge）目录里没有自己的 jar，
            // 客户端 jar 与原版共享，必须按官方规则解析，否则刚装好的实例不会出现在版本列表里
            VersionMeta m = parseLocalMeta(id);
            if (m == null) continue;
            if (!resolveClientJarFile(id, m).isFile()) continue;
            VersionEntry e = new VersionEntry();
            e.id = id;
            e.type = "local";
            e.local = true;
            out.add(e);
        }
        return out;
    }

    /** 读取本地版本的元数据，并按官方语义合并继承链；本地没有该版本时返回 null。 */
    public VersionMeta readMeta(String versionId) {
        return parseLocalMeta(versionId);
    }

    // ===== 完整下载 =====

    public void install(VersionEntry entry) throws IOException {
        progress.running = true;
        ready = false;   // 失败或中断时不能留下“可启动”的假状态
        try {
            File versionDir = new File(gameDir, "versions/" + entry.id);
            Files.createDirectories(versionDir.toPath());

            installVersionJson(entry, versionDir);
            String reason = meta.missingReason();
            if (reason != null) {
                throw new IOException("版本 " + entry.id + " 无法启动：" + reason);
            }
            log.accept("版本 " + meta.id + "：需要 Java " + meta.javaVersionMajor + "，主类 " + meta.mainClass
                    + (meta.minecraftArguments != null ? "（旧式 minecraftArguments 格式）" : ""));

            installClient(entry, versionDir);
            List<NativeJar> nativeJars = installLibraries();
            installNatives(entry, versionDir, nativeJars);
            installAssets();
            installLoggingConfig();

            progress.stage = "完成";
            progress.detail = "版本 " + meta.id + " 已就绪";
            ready = true;
            log.accept("=== 下载完成，可以启动 ===");
        } finally {
            progress.running = false;
        }
    }

    /**
     * 为加载器安装器（Forge / NeoForge 的官方 --installClient）已经创建好的实例补齐运行条件：
     * 下载合并后缺失的依赖库，并把原生库解压到该实例的 natives 目录。
     *
     * 刻意不重新下载客户端 jar：加载器已经在该位置放了打过补丁的客户端，
     * 用父版本的原始 client.jar 覆盖会直接破坏这个实例。
     */
    public void prepareLoaderInstance(String versionId) throws IOException {
        progress.running = true;
        ready = false;
        try {
            meta = parseLocalMeta(versionId);
            if (meta == null) throw new IOException("实例 " + versionId + " 缺少 " + versionId + ".json");
            String reason = meta.missingReason();
            if (reason != null) throw new IOException("实例 " + versionId + " 无法启动：" + reason);

            File versionDir = new File(gameDir, "versions/" + versionId);
            clientJar = resolveClientJarFile(versionId, meta);
            if (!clientJar.isFile()) {
                if (meta.clientUrl == null) {
                    throw new IOException("实例 " + versionId + " 找不到客户端 jar，也没有可下载的地址"
                            + "（其继承的原版版本 " + meta.inheritsFrom + " 可能还没下载）");
                }
                stage("客户端主程序", clientJar.getName());
                Net.download(meta.clientUrl, clientJar, meta.clientSize, meta.clientSha1, true, null, log);
                log.accept("客户端 jar 已补齐：" + relocate(clientJar));
            } else {
                log.accept("复用已存在的客户端 jar：" + relocate(clientJar));
            }
            log.accept("实例 " + versionId + "：加载器已就绪，需要 Java " + meta.javaVersionMajor
                    + "，主类 " + meta.mainClass);

            stage("依赖库校验", "补齐缺失的依赖");
            List<NativeJar> nativeJars = installLibraries();

            VersionEntry synthetic = new VersionEntry();
            synthetic.id = versionId;
            installNatives(synthetic, versionDir, nativeJars);

            progress.stage = "完成";
            progress.detail = "实例 " + versionId + " 已就绪";
            ready = true;
            log.accept("=== 加载器实例准备完成，可以启动 ===");
        } finally {
            progress.running = false;
        }
    }

    /**
     * 若该版本已经完整落地，则直接从本地装载（不联网），用于重启启动器后直接启动。
     * 返回 false 表示尚未下载，需要走 {@link #install}。
     */
    public boolean loadLocal(VersionEntry entry) throws IOException {
        // 先清空上一次的状态，避免选中未下载的版本时仍能启动上一个版本
        meta = null;
        clientJar = null;
        nativesDir = null;
        ready = false;
        classpath.clear();

        File versionDir = new File(gameDir, "versions/" + entry.id);
        File json = new File(versionDir, entry.id + ".json");
        if (!json.isFile()) return false;

        VersionMeta local = parseLocalMeta(entry.id);
        if (local == null || !local.launchable()) return false;

        // 加载器实例目录里往往没有自己的 jar，客户端 jar 与原版共享，按官方规则解析
        File jar = resolveClientJarFile(entry.id, local);
        if (!jar.isFile()) return false;

        List<File> cp = new ArrayList<>();
        for (VersionMeta.Lib lib : local.libraries) {
            if (lib.path == null) continue;
            if (!Rules.allowed(lib.rules, Map.of()) || !Rules.nativeArchAllowed(lib.name)) continue;
            File f = new File(gameDir, "libraries/" + lib.path);
            if (f.isFile()) cp.add(f);
        }
        if (cp.isEmpty()) return false;

        meta = local;
        clientJar = jar;
        nativesDir = new File(versionDir, entry.id + "-natives");
        classpath.clear();
        classpath.addAll(cp);
        ready = true;
        return true;
    }

    // ===== 各阶段 =====

    /**
     * 启动前完整性检查：返回缺失项描述，空列表表示可以直接启动。
     *
     * {@link #loadLocal} 会静默跳过缺失的依赖库，因此 isReady() 为真也可能缺文件。
     * 这里只做本地文件系统检查（不联网、不逐个扫描数千个资源对象，保证点击启动时几乎无延迟）。
     */
    public List<String> checkIntegrity() {
        List<String> problems = new ArrayList<>();
        if (meta == null) {
            problems.add("版本信息未加载（版本 JSON 缺失或解析失败）");
            return problems;
        }
        if (clientJar == null || !clientJar.isFile() || clientJar.length() == 0) {
            problems.add("客户端 jar 缺失：" + (clientJar == null ? "未知路径" : clientJar.getAbsolutePath()));
        }
        if (meta.inheritsFrom != null && meta.clientUrl == null && meta.effectiveGameArgs().isEmpty()
                && meta.mainClass == null) {
            problems.add("版本继承链未合并成功（缺少父版本 " + meta.inheritsFrom + " 的版本 JSON）");
        }

        int missingLibs = 0;
        boolean hasNatives = false;
        List<String> examples = new ArrayList<>();
        for (VersionMeta.Lib lib : meta.libraries) {
            if (lib.path == null) continue;
            if (lib.classifierNative || (lib.natives != null && !lib.natives.isEmpty())) hasNatives = true;
            if (!Rules.allowed(lib.rules, Map.of()) || !Rules.nativeArchAllowed(lib.name)) continue;
            File f = new File(gameDir, "libraries/" + lib.path);
            if (!f.isFile() || f.length() == 0) {
                missingLibs++;
                if (examples.size() < 3) examples.add(lib.path);
            }
        }
        if (missingLibs > 0) {
            problems.add("依赖库缺失 " + missingLibs + " 个（libraries 目录），例如：" + String.join("、", examples));
        }
        if (hasNatives && (nativesDir == null || !nativesDir.isDirectory())) {
            problems.add("原生库（natives）目录不存在：" + (nativesDir == null ? "未知" : nativesDir.getAbsolutePath()));
        } else if (hasNatives && nativesDir != null) {
            File[] files = nativesDir.listFiles();
            if (files == null || files.length == 0) problems.add("原生库（natives）尚未解压：" + nativesDir.getAbsolutePath());
        }
        File indexFile = meta.indexId == null ? null : new File(gameDir, "assets/indexes/" + meta.indexId + ".json");
        if (indexFile != null && !indexFile.isFile()) {
            problems.add("资源索引缺失：" + indexFile.getAbsolutePath() + "（游戏可能缺少音效 / 语言文件）");
        }
        return problems;
    }

    private void installVersionJson(VersionEntry entry, File versionDir) throws IOException {
        meta = null;
        File file = new File(versionDir, entry.id + ".json");
        if (file.isFile()) {
            meta = parseLocalMeta(entry.id);
            if (meta != null) log.accept("复用已存在的版本信息 " + file.getName());
        }
        if (meta == null) {
            // 加载器实例的 JSON 由 LoaderInstaller 自己写入，没有官方下载地址
            if (entry.url == null) {
                throw new IOException("缺少 " + entry.id + ".json，且该版本不来自官方清单，无法下载");
            }
            stage("版本信息", entry.id + ".json");
            log.accept("下载版本信息 " + entry.id + ".json");
            Net.download(entry.url, file, 0, entry.sha1, true, null, log);
            meta = parseLocalMeta(entry.id);
        }
        if (meta == null) throw new IOException("版本 " + entry.id + " 的 JSON 无法解析");
        if (meta.inheritsFrom != null) {
            log.accept("版本 " + entry.id + " 继承自 " + meta.inheritsFrom + "，已按官方语义合并父版本");
        }
    }

    // ===== 版本 JSON 的继承解析 =====

    /** 继承链解析深度，防止加载器 profile 互相引用时无限递归。 */
    private int parentDepth;

    /**
     * 读取本地版本 JSON 并沿 inheritsFrom 合并父版本。
     * 加载器实例（Fabric / Quilt / Forge / NeoForge）只有自己那层 JSON，
     * 客户端下载地址、资源索引、原版依赖库都来自父版本，不合并就无法启动。
     */
    private VersionMeta parseLocalMeta(String id) {
        File json = new File(gameDir, "versions/" + id + "/" + id + ".json");
        if (!json.isFile()) return null;
        try {
            return VersionMeta.parse(Files.readString(json.toPath(), StandardCharsets.UTF_8), this::loadParentMeta);
        } catch (Exception ex) {
            log.accept("版本 JSON 解析失败（" + id + "）：" + ex.getMessage());
            return null;
        }
    }

    /** 取父版本（本地已有则直接用，否则按官方清单地址下载），返回已完全合并的元数据。 */
    private VersionMeta loadParentMeta(String id) {
        if (parentDepth >= 6) return null;
        parentDepth++;
        try {
            return fetchMeta(id);
        } finally {
            parentDepth--;
        }
    }

    private VersionMeta fetchMeta(String id) {
        File json = new File(gameDir, "versions/" + id + "/" + id + ".json");
        if (!json.isFile()) {
            String url = manifestUrlFor(id);
            if (url == null) {
                log.accept("缺少父版本 " + id + "，无法合并（请先在「下载」页下载该版本）");
                return null;
            }
            stage("父版本信息", id + ".json");
            try {
                Net.download(url, json, 0, null, false, null, log);
            } catch (Exception ex) {
                log.accept("父版本 " + id + " 的 JSON 下载失败：" + ex.getMessage());
                return null;
            }
        }
        try {
            VersionMeta vm = VersionMeta.parse(Files.readString(json.toPath(), StandardCharsets.UTF_8), this::loadParentMeta);
            vm.inheritsFrom = null;   // 已完成解析，避免上层重复合并造成参数重复
            return vm;
        } catch (Exception ex) {
            log.accept("父版本 JSON 解析失败（" + id + "）：" + ex.getMessage());
            return null;
        }
    }

    /** 从缓存的官方清单里查版本 JSON 地址。 */
    private String manifestUrlFor(String id) {
        File cached = new File(gameDir, "versions/version_manifest_v2.json");
        if (!cached.isFile()) return null;
        try {
            Object root = Json.parse(Files.readString(cached.toPath(), StandardCharsets.UTF_8));
            List<Object> versions = Json.asList(Json.get(root, "versions"));
            if (versions == null) return null;
            for (Object o : versions) {
                if (id.equals(Json.str(o, "id"))) return Json.str(o, "url");
            }
        } catch (Exception ignore) {
            // 清单损坏时走不到父版本，后续会给出明确提示
        }
        return null;
    }

    /**
     * 安装一个只有本地 JSON 的版本（Fabric / Quilt / Legacy Fabric 的 profile 实例）。
     * 这类版本没有官方下载地址，JSON 由 {@link LoaderInstaller} 写入，
     * 其余（客户端、依赖库、原生库、资源）全部来自合并进来的父版本。
     */
    public void installLoaderProfile(String versionId) throws IOException {
        VersionEntry entry = new VersionEntry();
        entry.id = versionId;
        entry.type = "release";
        entry.url = null;
        install(entry);
    }

    /**
     * 解析"这个实例该用哪个客户端 jar"，按官方启动器的规则逐级回退：
     * 1. 实例目录里自己的 jar（加载器安装器生成的打过补丁的客户端）；
     * 2. JSON 的 jar 字段指定的版本（老版本 Forge 用）；
     * 3. 所继承版本的 jar（现代 Fabric / Forge 实例目录里没有 jar，客户端 jar 与原版共享）。
     * 都不存在时返回按规则应该放置的位置（调用方据此下载）。
     */
    private File resolveClientJarFile(String versionId, VersionMeta m) {
        String id = versionId;
        VersionMeta cur = m;
        for (int depth = 0; depth < 6 && cur != null; depth++) {
            File own = new File(gameDir, "versions/" + id + "/" + id + ".jar");
            if (own.isFile()) return own;
            if (cur.jarId != null && !cur.jarId.equals(id)) {
                File named = new File(gameDir, "versions/" + cur.jarId + "/" + cur.jarId + ".jar");
                if (named.isFile()) return named;
                return named;
            }
            if (cur.inheritsFrom == null) return own;
            VersionMeta parent = parseLocalMeta(cur.inheritsFrom);
            id = cur.inheritsFrom;
            cur = parent != null ? parent : null;
            if (cur == null) return new File(gameDir, "versions/" + id + "/" + id + ".jar");
        }
        return new File(gameDir, "versions/" + versionId + "/" + versionId + ".jar");
    }

    /**
     * 安装/校验客户端 jar。已存在的 jar 一律复用，不覆盖：
     * 它可能是加载器安装器打过补丁的客户端，也可能是与原版共享的 jar。
     */
    private void installClient(VersionEntry entry, File versionDir) throws IOException {
        clientJar = resolveClientJarFile(entry.id, meta);
        if (clientJar.isFile()) {
            log.accept("复用已存在的客户端 jar：" + relocate(clientJar));
            return;
        }
        if (meta.clientUrl == null) {
            throw new IOException("实例 " + entry.id + " 拿不到客户端下载地址：所继承的原版版本 "
                    + (meta.inheritsFrom == null ? "未知" : meta.inheritsFrom) + " 尚未下载，请先下载该版本");
        }
        stage("客户端主程序", clientJar.getName());
        long n = Net.download(meta.clientUrl, clientJar, meta.clientSize, meta.clientSha1, true, null, log);
        log.accept(n == 0 ? "client.jar 已存在且校验通过，跳过" : "client.jar 下载完成 " + n + " 字节");
        bump();
    }

    /** 相对安装目录的路径，日志里比绝对路径好读。 */
    private String relocate(File f) {
        String base = gameDir.getAbsolutePath();
        String path = f.getAbsolutePath();
        return path.startsWith(base) ? path.substring(base.length() + 1).replace('\\', '/') : path;
    }

    /**
     * 下载全部规则命中的依赖库，返回需要解压的原生库 jar 列表。
     *
     * 下载阶段并行执行（DEFAULT_LIBRARY_THREADS 个线程，每个文件独立分片，支持断点续传），
     * 但 classpath 顺序必须在下载完成后按元数据原顺序重建 —— 并行下载不改变顺序语义。
     */
    private List<NativeJar> installLibraries() throws IOException {
        stage("依赖库", "按当前系统过滤规则");
        List<VersionMeta.Lib> allowed = new ArrayList<>();
        int skippedArch = 0;
        for (VersionMeta.Lib lib : meta.libraries) {
            if (Rules.allowed(lib.rules, Map.of()) && Rules.nativeArchAllowed(lib.name)) {
                allowed.add(lib);
            } else if (lib.classifierNative) {
                skippedArch++;
            }
        }
        log.accept("依赖库 " + allowed.size() + " / " + meta.libraries.size() + " 条通过规则过滤"
                + (skippedArch > 0 ? "（排除 " + skippedArch + " 条当前平台不需要的原生库）" : ""));
        String osKey = Rules.osKey();

        // ---- 阶段一：收集待下载文件，并行下载 ----
        List<Net.Task> tasks = new ArrayList<>();
        int noTaskLibs = 0;
        for (VersionMeta.Lib lib : allowed) {
            int created = 0;
            if (lib.path != null && lib.url != null) {
                File f = new File(gameDir, "libraries/" + lib.path);
                tasks.add(new Net.Task(lib.url, f, lib.size, lib.sha1, true));
                created++;
            }
            if (lib.natives != null && lib.classifiers != null) {
                // 老版本（1.6 ~ 1.12.2，含愚人节版本）：natives 映射 + downloads.classifiers 里带完整地址
                Object classifierRaw = lib.natives.get(osKey);
                if (classifierRaw != null) {
                    // 老版本这里可能带 ${arch} 占位符，需要启动器按位数替换
                    String classifier = String.valueOf(classifierRaw).replace("${arch}", Rules.is64Bit() ? "64" : "32");
                    Object artifact = lib.classifiers.get(classifier);
                    String path = Json.str(artifact, "path");
                    String url = Json.str(artifact, "url");
                    if (path != null && url != null) {
                        tasks.add(new Net.Task(url, new File(gameDir, "libraries/" + path),
                                Json.num(artifact, "size", 0), Json.str(artifact, "sha1"), true));
                        created++;
                    }
                }
            } else if (lib.natives != null && lib.mavenBase != null) {
                // 部分老版本 / 加载器 profile：只有 natives 映射，没有 classifiers 地址，
                // 原生库路径要按 maven 坐标自己派生（这些条目的主 jar 往往不存在，也不能算进 classpath）
                Object classifierRaw = lib.natives.get(osKey);
                if (classifierRaw != null) {
                    String classifier = String.valueOf(classifierRaw).replace("${arch}", Rules.is64Bit() ? "64" : "32");
                    String path = lib.derivedClassifierPath(classifier);
                    if (path != null) {
                        File f = new File(gameDir, "libraries/" + path);
                        if (!f.isFile()) {
                            tasks.add(new Net.Task(lib.mavenBase() + path, f, 0, null, false));
                            created++;
                        }
                    }
                }
            }
            if (created == 0) noTaskLibs++;
        }

        progress.total = Math.max(1, tasks.size() + noTaskLibs);
        progress.done = 0;
        for (int i = 0; i < noTaskLibs; i++) bump();
        for (Net.Task t : tasks) t.onFinish = this::bump;

        int threads = Math.max(1, Math.min(DEFAULT_LIBRARY_THREADS, tasks.size()));
        log.accept("并行下载依赖库 " + tasks.size() + " 个文件（" + threads + " 线程，中断可续传）");
        int failed = Net.downloadAll(tasks, DEFAULT_LIBRARY_THREADS, log);
        if (failed > 0) {
            StringBuilder sb = new StringBuilder();
            int shown = 0;
            for (Net.Task t : tasks) {
                if (t.error == null) continue;
                if (shown++ >= 3) break;
                sb.append("\n  - ").append(t.dest.getName()).append("：").append(t.error);
            }
            throw new IOException(failed + " 个依赖库下载失败（重试或检查网络后再次点击「下载 / 更新」即可续传）" + sb);
        }

        // ---- 阶段二：按元数据原顺序重建 classpath / 原生库列表 ----
        classpath.clear();
        List<NativeJar> nativeJars = new ArrayList<>();
        for (VersionMeta.Lib lib : allowed) {
            if (lib.path != null && lib.url != null) {
                File f = new File(gameDir, "libraries/" + lib.path);
                if (f.isFile()) classpath.add(f);
                if (lib.classifierNative && f.isFile()) nativeJars.add(new NativeJar(f, lib.name));
            }
            if (lib.natives != null && lib.classifiers != null) {
                Object classifierRaw = lib.natives.get(osKey);
                if (classifierRaw != null) {
                    String classifier = String.valueOf(classifierRaw).replace("${arch}", Rules.is64Bit() ? "64" : "32");
                    String path = Json.str(lib.classifiers.get(classifier), "path");
                    if (path != null) {
                        File f = new File(gameDir, "libraries/" + path);
                        if (f.isFile()) nativeJars.add(new NativeJar(f, lib.name));
                    }
                }
            } else if (lib.natives != null && lib.mavenBase != null) {
                Object classifierRaw = lib.natives.get(osKey);
                if (classifierRaw != null) {
                    String classifier = String.valueOf(classifierRaw).replace("${arch}", Rules.is64Bit() ? "64" : "32");
                    String path = lib.derivedClassifierPath(classifier);
                    if (path != null) {
                        File f = new File(gameDir, "libraries/" + path);
                        if (f.isFile()) nativeJars.add(new NativeJar(f, lib.name));
                    }
                }
            }
        }
        log.accept("依赖库就绪（" + classpath.size() + " 个入 classpath），其中原生库 " + nativeJars.size() + " 个待解压");
        return nativeJars;
    }

    private void installNatives(VersionEntry entry, File versionDir, List<NativeJar> nativeJars) throws IOException {
        stage("原生库解压", entry.id + "-natives");
        nativesDir = new File(versionDir, entry.id + "-natives");
        Set<String> subdirs = GameProcess.deriveNativesSubdirs(meta);
        Files.createDirectories(nativesDir.toPath());
        for (String s : subdirs) Files.createDirectories(new File(nativesDir, s).toPath());

        progress.total = Math.max(1, nativeJars.size());
        progress.done = 0;
        int extracted = 0;
        for (NativeJar nj : nativeJars) {
            extracted += extractNatives(nj, nativesDir);
            bump();
        }
        log.accept("已解压 " + extracted + " 个原生文件 → " + nativesDir.getAbsolutePath());
        log.accept("natives 子目录：" + subdirs);
    }

    /**
     * 解压原生库 jar：跳过目录、META-INF 与 extract.exclude 命中的条目，文件名扁平化。
     * 解压到 natives 根，同时按库来源再放一份到对应子目录（java / lwjgl / jna / netty），
     * 因为现代版本的 jvm 参数是分别指向这些子目录的。
     */
    private int extractNatives(NativeJar nj, File nativesRoot) throws IOException {
        File target = new File(nativesRoot, GameProcess.nativesSubdirFor(nj.libName));
        int count = 0;
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(Files.newInputStream(nj.file.toPath())))) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName();
                if (e.isDirectory() || name.startsWith("META-INF/") || name.indexOf('#') >= 0) continue;
                if (name.endsWith(".git") || name.endsWith(".sha1")) continue;
                String base = name.substring(name.lastIndexOf('/') + 1);
                if (base.isEmpty()) continue;
                byte[] data = zin.readAllBytes();
                Files.write(new File(target, base).toPath(), data);
                Files.write(new File(nativesRoot, base).toPath(), data);
                count++;
            }
        }
        return count;
    }

    private void installAssets() throws IOException {
        stage("资源索引", "assets/indexes/" + meta.indexId + ".json");
        File indexFile = new File(gameDir, "assets/indexes/" + meta.indexId + ".json");
        Net.download(meta.indexUrl, indexFile, meta.indexSize, meta.indexSha1, true, null, log);

        Object indexRoot = Json.parse(Files.readString(indexFile.toPath(), StandardCharsets.UTF_8));
        Map<String, Object> objects = Json.asMap(Json.get(indexRoot, "objects"));
        if (objects == null) throw new IOException("资源索引缺少 objects 字段");
        log.accept("资源文件共 " + objects.size() + " 个（约 " + (meta.indexTotalSize / 1024 / 1024) + " MB）");

        stage("游戏资源", "并发下载中");
        progress.total = objects.size();
        progress.done = 0;
        progress.bytes = 0;

        AtomicInteger failed = new AtomicInteger();
        AtomicLong byteCounter = new AtomicLong();
        List<String> failures = Collections.synchronizedList(new ArrayList<>());
        int threads = Math.max(2, Math.min(16, Runtime.getRuntime().availableProcessors() * 2));
        ExecutorService pool = Executors.newFixedThreadPool(threads, r -> {
            Thread t = new Thread(r, "asset-download");
            t.setDaemon(true);
            return t;
        });
        CountDownLatch latch = new CountDownLatch(objects.size());

        try {
            for (Map.Entry<String, Object> en : objects.entrySet()) {
                final String assetName = en.getKey();
                final Object node = en.getValue();
                final String hash = Json.str(node, "hash");
                final long size = Json.num(node, "size", 0);
                pool.execute(() -> {
                    try {
                        if (hash == null) return;
                        File dest = new File(gameDir, "assets/objects/" + hash.substring(0, 2) + "/" + hash);
                        boolean complete = dest.isFile() && size > 0 && dest.length() == size;
                        if (!complete) {
                            Net.download(ASSET_BASE + hash.substring(0, 2) + "/" + hash, dest, size, hash, false,
                                    b -> progress.bytes = byteCounter.addAndGet(b), null);
                        }
                    } catch (Exception ex) {
                        failed.incrementAndGet();
                        if (failures.size() < 5) failures.add(assetName + "：" + ex.getMessage());
                    } finally {
                        progress.done++;
                        latch.countDown();
                    }
                });
            }
            latch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            pool.shutdownNow();
        }

        if (failed.get() > 0) {
            log.accept("警告：" + failed.get() + " 个资源下载失败（不影响启动，可能缺音效/语言文件）");
            for (String f : failures) log.accept("  - " + f);
        } else {
            log.accept("资源全部就绪，本次累计下载 " + (progress.bytes / 1024 / 1024) + " MB");
        }
    }

    private void installLoggingConfig() throws IOException {
        if (meta.logUrl == null || meta.logPath == null) return;
        stage("日志配置", meta.logPath);
        File f = new File(gameDir, "assets/" + meta.logPath);
        Net.download(meta.logUrl, f, meta.logSize, meta.logSha1, true, null, log);
        bump();
    }

    // ===== 小工具 =====

    private void stage(String name, String detail) {
        progress.stage = name;
        progress.detail = detail == null ? "" : detail;
        progress.done = 0;
        progress.total = 0;
        progress.bytes = 0;
    }

    private void bump() {
        progress.done++;
    }
}
