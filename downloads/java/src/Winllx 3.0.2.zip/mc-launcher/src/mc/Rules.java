package mc;

import java.util.List;
import java.util.Map;

/**
 * 依赖库 rules 求值。
 * 语义：没有 rules → 允许；存在 rules → 初始视为拒绝，按顺序逐条匹配，命中的规则用其 action 覆盖结果。
 */
public final class Rules {

    private static final String OS_NAME = System.getProperty("os.name", "").toLowerCase();
    private static final String OS_ARCH = normalizeArch(System.getProperty("os.arch", ""));
    private static final String OS_VERSION = System.getProperty("os.version", "");

    private Rules() {}

    public static String osKey() {
        if (OS_NAME.contains("win")) return "windows";
        if (OS_NAME.contains("mac") || OS_NAME.contains("darwin")) return "osx";
        return "linux";
    }

    public static boolean allowed(List<Object> rules, Map<String, Boolean> features) {
        if (rules == null || rules.isEmpty()) return true;
        boolean allow = false;
        for (Object r : rules) {
            Map<String, Object> rule = Json.asMap(r);
            if (rule == null) continue;
            if (matches(rule, features)) {
                allow = "allow".equalsIgnoreCase(Json.str(r, "action"));
            }
        }
        return allow;
    }

    private static boolean matches(Map<String, Object> rule, Map<String, Boolean> features) {
        Object osNode = rule.get("os");
        if (osNode instanceof Map) {
            String name = Json.str(osNode, "name");
            if (name != null && !osNameMatches(name)) return false;

            String arch = Json.str(osNode, "arch");
            if (arch != null && !normalizeArch(arch).equals(OS_ARCH)) return false;

            Object range = Json.get(osNode, "versionRange");
            if (range instanceof Map) {
                String min = Json.str(range, "min");
                String max = Json.str(range, "max");
                if (min != null && compareVersion(OS_VERSION, min) < 0) return false;
                if (max != null && compareVersion(OS_VERSION, max) > 0) return false;
            }
        }
        Object featuresNode = rule.get("features");
        if (featuresNode instanceof Map) {
            for (Map.Entry<String, Object> e : Json.asMap(featuresNode).entrySet()) {
                boolean want = Boolean.TRUE.equals(e.getValue());
                boolean have = features != null && Boolean.TRUE.equals(features.get(e.getKey()));
                if (want != have) return false;
            }
        }
        return true;
    }

    /**
     * 现代版本的原生库把平台写进了 name（如 org.lwjgl:lwjgl:3.4.3:natives-windows-arm64），
     * 而它的 rules 只判 os、不判架构，必须由启动器按当前架构挑选；
     * 否则会把其它架构的 dll 一起下载解压，扁平化后互相覆盖导致原生库加载失败。
     */
    public static boolean nativeArchAllowed(String libName) {
        if (libName == null) return true;
        int c = libName.indexOf(":natives-");
        if (c < 0) return true;
        String classifier = libName.substring(c + ":natives-".length());
        String os = osKey();
        if (!classifier.startsWith(os)) return true;   // 系统不匹配的情况交给 rules 处理
        String rest = classifier.substring(os.length()).replace("-", "").replace("_", "").toLowerCase();
        if (rest.contains("arm64") || rest.contains("aarch")) return "arm64".equals(OS_ARCH);
        if (rest.contains("amd64") || rest.contains("x8664") || rest.contains("x64")) return "x86_64".equals(OS_ARCH);
        if (rest.contains("x86") || rest.contains("i386") || rest.contains("i686")) return "x86".equals(OS_ARCH);
        return true;   // 未限定架构
    }

    /** 当前 JVM 是否为 64 位（老版本 natives 的 ${arch} 占位符取值）。 */
    public static boolean is64Bit() {
        return !"x86".equals(OS_ARCH);
    }

    private static boolean osNameMatches(String mojangName) {
        switch (mojangName.toLowerCase()) {
            case "windows": return OS_NAME.contains("win");
            case "osx": return OS_NAME.contains("mac") || OS_NAME.contains("darwin");
            case "linux": return OS_NAME.contains("linux");
            default: return mojangName.equalsIgnoreCase(OS_NAME);
        }
    }

    /** 把各种架构别名归一化成 mojang 用的 x86 / x86_64 / arm64。 */
    public static String normalizeArch(String arch) {
        if (arch == null) return "";
        String a = arch.toLowerCase();
        switch (a) {
            case "amd64":
            case "x86_64":
            case "x86-64":
                return "x86_64";
            case "x86":
            case "x86_32":
            case "i386":
            case "i486":
            case "i586":
            case "i686":
                return "x86";
            case "aarch64":
            case "arm64":
                return "arm64";
            default:
                return a;
        }
    }

    /** 点分版本号比较（缺段补 0），a>b 返回正数。 */
    private static int compareVersion(String a, String b) {
        String[] xs = a.split("\\.");
        String[] ys = b.split("\\.");
        int n = Math.max(xs.length, ys.length);
        for (int i = 0; i < n; i++) {
            int x = i < xs.length ? parseIntSafe(xs[i]) : 0;
            int y = i < ys.length ? parseIntSafe(ys[i]) : 0;
            if (x != y) return Integer.compare(x, y);
        }
        return 0;
    }

    private static int parseIntSafe(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') sb.append(c);
            else break;
        }
        if (sb.isEmpty()) return 0;
        try {
            return Integer.parseInt(sb.toString());
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
