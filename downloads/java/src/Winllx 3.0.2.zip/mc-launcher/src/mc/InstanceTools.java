package mc;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * 实例相关工具（不依赖 Swing，便于单独验证）：
 * 存档管理、资源包 / 光影包管理、日志与崩溃分析、实例导出 / 导入。
 *
 * 所有操作都是真实文件操作，不含占位逻辑。
 */
public final class InstanceTools {

    private InstanceTools() {}

    public static final int ERROR = 0;
    public static final int WARN = 1;
    public static final int INFO = 2;

    /** 资源包 / 光影包共用的一个条目。 */
    public static final class Pack {
        public File file;
        /** 是否目录形式（未打包的文件夹）。 */
        public boolean directory;
        /** 是否在 options.txt 里被启用。 */
        public boolean enabled;
        /** pack.mcmeta 里的描述（尽力而为，读不到为空）。 */
        public String description = "";
        public long size;

        public String name() {
            return file == null ? "" : file.getName();
        }
    }

    /** 一个世界存档。 */
    public static final class Save {
        public File dir;
        public String levelName;
        public long size;
        public long lastModified;

        public String display() {
            String n = levelName != null && !levelName.isBlank() ? levelName : dir.getName();
            return n + "   (" + dir.getName() + " · " + human(size) + ")";
        }

        @Override
        public String toString() {
            return display();
        }
    }

    // ============================================================
    // 存档
    // ============================================================

    /** 列出存档：&lt;gameDir&gt;/saves 下每个含 level.dat 的目录。 */
    public static List<Save> listSaves(File gameDir) {
        List<Save> out = new ArrayList<>();
        File saves = new File(gameDir, "saves");
        File[] dirs = saves.listFiles(File::isDirectory);
        if (dirs == null) return out;
        for (File d : dirs) {
            File level = new File(d, "level.dat");
            if (!level.isFile()) continue;      // 非法/半成品存档直接跳过
            Save s = new Save();
            s.dir = d;
            s.levelName = readLevelName(level);
            s.size = folderSize(d);
            s.lastModified = level.lastModified();
            out.add(s);
        }
        out.sort(Comparator.comparingLong((Save s) -> s.lastModified).reversed());
        return out;
    }

    /** 把存档目录打包成 zip（保留目录内的相对结构）。 */
    public static void backupSave(File saveDir, File destZip, Consumer<String> log) throws IOException {
        File parent = destZip.getParentFile();
        if (parent != null) Files.createDirectories(parent.toPath());
        int n = 0;
        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(destZip)))) {
            n = zipDirectory(zip, saveDir, saveDir.getName());
        }
        if (log != null) log.accept("已备份存档到 " + destZip.getAbsolutePath() + "（" + n + " 个文件）");
    }

    /** 从 zip 导入存档：解到 saves 下的新目录，重名时自动加序号。 */
    public static File importSave(File zipFile, File gameDir, Consumer<String> log) throws IOException {
        File saves = new File(gameDir, "saves");
        Files.createDirectories(saves.toPath());
        String base = stripExt(zipFile.getName());

        List<String> entries = new ArrayList<>();
        try (ZipInputStream ignored = new ZipInputStream(new FileInputStream(zipFile))) {
            // 先探测是否所有条目都在同一个顶层目录里（我们的备份格式就是这种）
            java.util.zip.ZipEntry e;
            while ((e = ignored.getNextEntry()) != null) entries.add(e.getName());
        }
        if (entries.isEmpty()) throw new IOException("压缩包里没有内容");
        String commonRoot = commonTopDir(entries);

        File target = uniqueDir(saves, commonRoot != null ? commonRoot : base);
        int count = 0;
        try (ZipInputStream zip = new ZipInputStream(new FileInputStream(zipFile))) {
            java.util.zip.ZipEntry e;
            while ((e = zip.getNextEntry()) != null) {
                String name = e.getName().replace('\\', '/');
                String rel = commonRoot != null && name.startsWith(commonRoot + "/")
                        ? name.substring(commonRoot.length() + 1) : name;
                if (rel.isEmpty()) continue;
                File dest = new File(target, rel);
                if (!dest.getCanonicalPath().startsWith(target.getCanonicalPath())) continue;  // 防目录穿越
                if (e.isDirectory()) {
                    Files.createDirectories(dest.toPath());
                } else {
                    File p = dest.getParentFile();
                    if (p != null) Files.createDirectories(p.toPath());
                    Files.copy(zip, dest.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    count++;
                }
            }
        }
        if (log != null) log.accept("已导入存档到 " + target.getAbsolutePath() + "（" + count + " 个文件）");
        return target;
    }

    /** 删除存档目录。 */
    public static void deleteSave(File saveDir) throws IOException {
        deleteRecursively(saveDir);
    }

    // ============================================================
    // 资源包 / 光影包
    // ============================================================

    /**
     * 列出资源包或光影包。
     *
     * @param gameDir 游戏目录
     * @param kind    "resourcepacks" 或 "shaderpacks"
     */
    public static List<Pack> listPacks(File gameDir, String kind) {
        List<Pack> out = new ArrayList<>();
        File dir = new File(gameDir, kind);
        File[] kids = dir.listFiles();
        if (kids == null) return out;
        Set<String> enabled = "resourcepacks".equals(kind) ? enabledResourcePacks(gameDir) : enabledShaders(gameDir);
        for (File f : kids) {
            boolean isDir = f.isDirectory();
            String lower = f.getName().toLowerCase();
            if (!isDir && !lower.endsWith(".zip")) continue;
            if (isDir && "resourcepacks".equals(kind) && new File(f, "pack.mcmeta").exists()) {
                // 目录型资源包
            } else if (isDir && "shaderpacks".equals(kind) && new File(f, "shaders").isDirectory()) {
                // 目录型光影包
            } else if (isDir) {
                continue;
            }
            Pack p = new Pack();
            p.file = f;
            p.directory = isDir;
            // options.txt 里资源包记作 "file/<名称>"，光影记作纯名称
            p.enabled = enabled.contains("resourcepacks".equals(kind) ? "file/" + f.getName() : f.getName());
            p.description = readPackDescription(f, isDir);
            p.size = isDir ? folderSize(f) : f.length();
            out.add(p);
        }
        out.sort(Comparator.comparing(p -> p.file.getName().toLowerCase()));
        return out;
    }

    /** 启用 / 停用资源包（写 options.txt 的 resourcePacks 列表，原版即按此加载）。 */
    public static void setResourcePackEnabled(File gameDir, Pack pack, boolean enabled, Consumer<String> log)
            throws IOException {
        String ref = "file/" + pack.file.getName();
        List<String> list = new ArrayList<>(readOptionsList(gameDir, "resourcePacks"));
        if (enabled) {
            if (!list.contains(ref)) list.add(ref);
        } else {
            list.remove(ref);
        }
        writeOptionsList(gameDir, "resourcePacks", list);
        // 启用的包同时从"不兼容列表"里移除，避免它被游戏标记为不兼容后不生效
        if (enabled) {
            List<String> bad = new ArrayList<>(readOptionsList(gameDir, "incompatibleResourcePacks"));
            if (bad.remove(ref)) writeOptionsList(gameDir, "incompatibleResourcePacks", bad);
        }
        if (log != null) log.accept((enabled ? "已启用" : "已停用") + "资源包 " + pack.file.getName()
                + "（已写入 " + new File(gameDir, "options.txt").getAbsolutePath() + "）");
    }

    /** 启用 / 停用光影包（写 options.txt 的 shaderPack，并同步 Iris 的 config/iris.properties）。 */
    public static void setShaderPackEnabled(File gameDir, Pack pack, boolean enabled, Consumer<String> log)
            throws IOException {
        writeOptionLine(gameDir, "shaderPack", enabled ? pack.file.getName() : "");
        File iris = new File(new File(gameDir, "config"), "iris.properties");
        if (iris.isFile()) {
            List<String> lines = new ArrayList<>(Files.readAllLines(iris.toPath(), StandardCharsets.UTF_8));
            boolean replaced = false;
            for (int i = 0; i < lines.size(); i++) {
                if (lines.get(i).trim().startsWith("shaderPack=")) {
                    lines.set(i, "shaderPack=" + (enabled ? pack.file.getName() : ""));
                    replaced = true;
                    break;
                }
            }
            if (!replaced) lines.add("shaderPack=" + (enabled ? pack.file.getName() : ""));
            Files.write(iris.toPath(), lines, StandardCharsets.UTF_8);
        }
        if (log != null) log.accept((enabled ? "已启用" : "已停用") + "光影包 " + pack.file.getName()
                + "（options.txt" + (iris.isFile() ? " + IRIS 配置" : "") + " 已更新）");
    }

    public static void deletePack(Pack pack) throws IOException {
        deleteRecursively(pack.file);
    }

    // ============================================================
    // 日志与崩溃分析
    // ============================================================

    /** 一条分析结论。 */
    public static final class Finding {
        public final int severity;
        public final String title;
        public final String detail;

        Finding(int severity, String title, String detail) {
            this.severity = severity;
            this.title = title;
            this.detail = detail;
        }
    }

    /** 日志分析结果。 */
    public static final class LogReport {
        public final File gameDir;
        public File logFile;
        public File crashFile;
        public File hsErrFile;
        public int logLines;
        public String mcVersion;
        public final List<Finding> findings = new ArrayList<>();
        private final Set<String> seen = new LinkedHashSet<>();

        LogReport(File gameDir) {
            this.gameDir = gameDir;
        }

        void add(int severity, String title, String detail) {
            String key = severity + "\u0000" + title;
            if (!seen.add(key)) return;
            findings.add(new Finding(severity, title, detail));
        }

        public int errorCount() {
            int n = 0;
            for (Finding f : findings) if (f.severity == ERROR) n++;
            return n;
        }

        public int warnCount() {
            int n = 0;
            for (Finding f : findings) if (f.severity == WARN) n++;
            return n;
        }

        /** 给弹窗显示的完整报告文本。 */
        public String format() {
            StringBuilder sb = new StringBuilder();
            sb.append("游戏目录：").append(gameDir.getAbsolutePath()).append("\n");
            sb.append("日志文件：").append(logFile == null ? "未找到 logs/latest.log" : logFile.getName()
                    + "（" + logLines + " 行）").append("\n");
            if (crashFile != null) sb.append("崩溃报告：").append(crashFile.getName()).append("\n");
            if (hsErrFile != null) sb.append("JVM 崩溃日志：").append(hsErrFile.getName()).append("\n");
            if (mcVersion != null) sb.append("识别到的 Minecraft 版本：").append(mcVersion).append("\n");
            sb.append("\n");

            if (findings.isEmpty()) {
                sb.append("结论：没有在日志里发现常见的崩溃 / 报错特征。\n");
                if (logFile == null) sb.append("提示：还没有生成 logs/latest.log，先启动一次游戏再看。\n");
            } else if (errorCount() > 0) {
                sb.append("结论：找到 ").append(errorCount()).append(" 个明确的报错线索，按下面顺序排查即可。\n");
            } else {
                sb.append("结论：只找到 ").append(warnCount()).append(" 条提示，游戏大概率能正常进入。\n");
            }

            if (!findings.isEmpty()) {
                sb.append("\n──────── 分析结果 ────────\n");
                int i = 1;
                for (Finding f : findings) {
                    sb.append(i++).append(". ");
                    sb.append(f.severity == ERROR ? "【报错】" : f.severity == WARN ? "【警告】" : "【提示】");
                    sb.append(f.title).append("\n   ").append(f.detail).append("\n");
                }
            }
            return sb.toString();
        }
    }

    /** 分析最新日志、最新崩溃报告与 hs_err 文件，给出常见故障的可读结论。 */
    public static LogReport analyzeLogs(File gameDir) {
        LogReport rep = new LogReport(gameDir);

        File latest = new File(new File(gameDir, "logs"), "latest.log");
        if (latest.isFile()) rep.logFile = latest;

        rep.crashFile = newest(new File(gameDir, "crash-reports"));
        File[] hs = gameDir.listFiles(f -> f.isFile() && f.getName().startsWith("hs_err_pid"));
        if (hs != null && hs.length > 0) {
            Arrays.sort(hs, Comparator.comparingLong(File::lastModified).reversed());
            rep.hsErrFile = hs[0];
        }

        List<String> lines = new ArrayList<>();
        if (rep.logFile != null) {
            try {
                lines = Files.readAllLines(rep.logFile.toPath(), StandardCharsets.UTF_8);
            } catch (IOException ignore) {
                lines = new ArrayList<>();
            }
        }
        rep.logLines = lines.size();
        // 只看最后 4000 行，长日志中间部分对结论没帮助
        int from = Math.max(0, lines.size() - 4000);
        List<String> tail = lines.subList(from, lines.size());

        String joined = String.join("\n", tail);
        rep.mcVersion = matchFirst(joined, "Minecraft Version:\\s*([\\w.\\-+]+)",
                "Loading Minecraft ([\\w.\\-+]+)", "Minecraft ([1-9]\\.[\\d.]+)");

        // ---- 常见故障特征 ----
        if (joined.contains("java.lang.OutOfMemoryError")) {
            String extra = linked(joined, "OutOfMemoryError", "(Java heap space|Metaspace|GC overhead)");
            rep.add(ERROR, "内存不足（OutOfMemoryError）",
                    "游戏分配到的内存不够" + (extra == null ? "" : "（" + extra + "）")
                            + "。到「实例 → 版本设置 → 内存」调大 -Xmx，或减少 mod / 把渲染距离调小。");
        }
        if (joined.contains("UnsupportedClassVersionError")) {
            String v = matchFirst(joined, "class file version (\\d+)");
            rep.add(ERROR, "Java 版本过低",
                    "加载某个类时提示 class 文件版本 " + (v == null ? "过高" : v)
                            + "，说明当前 Java 比该版本要求的更旧。到「实例 → 版本设置」把 Java 换成本实例需要的版本"
                            + "（一般 1.17+ 需要 Java 17，1.20.5+ 需要 Java 21）。");
        }
        if (joined.contains("UnsatisfiedLinkError") || joined.contains("no lwjgl") || joined.contains("Failed to locate library")) {
            rep.add(ERROR, "原生库（natives）缺失或架构不符",
                    "报错里出现 UnsatisfiedLinkError / lwjgl 加载失败。请确认用的是 64 位 Java，"
                            + "并在「下载」页对同一版本重新执行一次「下载 / 更新」以补齐原生库。");
        }
        if (joined.contains("Missing or unsupported mandatory dependencies")
                || (joined.contains("Mod file") && joined.contains("is missing"))
                || joined.contains("Incompatible mod set")) {
            rep.add(ERROR, "mod 依赖缺失（Forge / NeoForge）",
                    "加载器报告必需的依赖没有满足。到「Mod」页搜索并安装缺失的前置，或用「Mod → 检查冲突」看具体缺哪个。");
        }
        if (joined.contains("Mixin apply failed") || joined.contains("Mixin transformation")
                || joined.contains("failed to apply mixin")) {
            rep.add(ERROR, "Mixin 注入失败（mod 与游戏版本不匹配）",
                    "mod 的 Mixin 无法注入到当前版本，通常是把 mod 装到了不兼容的 Minecraft 版本上。"
                            + "换成与实例 MC 版本一致的 mod 版本。");
        }
        if (joined.contains("Duplicate mods") || joined.contains("DuplicateModsFoundException")) {
            rep.add(ERROR, "同一个 mod 装了多份",
                    "加载器检测到重复 mod。到「实例 → 模组」，同一 mod 只保留一个 jar。");
        }
        if (joined.contains("java.lang.NoSuchMethodError") || joined.contains("java.lang.NoClassDefFoundError")) {
            rep.add(ERROR, "类 / 方法缺失（依赖版本不匹配）",
                    "出现 NoSuchMethodError 或 NoClassDefFoundError，一般是前置库版本与 mod 要求不一致。"
                            + "把前置（如 Fabric API / 加载器本身）更新到匹配版本。");
        }
        if (joined.contains("GLFW error") || joined.contains("Pixel format not accelerated")
                || joined.contains("Failed to create window") || joined.contains("OpenGL")) {
            rep.add(WARN, "图形（OpenGL / GLFW）问题",
                    "出现 GLFW / OpenGL 相关报错，通常是显卡驱动过旧或核显不支持所需版本。"
                            + "更新显卡驱动，或为该实例追加 JVM 参数 -Dorg.lwjgl.util.Debug=true 复现细节。");
        }
        if (joined.contains("Exception in thread \"main\"") || joined.contains("The game crashed whilst")) {
            String reason = matchFirst(joined, "The game crashed whilst ([^\\n]{0,80})");
            rep.add(ERROR, "游戏启动即崩溃",
                    "主线程抛出异常导致退出" + (reason == null ? "" : "：" + reason.trim())
                            + "。请看上面列出的具体特征，或用「模组」页的冲突检查。");
        }
        if (rep.hsErrFile != null) {
            String sig = matchFirst(readHead(rep.hsErrFile, 40), "SIGSEGV[^\\n]{0,60}", "EXCEPTION_ACCESS_VIOLATION");
            rep.add(ERROR, "JVM 自身崩溃（生成 hs_err_pid 日志）",
                    "Java 虚拟机整体崩溃" + (sig == null ? "" : "（" + sig.trim() + "）")
                            + "，最常见原因是显卡驱动或某个原生加速库（如光影 / 优化 mod）与 JVM 冲突。"
                            + "日志文件：" + rep.hsErrFile.getAbsolutePath());
        }
        if (joined.contains("Failed to download") || joined.contains("Unable to access")) {
            rep.add(WARN, "网络 / 资源访问失败",
                    "日志里出现下载或访问失败，多为网络波动。重新启动一次或检查代理设置。");
        }
        if (joined.contains("java.lang.NoSuchFieldError")) {
            rep.add(WARN, "字段不存在（mod 与前置版本不符）",
                    "出现 NoSuchFieldError，通常是把 mod 装到了与其编译时不一致的加载器版本上。");
        }

        // 统计已加载 mod 数量，作为背景信息
        String modCount = matchFirst(joined, "Loading (\\d+) mods");
        if (modCount != null) rep.add(INFO, "本次加载了 " + modCount + " 个 mod", "来自日志的加载器统计。");
        return rep;
    }

    // ============================================================
    // 实例导出 / 导入
    // ============================================================

    /**
     * 导出实例：版本目录（versions/&lt;id&gt;）+ 游戏目录内容（按 manifest 记录的隔离方式）。
     * 刻意不打包 libraries / assets：它们是所有实例共享的公共资源，体积巨大且可重新下载。
     *
     * 压缩包结构：instance.json（清单）+ versions/&lt;id&gt;/… + game/…
     */
    public static void exportInstance(Settings st, ModScan.Instance inst, File destZip, Consumer<String> log)
            throws IOException {
        File versionDir = new File(new File(st.baseDir(), "versions"), inst.id);
        File gameDir = inst.gameDir;

        StringBuilder sb = new StringBuilder("{\n");
        sb.append("  \"id\": \"").append(esc(inst.id)).append("\",\n");
        sb.append("  \"mcVersion\": \"").append(esc(inst.mcVersion)).append("\",\n");
        sb.append("  \"loader\": \"").append(esc(inst.loader)).append("\",\n");
        sb.append("  \"isolation\": ").append(st.instanceIsolation).append(",\n");
        sb.append("  \"hasGame\": ").append(gameDir.isDirectory()).append("\n}\n");

        File parent = destZip.getParentFile();
        if (parent != null) Files.createDirectories(parent.toPath());
        int n = 0;
        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(destZip)))) {
            zip.putNextEntry(new ZipEntry("instance.json"));
            zip.write(sb.toString().getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();

            if (versionDir.isDirectory()) n += zipDirectory(zip, versionDir, "versions/" + inst.id);
            for (String sub : GAME_SUBDIRS) {
                File f = new File(gameDir, sub);
                if (!f.exists()) continue;
                if (f.isDirectory()) n += zipDirectory(zip, f, "game/" + sub);
                else n += zipFile(zip, f, "game/" + sub);
            }
        }
        if (log != null) log.accept("已导出实例 " + inst.id + " → " + destZip.getAbsolutePath() + "（" + n + " 个文件）");
    }

    /** 需要随实例一起迁移的游戏目录内容（存档 / 配置 / mod / 资源包 / 截图）。 */
    private static final String[] GAME_SUBDIRS = {
            "mods", "config", "saves", "resourcepacks", "shaderpacks", "screenshots",
            "options.txt", "servers.dat", "defaultconfigs", "local", "logs"
    };

    /**
     * 导入实例：读取清单，把 versions/&lt;id&gt; 落到安装目录的 versions 下，
     * 把 game/… 内容落到「实例隔离开启时为 instances/&lt;id&gt;，否则为安装目录」。
     *
     * @return 导入后的版本 id
     */
    public static String importInstance(File zipFile, Settings st, Consumer<String> log) throws IOException {
        String id = null;
        try (ZipInputStream zip = new ZipInputStream(new FileInputStream(zipFile))) {
            java.util.zip.ZipEntry e;
            while ((e = zip.getNextEntry()) != null) {
                if ("instance.json".equals(e.getName())) {
                    String text = new String(zip.readAllBytes(), StandardCharsets.UTF_8);
                    id = Json.str(Json.parse(text), "id");
                    break;
                }
            }
        }
        if (id == null) throw new IOException("不是本启动器导出的实例包（缺少 instance.json）");

        File base = st.baseDir();
        File versionTarget = new File(new File(base, "versions"), id);
        File gameTarget = st.instanceIsolation ? new File(new File(base, "instances"), id) : base;
        Files.createDirectories(versionTarget.toPath());

        int count = 0;
        try (ZipInputStream zip = new ZipInputStream(new FileInputStream(zipFile))) {
            java.util.zip.ZipEntry e;
            while ((e = zip.getNextEntry()) != null) {
                String name = e.getName().replace('\\', '/');
                if ("instance.json".equals(name) || e.isDirectory()) continue;
                File dest;
                if (name.startsWith("versions/" + id + "/")) {
                    dest = new File(base, name);
                } else if (name.startsWith("game/")) {
                    dest = new File(gameTarget, name.substring("game/".length()));
                } else {
                    continue;
                }
                File p = dest.getParentFile();
                if (p != null) Files.createDirectories(p.toPath());
                Files.copy(zip, dest.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                count++;
            }
        }
        if (log != null) log.accept("已导入实例 " + id + " → versions/" + id
                + "（游戏目录内容写入 " + gameTarget.getAbsolutePath() + "，共 " + count + " 个文件）");
        return id;
    }

    // ============================================================
    // 资源包选项（options.txt）
    // ============================================================

    private static Set<String> enabledResourcePacks(File gameDir) {
        return new LinkedHashSet<>(readOptionsList(gameDir, "resourcePacks"));
    }

    private static Set<String> enabledShaders(File gameDir) {
        Set<String> set = new LinkedHashSet<>();
        String v = readOptionLine(gameDir, "shaderPack");
        if (v != null && !v.isBlank()) set.add(v.trim());
        return set;
    }

    /** 读 options.txt 里形如 key:["a","b"] 的列表值。 */
    static List<String> readOptionsList(File gameDir, String key) {
        String line = readOptionLine(gameDir, key);
        List<String> out = new ArrayList<>();
        if (line == null) return out;
        int open = line.indexOf('[');
        int close = line.lastIndexOf(']');
        if (open < 0 || close <= open) return out;
        String body = line.substring(open + 1, close);
        for (String part : body.split(",")) {
            String s = part.trim();
            if (s.length() >= 2 && s.startsWith("\"") && s.endsWith("\"")) s = s.substring(1, s.length() - 1);
            if (!s.isEmpty()) out.add(s);
        }
        return out;
    }

    static void writeOptionsList(File gameDir, String key, List<String> values) throws IOException {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < values.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append('"').append(values.get(i).replace("\"", "\\\"")).append('"');
        }
        sb.append(']');
        writeOptionLine(gameDir, key, sb.toString());
    }

    /** 读 options.txt 里某一行 key:value 的值（不含 key:）。 */
    static String readOptionLine(File gameDir, String key) {
        File f = new File(gameDir, "options.txt");
        if (!f.isFile()) return null;
        try {
            for (String line : Files.readAllLines(f.toPath(), StandardCharsets.UTF_8)) {
                String t = line.trim();
                if (t.startsWith(key + ":")) return t.substring(key.length() + 1);
            }
        } catch (IOException ignore) {
            // 读不到当作未设置
        }
        return null;
    }

    /** 写入 / 更新 options.txt 的一行 key:value（不存在则追加）。 */
    static void writeOptionLine(File gameDir, String key, String value) throws IOException {
        File f = new File(gameDir, "options.txt");
        List<String> lines = f.isFile()
                ? new ArrayList<>(Files.readAllLines(f.toPath(), StandardCharsets.UTF_8))
                : new ArrayList<>();
        String want = key + ":" + value;
        boolean replaced = false;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).trim().startsWith(key + ":")) {
                lines.set(i, want);
                replaced = true;
                break;
            }
        }
        if (!replaced) lines.add(want);
        Files.write(f.toPath(), lines, StandardCharsets.UTF_8);
    }

    // ============================================================
    // level.dat（NBT）读取世界名
    // ============================================================

    /** 从 level.dat 里读出 LevelName；解析失败返回 null（用目录名兜底）。 */
    static String readLevelName(File levelDat) {
        try (DataInputStream in = new DataInputStream(
                new GZIPInputStream(new BufferedInputStream(new FileInputStream(levelDat))))) {
            int type = in.readByte() & 0xFF;
            if (type != 10) return null;
            in.readUTF();                       // 根 compound 名称
            return scanCompound(in);
        } catch (Exception e) {
            return null;
        }
    }

    private static String scanCompound(DataInputStream in) throws IOException {
        while (true) {
            int type = in.readByte() & 0xFF;
            if (type == 0) return null;
            String name = in.readUTF();
            if (type == 8) {
                String v = in.readUTF();
                if ("LevelName".equals(name)) return v;
                continue;
            }
            String r = skipOrScan(in, type);
            if (r != null) return r;
        }
    }

    private static String skipOrScan(DataInputStream in, int type) throws IOException {
        switch (type) {
            case 1: in.readByte(); break;
            case 2: in.readShort(); break;
            case 3: in.readInt(); break;
            case 4: in.readLong(); break;
            case 5: in.readFloat(); break;
            case 6: in.readDouble(); break;
            case 7: skipFully(in, in.readInt()); break;
            case 9: {
                int elem = in.readByte() & 0xFF;
                int len = in.readInt();
                for (int i = 0; i < len; i++) {
                    String r = skipOrScan(in, elem);
                    if (r != null) return r;
                }
                break;
            }
            case 10: return scanCompound(in);
            case 11: skipFully(in, 4L * in.readInt()); break;
            case 12: skipFully(in, 8L * in.readInt()); break;
            default: break;
        }
        return null;
    }

    // ============================================================
    // 通用文件工具
    // ============================================================

    private static int zipDirectory(ZipOutputStream zip, File dir, String prefix) throws IOException {
        File[] kids = dir.listFiles();
        if (kids == null) return 0;
        Arrays.sort(kids, Comparator.comparing(File::getName));
        int n = 0;
        for (File f : kids) {
            if (f.isDirectory()) n += zipDirectory(zip, f, prefix + "/" + f.getName());
            else n += zipFile(zip, f, prefix + "/" + f.getName());
        }
        return n;
    }

    private static int zipFile(ZipOutputStream zip, File f, String entryName) throws IOException {
        zip.putNextEntry(new ZipEntry(entryName));
        try (InputStream in = new BufferedInputStream(new FileInputStream(f))) {
            in.transferTo(zip);
        }
        zip.closeEntry();
        return 1;
    }

    /** 递归统计目录大小（字节）。 */
    public static long folderSize(File dir) {
        if (dir == null || !dir.isDirectory()) return 0;
        long total = 0;
        File[] kids = dir.listFiles();
        if (kids == null) return 0;
        for (File f : kids) total += f.isDirectory() ? folderSize(f) : f.length();
        return total;
    }

    /** 递归删除（含只读文件）。 */
    public static void deleteRecursively(File f) throws IOException {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursively(k);
        }
        Files.deleteIfExists(f.toPath());
    }

    private static File newest(File dir) {
        File[] kids = dir.isDirectory() ? dir.listFiles(File::isFile) : null;
        if (kids == null || kids.length == 0) return null;
        Arrays.sort(kids, Comparator.comparingLong(File::lastModified).reversed());
        return kids[0];
    }

    private static String readHead(File f, int maxLines) {
        try {
            List<String> lines = Files.readAllLines(f.toPath(), StandardCharsets.UTF_8);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.min(maxLines, lines.size()); i++) sb.append(lines.get(i)).append('\n');
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private static String readPackDescription(File pack, boolean isDir) {
        try {
            String text;
            if (isDir) {
                File meta = new File(pack, "pack.mcmeta");
                if (!meta.isFile()) return "";
                text = Files.readString(meta.toPath(), StandardCharsets.UTF_8);
            } else {
                try (java.util.zip.ZipFile zip = new java.util.zip.ZipFile(pack)) {
                    java.util.zip.ZipEntry e = zip.getEntry("pack.mcmeta");
                    if (e == null) return "";
                    try (InputStream in = zip.getInputStream(e)) {
                        text = new String(in.readAllBytes(), StandardCharsets.UTF_8);
                    }
                }
            }
            // pack.mcmeta 的描述可能是字符串，也可能是 {"text":"..."}；用正则取第一段可读文本
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("\"description\"\\s*:\\s*(?:\"([^\"]*)\"|\\{[^}]*\"text\"\\s*:\\s*\"([^\"]*)\")")
                    .matcher(text);
            if (m.find()) return m.group(1) != null ? m.group(1) : m.group(2);
        } catch (Exception ignore) {
            // 描述读不出来不影响其余功能
        }
        return "";
    }

    private static String commonTopDir(List<String> entries) {
        String root = null;
        for (String n : entries) {
            String s = n.replace('\\', '/');
            int slash = s.indexOf('/');
            if (slash <= 0) return null;
            String top = s.substring(0, slash);
            if (root == null) root = top;
            else if (!root.equals(top)) return null;
        }
        return root;
    }

    private static File uniqueDir(File parent, String base) {
        File f = new File(parent, base);
        int i = 1;
        while (f.exists()) f = new File(parent, base + "-" + (i++));
        return f;
    }

    private static String stripExt(String name) {
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private static void skipFully(DataInputStream in, long n) throws IOException {
        long left = n;
        while (left > 0) {
            long skipped = in.skip(left);
            if (skipped <= 0) {
                if (in.read() < 0) return;
                left--;
            } else {
                left -= skipped;
            }
        }
    }

    private static String matchFirst(String text, String... regexes) {
        for (String r : regexes) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile(r).matcher(text);
            if (m.find()) return m.group(m.groupCount() >= 1 ? 1 : 0);
        }
        return null;
    }

    private static String linked(String text, String anchor, String target) {
        int i = text.indexOf(anchor);
        if (i < 0) return null;
        String window = text.substring(i, Math.min(text.length(), i + 400));
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(target).matcher(window);
        return m.find() ? m.group(1) : null;
    }

    private static String human(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return (bytes / 1024) + " KB";
        if (bytes < 1024L * 1024 * 1024) return (bytes / 1024 / 1024) + " MB";
        return String.format("%.2f GB", bytes / 1024.0 / 1024 / 1024);
    }

    static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
