package mc;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 组装 JVM 命令行、派生 natives 目录、启动游戏进程并把子进程输出泵回日志。 */
public final class GameProcess {

    public static final String LAUNCHER_NAME = "mc-launcher";
    public static final String LAUNCHER_VERSION = "1.0";

    private static final boolean WINDOWS = System.getProperty("os.name", "").toLowerCase().contains("win");

    /** 一次启动所需的全部参数（由 {@link Settings} 与当前安装状态组装）。 */
    public static final class Options {
        /** 安装目录：natives / assets / classpath 的基准（实例隔离时仍指向共享安装目录）。 */
        public File installDir;
        /** 传入 --gameDir 的游戏目录（实例隔离时为每个版本独立目录）。 */
        public File gameDir;
        public File clientJar;
        public List<File> classpath;
        public File nativesDir;
        public String username = "Player";
        public int maxMemoryGb = 4;

        public boolean customResolution;
        public int width = 854;
        public int height = 480;

        /** default / ipv4 / ipv6 */
        public String ipPreference = "default";

        public String launcherName = LAUNCHER_NAME;
        public String launcherVersion = LAUNCHER_VERSION;

        /** 账号凭据：离线模式保持默认值，正版登录时由 {@link MsAuth.Account} 覆盖。 */
        public String authUuid;
        public String authAccessToken = "0";
        public String authXuid = "0";
        public String userType = "legacy";

        /** 实例设置里追加的 JVM 参数（放在主类之前），以及追加的游戏参数（放在命令行最后）。 */
        public List<String> extraJvmArgs = new ArrayList<>();
        public List<String> extraGameArgs = new ArrayList<>();
    }

    /** ${natives_directory}/xxx 形式的子目录引用（26.3 会派生出 java/jna/lwjgl/netty）。 */
    private static final Pattern NATIVES_SUBDIR = Pattern.compile("\\$\\{natives_directory\\}/([A-Za-z0-9_.\\-]+)");
    private static final Pattern ANY_PLACEHOLDER = Pattern.compile("\\$\\{[A-Za-z0-9_]+\\}");

    private GameProcess() {}

    /** 从 jvm 参数派生 ${natives_directory} 下的子目录集合（含固定兜底项）。 */
    public static Set<String> deriveNativesSubdirs(VersionMeta meta) {
        Set<String> dirs = new LinkedHashSet<>();
        dirs.add("java");
        dirs.add("jna");
        dirs.add("lwjgl");
        dirs.add("netty");
        collectSubdirs(meta.effectiveJvmArgs(), dirs);
        collectSubdirs(meta.effectiveGameArgs(), dirs);
        return dirs;
    }

    /**
     * 原生库应解压到 ${natives_directory} 下的哪个子目录。
     * 现代版本的 jvm 参数把不同来源的原生库分开索引：
     * java.library.path→java、SharedLibraryExtractPath→lwjgl、jna.tmpdir→jna、netty workdir→netty。
     */
    public static String nativesSubdirFor(String libName) {
        String group = libName == null ? "" : libName;
        int c = group.indexOf(':');
        if (c > 0) group = group.substring(0, c);
        group = group.toLowerCase();
        if (group.startsWith("org.lwjgl")) return "lwjgl";
        if (group.contains("netty")) return "netty";
        if (group.contains("jna")) return "jna";
        return "java";
    }

    /** 组装完整命令行（java + 内存参数 + jvm 参数 + 主类 + 游戏参数，占位符已替换）。 */
    public static List<String> buildCommand(JavaRuntime.Java jre, VersionMeta meta, Options opt) {
        List<String> cmd = new ArrayList<>();
        cmd.add(jre != null && jre.exe != null ? jre.exe.getAbsolutePath() : "java");
        cmd.add("-Xms512M");
        cmd.add("-Xmx" + Math.max(1, opt.maxMemoryGb) + "G");

        // IP 协议偏好：直接控制 JVM 的地址族选择，对连接服务器有实际影响
        if ("ipv4".equals(opt.ipPreference)) {
            cmd.add("-Djava.net.preferIPv4Stack=true");
            cmd.add("-Djava.net.preferIPv6Addresses=false");
        } else if ("ipv6".equals(opt.ipPreference)) {
            cmd.add("-Djava.net.preferIPv6Addresses=true");
        }

        // 版本 JSON 的规则里包含 features（如 has_custom_resolution），必须显式传入才能启用 --width/--height
        Map<String, Boolean> features = new HashMap<>();
        features.put("is_demo_user", false);
        features.put("has_custom_resolution", opt.customResolution);
        features.put("has_quick_plays_support", false);
        features.put("is_quick_play_singleplayer", false);
        features.put("is_quick_play_multiplayer", false);
        features.put("is_quick_play_realms", false);

        expand(meta.effectiveJvmArgs(), cmd, features);
        if (opt.extraJvmArgs != null) cmd.addAll(opt.extraJvmArgs);

        // 日志配置参数来自版本 JSON 的 logging.client.argument（内部 ${path} 由启动器自己替换）
        if (meta.logArgument != null && meta.logPath != null) {
            File logFile = new File(opt.installDir, "assets/" + meta.logPath);
            cmd.add(meta.logArgument.replace("${path}", logFile.getAbsolutePath()));
        }

        if (meta.mainClass != null) cmd.add(meta.mainClass);
        expand(meta.effectiveGameArgs(), cmd, features);
        if (opt.extraGameArgs != null) cmd.addAll(opt.extraGameArgs);

        Map<String, String> placeholders = new HashMap<>();
        placeholders.put("natives_directory", opt.nativesDir.getAbsolutePath());
        placeholders.put("classpath", joinClasspath(opt.clientJar, opt.classpath));
        placeholders.put("launcher_name", opt.launcherName);
        placeholders.put("launcher_version", opt.launcherVersion);
        placeholders.put("auth_player_name", opt.username);
        placeholders.put("version_name", meta.id == null ? "" : meta.id);
        placeholders.put("game_directory", opt.gameDir.getAbsolutePath());
        placeholders.put("assets_root", new File(opt.installDir, "assets").getAbsolutePath());
        placeholders.put("assets_index_name", meta.indexId != null ? meta.indexId : (meta.assets == null ? "" : meta.assets));
        // Forge 1.13+ / NeoForge 的 jvm 参数使用这两个占位符构造模块路径（-p）与 legacyClassPath，
        // 不提供的话会被清空成 "/xxx.jar" 导致 BootstrapLauncher 找不到模块、直接启动失败
        placeholders.put("library_directory", new File(opt.installDir, "libraries").getAbsolutePath());
        placeholders.put("classpath_separator", File.pathSeparator);
        placeholders.put("auth_uuid", opt.authUuid != null && !opt.authUuid.isEmpty()
                ? opt.authUuid : offlineUuid(opt.username));
        placeholders.put("auth_access_token", opt.authAccessToken);
        placeholders.put("auth_xuid", opt.authXuid);
        placeholders.put("clientid", "");
        placeholders.put("user_type", opt.userType);
        // 旧式版本的 minecraftArguments 会带 --userProperties ${user_properties}，官方启动器传空对象
        placeholders.put("user_properties", "{}");
        placeholders.put("version_type", meta.type == null ? "release" : meta.type);
        placeholders.put("resolution_width", String.valueOf(opt.width));
        placeholders.put("resolution_height", String.valueOf(opt.height));
        placeholders.put("quickPlayPath", "");
        placeholders.put("quickPlaySingleplayer", "");
        placeholders.put("quickPlayMultiplayer", "");
        placeholders.put("quickPlayRealms", "");

        for (int i = 0; i < cmd.size(); i++) {
            String s = cmd.get(i);
            for (Map.Entry<String, String> e : placeholders.entrySet()) {
                s = s.replace("${" + e.getKey() + "}", e.getValue());
            }
            s = ANY_PLACEHOLDER.matcher(s).replaceAll("");   // 兜底：清掉未识别的占位符
            cmd.set(i, s);
        }
        return cmd;
    }

    /** 离线模式的玩家 UUID（与官方启动器一致：OfflinePlayer:<name> 的 v3 UUID，去掉横线）。 */
    public static String offlineUuid(String name) {
        try {
            return UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8))
                    .toString().replace("-", "");
        } catch (Exception e) {
            return "00000000000000000000000000000000";
        }
    }

    /**
     * 游戏输出行的回调，在输出线程（"mc-output"）里被逐行调用。
     * 用于耗时统计等需要"看到游戏真实输出"的场景，比解析带前缀的日志文本可靠。
     */
    public interface LineListener {
        void onGameLine(String line);
    }

    /**
     * 启动游戏并异步泵输出。
     *
     * @param onExit 进程退出后回调（在输出线程里执行，调用方需自行切回 EDT）
     */
    public static Process start(List<String> cmd, File gameDir, Consumer<String> log, IntConsumer onExit) throws IOException {
        return start(cmd, gameDir, log, onExit, null);
    }

    /**
     * 启动游戏并异步泵输出，同时把每一条游戏输出行转给 {@code listener}。
     *
     * @param listener 逐行回调（可为 null）；在输出线程里调用，实现需自行保证线程安全
     */
    public static Process start(List<String> cmd, File gameDir, Consumer<String> log, IntConsumer onExit,
                                LineListener listener) throws IOException {
        log.accept("启动命令：" + joinForLog(cmd));
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.directory(gameDir);
        pb.redirectErrorStream(true);
        Process p = pb.start();

        Thread pump = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    log.accept("[游戏] " + line);
                    if (listener != null) listener.onGameLine(line);
                }
            } catch (IOException e) {
                log.accept("[游戏] 输出读取中断：" + e.getMessage());
            }
            try {
                int code = p.waitFor();
                log.accept("游戏进程已退出，退出码 " + code);
                if (onExit != null) onExit.accept(code);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "mc-output");
        pump.setDaemon(true);
        pump.start();
        return p;
    }

    // ===== 进程优先级 =====

    /**
     * 调整游戏进程优先级（仅 Windows 生效，通过 PowerShell 设置 PriorityClass）。
     * 在后台线程执行，失败只写日志，不影响游戏本身。
     */
    public static void applyPriority(long pid, String level, Consumer<String> log) {
        if (!WINDOWS) {
            log.accept("进程优先级：当前系统不支持，已跳过");
            return;
        }
        String cls = switch (level == null ? "normal" : level) {
            case "below" -> "BelowNormal";
            case "above" -> "AboveNormal";
            case "high" -> "High";
            case "realtime" -> "RealTime";
            default -> "Normal";
        };
        if ("Normal".equals(cls)) return;   // 默认优先级无需调整

        Thread t = new Thread(() -> {
            try {
                Process p = new ProcessBuilder("powershell", "-NoProfile", "-Command",
                        "(Get-Process -Id " + pid + ").PriorityClass = '" + cls + "'")
                        .redirectErrorStream(true)
                        .start();
                String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
                boolean finished = p.waitFor(20, TimeUnit.SECONDS);
                if (finished && p.exitValue() == 0) {
                    log.accept("已将游戏进程优先级设为 " + cls);
                } else {
                    log.accept("设置进程优先级失败：" + (out.isEmpty() ? "PowerShell 未正常退出" : out));
                }
            } catch (Exception e) {
                log.accept("设置进程优先级失败：" + e.getMessage());
            }
        }, "set-priority");
        t.setDaemon(true);
        t.start();
    }

    // ===== 内部工具 =====

    private static void expand(List<Object> args, List<String> out, Map<String, Boolean> features) {
        if (args == null) return;
        for (Object o : args) {
            if (o == null) continue;
            if (o instanceof String s) {
                out.add(s);
                continue;
            }
            List<Object> arr = Json.asList(o);
            if (arr != null) {
                for (Object v : arr) out.add(String.valueOf(v));
                continue;
            }
            Map<String, Object> rule = Json.asMap(o);
            if (rule != null && Rules.allowed(Json.asList(rule.get("rules")), features)) {
                Object value = rule.get("value");
                List<Object> values = Json.asList(value);
                if (values != null) {
                    for (Object v : values) out.add(String.valueOf(v));
                } else if (value != null) {
                    out.add(String.valueOf(value));
                }
            }
        }
    }

    private static String joinClasspath(File clientJar, List<File> classpath) {
        List<File> all = new ArrayList<>();
        if (clientJar != null) all.add(clientJar);
        if (classpath != null) all.addAll(classpath);
        StringBuilder sb = new StringBuilder();
        for (File f : all) {
            if (sb.length() > 0) sb.append(File.pathSeparator);
            sb.append(f.getAbsolutePath());
        }
        return sb.toString();
    }

    private static String joinForLog(List<String> cmd) {
        StringBuilder sb = new StringBuilder();
        for (String s : cmd) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(s.indexOf(' ') >= 0 ? "\"" + s + "\"" : s);
        }
        return sb.toString();
    }

    private static void collectSubdirs(List<Object> args, Set<String> dirs) {
        if (args == null) return;
        for (Object o : args) collect(o, dirs);
    }

    private static void collect(Object o, Set<String> dirs) {
        if (o instanceof String s) {
            Matcher m = NATIVES_SUBDIR.matcher(s);
            while (m.find()) dirs.add(m.group(1));
        } else if (o instanceof List<?> list) {
            for (Object e : list) collect(e, dirs);
        } else if (o instanceof Map<?, ?> map) {
            for (Object e : map.values()) collect(e, dirs);
        }
    }
}
