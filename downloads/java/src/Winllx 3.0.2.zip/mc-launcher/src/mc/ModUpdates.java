package mc;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * Mod 更新检查：把本地 jar 的 sha1 发给 Modrinth 反查所属项目与已装版本，
 * 再按实例的加载器 / Minecraft 版本查询该项目的最新可用版本并比对。
 *
 * 之所以用「文件哈希反查」而不是「按文件名猜」：
 * 文件名可能被用户改过、也可能不带版本号；哈希是唯一可靠的身份标识。
 * Modrinth 未收录的 mod（例如自编译、CurseForge 独占）会如实报告"未收录、无法检查"，
 * 而不是假装"已是最新"。
 */
public final class ModUpdates {

    private ModUpdates() {}

    /** 检查一个 mod jar 需要的信息。 */
    public static final class Check {
        public ModScan.Mod mod;
        /** 状态：UPDATE / LATEST / UNKNOWN / ERROR。 */
        public String status = "UNKNOWN";
        /** 本地已装版本号（优先用 Modrinth 反查到的，其次 jar 内元数据）。 */
        public String installedVersion = "";
        /** 线上最新匹配版本号。 */
        public String latestVersion = "";
        /** 线上最新文件名、下载地址与校验信息。 */
        public String latestFilename = "";
        public String downloadUrl = "";
        public long size;
        public String sha1;
        public String projectId = "";
        public String projectTitle = "";
        public String note = "";
        /** 线上最新版本要求的加载器 / MC 版本（仅用于展示）。 */
        public final List<String> latestLoaders = new ArrayList<>();
        public final List<String> latestGameVersions = new ArrayList<>();

        public Mods.ModVersion latest;

        public String fileName() {
            return mod == null || mod.file == null ? "" : mod.file.getName();
        }

        public boolean updatable() {
            return "UPDATE".equals(status) && downloadUrl != null && !downloadUrl.isBlank();
        }

        public String statusLabel() {
            return switch (status) {
                case "UPDATE" -> "可更新";
                case "LATEST" -> "已是最新";
                case "UNKNOWN" -> "无法检查";
                default -> "出错";
            };
        }

        /** 一行摘要，用于日志与列表。 */
        public String display() {
            StringBuilder sb = new StringBuilder();
            sb.append(fileName()).append("　").append(statusLabel());
            if ("UPDATE".equals(status)) {
                sb.append("：").append(installedVersion.isEmpty() ? "?" : installedVersion)
                  .append(" → ").append(latestVersion);
            } else if ("LATEST".equals(status)) {
                sb.append("（").append(installedVersion).append("）");
            }
            if (note != null && !note.isBlank()) sb.append("　— ").append(note);
            return sb.toString();
        }

        @Override
        public String toString() {
            return display();
        }
    }

    /** 一次检查的汇总结果。 */
    public static final class Report {
        public final String instanceId;
        public final String loader;
        public final String mcVersion;
        public final List<Check> checks = new ArrayList<>();

        Report(String instanceId, String loader, String mcVersion) {
            this.instanceId = instanceId;
            this.loader = loader;
            this.mcVersion = mcVersion;
        }

        public List<Check> updatable() {
            List<Check> out = new ArrayList<>();
            for (Check c : checks) if (c.updatable()) out.add(c);
            return out;
        }

        public int unknownCount() {
            int n = 0;
            for (Check c : checks) if ("UNKNOWN".equals(c.status) || "ERROR".equals(c.status)) n++;
            return n;
        }

        /** 给弹窗显示的文本报告。 */
        public String format() {
            StringBuilder sb = new StringBuilder();
            sb.append("实例 ").append(instanceId)
              .append("（").append(ModScan.loaderLabel(loader)).append(" · MC ").append(mcVersion).append("）\n");
            sb.append("检查 ").append(checks.size()).append(" 个本地 mod，其中 ")
              .append(updatable().size()).append(" 个可更新，").append(unknownCount()).append(" 个无法检查。\n\n");
            if (checks.isEmpty()) {
                sb.append("mods 目录里没有 .jar 文件。\n");
                return sb.toString();
            }
            sb.append("──────── 可更新 ────────\n");
            List<Check> up = updatable();
            if (up.isEmpty()) {
                sb.append("（没有发现可用的新版本）\n");
            } else {
                for (Check c : up) {
                    sb.append("· ").append(c.fileName()).append("\n");
                    sb.append("    ").append(c.installedVersion.isEmpty() ? "?" : c.installedVersion)
                      .append(" → ").append(c.latestVersion);
                    if (!c.projectTitle.isBlank()) sb.append("　（").append(c.projectTitle).append("）");
                    sb.append("\n    新文件：").append(c.latestFilename).append("\n");
                }
            }
            sb.append("\n──────── 已是最新 ────────\n");
            int latest = 0;
            for (Check c : checks) {
                if (!"LATEST".equals(c.status)) continue;
                if (latest++ == 0) sb.append("");
                sb.append("· ").append(c.fileName()).append("（").append(c.installedVersion).append("）\n");
            }
            if (latest == 0) sb.append("（无）\n");

            List<Check> unknown = new ArrayList<>();
            for (Check c : checks) if ("UNKNOWN".equals(c.status) || "ERROR".equals(c.status)) unknown.add(c);
            if (!unknown.isEmpty()) {
                sb.append("\n──────── 无法检查 ────────\n");
                for (Check c : unknown) {
                    sb.append("· ").append(c.fileName()).append("　").append(c.note).append("\n");
                }
            }
            return sb.toString();
        }
    }

    // ===== 检查 =====

    /**
     * 检查一个实例里的所有 mod（含已停用的 {@code .jar.disabled}，便于用户顺带更新后再启用）。
     * 但若同一项目已有启用状态的 jar，对应的停用旧文件会被跳过（通常是我们更新时留下的备份）。
     *
     * @param log 进度日志（可为 null）
     */
    public static Report checkInstance(ModScan.Instance inst, Consumer<String> log) throws IOException {
        Report rep = new Report(inst.id, inst.loader, inst.mcVersion);
        List<ModScan.Mod> mods = ModScan.scan(inst.modsDir);
        // 停用的 mod 不在 scan 结果里（游戏不加载它们，冲突分析也不该看），但更新检查应该覆盖
        Map<String, ModScan.Mod> byPath = new LinkedHashMap<>();
        for (ModScan.Mod m : mods) byPath.put(m.file.getAbsolutePath(), m);
        File[] kids = inst.modsDir.listFiles();
        if (kids != null) {
            for (File f : kids) {
                String lower = f.getName().toLowerCase();
                if (!lower.endsWith(".jar.disabled")) continue;
                if (byPath.containsKey(f.getAbsolutePath())) continue;
                ModScan.Mod m = new ModScan.Mod();
                m.file = f;
                m.error = "已停用";
                byPath.put(f.getAbsolutePath(), m);
            }
        }

        if (byPath.isEmpty()) {
            if (log != null) log.accept("实例 " + inst.id + " 的 mods 目录里没有可检查的文件");
            return rep;
        }

        // ---- 1. 算哈希并反查 ----
        Map<String, ModScan.Mod> byHash = new LinkedHashMap<>();
        for (ModScan.Mod m : byPath.values()) {
            try {
                byHash.put(Net.sha1(m.file).toLowerCase(), m);
            } catch (IOException e) {
                Check c = new Check();
                c.mod = m;
                c.status = "ERROR";
                c.note = "读取文件失败：" + e.getMessage();
                rep.checks.add(c);
            }
        }
        if (log != null) log.accept("已计算 " + byHash.size() + " 个 mod 的 sha1，向 Modrinth 反查所属项目…");

        Map<String, Mods.ModVersion> known;
        try {
            known = Mods.versionsByHash(new ArrayList<>(byHash.keySet()));
        } catch (IOException e) {
            throw new IOException("查询 Modrinth 失败：" + e.getMessage(), e);
        }

        // ---- 2. 对每个已知项目查最新匹配版本 ----
        List<Check> pending = new ArrayList<>();
        for (Map.Entry<String, ModScan.Mod> e : byHash.entrySet()) {
            ModScan.Mod m = e.getValue();
            Mods.ModVersion have = known.get(e.getKey());
            Check c = new Check();
            c.mod = m;
            c.installedVersion = m.version == null ? "" : m.version;
            if (have == null) {
                c.status = "UNKNOWN";
                c.note = "Modrinth 未收录该文件（可能是自编译、CurseForge 独占或改过内容），无法比对更新";
                rep.checks.add(c);
                continue;
            }
            c.projectId = have.projectId;
            if (have.versionNumber != null && !have.versionNumber.isBlank()) c.installedVersion = have.versionNumber;
            pending.add(c);
        }

        // 同一项目可能有多个本地 jar（重复安装），按项目去重后再查，省一半请求
        Map<String, Mods.ModVersion> latestByProject = new HashMap<>();
        List<String> projectIds = new ArrayList<>();
        for (Check c : pending) {
            if (c.projectId == null || c.projectId.isBlank()) continue;
            if (latestByProject.containsKey(c.projectId)) continue;
            latestByProject.put(c.projectId, null);
            projectIds.add(c.projectId);
        }
        if (!projectIds.isEmpty() && log != null) {
            log.accept("查询 " + projectIds.size() + " 个项目在 " + ModScan.loaderLabel(inst.loader)
                    + " / MC " + inst.mcVersion + " 下的最新版本…");
        }
        fetchLatest(projectIds, inst.loader, inst.mcVersion, latestByProject, log);

        for (Check c : pending) {
            Mods.ModVersion latest = latestByProject.get(c.projectId);
            if (latest == null) {
                c.status = "UNKNOWN";
                c.note = "该项目在 Modrinth 上没有适配 " + ModScan.loaderLabel(inst.loader)
                        + " / MC " + inst.mcVersion + " 的版本";
                rep.checks.add(c);
                continue;
            }
            c.latest = latest;
            c.latestVersion = latest.versionNumber == null ? "" : latest.versionNumber;
            c.latestFilename = latest.filename == null ? "" : latest.filename;
            c.downloadUrl = latest.url;
            c.size = latest.size;
            c.sha1 = latest.sha1;
            c.latestLoaders.addAll(latest.loaders);
            c.latestGameVersions.addAll(latest.gameVersions);

            int cmp = ModScan.compare(c.latestVersion, c.installedVersion);
            if (cmp > 0) {
                c.status = "UPDATE";
            } else if (cmp < 0) {
                // 本地版本比线上"更新"：可能装的是自行编译版或测试版，不该提示降级
                c.status = "LATEST";
                c.note = "本地版本号高于 Modrinth 上的最新匹配版本";
            } else {
                c.status = "LATEST";
            }
            rep.checks.add(c);
        }

        // 后处理：同项目已存在启用状态的 jar 时，被停用的旧文件不再参与更新提示。
        // 我们更新 mod 时会把旧文件留作 .disabled 备份，若不排除，它会在每次检查里一直显示"可更新"，误导用户。
        Map<String, String> enabledByProject = new HashMap<>();
        for (Check c : rep.checks) {
            if (disabledFile(c.mod) || c.projectId == null || c.projectId.isBlank()) continue;
            enabledByProject.putIfAbsent(c.projectId, c.fileName());
        }
        if (!enabledByProject.isEmpty()) {
            List<Check> keep = new ArrayList<>();
            int skipped = 0;
            for (Check c : rep.checks) {
                if (disabledFile(c.mod) && c.projectId != null && enabledByProject.containsKey(c.projectId)) {
                    skipped++;
                    continue;
                }
                keep.add(c);
            }
            if (skipped > 0) {
                rep.checks.clear();
                rep.checks.addAll(keep);
                if (log != null) log.accept("跳过 " + skipped + " 个已被同项目启用版本替代的停用旧文件");
            }
        }

        rep.checks.sort(Comparator.comparing((Check c) -> switch (c.status) {
            case "UPDATE" -> 0;
            case "LATEST" -> 1;
            case "UNKNOWN" -> 2;
            default -> 3;
        }).thenComparing(Check::fileName));

        if (log != null) {
            log.accept("更新检查完成：共有 " + rep.updatable().size() + " 个 mod 可更新，"
                    + rep.unknownCount() + " 个无法检查（共 " + rep.checks.size() + " 个）");
        }
        return rep;
    }

    /** 并行查询每个项目的最新匹配版本，结果写回 {@code out}（值为 null 表示没有匹配版本）。 */
    private static void fetchLatest(List<String> projectIds, String loader, String mcVersion,
                                    Map<String, Mods.ModVersion> out, Consumer<String> log) {
        int threads = Math.max(1, Math.min(6, projectIds.size()));
        ExecutorService pool = Executors.newFixedThreadPool(threads, r -> {
            Thread t = new Thread(r, "mc-update-check");
            t.setDaemon(true);
            return t;
        });
        CountDownLatch latch = new CountDownLatch(projectIds.size());
        AtomicInteger failed = new AtomicInteger();
        try {
            for (String id : projectIds) {
                pool.execute(() -> {
                    try {
                        List<Mods.ModVersion> vs = Mods.versions(id, loader, mcVersion);
                        Mods.ModVersion pick = Mods.pick(vs);
                        if (pick != null) {
                            synchronized (out) {
                                out.put(id, pick);
                            }
                        }
                    } catch (Exception e) {
                        failed.incrementAndGet();
                        if (log != null) log.accept("查询项目 " + id + " 的版本失败：" + e.getMessage());
                    } finally {
                        latch.countDown();
                    }
                });
            }
            latch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            pool.shutdownNow();
        }
        if (failed.get() > 0 && log != null) {
            log.accept(failed.get() + " 个项目的版本查询失败，这些 mod 会被标为「无法检查」");
        }
    }

    // ===== 更新 =====

    /**
     * 把一个 mod 更新到线上最新版。
     *
     * 旧 jar 不会被直接删掉：改名为 {@code <原名>.disabled} 保留（游戏不会加载 .disabled 文件），
     * 这样既能立即生效，用户后悔了也随时能改回来。
     *
     * @return 新 jar 的文件
     */
    public static File apply(Check check, Consumer<String> log) throws IOException {
        if (!check.updatable()) throw new IOException("该 mod 没有可用的新版本");
        File modsDir = check.mod.file.getParentFile();
        File old = check.mod.file;
        String newName = check.latestFilename == null || check.latestFilename.isBlank()
                ? old.getName() : check.latestFilename;
        boolean sameName = old.getName().equalsIgnoreCase(newName);
        boolean oldDisabled = old.getName().toLowerCase().endsWith(".disabled");

        if (sameName && sameContent(old, check.sha1)) {
            // 文件名与内容都与线上最新版一致：本地已经是最新，不做无意义的重复下载
            if (log != null) log.accept(check.fileName() + " 的内容与线上最新版一致，无需重新下载");
            return old;
        } else if (sameName) {
            // 同名不同内容：旧文件必须先让位，否则会被新版本直接覆盖掉
            File keep = new File(modsDir, old.getName() + ".disabled");
            Files.move(old.toPath(), keep.toPath(), StandardCopyOption.REPLACE_EXISTING);
            if (log != null) log.accept("旧版本已保留为 " + keep.getName());
        } else if (!oldDisabled) {
            // 不同名且旧文件当前是启用状态：改名成 .disabled 停用，防止同一个 mod 出现两份而报 ID 冲突
            File keep = new File(modsDir, old.getName() + ".disabled");
            Files.move(old.toPath(), keep.toPath(), StandardCopyOption.REPLACE_EXISTING);
            if (log != null) log.accept("旧版本已停用并保留为 " + keep.getName());
        }
        // 剩下一种情况：不同名且旧文件本来就是 .disabled，保持原样即可（它不会被加载）

        File dest = new File(modsDir, newName);
        long n = Net.download(check.downloadUrl, dest, check.size, check.sha1, true, null, log);
        if (log != null) {
            log.accept("已更新 " + check.fileName() + " → " + newName + "（"
                    + check.installedVersion + " → " + check.latestVersion + "，"
                    + (n / 1024) + " KB）");
        }
        return dest;
    }

    private static boolean disabledFile(ModScan.Mod m) {
        return m != null && m.file != null && m.file.getName().toLowerCase().endsWith(".disabled");
    }

    private static boolean sameContent(File f, String sha1) {
        if (sha1 == null || sha1.isBlank()) return false;
        try {
            return sha1.equalsIgnoreCase(Net.sha1(f));
        } catch (IOException e) {
            return false;
        }
    }
}
