package mc;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Modrinth 公共 API（v2）客户端：搜索 mod、查询版本、下载 jar。
 * Modrinth 无需 API key，是目前唯一能直接使用的 mod 分发源（CurseForge 需要私钥，不适合客户端内置）。
 */
public final class Mods {

    private static final String API = "https://api.modrinth.com/v2";

    private Mods() {}

    /** 搜索结果条目。 */
    public static final class Hit {
        public String projectId;
        public String slug;
        public String title;
        public String description;
        public String author;
        public String iconUrl;
        public long downloads;
        public final List<String> loaders = new ArrayList<>();

        public String display() {
            return (title == null ? slug : title) + "   [" + String.join("/", loaders) + "]";
        }

        @Override
        public String toString() {
            return display() + "   下载 " + downloads;
        }
    }

    /** 同一 mod 不同版本之间的依赖声明。 */
    public static final class Dependency {
        public String projectId;
        public String versionId;
        public String fileName;
        /** required / optional / incompatible / embedded */
        public String type;

        @Override
        public String toString() {
            return type + ":" + (projectId != null ? projectId : fileName);
        }
    }

    /** 某个 mod 的一个具体发布版本。 */
    public static final class ModVersion {
        public String id;
        public String projectId;
        public String name;
        public String versionNumber;
        public String versionType;
        public String datePublished;
        public String url;
        public String filename;
        public String sha1;
        public long size;
        public final List<String> gameVersions = new ArrayList<>();
        public final List<String> loaders = new ArrayList<>();
        public final List<Dependency> dependencies = new ArrayList<>();

        @Override
        public String toString() {
            String n = name != null && !name.isBlank() ? name : versionNumber;
            return n + "   [" + (versionType == null ? "?" : versionType) + " · "
                    + String.join("/", gameVersions) + " · " + String.join("/", loaders) + "]";
        }
    }

    // ===== 搜索 =====

    /**
     * 搜索 mod。
     *
     * @param loader      fabric / forge / neoforge / quilt，null 或 vanilla 表示不按加载器过滤
     * @param gameVersion 按 Minecraft 版本过滤，null 表示不过滤
     */
    public static List<Hit> search(String query, String loader, String gameVersion, int limit) throws IOException {
        StringBuilder facets = new StringBuilder("[[\"project_type:mod\"]");
        // 排掉纯服务端 mod：客户端只能装 client_side 为 required/optional 的
        facets.append(",[\"client_side:required\",\"client_side:optional\"]");
        if (loader != null && !loader.isBlank() && !"vanilla".equals(loader)) {
            facets.append(",[\"categories:").append(loader).append("\"]");
        }
        if (gameVersion != null && !gameVersion.isBlank()) {
            facets.append(",[\"versions:").append(gameVersion).append("\"]");
        }
        facets.append("]");

        String url = API + "/search?limit=" + Math.max(1, Math.min(100, limit))
                + "&query=" + enc(query == null ? "" : query)
                + "&facets=" + enc(facets.toString());
        Object root = Json.parse(Net.getString(url));

        List<Hit> out = new ArrayList<>();
        List<Object> hits = Json.asList(Json.get(root, "hits"));
        if (hits == null) return out;
        for (Object o : hits) {
            Hit h = new Hit();
            h.projectId = Json.str(o, "project_id");
            h.slug = Json.str(o, "slug");
            h.title = Json.str(o, "title");
            h.description = Json.str(o, "description");
            h.author = Json.str(o, "author");
            h.iconUrl = Json.str(o, "icon_url");
            h.downloads = Json.num(o, "downloads", 0);
            for (String c : strList(Json.get(o, "categories"))) h.loaders.add(c);
            if (h.projectId != null) out.add(h);
        }
        return out;
    }

    // ===== 版本 =====

    /** 读取某 mod 的版本列表，可按加载器与游戏版本过滤。 */
    public static List<ModVersion> versions(String projectIdOrSlug, String loader, String gameVersion) throws IOException {
        StringBuilder url = new StringBuilder(API).append("/project/").append(enc(projectIdOrSlug)).append("/version");
        List<String> params = new ArrayList<>();
        if (loader != null && !loader.isBlank() && !"vanilla".equals(loader)) {
            params.add("loaders=" + enc("[\"" + loader + "\"]"));
        }
        if (gameVersion != null && !gameVersion.isBlank()) {
            params.add("game_versions=" + enc("[\"" + gameVersion + "\"]"));
        }
        if (!params.isEmpty()) url.append('?').append(String.join("&", params));

        List<ModVersion> out = new ArrayList<>();
        List<Object> arr = Json.asList(Json.parse(Net.getString(url.toString())));
        if (arr == null) return out;
        for (Object o : arr) {
            ModVersion v = parseVersion(o);
            if (v != null) out.add(v);
        }
        return out;
    }

    /**
     * 按文件 sha1 批量反查 Modrinth 上对应的版本（POST /version_files）。
     *
     * 这是"检查更新"能定位到本地某个 jar 属于哪个项目、装的是哪个版本的关键：
     * 本地 jar 的元数据可能被改写或缺失，直接按内容哈希问服务器最准确。
     *
     * @return hash（小写）→ 版本对象；未收录的 hash 不会出现在结果里，不是错误
     */
    public static Map<String, ModVersion> versionsByHash(List<String> sha1s) throws IOException {
        Map<String, ModVersion> out = new LinkedHashMap<>();
        if (sha1s == null || sha1s.isEmpty()) return out;
        // 接口单次上限 200 个 hash，超出自动分批
        for (int i = 0; i < sha1s.size(); i += 200) {
            List<String> batch = sha1s.subList(i, Math.min(sha1s.size(), i + 200));
            StringBuilder body = new StringBuilder("{\"algorithm\":\"sha1\",\"hashes\":[");
            for (int j = 0; j < batch.size(); j++) {
                if (j > 0) body.append(',');
                body.append('"').append(batch.get(j).replace("\"", "")).append('"');
            }
            body.append("]}");

            Net.Response resp = Net.postJson(API + "/version_files", body.toString(), null);
            if (!resp.ok()) {
                if (resp.code == 404) continue;   // 该批 hash 全部未收录
                throw new IOException("Modrinth /version_files 返回 HTTP " + resp.code);
            }
            Object root = Json.parse(resp.body);
            if (root == null) continue;
            for (Map.Entry<String, Object> e : rootMap(root).entrySet()) {
                ModVersion v = parseVersion(e.getValue());
                if (v != null) out.put(e.getKey().toLowerCase(), v);
            }
        }
        return out;
    }

    /** 解析 /version_files 返回的动态键对象：{ "<hash>": {version} }。 */
    private static Map<String, Object> rootMap(Object root) {
        Map<String, Object> map = Json.asMap(root);
        return map == null ? Map.of() : map;
    }

    /** 把 Modrinth 的一个版本对象解析成 {@link ModVersion}；缺少下载地址时返回 null。 */
    static ModVersion parseVersion(Object o) {
        ModVersion v = new ModVersion();
        v.id = Json.str(o, "id");
        v.projectId = Json.str(o, "project_id");
        v.name = Json.str(o, "name");
        v.versionNumber = Json.str(o, "version_number");
        v.versionType = Json.str(o, "version_type");
        v.datePublished = Json.str(o, "date_published");
        v.gameVersions.addAll(strList(Json.get(o, "game_versions")));
        v.loaders.addAll(strList(Json.get(o, "loaders")));

        // 主文件：优先 primary=true，否则取第一个
        List<Object> files = Json.asList(Json.get(o, "files"));
        if (files != null) {
            Object chosen = null;
            for (Object f : files) {
                if (Boolean.TRUE.equals(Json.get(f, "primary"))) {
                    chosen = f;
                    break;
                }
            }
            if (chosen == null && !files.isEmpty()) chosen = files.get(0);
            if (chosen != null) {
                v.url = Json.str(chosen, "url");
                v.filename = Json.str(chosen, "filename");
                v.size = Json.num(chosen, "size", 0);
                v.sha1 = Json.str(Json.get(chosen, "hashes"), "sha1");
            }
        }

        List<Object> deps = Json.asList(Json.get(o, "dependencies"));
        if (deps != null) {
            for (Object d : deps) {
                Dependency dep = new Dependency();
                dep.projectId = Json.str(d, "project_id");
                dep.versionId = Json.str(d, "version_id");
                dep.fileName = Json.str(d, "file_name");
                dep.type = Json.str(d, "dependency_type");
                if (dep.type != null) v.dependencies.add(dep);
            }
        }
        return v.url == null ? null : v;
    }

    /**
     * 从版本列表里挑一个：优先正式版（release），否则取最新的一个。
     * Modrinth 的版本列表按发布时间倒序返回。
     */
    public static ModVersion pick(List<ModVersion> versions) {
        if (versions.isEmpty()) return null;
        for (ModVersion v : versions) {
            if ("release".equals(v.versionType)) return v;
        }
        return versions.get(0);
    }

    /** 读取项目的缺失前置名称（用于把 modid 翻译成人能看懂的名字），失败返回 null。 */
    public static String projectTitle(String projectIdOrSlug) {
        if (projectIdOrSlug == null || projectIdOrSlug.isBlank()) return null;
        try {
            return Json.str(Json.parse(Net.getString(API + "/project/" + enc(projectIdOrSlug))), "title");
        } catch (Exception e) {
            return null;
        }
    }

    // ===== 下载 =====

    /** 把版本的主文件下载到 modsDir，返回落地文件。带 sha1 与大小校验。 */
    public static File download(ModVersion v, File modsDir, Consumer<String> log) throws IOException {
        if (v.url == null || v.filename == null) throw new IOException("该版本没有可下载的文件");
        if (!modsDir.isDirectory() && !modsDir.mkdirs()) {
            throw new IOException("无法创建 mods 目录：" + modsDir.getAbsolutePath());
        }
        File dest = new File(modsDir, v.filename);
        // 清掉同 mod 的旧同名版本（文件名含版本号，直接覆盖同名文件）
        if (dest.isFile() && dest.length() == v.size) {
            log.accept("mod 文件已存在，跳过下载：" + v.filename);
            return dest;
        }
        log.accept("下载 mod：" + v.filename);
        Net.download(v.url, dest, v.size, v.sha1, true, null, log);
        log.accept("已保存到 " + dest.getAbsolutePath());
        return dest;
    }

    // ===== 小工具 =====

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    private static List<String> strList(Object node) {
        List<String> out = new ArrayList<>();
        List<Object> arr = Json.asList(node);
        if (arr == null) return out;
        for (Object o : arr) {
            if (o != null) out.add(String.valueOf(o));
        }
        return out;
    }
}
