package mc;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/** mc-launcher 入口：独立于 Winllx 的 Minecraft 启动器（下载 + 启动）。 */
public final class Main {

    private Main() {}

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignore) {
            // 使用默认外观即可
        }
        SwingUtilities.invokeLater(() -> new LauncherUI().show());
    }
}
