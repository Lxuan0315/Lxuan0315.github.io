package mc;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * 版本 JSON 的结构化模型（只保留启动所需字段）。
 *
 * 支持三类现代启动器必须处理的形态：
 * 1. 现代正式版（1.13+）：arguments.jvm / arguments.game；
 * 2. 旧式版本（1.6 ~ 1.12.2，含 1.RV-Pre1 这类愚人节版本）：单个 minecraftArguments 字符串，
 *    且 JSON 里没有 jvm 参数块，需要启动器自备 -Djava.library.path / -cp；
 * 3. 加载器 profile（Fabric / Quilt / Forge / NeoForge）：带 inheritsFrom 指向原版，
 *    库用 maven 坐标 + url 基址描述（没有 downloads 块），必须与父版本合并后才完整。
 */
public final class VersionMeta {

    /** 库坐标缺 url 基址时的兜底 maven 仓库。 */
    private static final String DEFAULT_MAVEN = "https://libraries.minecraft.net/";

    /** 旧式版本 JSON 不带 jvm 参数，启动器需自备这组参数（与官方启动器的等价实现）。 */
    private static final List<Object> LEGACY_JVM_ARGS = List.of(
            "-Djava.library.path=${natives_directory}", "-cp", "${classpath}");

    /** 继承链最大深度，防止 profile 互相引用导致死循环。 */
    private static final int MAX_INHERIT_DEPTH = 5;

    public String id;
    public String type;
    /** 加载器 profile 指向的原版版本 id；原版自身为 null。 */
    public String inheritsFrom;
    /**
     * 客户端 jar 应该用哪个版本的。
     * 官方规则：本字段为空时沿用所继承版本的 jar；老版本 Forge（1.7.10 等）显式写成本身。
     * 现代加载器实例目录里通常没有自己的 jar，客户端 jar 是共享的原版 jar。
     */
    public String jarId;
    public String mainClass;
    public String assets;

    public String javaComponent;
    public int javaVersionMajor;
    /** 本 JSON 是否显式声明了 javaVersion（没声明时要继承父版本，否则会把 Java 21 的版本误判成 Java 8）。 */
    public boolean javaVersionDeclared;

    public String clientUrl;
    public String clientSha1;
    public long clientSize;

    public String indexId;
    public String indexUrl;
    public String indexSha1;
    public long indexSize;
    public long indexTotalSize;

    public String logUrl;
    public String logSha1;
    public String logPath;
    public long logSize;
    public String logArgument;

    /** 旧式版本的单个参数字符串（新版本为 null）。 */
    public String minecraftArguments;

    public final List<Object> jvmArgs = new ArrayList<>();
    public final List<Object> gameArgs = new ArrayList<>();
    public final List<Lib> libraries = new ArrayList<>();

    /**
     * 单条依赖库。
     * 现代版本的原生库是独立条目（name 里带 :natives-，artifact 就是 native jar）；
     * 老版本用 natives 映射（os 名 -> classifier）+ downloads.classifiers；
     * 加载器 profile 与部分老版本只有 maven 坐标 + url 基址，路径需要自己推导。
     */
    public static final class Lib {
        public String name;
        public String path;
        public String url;
        public String sha1;
        public long size;
        /** 库自带的 maven 仓库基址（加载器 profile / 老版本的 "url" 字段）。 */
        public String mavenBase;
        public List<Object> rules;
        public Map<String, Object> natives;
        public Map<String, Object> classifiers;
        public List<String> extractExclude;
        public boolean classifierNative;

        /**
         * 老版本原生库只有 natives 映射、没有 downloads.classifiers 时，
         * 按 maven 坐标派生指定 classifier 的 jar 路径。
         */
        public String derivedClassifierPath(String classifier) {
            if (name == null || classifier == null) return null;
            String[] p = name.split(":");
            if (p.length < 3) return null;
            String file = p[1] + "-" + p[2] + "-" + classifier + ".jar";
            return p[0].replace('.', '/') + "/" + p[1] + "/" + p[2] + "/" + file;
        }

        /** 派生后的 maven 仓库基址（保证以 / 结尾）。 */
        public String mavenBase() {
            String base = mavenBase != null ? mavenBase : DEFAULT_MAVEN;
            return base.endsWith("/") ? base : base + "/";
        }
    }

    public static VersionMeta parse(String json) {
        return parse(json, null);
    }

    /**
     * 解析版本 JSON 并沿 inheritsFrom 逐级合并父版本。
     *
     * @param parents 按版本 id 取父版本元数据；返回 null 表示取不到（此时保留本层信息，不合并）
     */
    public static VersionMeta parse(String json, Function<String, VersionMeta> parents) {
        VersionMeta m = parseFields(json);
        if (parents == null) return m;

        String parentId = m.inheritsFrom;
        for (int depth = 0; parentId != null && !parentId.isBlank() && depth < MAX_INHERIT_DEPTH; depth++) {
            VersionMeta parent = parents.apply(parentId);
            if (parent == null) break;
            m.inheritFrom(parent);
            parentId = parent.inheritsFrom;
        }
        return m;
    }

    private static VersionMeta parseFields(String json) {
        Object root = Json.parse(json);
        VersionMeta m = new VersionMeta();
        m.id = Json.str(root, "id");
        m.type = Json.str(root, "type");
        m.inheritsFrom = Json.str(root, "inheritsFrom");
        m.jarId = Json.str(root, "jar");
        m.mainClass = Json.str(root, "mainClass");
        m.assets = Json.str(root, "assets");
        m.minecraftArguments = Json.str(root, "minecraftArguments");

        Object jv = Json.get(root, "javaVersion");
        if (jv instanceof Map) {
            m.javaVersionDeclared = true;
            m.javaComponent = Json.str(jv, "component");
            m.javaVersionMajor = Json.intVal(jv, "majorVersion", 8);
        }

        Object client = Json.get(Json.get(root, "downloads"), "client");
        m.clientUrl = Json.str(client, "url");
        m.clientSha1 = Json.str(client, "sha1");
        m.clientSize = Json.num(client, "size", 0);

        Object index = Json.get(root, "assetIndex");
        m.indexId = Json.str(index, "id");
        m.indexUrl = Json.str(index, "url");
        m.indexSha1 = Json.str(index, "sha1");
        m.indexSize = Json.num(index, "size", 0);
        m.indexTotalSize = Json.num(index, "totalSize", 0);

        Object logClient = Json.get(Json.get(root, "logging"), "client");
        m.logArgument = Json.str(logClient, "argument");
        Object logFile = Json.get(logClient, "file");
        m.logUrl = Json.str(logFile, "url");
        m.logSha1 = Json.str(logFile, "sha1");
        m.logSize = Json.num(logFile, "size", 0);
        // 现代版本不含 path 字段（只有 id），老版本才有 path；缺失时按官方约定落到 assets/log_configs/<id>
        m.logPath = Json.str(logFile, "path");
        if (m.logPath == null) {
            String logId = Json.str(logFile, "id");
            if (logId != null) m.logPath = "log_configs/" + logId;
        }

        Object args = Json.get(root, "arguments");
        if (args instanceof Map) {
            List<Object> jvm = Json.asList(Json.get(args, "jvm"));
            if (jvm != null) m.jvmArgs.addAll(jvm);
            List<Object> game = Json.asList(Json.get(args, "game"));
            if (game != null) m.gameArgs.addAll(game);
        }

        List<Object> libs = Json.asList(Json.get(root, "libraries"));
        if (libs != null) {
            for (Object o : libs) {
                Map<String, Object> lm = Json.asMap(o);
                if (lm == null) continue;
                Lib lib = new Lib();
                lib.name = Json.str(o, "name");
                lib.mavenBase = Json.str(o, "url");

                Object artifact = Json.get(Json.get(o, "downloads"), "artifact");
                lib.path = Json.str(artifact, "path");
                lib.url = Json.str(artifact, "url");
                lib.sha1 = Json.str(artifact, "sha1");
                lib.size = Json.num(artifact, "size", 0);
                // 只有完全没有 downloads 块的条目（加载器 profile）才按 maven 坐标推导；
                // 老版本的原生库条目虽然也没有 artifact，但有 downloads.classifiers，必须留给 natives 分支处理，
                // 否则会把不存在的主 artifact 当成依赖去下载（404 会让整个安装失败）。
                if (Json.get(o, "downloads") == null) deriveMavenPath(lib);

                lib.rules = Json.asList(lm.get("rules"));
                lib.natives = Json.asMap(lm.get("natives"));
                lib.classifiers = Json.asMap(Json.get(Json.get(o, "downloads"), "classifiers"));

                List<Object> excludes = Json.asList(Json.get(lm.get("extract"), "exclude"));
                if (excludes != null) {
                    lib.extractExclude = new ArrayList<>();
                    for (Object ex : excludes) lib.extractExclude.add(String.valueOf(ex));
                }
                lib.classifierNative = lib.name != null && lib.name.contains(":natives-");

                m.libraries.add(lib);
            }
        }
        return m;
    }

    /** maven 坐标（group:artifact:version[:classifier]）+ 仓库基址 → 相对路径与下载地址。 */
    private static void deriveMavenPath(Lib lib) {
        if (lib.path != null || lib.name == null) return;
        String[] p = lib.name.split(":");
        if (p.length < 3) return;
        String group = p[0];
        String artifact = p[1];
        String version = p[2];
        String classifier = p.length > 3 ? p[3] : null;
        String file = artifact + "-" + version + (classifier == null ? "" : "-" + classifier) + ".jar";
        lib.path = group.replace('.', '/') + "/" + artifact + "/" + version + "/" + file;
        lib.url = lib.mavenBase() + lib.path;
    }

    // ===== 继承合并 =====

    /**
     * 用父版本补全本层缺省字段（加载器 profile 只有自己的主类、库和少量参数）。
     * 官方启动器的合并语义：子层覆盖同名字段，库与参数是"父在前、子在后"的拼接。
     */
    public void inheritFrom(VersionMeta parent) {
        if (parent == null) return;

        if (type == null) type = parent.type;
        if (assets == null) assets = parent.assets;
        if (!javaVersionDeclared) {
            javaComponent = parent.javaComponent;
            javaVersionMajor = parent.javaVersionMajor;
        }
        if (indexId == null) {
            indexId = parent.indexId;
            indexUrl = parent.indexUrl;
            indexSha1 = parent.indexSha1;
            indexSize = parent.indexSize;
            indexTotalSize = parent.indexTotalSize;
        }
        if (clientUrl == null) {
            clientUrl = parent.clientUrl;
            clientSha1 = parent.clientSha1;
            clientSize = parent.clientSize;
        }
        if (logUrl == null) {
            logUrl = parent.logUrl;
            logSha1 = parent.logSha1;
            logSize = parent.logSize;
        }
        if (logPath == null) logPath = parent.logPath;
        if (logArgument == null) logArgument = parent.logArgument;
        if (minecraftArguments == null) minecraftArguments = parent.minecraftArguments;

        // 库：父在前、子在后；同名以子为准（子层可能升级了同名库的版本）
        LinkedHashMap<String, Lib> merged = new LinkedHashMap<>();
        for (Lib l : parent.libraries) merged.put(libKey(l), l);
        for (Lib l : libraries) merged.put(libKey(l), l);
        libraries.clear();
        libraries.addAll(merged.values());

        // jvm 参数：父版本没有时补上旧式默认组（否则加载器 profile 只有自己的参数，缺 -cp）
        List<Object> jvm = new ArrayList<>();
        if (parent.jvmArgs.isEmpty()) jvm.addAll(LEGACY_JVM_ARGS);
        else jvm.addAll(parent.jvmArgs);
        jvm.addAll(jvmArgs);
        jvmArgs.clear();
        jvmArgs.addAll(jvm);

        // 游戏参数：父在前、子在后（旧式父版本的游戏参数由 effectiveGameArgs() 从字符串切出）
        List<Object> game = new ArrayList<>(parent.gameArgs);
        game.addAll(gameArgs);
        gameArgs.clear();
        gameArgs.addAll(game);

        if (mainClass == null) mainClass = parent.mainClass;
    }

    private static String libKey(Lib l) {
        if (l.name != null) return l.name;
        return l.path == null ? "" : l.path;
    }

    // ===== 启动参数 =====

    /** 最终使用的 jvm 参数：JSON 没给时用旧式默认组。 */
    public List<Object> effectiveJvmArgs() {
        return jvmArgs.isEmpty() ? new ArrayList<>(LEGACY_JVM_ARGS) : jvmArgs;
    }

    /** 最终使用的游戏参数：新式用数组；旧式把 minecraftArguments 按空白切分。 */
    public List<Object> effectiveGameArgs() {
        if (!gameArgs.isEmpty()) return gameArgs;
        List<Object> out = new ArrayList<>();
        if (minecraftArguments == null || minecraftArguments.isBlank()) return out;
        for (String s : minecraftArguments.trim().split("\\s+")) {
            if (!s.isEmpty()) out.add(s);
        }
        return out;
    }

    /** 是否具备启动所需的参数描述（新旧格式都算）。 */
    public boolean launchable() {
        if (mainClass == null || mainClass.isBlank()) return false;
        if (!jvmArgs.isEmpty() || !gameArgs.isEmpty()) return true;
        return minecraftArguments != null && !minecraftArguments.isBlank();
    }

    /** 不可启动时给用户看的原因，可启动时返回 null。 */
    public String missingReason() {
        if (mainClass == null || mainClass.isBlank()) return "版本 JSON 缺少 mainClass";
        if (!launchable()) return "版本 JSON 既没有 arguments 也没有 minecraftArguments";
        return null;
    }
}
