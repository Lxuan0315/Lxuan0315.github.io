@echo off
cd /d "%~dp0"

echo ========================================
echo        mc-launcher Build
echo ========================================

set "JAVA_HOME=%~dp0..\lib\jbr"
if not exist "%JAVA_HOME%\bin\javac.exe" (
    echo [ERROR] 未找到内置 JDK: %JAVA_HOME%\bin\javac.exe
    pause
    exit /b 1
)

rem 清掉可能存在的全局 CLASSPATH，避免引入无关的 jar 路径
set "CLASSPATH="

if not exist "out" mkdir "out"
"%JAVA_HOME%\bin\javac.exe" -encoding UTF-8 -d out src\mc\*.java
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] 编译失败。
    pause
    exit /b 1
)
echo 编译完成 -^> out\
