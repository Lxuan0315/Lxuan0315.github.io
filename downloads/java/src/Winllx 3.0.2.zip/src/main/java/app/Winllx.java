package app;

import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Calendar;
import java.util.Properties;

import javax.imageio.ImageIO;
import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.filechooser.FileNameExtensionFilter;

import modules.AppStoreModule;
import modules.BoardModule;
import modules.BrowserModule;
import modules.CalculatorModule;
import modules.CalendarModule;
import modules.ClipboardModule;
import modules.ClockModule;
import modules.ExitAction;
import modules.FileManagerModule;
import modules.LiquidGlassModule;
import modules.MindReaderModule;
import modules.NotesModule;
import modules.SystemMonitorModule;
import modules.TodoModule;
import modules.WeatherModule;
import ui.GlassBrowserPanel;
import ui.GlassFrame;
import ui.SettingsFrame;
import utils.GlassAssetServer;
import utils.LangManager;
import utils.Loading;
import utils.WinllxIcon;

public class Winllx {
    private static String APP_TITLE = "Winllx";
    private static final Color DEFAULT_BG = Color.WHITE;
    private static final String TRAY_ICON_PATH = "C:/Users/86132/Desktop/java.png";
    private static final String SETTINGS_FILE = System.getProperty("user.dir") + "/Winllx/app_settings.properties";
    private static boolean trayEnabled = true;
    private static TrayIcon trayIcon;
    private static JFrame mainFrame;
    private static BufferedImage backgroundImage = null;
    private static String bgImagePath = null;

    /** 音量缓存快照（snapshot 时立即返回，后台用 SystemVolumeControl.getVolume() 刷新）。 */
    private static volatile int cachedVolume = 50;
    /** 系统是否处于静音（名片音量图标据此显示 0.svg）。 */
    private static volatile boolean cachedVolumeMuted = false;
    
    private static final int GRID_CELL_WIDTH = 120;
    private static final int GRID_CELL_HEIGHT = 100;
    private static final int GRID_PADDING_X = 50;
    private static final int GRID_PADDING_Y = 120;
    /** 非最大化（窗口化）时为 true：HTML 端按流式布局排列按钮，忽略拖拽保存的网格坐标。 */
    private static boolean windowedMode = false;

    /** HTML 主界面：桌面外壳的承载容器（先露出壁纸底色）与浏览器面板。 */
    private static JPanel desktopHolder;
    private static GlassBrowserPanel desktopBrowser;

    /** 背景图不透明度 / 适配模式（由 HTML 桌面外壳消费）。 */
    private static float bgImageOpacity = 1f;
    private static int bgImageFit = 0;
    /** 桌面文字色（浅底黑字 / 深底白字）。 */
    private static Color desktopTextColor = Color.BLACK;
    /** 网格辅助线透明度（0 = 不显示）。 */
    private static int gridAlphaShown = 0;

    /** 在线状态（Java 侧对 www.baidu.com:443 的真实探测结果），随 /api/status 下发。 */
    private static volatile boolean netOnline = true;

    public static void main(String[] stringArray) {
        // 单实例保护：Winllx 不能多开 —— 必须在动 JCEF / 资源端口之前就拦掉（详见下面注释）
        if (anotherInstanceRunning()) {
            activateRunningInstance();   // 顺手把已在运行的窗口唤到前台
            System.err.println("[Winllx] 已有一个 Winllx 在运行，本次启动直接退出（Winllx 不支持多开）。");
            System.exit(0);
            return;
        }

        LangManager.init();
        Loading loading = new Loading();
        loading.show();

        // HTML 主界面与 Java 的通道：桌面外壳通过 /api/* 取状态、开模块（须在页面加载前注册）
        GlassAssetServer.setApiHandler(Winllx::handleApi);
        // 网络档位后台轮询（与任务栏同源），供桌面右下角状态卡片显示
        Winllx.startNetworkPoller();

        // 后台预热 JCEF（Chromium 内核初始化耗时较长，尽早开始，用户点击子应用时才秒开）
        new Thread(() -> {
            try {
                System.out.println("[Winllx] 后台预热 JCEF 内核...");
                Class<?> gbp = Class.forName("ui.GlassBrowserPanel");
                java.lang.reflect.Method m = gbp.getMethod("ensureJcef");
                Object result = m.invoke(null);
                System.out.println("[Winllx] JCEF 预热完成: " + result);
            } catch (Throwable t) {
                System.err.println("[Winllx] JCEF 预热失败（不影响主程序）: " + t.getMessage());
            }
        }, "jcef-prewarm").start();

        // 后台刷新系统音量缓存（阻塞 PowerShell 调用不能放 EDT）
        new Thread(() -> { try { ui.SystemVolumeControl.init(); refreshSystemVolumeCache(); } catch (Throwable ignore) {} }, "volume-init").start();

        WinllxIcon.init();
        Winllx.initMainWindow();

        SwingUtilities.invokeLater(() -> {
            Winllx.initSystemTray();
            loading.close();
        });
    }

    public static void setMainVisible(boolean bl) {
        if (mainFrame != null) {
            mainFrame.setVisible(bl);
        }
    }

    /* ==================== 单实例保护（Winllx 不能多开） ====================
       为什么必须拦：两个实例抢的是同一份 jcef_cache（CEF 的 profile 目录）。
       第二个实例拿不到 profile 时，CEF 会走 Chrome runtime 分支，直接开出一个**整套 Chrome
       界面的原生窗口**（带标签栏，并且必定弹出 "--no-sandbox 不受支持"、"缺少 Google API keys"、
       "Chromium 不是默认浏览器" 三条信息栏，以及恢复上次残留会话的弹窗），
       同时它的主界面因为 JCEF 起不来而加载不出来；资源服务也抢不到 18520，会退化成随机端口
       （origin 一变，网页里的 localStorage 也就接不上了）。

       两道检查，取其一命中就退出：
       ① Winllx/instance.lock 的独占文件锁 —— 跨进程互斥，且进程无论怎么结束（包括崩溃/被杀）
          OS 都会自动释放，不会留脏锁；这是防同一目录多开的主力。
       ② 127.0.0.1:18520 的探测 —— 防"不同目录各放一份 Winllx"同时开（那样各有各的锁，
          却会抢同一个资源端口）。用 /api/state 回包里带不带我们状态 JSON 的字段名确认是自己人，
          避免把占用同一端口的其它程序误判成 Winllx。 */
    private static final int INSTANCE_PORT = 18520;
    /** 实例锁：句柄与 FileLock 都要强引用住 —— 只留着 channel 不够，
        FileLock 一旦被 GC 回收，锁会被自动释放（通道被 GC 关闭也会），进程里就悄悄失去保护了。 */
    private static java.nio.channels.FileChannel instanceLockChannel;
    private static java.nio.channels.FileLock instanceLock;

    /** true = 已经有一个 Winllx 在运行。 */
    private static boolean anotherInstanceRunning() {
        boolean lockAcquired = acquireInstanceLock();
        if (portLooksLikeWinllx()) return true;   // 端口上有另一份 Winllx（不同目录也会撞上）
        return !lockAcquired;                     // 锁被人占着 → 同目录已有一个实例在跑
    }

    /** 抢 Winllx/instance.lock 的独占锁；抢到返回 true 并一直持有到进程结束。 */
    private static boolean acquireInstanceLock() {
        try {
            java.io.File lockFile = new java.io.File(System.getProperty("user.dir"), "Winllx/instance.lock");
            java.io.File parent = lockFile.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            java.nio.channels.FileChannel ch = java.nio.channels.FileChannel.open(lockFile.toPath(),
                    java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.WRITE);
            java.nio.channels.FileLock lk = null;
            try { lk = ch.tryLock(); } catch (Throwable ignore) {}
            if (lk == null || !lk.isValid()) {
                try { ch.close(); } catch (Throwable ignore) {}
                return false;
            }
            instanceLockChannel = ch;   // 两个都故意不释放：进程活着就一直是我们的
            instanceLock = lk;
            return true;
        } catch (Throwable t) {
            System.out.println("[Winllx] 实例锁不可用，继续启动: " + t.getMessage());
            return true;          // 锁机制本身出问题时不能挡住启动
        }
    }

    /** true = 18520 上已经有 Winllx 在跑。 */
    private static boolean portLooksLikeWinllx() {
        String resp = getFromInstancePort("/api/state");
        if (resp == null) return false;
        return resp.contains("\"textColor\"") || resp.contains("\"cellW\"") || resp.contains("\"maximized\"");
    }

    /** 请求已在运行的实例把主窗口唤到前台（best-effort，失败也不影响本次退出）。 */
    private static void activateRunningInstance() {
        getFromInstancePort("/api/activate");
    }

    /** 向 127.0.0.1:18520 发一次极短的 HTTP/1.0 GET，返回原始回包；连不上返回 null。 */
    private static String getFromInstancePort(String path) {
        try (java.net.Socket s = new java.net.Socket()) {
            s.connect(new java.net.InetSocketAddress("127.0.0.1", INSTANCE_PORT), 400);
            s.setSoTimeout(400);
            java.io.OutputStream os = s.getOutputStream();
            os.write(("GET " + path + " HTTP/1.0\r\nHost: 127.0.0.1\r\n\r\n")
                    .getBytes(java.nio.charset.StandardCharsets.UTF_8));
            os.flush();
            // HTTP/1.0 且服务端回了 Content-Length 后会关连接，readAllBytes 不会挂住
            return new String(s.getInputStream().readAllBytes(),
                    java.nio.charset.StandardCharsets.UTF_8);
        } catch (Throwable t) {
            return null;
        }
    }

    public static Color getMainBackgroundColor() {
        if (mainFrame != null) {
            return mainFrame.getContentPane().getBackground();
        }
        return DEFAULT_BG;
    }

    private static void initMainWindow() {
        APP_TITLE = LangManager.getString("app.title");
        mainFrame = new JFrame(APP_TITLE);
        Color color = Winllx.loadBackgroundColor();
        desktopTextColor = Winllx.getContrastColor(color);
        gridAlphaShown = Winllx.loadGridAlpha();
        bgImageOpacity = Winllx.loadBgImageOpacity();
        bgImageFit = Winllx.loadBgImageFitMode();

        // 主界面 = HTML 桌面外壳。容器先铺上保存的壁纸底色（避免 JCEF 就绪前的白/黑闪屏），
        // 浏览器面板挂上来后由网页自己画壁纸、时钟、桌面按钮与右下角液态玻璃名片。
        desktopHolder = new JPanel(new BorderLayout());
        desktopHolder.setBackground(color);
        mainFrame.setContentPane(desktopHolder);
        mainFrame.setExtendedState(6);
        // 注意：这里不能调用 mainFrame.setLayout(null)——那会把 desktopHolder 的 BorderLayout
        // 也改成 null 布局，浏览器面板将拿不到任何尺寸（0×0），表现为整窗只剩底色（JCEF 不绘制）。
        // 现在桌面元素都由网页自己排版，Swing 侧不再需要绝对定位。
        mainFrame.setDefaultCloseOperation(3);
        WinllxIcon.applyToFrame(mainFrame);
        GlassFrame.setMainFrame(mainFrame);
        GlassFrame.setGlassEnabled(Winllx.loadGlassWindows());

        desktopBrowser = new GlassBrowserPanel("main/index.html");
        desktopHolder.add(desktopBrowser, BorderLayout.CENTER);

        mainFrame.setVisible(true);

        mainFrame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent componentEvent) {
                Winllx.refreshDesktop();
            }

            @Override
            public void componentShown(ComponentEvent componentEvent) {
                Winllx.refreshDesktop();
            }
        });
        // 最大化状态切换：网页端在"固定网格布局"与"流式布局"之间切换
        mainFrame.addWindowStateListener(e -> {
            boolean maximized = (e.getNewState() & Frame.MAXIMIZED_BOTH) != 0;
            boolean wasWindowed = windowedMode;
            windowedMode = !maximized;
            if (wasWindowed != windowedMode) {
                Winllx.refreshDesktop();
            }
        });

        // 背景图解码较耗时，放后台线程读取，读完后让网页端重新拉一次状态
        Winllx.loadBackgroundImageAsync();
    }

    /** 让 HTML 桌面外壳重新拉取一次 /api/state（背景、网格、文本色等变化后调用）。 */
    private static void refreshDesktop() {
        if (desktopBrowser != null) {
            desktopBrowser.executeJavaScript(
                    "try{window.__winllxRefresh&&window.__winllxRefresh();}catch(e){}");
        }
    }

    private static volatile SettingsFrame settingsFrameRef = null;

    private static void openSettings() {
        // 若已有窗口实例且尚未销毁，直接前置显示；否则新建
        if (settingsFrameRef != null) {
            try {
                java.lang.reflect.Field f = SettingsFrame.class.getDeclaredField("frame");
                f.setAccessible(true);
                JFrame f2 = (JFrame) f.get(settingsFrameRef);
                if (f2 != null && f2.isDisplayable()) {
                    f2.setVisible(true);
                    f2.toFront();
                    return;
                }
            } catch (Throwable ignore) {}
        }

        final SettingsFrame.HostActions actions = new SettingsFrame.HostActions() {
            @Override public void applyLang(String lang) {
                if (lang == null || lang.isEmpty()) return;
                LangManager.setLanguage(lang);
                // 提示由 settings.html 里的 showToast 承担，不再弹 Swing JOptionPane
                Winllx.refreshDesktop();   // 桌面按钮文案随语言即时刷新
            }

            @Override public void applyThemeMode(int mode) {
                if (mode == 0 || mode == 1 || mode == 2) {
                    Winllx.applyTheme(mode);
                } else if (mode == 3) {
                    if (backgroundImage == null) {
                        BufferedImage img = Winllx.selectBackgroundImage(mainFrame);
                        if (img != null) {
                            backgroundImage = img;
                            Winllx.saveBgImagePath(bgImagePath);
                            Winllx.saveBgMode(3);
                            Winllx.syncTextColorForImage(img);
                            Winllx.refreshDesktop();
                        }
                    } else {
                        Winllx.saveBgMode(3);
                    }
                }
            }

            @Override public void applyBgColor(String colorHex) {
                if (colorHex == null || colorHex.isEmpty()) return;
                Color c;
                try { c = Winllx.hexToColor(colorHex); }
                catch (Exception e) { c = Color.WHITE; }
                if (loadBgMode() != 3) {
                    backgroundImage = null;
                    bgImagePath = null;
                }
                Winllx.setDesktopBackgroundColor(c);
                Winllx.saveBackgroundColor(c);
                Winllx.saveBgMode(2);
                Winllx.refreshDesktop();
            }

            @Override public void applyBgImage(File imgFile, String dataUrlPreview) {
                if (imgFile == null) return;
                try {
                    BufferedImage img = ImageIO.read(imgFile);
                    if (img != null) {
                        backgroundImage = img;
                        bgImagePath = imgFile.getAbsolutePath();
                        Winllx.saveBgImagePath(bgImagePath);
                        Winllx.saveBgMode(3);
                        Winllx.syncTextColorForImage(img);
                        Winllx.refreshDesktop();
                    }
                } catch (Exception ex) {
                    System.err.println("[Winllx] 背景图加载失败: " + ex.getMessage());
                    // 错误提示由 settings.html 里的 showToast 承担
                }
            }

            @Override public void clearBgImage() {
                backgroundImage = null;
                bgImagePath = null;
                Winllx.saveBgImagePath("");
                Color cur = mainFrame.getContentPane().getBackground();
                int mode;
                if (cur.equals(Color.BLACK)) mode = 1;
                else if (cur.equals(Color.WHITE)) mode = 0;
                else mode = 2;
                Winllx.saveBgMode(mode);
                Winllx.syncTextColor();
                Winllx.refreshDesktop();
            }

            @Override public void applyBgFit(int mode) {
                bgImageFit = mode;
                Winllx.saveBgImageFitMode(mode);
                Winllx.refreshDesktop();
            }

            @Override public void applyBgOpacity(float opacity) {
                float op = Math.max(0.1f, Math.min(1.0f, opacity));
                bgImageOpacity = op;
                Winllx.saveBgImageOpacity(op);
                Winllx.refreshDesktop();
            }

            @Override public void applyIconTheme(int theme) {
                WinllxIcon.setTheme(theme);
                WinllxIcon.applyToFrame(mainFrame);
                Winllx.refreshTrayIcon();  // 托盘图标同步跟随窗口图标主题
            }

            @Override public void showIconThemeTest(int theme) {
                JFrame tf = WinllxIcon.createFrame(
                        "\u56fe\u6807\u6d4b\u8bd5\u7a97\u53e3 - " + (theme == 0
                                ? LangManager.getString("setting.icon.light")
                                : LangManager.getString("setting.icon.dark")));
                tf.setSize(300, 200);
                tf.setLocationRelativeTo(mainFrame);
                tf.setLayout(new BorderLayout());
                JLabel label = new JLabel(
                        LangManager.getString("setting.icon.theme") + "\uff1a" +
                                (theme == 0 ? LangManager.getString("setting.icon.light")
                                        : LangManager.getString("setting.icon.dark")), JLabel.CENTER);
                label.setFont(new Font("微软雅黑", Font.BOLD, 16));
                tf.add(label, BorderLayout.CENTER);
                tf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                tf.setVisible(true);
            }

            @Override public void applyVolume(int volume) { Winllx.setSystemVolume(volume); }

            @Override public void querySystemVolume(java.util.function.IntConsumer onReady) {
                if (onReady == null) return;
                new Thread(() -> {
                    ui.SystemVolumeControl.init();
                    int v = ui.SystemVolumeControl.getVolume();
                    cachedVolume = v;
                    onReady.accept(v);
                }, "query-volume").start();
            }

            @Override public void applyGridShow(boolean show) {
                int alpha = show ? 100 : 0;
                gridAlphaShown = alpha;
                Winllx.saveGridAlpha(alpha);
                Winllx.refreshDesktop();
            }

            @Override public void applyGlassWin(boolean enable) {
                Winllx.saveGlassWindows(enable);
                GlassFrame.setGlassEnabled(enable);
            }

            @Override public void applyTray(boolean enable) {
                Winllx.saveTray(enable);
                Winllx.updateTray(enable);
            }

            @Override public void applyAutoStart(boolean enable) {
                Winllx.applyAutoStart(enable);
            }

            @Override public boolean isAutoStartOn() {
                return Winllx.isAutoStartEnabled();
            }

            @Override public void applyLiquidGlass(String payloadStr) {
                Winllx.applyLiquidGlass(payloadStr);
            }

            @Override public void clearCache() {
                final File cache = new File(System.getProperty("user.dir"), "Winllx/jcef_cache");
                new Thread(() -> {
                    int[] cnt = new int[]{0, 0};
                    Winllx.deleteRecursively(cache, cnt);
                    SwingUtilities.invokeLater(() -> {
                        String msg = LangManager.getString("msg.cache.cleared")
                                + " (" + cnt[0] + " / " + cnt[1] + ")";
                        JOptionPane.showMessageDialog(mainFrame, msg,
                                LangManager.getString("lbl.clearCache"),
                                JOptionPane.INFORMATION_MESSAGE);
                    });
                }, "jcef-cache-clear").start();
            }

            @Override public void clearAllData() {
                new Thread(() -> {
                    File root = new File(System.getProperty("user.dir"), "Winllx");
                    int[] cnt = new int[]{0, 0};
                    // 商店下载安装的应用及其索引缓存
                    Winllx.deleteRecursively(new File(root, "apps"), cnt);
                    // 便笺 / 待办 / 日历 / 浏览器记录等网页数据与 JCEF 缓存
                    Winllx.deleteRecursively(new File(root, "jcef_cache"), cnt);
                    // 便笺附件目录
                    Winllx.deleteRecursively(new File(root, "notes"), cnt);
                    // 全部设置文件
                    for (String name : new String[]{"app_settings.properties", "browser.properties",
                            "github_accel.properties", "icon_settings.properties", "weather_cities.txt"}) {
                        File f = new File(root, name);
                        if (f.exists()) f.delete();
                    }
                    // 不动 Winllx/minecraft：游戏本体、模组与存档不属于 Winllx 的应用数据
                }, "winllx-clear-all").start();
            }

            @Override public void resetAllSettings() {
                try {
                    File dir = new File(SETTINGS_FILE).getParentFile();
                    if (dir != null && !dir.exists()) dir.mkdirs();
                    Properties p = new Properties();
                    p.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings (reset)");
                } catch (Exception ignore) {}
                Winllx.applyTheme(0);
                Winllx.saveGridAlpha(0);
                gridAlphaShown = 0;
                Winllx.saveGlassWindows(true);
                GlassFrame.setGlassEnabled(true);
                Winllx.saveTray(true);
                Winllx.updateTray(true);
                WinllxIcon.setTheme(0);
                WinllxIcon.applyToFrame(mainFrame);
                bgImageOpacity = 1.0f;
                bgImageFit = 0;
                backgroundImage = null;
                bgImagePath = null;
                Winllx.saveBgImageOpacity(1.0f);
                Winllx.saveBgImageFitMode(0);
                Winllx.saveBgImagePath("");
                Winllx.saveBgMode(0);
                Winllx.refreshDesktop();
            }

            @Override public File pickBgImageByFileChooser(Component parent) {
                return _pickBgImageReturnFile(parent);
            }

            @Override public String getSettingsSnapshotJson() {
                return Winllx.buildSettingsSnapshotJson();
            }

            @Override public void onCloseSettings(Point location) {
                Winllx.saveSettingsPosition(location);
                // 销毁式：窗口已 dispose（见 SettingsFrame.doClose），下次打开会新建
            }

            @Override public JFrame getMainFrame() { return mainFrame; }
        };

        SwingUtilities.invokeLater(() -> {
            settingsFrameRef = new SettingsFrame(actions);
        });
    }

    /** selectBackgroundImage 语义相同，但返回 File 对象而不是 BufferedImage（供 bridge 持久化路径） */
    private static File _pickBgImageReturnFile(Component parent) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(LangManager.getString("dialog.image.select"));
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "Image Files (jpg, png, gif, bmp, jpeg, wbmp)",
                "jpg", "png", "gif", "bmp", "jpeg", "wbmp");
        fileChooser.setFileFilter(filter);
        int result = fileChooser.showOpenDialog(parent);
        if (result == JFileChooser.APPROVE_OPTION) {
            File f = fileChooser.getSelectedFile();
            try {
                BufferedImage img = ImageIO.read(f);
                if (img != null) { return f; }
                JOptionPane.showMessageDialog(parent,
                        LangManager.getString("msg.image.load.error"),
                        LangManager.getString("dialog.error"), JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(parent,
                        LangManager.getString("msg.image.load.error"),
                        LangManager.getString("dialog.error"), JOptionPane.ERROR_MESSAGE);
            }
        }
        return null;
    }

    /** 生成当前设置的 JSON 快照（settings.html 里 __applySnapshot 消费） */
    private static String buildSettingsSnapshotJson() {
        StringBuilder sb = new StringBuilder();
        sb.append('{');
        sb.append("\"lang\":").append(_q(LangManager.getCurrentLang())).append(',');
        int theme;
        if (backgroundImage != null) theme = 3;
        else {
            Color c = mainFrame.getContentPane().getBackground();
            if (Color.BLACK.equals(c)) theme = 1;
            else if (Color.WHITE.equals(c)) theme = 0;
            else theme = 2;
        }
        sb.append("\"theme\":").append(theme).append(',');
        Color bg = mainFrame.getContentPane().getBackground();
        sb.append("\"bgColor\":").append(_q(colorToHex(bg))).append(',');
        String preview = _bgImageDataUrl();
        sb.append("\"bgImage\":").append(preview == null ? "null" : _q(preview)).append(',');
        sb.append("\"bgImagePath\":").append(bgImagePath == null ? "null" : _q(bgImagePath)).append(',');
        sb.append("\"bgFit\":").append(bgImageFit).append(',');
        sb.append("\"bgOpacity\":").append(bgImageOpacity).append(',');
        sb.append("\"iconTheme\":").append(WinllxIcon.getCurrentTheme()).append(',');
        sb.append("\"iconLightData\":").append(_q(_iconThumb(0))).append(',');
        sb.append("\"iconDarkData\":").append(_q(_iconThumb(1))).append(',');
        sb.append("\"iconFailed\":").append(WinllxIcon.isAnyIconFailed()).append(',');
        sb.append("\"volume\":").append(getSystemVolume()).append(',');
        sb.append("\"gridShow\":").append(gridAlphaShown > 0).append(',');
        sb.append("\"glassWin\":").append(loadGlassWindows()).append(',');
        sb.append("\"tray\":").append(loadTray()).append(',');
        sb.append("\"autoStart\":").append(isAutoStartEnabled()).append(',');
        sb.append("\"blurAmount\":").append(lgBlur()).append(',');
        sb.append("\"saturation\":").append(lgSat()).append(',');
        sb.append("\"displacementScale\":").append(lgDisp()).append(',');
        sb.append("\"aberrationIntensity\":").append(lgAber()).append(',');
        sb.append("\"elasticity\":").append(lgElast()).append(',');
        sb.append("\"activationZone\":").append(lgAct()).append(',');
        sb.append("\"activeScale\":").append(lgScale()).append(',');
        sb.append("\"mode\":").append(_q(lgMode())).append(',');
        sb.append("\"overLight\":").append(lgOverLight()).append(',');
        sb.append("\"cornerRadius\":").append(lgRadius()).append(',');
        sb.append("\"version\":").append(_q("Winllx 2.3.1"));
        sb.append('}');
        return sb.toString();
    }

    private static String _q(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder(s.length() + 16);
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '"':  sb.append("\\\""); break;
                case '\r': sb.append("\\r"); break;
                case '\n': sb.append("\\n"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04X", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('"');
        return sb.toString();
    }

    private static String _bgImageDataUrl() {
        if (backgroundImage == null) return null;
        try {
            int maxW = 600;
            int w = backgroundImage.getWidth(), h = backgroundImage.getHeight();
            BufferedImage src = backgroundImage;
            if (w > maxW) {
                int nh = (int) Math.round(h * (maxW * 1.0 / w));
                Image sc = src.getScaledInstance(maxW, nh, Image.SCALE_SMOOTH);
                BufferedImage b2 = new BufferedImage(maxW, nh, BufferedImage.TYPE_INT_RGB);
                Graphics2D g = b2.createGraphics();
                g.drawImage(sc, 0, 0, null);
                g.dispose();
                src = b2;
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ImageIO.write(src, "jpg", bos);
            return "data:image/jpeg;base64," + Base64.getEncoder().encodeToString(bos.toByteArray());
        } catch (Throwable t) { return null; }
    }

    private static String _iconThumb(int theme) {
        try {
            Image img = WinllxIcon.getIconImage(theme);
            if (img == null) return "";
            BufferedImage bi;
            if (img instanceof BufferedImage) bi = (BufferedImage) img;
            else {
                bi = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g = bi.createGraphics();
                g.drawImage(img.getScaledInstance(64, 64, Image.SCALE_SMOOTH), 0, 0, null);
                g.dispose();
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ImageIO.write(bi, "png", bos);
            return "data:image/png;base64," + Base64.getEncoder().encodeToString(bos.toByteArray());
        } catch (Throwable t) { return ""; }
    }

    /* 设置窗口由 SettingsFrame（JCEF + settings/settings.html）承担。 */

    private static Color getContrastColor(Color color) {
        if (color == null) {
            return Color.BLACK;
        }
        double d = 0.2126 * (double)color.getRed() + 0.7152 * (double)color.getGreen() + 0.0722 * (double)color.getBlue();
        return d < 128.0 ? Color.WHITE : Color.BLACK;
    }

    private static void syncTextColor() {
        Winllx.setDesktopBackgroundColor(mainFrame.getContentPane().getBackground());
        Winllx.refreshDesktop();
    }

    /** 铺设桌面底色并同步文字色（HTML 端据此决定按钮/时钟用黑字还是白字）。 */
    private static void setDesktopBackgroundColor(Color c) {
        if (c == null) c = DEFAULT_BG;
        if (desktopHolder != null) desktopHolder.setBackground(c);
        desktopTextColor = Winllx.getContrastColor(c);
    }

    private static void applyTheme(int n) {
        Color color = switch (n) {
            case 1 -> Color.BLACK;
            case 2 -> Color.BLUE;
            default -> Color.WHITE;
        };
        backgroundImage = null;
        bgImagePath = null;
        Winllx.setDesktopBackgroundColor(color);
        Winllx.saveBackgroundColor(color);
        Winllx.saveBgMode(n);
        Winllx.saveBgImagePath("");
        Winllx.refreshDesktop();
    }

    private static Color loadBackgroundColor() {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                String string = properties.getProperty("bgColor");
                if (string != null && !string.isEmpty()) {
                    return Winllx.hexToColor(string);
                }
            }
        }
        catch (Exception exception) {
        }
        return DEFAULT_BG;
    }

    private static Color loadTextColor() {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                String string = properties.getProperty("textColor");
                if ("white".equalsIgnoreCase(string)) {
                    return Color.WHITE;
                }
            }
        }
        catch (Exception exception) {
        }
        return Color.BLACK;
    }

    private static int loadGridAlpha() {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                String string = properties.getProperty("gridAlpha");
                if (string != null && !string.isEmpty()) {
                    return Math.max(0, Math.min(100, Integer.parseInt(string)));
                }
            }
        }
        catch (Exception exception) {
        }
        return 0;
    }

    private static void saveGridAlpha(int alpha) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            File f = new File(SETTINGS_FILE);
            if (f.exists()) {
                properties.load(new FileInputStream(f));
            }
            properties.setProperty("gridAlpha", String.valueOf(alpha));
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static void saveSettingsPosition(Point pos) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            File f = new File(SETTINGS_FILE);
            if (f.exists()) {
                properties.load(new FileInputStream(f));
            }
            properties.setProperty("settingsX", String.valueOf(pos.x));
            properties.setProperty("settingsY", String.valueOf(pos.y));
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static void saveBackgroundColor(Color color) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            properties.setProperty("bgColor", Winllx.colorToHex(color));
            properties.setProperty("textColor", Winllx.getContrastColor(color) == Color.WHITE ? "white" : "black");
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static String colorToHex(Color color) {
        return String.format("#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
    }

    private static Color hexToColor(String string) {
        if (string.startsWith("#")) {
            string = string.substring(1);
        }
        if (string.length() == 6) {
            int n = Integer.parseInt(string.substring(0, 2), 16);
            int n2 = Integer.parseInt(string.substring(2, 4), 16);
            int n3 = Integer.parseInt(string.substring(4, 6), 16);
            return new Color(n, n2, n3);
        }
        return DEFAULT_BG;
    }

    private static void saveProperty(String key, String value) {
        try {
            File file = new File(SETTINGS_FILE).getParentFile();
            if (file != null && !file.exists()) {
                file.mkdirs();
            }
            Properties properties = new Properties();
            File f = new File(SETTINGS_FILE);
            if (f.exists()) {
                properties.load(new FileInputStream(f));
            }
            properties.setProperty(key, value);
            properties.store(new FileOutputStream(SETTINGS_FILE), "Winllx Application Settings");
        }
        catch (Exception exception) {
        }
    }

    private static String loadProperty(String key) {
        try {
            File file = new File(SETTINGS_FILE);
            if (file.exists()) {
                Properties properties = new Properties();
                properties.load(new FileInputStream(file));
                return properties.getProperty(key);
            }
        }
        catch (Exception exception) {
        }
        return null;
    }

    private static void saveBgMode(int mode) {
        saveProperty("bgMode", String.valueOf(mode));
    }

    private static int loadBgMode() {
        String s = loadProperty("bgMode");
        if (s != null && !s.isEmpty()) {
            try { return Integer.parseInt(s); } catch (Exception e) {}
        }
        return 0;
    }

    private static void saveBgImagePath(String path) {
        saveProperty("bgImagePath", path != null ? path : "");
    }

    private static String loadBgImagePath() {
        return loadProperty("bgImagePath");
    }

    private static void saveBgImageOpacity(float opacity) {
        saveProperty("bgImageOpacity", String.valueOf(opacity));
    }

    private static float loadBgImageOpacity() {
        String s = loadProperty("bgImageOpacity");
        if (s != null && !s.isEmpty()) {
            try { return Float.parseFloat(s); } catch (Exception e) {}
        }
        return 1.0f;
    }

    private static void saveBgImageFitMode(int mode) {
        saveProperty("bgImageFitMode", String.valueOf(mode));
    }

    private static void saveGlassWindows(boolean enabled) {
        saveProperty("glassWindows", String.valueOf(enabled));
    }

    private static boolean loadGlassWindows() {
        String s = loadProperty("glassWindows");
        // 未保存过该设置时默认开启毛玻璃（只有明确保存过 false 才关闭）
        return s == null || s.trim().isEmpty() || "true".equalsIgnoreCase(s.trim());
    }

    private static void saveTray(boolean enabled) {
        saveProperty("tray", String.valueOf(enabled));
    }

    private static boolean loadTray() {
        String s = loadProperty("tray");
        return s == null || "true".equalsIgnoreCase(s);
    }

    /** 开机自启动（随系统启动自动运行并添加托盘图标） */
    private static void saveAutoStart(boolean enabled) {
        saveProperty("autoStart", String.valueOf(enabled));
    }

    private static boolean loadAutoStart() {
        String s = loadProperty("autoStart");
        return "true".equalsIgnoreCase(s);
    }

    /**
     * 设置开机自启动：写入/删除 HKCU Run 键。
     * 命令使用 javaw 静默启动当前程序（含 classpath），避免弹出控制台窗口。
     */
    private static void applyAutoStart(boolean enable) {
        saveAutoStart(enable);
        try {
            java.util.prefs.Preferences runKey = java.util.prefs.Preferences.userRoot()
                    .node("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
            if (enable) {
                String javaBin = System.getProperty("java.home") + "\\bin\\javaw.exe";
                // 用程序目录作为工作目录，保证开机启动后配置文件/图标/语言文件路径仍然有效
                String dir = System.getProperty("user.dir");
                if (dir == null || dir.trim().isEmpty()) dir = ".";
                // cmd /c start 指定工作目录 + javaw 静默启动，避免控制台窗口弹出
                // （--enable-native-access 是 FFM 调 Win32 读电池需要的，见 win32PowerStatus）
                String cmd = "cmd.exe /c start \"Winllx\" /d \"" + dir + "\" \"" + javaBin
                        + "\" --enable-native-access=ALL-UNNAMED -cp \"" + dir + "\" app.Winllx";
                runKey.put("Winllx", cmd);
                System.out.println("[Winllx] 已开启开机自启动: " + cmd);
            } else {
                runKey.remove("Winllx");
                System.out.println("[Winllx] 已关闭开机自启动");
            }
        } catch (Throwable t) {
            System.err.println("[Winllx] 设置开机自启动失败: " + t.getMessage());
        }
    }

    private static boolean isAutoStartEnabled() {
        try {
            java.util.prefs.Preferences runKey = java.util.prefs.Preferences.userRoot()
                    .node("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
            return runKey.get("Winllx", null) != null;
        } catch (Throwable t) {
            return loadAutoStart();
        }
    }

    // ===== 液态玻璃按钮效果参数（默认值 = 液态玻璃应用 web/glass 里的演示预览，保证按钮与之完全一致）=====
    private static final float LG_BLUR = 0.5f;    // 模糊系数（演示默认，实际 blur=(4+0.5*32)px=20px）
    private static final float LG_SAT = 140f;     // 饱和度（%）
    private static final float LG_DISP = 100f;    // 位移缩放
    private static final float LG_ABER = 2f;      // 色差强度
    private static final float LG_ELAST = 0f;     // 弹性系数
    private static final float LG_ACT = 200f;     // 激活区域（px）
    private static final float LG_SCALE = 0.96f;  // 按下缩放
    private static final String LG_MODE = "standard"; // 折射模式：standard / polar / prominent / shader
    private static final boolean LG_OVERLIGHT = false; // 亮底加深
    private static final float LG_RADIUS = 32f;   // 圆角

    private static float loadLgFloat(String key, float def) {
        String s = loadProperty(key);
        if (s == null || s.isEmpty()) return def;
        try { return Float.parseFloat(s); } catch (Exception e) { return def; }
    }
    private static String loadLgString(String key, String def) {
        String s = loadProperty(key);
        return (s == null || s.isEmpty()) ? def : s;
    }
    private static boolean loadLgBool(String key, boolean def) {
        String s = loadProperty(key);
        return (s == null || s.isEmpty()) ? def : Boolean.parseBoolean(s);
    }
    private static float lgBlur() { return loadLgFloat("lgBlurAmount", LG_BLUR); }
    private static float lgSat() { return loadLgFloat("lgSaturation", LG_SAT); }
    private static float lgDisp() { return loadLgFloat("lgDisplacementScale", LG_DISP); }
    private static float lgAber() { return loadLgFloat("lgAberrationIntensity", LG_ABER); }
    private static float lgElast() { return loadLgFloat("lgElasticity", LG_ELAST); }
    private static float lgAct() { return loadLgFloat("lgActivationZone", LG_ACT); }
    private static float lgScale() { return loadLgFloat("lgActiveScale", LG_SCALE); }
    private static String lgMode() { return loadLgString("lgMode", LG_MODE); }
    private static boolean lgOverLight() { return loadLgBool("lgOverLight", LG_OVERLIGHT); }
    private static float lgRadius() { return loadLgFloat("lgCornerRadius", LG_RADIUS); }

    /** 解析 setLiquidGlass 桥接 payload 并持久化每个参数（缺失的字段保持原值） */
    private static void applyLiquidGlass(String payloadStr) {
        if (payloadStr == null) return;
        Float b = _jsonFloat(payloadStr, "blurAmount");
        if (b != null) saveProperty("lgBlurAmount", String.valueOf(b));
        Float s = _jsonFloat(payloadStr, "saturation");
        if (s != null) saveProperty("lgSaturation", String.valueOf(s));
        Float d = _jsonFloat(payloadStr, "displacementScale");
        if (d != null) saveProperty("lgDisplacementScale", String.valueOf(d));
        Float a = _jsonFloat(payloadStr, "aberrationIntensity");
        if (a != null) saveProperty("lgAberrationIntensity", String.valueOf(a));
        Float e = _jsonFloat(payloadStr, "elasticity");
        if (e != null) saveProperty("lgElasticity", String.valueOf(e));
        Float z = _jsonFloat(payloadStr, "activationZone");
        if (z != null) saveProperty("lgActivationZone", String.valueOf(z));
        Float as = _jsonFloat(payloadStr, "activeScale");
        if (as != null) saveProperty("lgActiveScale", String.valueOf(as));
        Float cr = _jsonFloat(payloadStr, "cornerRadius");
        if (cr != null) saveProperty("lgCornerRadius", String.valueOf(cr));
        String md = _jsonString(payloadStr, "mode");
        if (md != null) saveProperty("lgMode", md);
        Boolean ol = _jsonBool(payloadStr, "overLight");
        if (ol != null) saveProperty("lgOverLight", String.valueOf(ol));

        // 实时推送改动到所有已打开的便笺窗口（便笺 JS 端 applyLiquidGlassParams 接收并更新按钮）
        NotesModule.pushLiquidGlassToAll(payloadStr);
        // HTML 主界面同样要跟着变（滑块拖动时实时生效）
        Winllx.refreshDesktop();
    }

    private static String _jsonString(String json, String key) {
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("\\\"" + key + "\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"");
        java.util.regex.Matcher m = p.matcher(json);
        if (m.find()) return m.group(1);
        return null;
    }

    private static Boolean _jsonBool(String json, String key) {
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("\\\"" + key + "\\\"\\s*:\\s*(true|false)");
        java.util.regex.Matcher m = p.matcher(json);
        if (m.find()) return Boolean.parseBoolean(m.group(1));
        return null;
    }

    private static Float _jsonFloat(String json, String key) {
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("\\\"" + key + "\\\"\\s*:\\s*(\\-?\\d+(\\.\\d+)?)");
        java.util.regex.Matcher m = p.matcher(json);
        if (m.find()) {
            try { return Float.parseFloat(m.group(1)); } catch (Exception ex) { return null; }
        }
        return null;
    }

    /** 根据设置启用/停用系统托盘图标（运行时即时生效） */
    private static void updateTray(boolean enable) {
        trayEnabled = enable;
        if (enable) {
            if (trayIcon == null) initSystemTray();
        } else if (trayIcon != null) {
            try { SystemTray.getSystemTray().remove(trayIcon); } catch (Exception ignore) {}
            trayIcon = null;
        }
    }

    private static int loadBgImageFitMode() {
        String s = loadProperty("bgImageFitMode");
        if (s != null && !s.isEmpty()) {
            try { return Integer.parseInt(s); } catch (Exception e) {}
        }
        return 0;
    }

    // ===== 字体（供 SettingsFrame.HostActions 调用） =====
    private static final String DEFAULT_FONT_FAMILY = "微软雅黑";
    private static final int DEFAULT_FONT_SIZE = 14;

    private static String loadFontFamily() {
        String s = loadProperty("fontFamily");
        return (s == null || s.isEmpty()) ? DEFAULT_FONT_FAMILY : s;
    }
    private static int loadFontSize() {
        String s = loadProperty("fontSize");
        if (s != null && !s.isEmpty()) {
            try { return Math.max(10, Math.min(28, Integer.parseInt(s))); } catch (Exception e) {}
        }
        return DEFAULT_FONT_SIZE;
    }

    /** 递归删除文件/目录；cnt[0]=成功删除数，cnt[1]=总条目数。 */
    private static void deleteRecursively(File f, int[] cnt) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File c : children) deleteRecursively(c, cnt);
        }
        cnt[1]++;
        if (f.delete()) cnt[0]++;
    }

    /** 读取保存的壁纸：解码放后台线程，避免拖慢主窗口启动；读完让 HTML 端重新拉状态。 */
    private static void loadBackgroundImageAsync() {
        final String path = Winllx.loadBgImagePath();
        if (path == null || path.isEmpty()) return;
        new Thread(() -> {
            try {
                File imgFile = new File(path);
                if (!imgFile.exists()) return;
                final BufferedImage img = ImageIO.read(imgFile);
                if (img == null) return;
                SwingUtilities.invokeLater(() -> {
                    backgroundImage = img;
                    bgImagePath = path;
                    Winllx.syncTextColorForImage(img);
                    Winllx.refreshDesktop();
                });
            } catch (Exception exception) {
            }
        }, "bg-image-load").start();
    }

    private static BufferedImage selectBackgroundImage(JFrame parent) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(LangManager.getString("dialog.image.select"));
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "Image Files (jpg, png, gif, bmp, jpeg, wbmp)",
                "jpg", "png", "gif", "bmp", "jpeg", "wbmp");
        fileChooser.setFileFilter(filter);
        int result = fileChooser.showOpenDialog(parent);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                BufferedImage img = ImageIO.read(selectedFile);
                if (img != null) {
                    bgImagePath = selectedFile.getAbsolutePath();
                    return img;
                } else {
                    JOptionPane.showMessageDialog(parent,
                            LangManager.getString("msg.image.load.error"),
                            LangManager.getString("dialog.error"),
                            JOptionPane.ERROR_MESSAGE);
                }
            }
            catch (Exception ex) {
                JOptionPane.showMessageDialog(parent,
                        LangManager.getString("msg.image.load.error"),
                        LangManager.getString("dialog.error"),
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        return null;
    }

    private static Color getAverageColor(BufferedImage image) {
        if (image == null) return Color.GRAY;
        long sumR = 0, sumG = 0, sumB = 0;
        int w = image.getWidth();
        int h = image.getHeight();
        int step = Math.max(1, (int) Math.sqrt(w * h / 10000.0));
        int count = 0;
        for (int y = 0; y < h; y += step) {
            for (int x = 0; x < w; x += step) {
                int rgb = image.getRGB(x, y);
                sumR += (rgb >> 16) & 0xFF;
                sumG += (rgb >> 8) & 0xFF;
                sumB += rgb & 0xFF;
                count++;
            }
        }
        if (count == 0) return Color.GRAY;
        return new Color((int)(sumR / count), (int)(sumG / count), (int)(sumB / count));
    }

    private static void syncTextColorForImage(BufferedImage image) {
        if (image == null) return;
        new Thread(() -> {
            Color avg = Winllx.getAverageColor(image);
            SwingUtilities.invokeLater(() -> syncTextColorForImage(avg));
        }).start();
    }

    private static void syncTextColorForImage(Color avgColor) {
        if (avgColor == null) return;
        desktopTextColor = Winllx.getContrastColor(avgColor);
        saveProperty("textColor", desktopTextColor == Color.WHITE ? "white" : "black");
        Winllx.refreshDesktop();
    }

    private static void initSystemTray() {
        trayEnabled = loadTray();
        if (!trayEnabled || !SystemTray.isSupported()) {
            return;
        }
        SystemTray systemTray = SystemTray.getSystemTray();

        // 托盘图标 = 主窗口当前图标主题（跟随 设置-图标 主题切换），失败才回退旧图标
        Image image = WinllxIcon.getCurrentIconImage();
        if (image == null) {
            image = Toolkit.getDefaultToolkit().getImage(TRAY_ICON_PATH);
        }

        // 托盘菜单改用 Swing JPopupMenu：AWT 原生 PopupMenu/MenuItem 在 JBR 环境下取不到含中文的字体，
        // 菜单文字会渲染成方块。JPopupMenu 与主界面走同一套字体渲染，中文正常显示。
        final SystemTray finalTray = systemTray;
        final JPopupMenu popupMenu = buildTrayMenu(finalTray);

        trayIcon = new TrayIcon(image, APP_TITLE);
        trayIcon.setImageAutoSize(true);

        trayIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                if (e.isPopupTrigger()) showTrayMenu(popupMenu);
            }

            @Override
            public void mouseReleased(java.awt.event.MouseEvent e) {
                if (e.isPopupTrigger() || e.getButton() == java.awt.event.MouseEvent.BUTTON3) {
                    showTrayMenu(popupMenu);
                }
            }
        });
        trayIcon.addActionListener(actionEvent -> Winllx.setMainVisible(true));
        try {
            systemTray.add(trayIcon);
        }
        catch (AWTException aWTException) {
            System.err.println(LangManager.getString("msg.tray.error"));
        }
    }

    /** 构建托盘 Swing 菜单，字体与主界面一致，避免 AWT 原生菜单中文显示为方块 */
    private static JPopupMenu buildTrayMenu(SystemTray systemTray) {
        Font menuFont = new Font(loadFontFamily(), Font.PLAIN, loadFontSize());
        JPopupMenu menu = new JPopupMenu();
        menu.setFont(menuFont);

        menu.add(createTrayItem(LangManager.getString("tray.open"), menuFont, e -> Winllx.setMainVisible(true)));
        menu.addSeparator();
        menu.add(createTrayItem(LangManager.getString("tray.settings"), menuFont, e -> Winllx.openSettings()));
        menu.addSeparator();
        menu.add(createTrayItem(LangManager.getString("tray.exit"), menuFont, e -> {
            if (trayIcon != null) systemTray.remove(trayIcon);
            // 退出前统一清理 JCEF，确保 jcef_helper.exe 子进程被终止
            try {
                Class<?> gbp = Class.forName("ui.GlassBrowserPanel");
                gbp.getMethod("shutdownJcef").invoke(null);
            } catch (Throwable ignore) {}
            System.exit(0);
        }));
        return menu;
    }

    private static JMenuItem createTrayItem(String text, Font font, ActionListener action) {
        JMenuItem item = new JMenuItem(text);
        item.setFont(font);
        item.addActionListener(action);
        return item;
    }

    /** 在鼠标位置弹出托盘菜单；invoker 设为自身，保证无主窗口时也能显示并在点击别处后收起 */
    private static void showTrayMenu(JPopupMenu menu) {
        if (menu == null) return;
        try {
            java.awt.Point p = java.awt.MouseInfo.getPointerInfo().getLocation();
            menu.setLocation(p);
            menu.setInvoker(menu);
            menu.setVisible(true);
            SwingUtilities.invokeLater(menu::requestFocusInWindow);
        }
        catch (Throwable t) {
            System.err.println("[Winllx] 托盘菜单弹出失败: " + t.getMessage());
        }
    }

    /** 刷新托盘图标（图标主题切换时调用），保持与窗口图标一致 */
    private static void refreshTrayIcon() {
        if (trayIcon == null) return;
        Image image = WinllxIcon.getCurrentIconImage();
        if (image != null) {
            trayIcon.setImage(image);
        }
    }

    private static void setSystemVolume(int n) {
        cachedVolume = Math.max(0, Math.min(100, n));
        ui.SystemVolumeControl.setVolume(cachedVolume);
    }

    private static int getSystemVolume() {
        return cachedVolume;
    }

    /** 后台线程刷新系统音量缓存（不阻塞 EDT）。 */
    public static void refreshSystemVolumeCache() {
        cachedVolume = ui.SystemVolumeControl.getVolume();
    }

    public static void showNotification(String string, String string2) {
        if (trayIcon != null) {
            trayIcon.displayMessage(string, string2, TrayIcon.MessageType.INFO);
        }
    }

    /* ============================================================
       HTML 桌面外壳 ↔ Java 的 /api 通道
       ============================================================ */

    /** /api/* 入口：桌面外壳由此取状态、开模块。 */
    private static GlassAssetServer.ApiResponse handleApi(String path,
                                                           java.util.Map<String, String> q,
                                                           String method, String body) {
        switch (path) {
            case "/state":     return GlassAssetServer.ApiResponse.json(Winllx.buildDesktopStateJson());
            case "/status":    return GlassAssetServer.ApiResponse.json(Winllx.buildStatusJson());
            case "/wallpaper": return Winllx.wallpaperApi();
            case "/icon":      return Winllx.iconApi(q);
            case "/action":    return Winllx.actionApi(q);
            case "/activate":  return Winllx.activateApi();
            case "/netcheck":  return Winllx.netcheckApi();
            case "/volume":    return Winllx.volumeApi(q);
            default:           return GlassAssetServer.ApiResponse.notFound("no such api: " + path);
        }
    }

    /** /api/activate：被"重复启动"的新实例调用，把已运行的主窗口唤到前台。 */
    private static GlassAssetServer.ApiResponse activateApi() {
        SwingUtilities.invokeLater(() -> {
            try {
                if (mainFrame == null) return;
                if (mainFrame.getExtendedState() == JFrame.ICONIFIED) {
                    mainFrame.setExtendedState(JFrame.NORMAL);
                }
                mainFrame.setVisible(true);
                mainFrame.toFront();
                mainFrame.requestFocus();
            } catch (Throwable ignored) {}
        });
        return GlassAssetServer.ApiResponse.json("{\"ok\":true}");
    }

    /** 桌面外壳所需的全部状态（背景、网格几何、文案、文字色）。 */
    private static String buildDesktopStateJson() {
        StringBuilder sb = new StringBuilder();
        sb.append('{');
        sb.append("\"lang\":").append(_q(LangManager.getCurrentLang())).append(',');
        sb.append("\"labels\":{");
        sb.append("\"note\":").append(_q(LangManager.getString("module.note"))).append(',');
        sb.append("\"calc\":").append(_q(LangManager.getString("module.calc"))).append(',');
        sb.append("\"file\":").append(_q(LangManager.getString("module.file"))).append(',');
        sb.append("\"mind\":").append(_q(LangManager.getString("module.mind"))).append(',');
        sb.append("\"sysmon\":").append(_q(LangManager.getString("module.sysmon"))).append(',');
        sb.append("\"board\":").append(_q(LangManager.getString("module.board"))).append(',');
        sb.append("\"clock\":").append(_q(LangManager.getString("module.clock"))).append(',');
        sb.append("\"weather\":").append(_q(LangManager.getString("module.weather"))).append(',');
        sb.append("\"store\":").append(_q(LangManager.getString("module.store"))).append(',');
        sb.append("\"browser\":").append(_q(LangManager.getString("module.browser"))).append(',');
        sb.append("\"settings\":").append(_q(LangManager.getString("btn.settings"))).append(',');
        sb.append("\"exit\":").append(_q(LangManager.getString("btn.exit"))).append(',');
        sb.append("\"minimize\":").append(_q(LangManager.getString("btn.minimize"))).append(',');
        sb.append("\"glass\":").append(_q("液态玻璃")).append(',');
        sb.append("\"todo\":").append(_q(LangManager.getString("module.todo"))).append(',');
        sb.append("\"clipboard\":").append(_q(LangManager.getString("module.clipboard"))).append(',');
        sb.append("\"calendar\":").append(_q(LangManager.getString("module.calendar")));
        sb.append("},");
        Color bg = desktopHolder != null ? desktopHolder.getBackground() : Winllx.loadBackgroundColor();
        sb.append("\"bgColor\":").append(_q(colorToHex(bg))).append(',');
        sb.append("\"hasImage\":").append(backgroundImage != null).append(',');
        sb.append("\"imageVersion\":").append(_q(Winllx.imageVersion())).append(',');
        sb.append("\"bgFit\":").append(bgImageFit).append(',');
        sb.append("\"bgOpacity\":").append(bgImageOpacity).append(',');
        sb.append("\"textColor\":").append(_q(colorToHex(desktopTextColor))).append(',');
        sb.append("\"gridAlpha\":").append(gridAlphaShown).append(',');
        sb.append("\"cellW\":").append(GRID_CELL_WIDTH).append(',');
        sb.append("\"cellH\":").append(GRID_CELL_HEIGHT).append(',');
        sb.append("\"padX\":").append(GRID_PADDING_X).append(',');
        sb.append("\"padY\":").append(GRID_PADDING_Y).append(',');
        sb.append("\"maximized\":").append(!windowedMode).append(',');
        sb.append("\"version\":").append(_q("Winllx 2.3.1"));
        sb.append('}');
        return sb.toString();
    }

    /** 右下角状态名片轮询用：在线状态 + 音量档位 + 电池电量/充电。
        （网络格数由页面侧按连接质量算，Java 这边只给"通不通"的真实探测结果。） */
    private static String buildStatusJson() {
        return "{\"online\":" + netOnline
                + ",\"volume\":" + cachedVolume + ",\"volumeLevel\":" + volumeLevel()
                + ",\"muted\":" + cachedVolumeMuted
                + ",\"batteryLevel\":" + battPct + ",\"charging\":" + battCharging + "}";
    }

    /** 音量档：0 = 静音（0.svg），1/2/3 = 依次多一道声波。 */
    private static int volumeLevel() {
        if (cachedVolumeMuted) return 0;
        if (cachedVolume <= 0) return 0;
        if (cachedVolume <= 33) return 1;
        if (cachedVolume <= 66) return 2;
        return 3;
    }

    /** 壁纸版本号（文件修改时间），用于 HTML 端 URL 去缓存。 */
    private static String imageVersion() {
        if (bgImagePath == null || bgImagePath.isEmpty()) return "";
        File f = new File(bgImagePath);
        return f.exists() ? String.valueOf(f.lastModified()) : "";
    }

    /** 直接回原图字节（比 base64 走 JS 桥接更省内存、浏览器还能自己解码缩放）。 */
    private static GlassAssetServer.ApiResponse wallpaperApi() {
        byte[] data = null;
        String ct = "image/jpeg";
        if (bgImagePath != null && !bgImagePath.isEmpty()) {
            File f = new File(bgImagePath);
            if (f.isFile()) {
                try {
                    data = java.nio.file.Files.readAllBytes(f.toPath());
                    ct = Winllx.guessImageMime(f.getName());
                } catch (Throwable ignore) {}
            }
        }
        if (data == null && backgroundImage != null) {
            try {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                ImageIO.write(backgroundImage, "jpg", bos);
                data = bos.toByteArray();
                ct = "image/jpeg";
            } catch (Throwable ignore) {}
        }
        if (data == null) return GlassAssetServer.ApiResponse.notFound("no wallpaper");
        return GlassAssetServer.ApiResponse.bytes(data, ct);
    }

    private static String guessImageMime(String name) {
        String n = name == null ? "" : name.toLowerCase();
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".bmp")) return "image/bmp";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".svg")) return "image/svg+xml";
        return "image/jpeg";
    }

    /* ===================== 右下角名片的三个图标 =====================
       /api/icon?type=wifi|volume|battery&level=N&theme=light|dark[&charging=1]
         - wifi   ：icon/wifi-icons/<theme>-theme/ 下的 no.svg / 1 / 2 / 3 / full.svg
         - volume ：icon/volume-icons/<theme>-theme/ 下的 0.svg(静音) / 1 / 2 / 3
         - battery：不用现成图标，全部按"实际电量百分比"实时绘制成 SVG（见 drawBatterySvg）。
                    level 就是实际电量 0~100；charging=1 时在电量格上叠一枚闪电。
                    （原版电池图标只有 charging.svg 和少数几档，画不出任意电量，故自绘。）
       ================================================================= */

    /** 当前实际电量百分比（0~100）与是否充电中，由 pollBattery 定时刷新。 */
    private static volatile int battPct = 100;
    private static volatile boolean battCharging = false;

    private static GlassAssetServer.ApiResponse iconApi(java.util.Map<String, String> q) {
        String type = q.get("type") == null ? "wifi" : q.get("type");
        String theme = "light".equals(q.get("theme")) ? "light" : "dark";
        int level = 0;
        try { level = Integer.parseInt(q.get("level") == null ? "0" : q.get("level")); } catch (Throwable ignore) {}

        switch (type) {
            case "volume": {
                int lv = Math.max(0, Math.min(3, level));
                return serveIcon("icon/volume-icons/" + theme + "-theme/" + lv + ".svg");
            }
            case "battery": {
                // 全部实时绘制：电量格宽度按实际百分比；charging=1 时叠一个闪电。
                boolean charging = level == -1
                        || "1".equals(q.get("charging"))
                        || "true".equalsIgnoreCase(q.get("charging"));
                String svg = drawBatterySvg(level, theme, charging);
                return GlassAssetServer.ApiResponse.bytes(svg.getBytes(java.nio.charset.StandardCharsets.UTF_8),
                        "image/svg+xml; charset=utf-8");
            }
            default: {
                int lv = Math.max(0, Math.min(4, level));
                String[] files = {"no.svg", "1.svg", "2.svg", "3.svg", "full.svg"};
                return serveIcon("icon/wifi-icons/" + theme + "-theme/" + files[lv]);
            }
        }
    }

    /** 回工程里的某个 SVG 文件；缺文件返回 404（前端 keep 上一次的图）。 */
    private static GlassAssetServer.ApiResponse serveIcon(String rel) {
        File f = Winllx.findProjectFile(rel);
        try {
            byte[] b = java.nio.file.Files.readAllBytes(f.toPath());
            return GlassAssetServer.ApiResponse.bytes(b, "image/svg+xml; charset=utf-8");
        } catch (Throwable t) {
            return GlassAssetServer.ApiResponse.notFound("icon missing: " + rel);
        }
    }

    /**
     * 按"实际电量百分比"实时绘制电池图标（原版图标画不出任意电量，故自绘）。
     * 外框 / 正极触点沿用 charging.svg 的坐标与线宽；电量格宽度 = 48 × pct%：
     *   0% → 空、25% → 12px、50% → 24px、75% → 36px、100% → 48px。
     * charging=true 时把 charging.svg 里的闪电叠上去（浅底白描边、深底深描边）。
     */
    private static String drawBatterySvg(int pctIn, String theme, boolean charging) {
        int pct = Math.max(0, Math.min(100, pctIn));
        boolean light = "light".equals(theme);
        String color = light ? "#111111" : "#FFFFFF";
        long w = Math.round(48.0 * pct / 100.0);   // 满格 48px（x 从 24 到 72）
        StringBuilder sb = new StringBuilder();
        sb.append("<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\" width=\"100\" height=\"100\">");
        sb.append("<rect x=\"20\" y=\"32\" width=\"56\" height=\"36\" rx=\"7\" fill=\"none\" stroke=\"")
          .append(color).append("\" stroke-width=\"4\" />");
        sb.append("<path d=\"M 76 44 L 80 44 L 80 56 L 76 56\" fill=\"none\" stroke=\"")
          .append(color).append("\" stroke-width=\"4\" stroke-linejoin=\"round\" />");
        if (w > 0) {
            sb.append("<rect x=\"24\" y=\"36\" width=\"").append(w)
              .append("\" height=\"28\" rx=\"4\" fill=\"").append(color).append("\" />");
        }
        if (charging) {
            // 闪电：先用与底色相反的粗描边把电量格"挖"出来，再填绿色（坐标取自 charging.svg）
            String halo = light ? "#FFFFFF" : "#1E1E1E";
            String bolt = "M 52 34 L 42 52 L 48 52 L 48 66 L 58 48 L 52 48 Z";
            sb.append("<path d=\"").append(bolt).append("\" fill=\"").append(halo)
              .append("\" stroke=\"").append(halo).append("\" stroke-width=\"8\" stroke-linejoin=\"round\" />");
            sb.append("<path d=\"").append(bolt).append("\" fill=\"#22C55E\" stroke=\"#22C55E\"")
              .append(" stroke-width=\"2\" stroke-linejoin=\"round\" />");
        }
        sb.append("</svg>");
        return sb.toString();
    }

    /** 在工程根（user.dir / 上级目录 / class 所在目录向上若干层）里找文件。 */
    private static File findProjectFile(String rel) {
        File base = new File(System.getProperty("user.dir", "."));
        File f = new File(base, rel);
        if (f.isFile()) return f;
        File parent = base.getParentFile();
        if (parent != null) {
            File f2 = new File(parent, rel);
            if (f2.isFile()) return f2;
        }
        try {
            java.net.URL loc = Winllx.class.getProtectionDomain().getCodeSource().getLocation();
            File d = new File(java.net.URLDecoder.decode(loc.getPath(), "UTF-8"));
            d = d.isDirectory() ? d : d.getParentFile();
            for (int i = 0; i < 5 && d != null; i++, d = d.getParentFile()) {
                File f3 = new File(d, rel);
                if (f3.isFile()) return f3;
            }
        } catch (Throwable ignore) {}
        return f;
    }

    /** 桌面按钮点击 → 打开对应模块（统一回 EDT 执行，Swing 调用都在 EDT 上）。 */
    private static GlassAssetServer.ApiResponse actionApi(java.util.Map<String, String> q) {
        String name = q.get("name");
        if (name == null || name.isEmpty()) {
            return GlassAssetServer.ApiResponse.json("{\"ok\":false,\"msg\":\"missing name\"}");
        }
        SwingUtilities.invokeLater(() -> Winllx.runDesktopAction(name));
        return GlassAssetServer.ApiResponse.json("{\"ok\":true}");
    }

    private static void runDesktopAction(String name) {
        switch (name) {
            case "note":       new NotesModule(); break;
            case "calc":       new CalculatorModule(); break;
            case "file":       new FileManagerModule(); break;
            case "mind":       new MindReaderModule(); break;
            case "sysmon":     new SystemMonitorModule(); break;
            case "board":      new BoardModule(); break;
            case "clock":      new ClockModule(); break;
            case "weather":    new WeatherModule(); break;
            case "store":      new AppStoreModule(); break;
            case "browser":    new BrowserModule(); break;
            case "settings":   Winllx.openSettings(); break;
            case "exit":       new ExitAction(); break;
            case "minimize":   Winllx.setMainVisible(false); break;
            case "glass":      new LiquidGlassModule(); break;
            case "todo":       new TodoModule(); break;
            case "clipboard":  new ClipboardModule(); break;
            case "calendar":   new CalendarModule(); break;
            default: break;
        }
    }

    /* ===================== 桌面右下角状态轮询 =====================
       这里**不许再起子进程**：原来电池与 Wi-Fi 格数是靠 `-WindowStyle Hidden` 的 PowerShell
       读 WinRT，安全软件的系统加固会把它判成"隐藏执行PowerShell"，每隔十几秒弹一次拦截框
       （发起程序 java.exe → 操作目标 powershell.exe）。
       现在：电池直接调 kernel32（JDK 的 FFM，无子进程）；网络格数交给页面侧的
       navigator.connection；Java 只保留一个纯 socket 的在线探测。 */

    private static void startNetworkPoller() {
        java.util.concurrent.ScheduledExecutorService se =
                java.util.concurrent.Executors.newScheduledThreadPool(3, r -> {
                    Thread t = new Thread(r, "desktop-status-poll");
                    t.setDaemon(true);
                    return t;
                });
        se.scheduleWithFixedDelay(Winllx::pollOnline, 0, 5, java.util.concurrent.TimeUnit.SECONDS);
        se.scheduleWithFixedDelay(Winllx::pollVolume, 0, 2, java.util.concurrent.TimeUnit.SECONDS);
        se.scheduleWithFixedDelay(Winllx::pollBattery, 2, 10, java.util.concurrent.TimeUnit.SECONDS);
    }

    /** 音量 + 静音状态（volctl.exe 原始串：VOL::60 或 MUTED::60）。 */
    private static void pollVolume() {
        try {
            ui.SystemVolumeControl.init();
            String raw = ui.SystemVolumeControl.getRawStatus();
            if (raw == null) return;
            if (raw.startsWith("MUTED::")) {
                cachedVolumeMuted = true;
                cachedVolume = Integer.parseInt(raw.substring(7).trim());
            } else if (raw.startsWith("VOL::")) {
                cachedVolumeMuted = false;
                cachedVolume = Integer.parseInt(raw.substring(5).trim());
            }
        } catch (Throwable ignore) {}
    }

    /** 每 10 秒读一次实际电量百分比与是否接电源（直接调 Win32，无子进程）。 */
    private static void pollBattery() {
        int[] st = Winllx.win32PowerStatus();
        if (st == null) return;
        if (st[1] == 128) {            // BatteryFlag=128：本机没有电池（台式机）→ 与旧实现一致：满电 + 已接电源
            battPct = 100;
            battCharging = true;
            return;
        }
        if (st[0] >= 0) battPct = Math.max(0, Math.min(100, st[0]));
        battCharging = (st[2] == 1);   // ACLineStatus：1 = 已接电源（充电/满电）
    }

    /* ---------- Win32 GetSystemPowerStatus：经 JDK 的 FFM 直接调用 ----------
       替代原来 `-WindowStyle Hidden` 的 PowerShell（那条会被安全软件判成"隐藏执行PowerShell"）。
       结构体 SYSTEM_POWER_STATUS：4 个 BYTE + 2 个 DWORD，共 12 字节。 */
    private static java.lang.invoke.MethodHandle powerStatusFn;
    private static java.lang.foreign.MemoryLayout powerStatusLayout;

    /** 返回 {电量百分比(-1 表示未知), BatteryFlag, ACLineStatus}；读不到返回 null。 */
    private static int[] win32PowerStatus() {
        try {
            if (powerStatusFn == null) {
                java.lang.foreign.Linker linker = java.lang.foreign.Linker.nativeLinker();
                // 注意：kernel32 的符号不在 defaultLookup 里，必须显式按库名查（实测过）
                java.lang.foreign.SymbolLookup lib = java.lang.foreign.SymbolLookup
                        .libraryLookup("kernel32", java.lang.foreign.Arena.global());
                powerStatusLayout = java.lang.foreign.MemoryLayout.structLayout(
                        java.lang.foreign.ValueLayout.JAVA_BYTE.withName("ACLineStatus"),
                        java.lang.foreign.ValueLayout.JAVA_BYTE.withName("BatteryFlag"),
                        java.lang.foreign.ValueLayout.JAVA_BYTE.withName("BatteryLifePercent"),
                        java.lang.foreign.ValueLayout.JAVA_BYTE.withName("SystemStatusFlag"),
                        java.lang.foreign.ValueLayout.JAVA_INT.withName("BatteryLifeTime"),
                        java.lang.foreign.ValueLayout.JAVA_INT.withName("BatteryFullLifeTime"));
                powerStatusFn = linker.downcallHandle(lib.find("GetSystemPowerStatus").orElseThrow(),
                        java.lang.foreign.FunctionDescriptor.of(
                                java.lang.foreign.ValueLayout.JAVA_INT, java.lang.foreign.ValueLayout.ADDRESS));
            }
            try (java.lang.foreign.Arena arena = java.lang.foreign.Arena.ofConfined()) {
                java.lang.foreign.MemorySegment seg = arena.allocate(powerStatusLayout);
                if ((int) powerStatusFn.invokeExact(seg) == 0) return null;      // Win32 调用失败
                int pct = seg.get(java.lang.foreign.ValueLayout.JAVA_BYTE, 2) & 0xFF;   // 255 = 未知
                int flag = seg.get(java.lang.foreign.ValueLayout.JAVA_BYTE, 1) & 0xFF;
                int ac = seg.get(java.lang.foreign.ValueLayout.JAVA_BYTE, 0) & 0xFF;
                return new int[]{ pct == 255 ? -1 : pct, flag, ac };
            }
        } catch (Throwable t) {
            return null;
        }
    }

    private static void pollOnline() {
        boolean up;
        try (java.net.Socket s = new java.net.Socket()) {
            s.connect(new java.net.InetSocketAddress("www.baidu.com", 443), 1200);
            up = true;
        } catch (Throwable t) {
            up = false;
        }
        netOnline = up;
    }

    /* ===================== 音量调节（右下角音量图标拖条） =====================
       /api/volume?v=0..100   —— 页面拖动竖直滑块 / 输入数值时调用
       /api/volume?toggle=1   —— 点音量名片顶部图标：切换系统静音（音量为 0 时不操作）
       都走 SystemVolumeControl（lib/volctl.exe 的 Core Audio IAudioEndpointVolume），不起任何子进程。 */
    private static GlassAssetServer.ApiResponse volumeApi(java.util.Map<String, String> q) {
        String raw = q == null ? null : q.get("v");
        if (raw == null) raw = q == null ? null : q.get("level");
        String toggle = q == null ? null : q.get("toggle");

        if (toggle != null && !toggle.isEmpty()) {
            // 音量为 0 时不操作：静音一个本来就是 0 的通道没有意义
            if (cachedVolume <= 0) {
                return GlassAssetServer.ApiResponse.json("{\"ok\":false,\"reason\":\"volume-zero\","
                        + "\"muted\":false,\"volume\":0,\"volumeLevel\":0}");
            }
            boolean wantMute = !cachedVolumeMuted;
            ui.SystemVolumeControl.setMute(wantMute);
            cachedVolumeMuted = wantMute;
            return GlassAssetServer.ApiResponse.json("{\"ok\":true,\"muted\":" + cachedVolumeMuted
                    + ",\"volume\":" + cachedVolume + ",\"volumeLevel\":" + volumeLevel() + "}");
        }

        if (raw == null) {
            return GlassAssetServer.ApiResponse.json("{\"ok\":false,\"muted\":" + cachedVolumeMuted
                    + ",\"volume\":" + cachedVolume
                    + ",\"volumeLevel\":" + volumeLevel() + "}");   // 不带参数 = 只查询当前值
        }
        int v;
        try {
            v = Integer.parseInt(raw.trim());
        } catch (Throwable t) {
            return GlassAssetServer.ApiResponse.error("bad volume: " + raw);
        }
        if (v > 0 && cachedVolumeMuted) ui.SystemVolumeControl.setMute(false);   // 调到有声 = 顺带解除静音
        Winllx.setSystemVolume(v);            // 内部已 clamp 到 0..100；async + 去抖，拖动不会刷爆进程
        if (v > 0) cachedVolumeMuted = false;
        // 这里不再回读系统值（读一次要起一个 volctl.exe，拖动时太浪费）：按刚写入的值回报，
        // 真值交给每 2 秒的 pollVolume 校准。
        return GlassAssetServer.ApiResponse.json("{\"ok\":true,\"muted\":" + cachedVolumeMuted
                + ",\"volume\":" + cachedVolume + ",\"volumeLevel\":" + volumeLevel() + "}");
    }

    /* ===================== 联网检测（点击右下角联网图标时调用） =====================
       Java 完全能做联网操作（java.net：Socket / HttpURLConnection / HttpClient）——
       程序里天气模块、壁纸下载本来就是这么联网的。这里现场做三件事：
       ① 枚举本机网卡与 IPv4；② 对 www.baidu.com:443 计时连接测延迟；③ 汇总是否在线。
       全部走 Java 自己的网络栈，不起任何子进程。 */
    private static GlassAssetServer.ApiResponse netcheckApi() {
        String ifName = "";
        String ip = "";
        boolean wireless = false;
        try {
            // 真实网卡优先，VPN / 虚拟网卡（Radmin、Hamachi、ZeroTier、Tailscale、WireGuard、TAP…）
            // 只在没有真实网卡时才用，否则会误报成"本机网卡"（这类适配器常带 26.x / 100.x 之类地址）
            java.util.List<String[]> phys = new java.util.ArrayList<>();
            java.util.List<String[]> virt = new java.util.ArrayList<>();
            java.util.Enumeration<java.net.NetworkInterface> it = java.net.NetworkInterface.getNetworkInterfaces();
            while (it.hasMoreElements()) {
                java.net.NetworkInterface ni = it.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                String v4 = null;
                java.util.Enumeration<java.net.InetAddress> as = ni.getInetAddresses();
                while (as.hasMoreElements()) {
                    java.net.InetAddress ia = as.nextElement();
                    if (ia instanceof java.net.Inet4Address && !ia.isLoopbackAddress()) {
                        v4 = ia.getHostAddress();
                        break;
                    }
                }
                if (v4 == null) continue;
                String nm = ni.getName() == null ? "" : ni.getName();
                String dn = ni.getDisplayName() == null ? "" : ni.getDisplayName();
                String all = (nm + " " + dn).toLowerCase();
                boolean virtual = all.contains("vpn") || all.contains("tap") || all.contains("virtual")
                        || all.contains("radmin") || all.contains("hamachi") || all.contains("zerotier")
                        || all.contains("tailscale") || all.contains("wireguard") || all.contains("wintun");
                (virtual ? virt : phys).add(new String[]{ dn, v4, nm });
            }
            java.util.List<String[]> pick = phys.isEmpty() ? virt : phys;
            if (!pick.isEmpty()) {
                ifName = pick.get(0)[0];
                ip = pick.get(0)[1];
                String n = pick.get(0)[2].toLowerCase();
                wireless = n.startsWith("wl") || ifName.contains("Wi-Fi") || ifName.contains("WLAN")
                        || ifName.contains("无线");
            }
        } catch (Throwable ignore) {}

        long t0 = System.nanoTime();
        boolean online;
        try (java.net.Socket s = new java.net.Socket()) {
            s.connect(new java.net.InetSocketAddress("www.baidu.com", 443), 1500);
            online = true;
        } catch (Throwable t) {
            online = false;
        }
        int ms = online ? (int) ((System.nanoTime() - t0) / 1_000_000L) : -1;
        netOnline = online;

        return GlassAssetServer.ApiResponse.json(new StringBuilder()
                .append("{\"ok\":true,\"online\":").append(online)
                .append(",\"latencyMs\":").append(ms)
                .append(",\"ifName\":").append(_q(ifName))
                .append(",\"ip\":").append(_q(ip))
                .append(",\"wireless\":").append(wireless)
                .append('}').toString());
    }
}
