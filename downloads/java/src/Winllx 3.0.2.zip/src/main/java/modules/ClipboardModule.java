package modules;

import ui.GlassBrowserPanel;
import utils.LangManager;

import javax.swing.*;
import org.cef.CefClient;
import org.cef.browser.CefBrowser;
import org.cef.handler.CefDisplayHandlerAdapter;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 剪贴板历史模块（JCEF + 网页版液态玻璃）。
 *
 * 后台守护线程轮询系统剪贴板文本，记录最近若干条历史（内存 + 本地文件持久化）。
 * 与网页的通信沿用 FileManagerModule 的"标题桥"协议：
 *   clipboard.html 的 window.__clipBridge.call() →
 *   document.title = '__CLIPBRIDGE__' + base64(JSON{seq,method,...}) →
 *   本类在后台线程处理后，经 executeJavaScript 回传 window.__clipBridge.onResult(seq, b64)。
 *
 * 请求为扁平结构、文本字段一律用 base64 传递，避免 JSON 转义问题。
 */
public class ClipboardModule {

    private static final String REL = "clipboard/clipboard.html";
    private static final int MAX_HISTORY = 200;
    private static final int MAX_TEXT_LEN = 200_000;
    private static final String TITLE_TAG = "__CLIPBRIDGE__";

    private static final File STORE_DIR = new File(System.getProperty("user.dir") + "/Winllx/clipboard");
    private static final File STORE_FILE = new File(STORE_DIR, "history.txt");

    private static final Object LOCK = new Object();
    /** 历史：新条目在前 */
    private static final Deque<Entry> HISTORY = new ArrayDeque<>();
    /** 已打开的窗口（用于广播刷新） */
    private static final Set<ClipboardModule> OPEN = ConcurrentHashMap.newKeySet();
    private static volatile boolean monitorStarted = false;
    private static volatile String lastSeen = null;

    private static final class Entry {
        final String text;
        final long time;
        Entry(String text, long time) { this.text = text; this.time = time; }
    }

    private JFrame frame;
    private GlassBrowserPanel browserPanel;
    private final ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "clipboard-bridge");
        t.setDaemon(true);
        return t;
    });

    public ClipboardModule() {
        loadHistory();
        ensureMonitor();
        OPEN.add(this);

        frame = utils.WinllxIcon.createFrame(LangManager.getString("module.clipboard"));
        frame.setSize(560, 640);
        frame.setMinimumSize(new Dimension(400, 420));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        browserPanel = new GlassBrowserPanel(REL, true);
        frame.add(browserPanel, BorderLayout.CENTER);

        // JCEF 未就绪时浏览器会延后创建，桥接需等浏览器创建完成后再装
        browserPanel.onBrowserReady(this::installBridge);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                OPEN.remove(ClipboardModule.this);
                try { if (browserPanel != null) browserPanel.closeBrowser(); } catch (Throwable ignored) {}
                try { exec.shutdownNow(); } catch (Throwable ignored) {}
            }
        });
        frame.setVisible(true);
        System.out.println("[WinllxClip] 剪贴板历史窗口已启动 (JCEF + clipboard.html)");
    }

    public GlassBrowserPanel getBrowserPanel() {
        return browserPanel;
    }

    /* ==================================================================
     * 剪贴板监听
     * ================================================================== */
    private static void ensureMonitor() {
        if (monitorStarted) return;
        synchronized (LOCK) {
            if (monitorStarted) return;
            monitorStarted = true;
            Thread t = new Thread(ClipboardModule::monitorLoop, "clipboard-monitor");
            t.setDaemon(true);
            t.start();
        }
    }

    private static void monitorLoop() {
        try {
            Clipboard cb = Toolkit.getDefaultToolkit().getSystemClipboard();
            // 记录启动时已有内容，避免把旧内容当作新复制项
            lastSeen = readClipboardText(cb);
            while (true) {
                try {
                    Thread.sleep(700);
                } catch (InterruptedException ie) {
                    return;
                }
                String text = readClipboardText(cb);
                if (text == null || text.isEmpty() || text.equals(lastSeen)) continue;
                lastSeen = text;
                addEntry(text, System.currentTimeMillis());
            }
        } catch (Throwable t) {
            System.err.println("[WinllxClip] 剪贴板监听失败: " + t.getMessage());
        }
    }

    private static String readClipboardText(Clipboard cb) {
        try {
            if (!cb.isDataFlavorAvailable(DataFlavor.stringFlavor)) return null;
            Object v = cb.getData(DataFlavor.stringFlavor);
            return v == null ? null : v.toString();
        } catch (Throwable t) {
            return null;
        }
    }

    private static void addEntry(String text, long time) {
        if (text.length() > MAX_TEXT_LEN) text = text.substring(0, MAX_TEXT_LEN);
        synchronized (LOCK) {
            Iterator<Entry> it = HISTORY.iterator();
            while (it.hasNext()) {
                if (it.next().text.equals(text)) { it.remove(); break; }
            }
            HISTORY.addFirst(new Entry(text, time));
            while (HISTORY.size() > MAX_HISTORY) HISTORY.removeLast();
            saveHistory();
        }
        broadcastReload();
    }

    private static void broadcastReload() {
        for (ClipboardModule m : OPEN) {
            try {
                GlassBrowserPanel p = m.browserPanel;
                if (p != null && p.isBrowserActive()) {
                    p.executeJavaScript("try{if(window.__clipboardOnChanged)window.__clipboardOnChanged();}catch(e){};");
                }
            } catch (Throwable ignored) {
            }
        }
    }

    /* ==================================================================
     * 历史持久化（每行：时间戳 \t base64(文本)）
     * ================================================================== */
    private static void loadHistory() {
        synchronized (LOCK) {
            if (!HISTORY.isEmpty()) return;
            if (!STORE_FILE.isFile()) return;
            try {
                for (String line : Files.readAllLines(STORE_FILE.toPath(), StandardCharsets.UTF_8)) {
                    int tab = line.indexOf('\t');
                    if (tab <= 0) continue;
                    long time;
                    try { time = Long.parseLong(line.substring(0, tab)); }
                    catch (NumberFormatException nfe) { continue; }
                    String text = new String(Base64.getDecoder().decode(line.substring(tab + 1)), StandardCharsets.UTF_8);
                    HISTORY.addLast(new Entry(text, time));
                }
            } catch (Throwable t) {
                System.err.println("[WinllxClip] 读取历史失败: " + t.getMessage());
            }
        }
    }

    private static void saveHistory() {
        try {
            STORE_DIR.mkdirs();
            StringBuilder sb = new StringBuilder();
            for (Entry e : HISTORY) {
                sb.append(e.time).append('\t')
                  .append(Base64.getEncoder().encodeToString(e.text.getBytes(StandardCharsets.UTF_8)))
                  .append('\n');
            }
            Files.write(STORE_FILE.toPath(), sb.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Throwable t) {
            System.err.println("[WinllxClip] 保存历史失败: " + t.getMessage());
        }
    }

    /* ==================================================================
     * 标题桥
     * ================================================================== */
    private void installBridge() {
        try {
            CefClient client = browserPanel.getClient();
            if (client == null) return;
            client.addDisplayHandler(new CefDisplayHandlerAdapter() {
                @Override
                public void onTitleChange(CefBrowser browser, String title) {
                    if (browser == null || browser != browserPanel.getBrowser()) return;
                    if (title != null && title.startsWith(TITLE_TAG)) {
                        final String payload = title.substring(TITLE_TAG.length());
                        exec.execute(() -> handleRequest(payload));
                    }
                }
            });
        } catch (Throwable t) {
            System.err.println("[WinllxClip] 标题桥安装失败: " + t.getMessage());
        }
    }

    private void handleRequest(String payload) {
        long seq = -1;
        try {
            String json = new String(Base64.getDecoder().decode(payload), StandardCharsets.UTF_8);
            Map<String, Object> req = Json.parseObject(json);
            seq = (req.get("seq") instanceof Number) ? ((Number) req.get("seq")).longValue() : -1L;
            String method = String.valueOf(req.get("method"));
            sendResult(seq, dispatch(method, req));
        } catch (Throwable t) {
            System.err.println("[WinllxClip] 桥请求处理失败: " + t.getMessage());
            sendResult(seq, Json.obj("ok", false, "error", "内部错误: " + t.getMessage()));
        }
    }

    private void sendResult(long seq, Object result) {
        try {
            String resJson = Json.stringify(result);
            final String b64 = Base64.getEncoder().encodeToString(resJson.getBytes(StandardCharsets.UTF_8));
            final long fSeq = seq;
            SwingUtilities.invokeLater(() -> {
                try {
                    browserPanel.executeJavaScript("window.__clipBridge.onResult(" + fSeq + ",'" + b64 + "')");
                } catch (Throwable t) {
                    System.err.println("[WinllxClip] 回传失败: " + t.getMessage());
                }
            });
        } catch (Throwable t) {
            System.err.println("[WinllxClip] 结果编码失败: " + t.getMessage());
        }
    }

    /* ==================================================================
     * 请求分发
     * ================================================================== */
    private Object dispatch(String method, Map<String, Object> a) {
        switch (method) {
            case "list": return doList();
            case "copy": return doCopy(str(a, "b64"));
            case "remove": return doRemove(num(a, "time"));
            case "clear": return doClear();
            default: return Json.obj("ok", false, "error", "未知方法: " + method);
        }
    }

    private static String str(Map<String, Object> a, String key) {
        Object v = a.get(key);
        return v == null ? "" : String.valueOf(v);
    }

    private static long num(Map<String, Object> a, String key) {
        Object v = a.get(key);
        return v instanceof Number ? ((Number) v).longValue() : -1L;
    }

    private Object doList() {
        List<Object> items = new ArrayList<>();
        synchronized (LOCK) {
            for (Entry e : HISTORY) items.add(Json.obj("text", e.text, "time", e.time));
        }
        return Json.obj("ok", true, "items", items);
    }

    private Object doCopy(String b64) {
        String text;
        try {
            text = new String(Base64.getDecoder().decode(b64), StandardCharsets.UTF_8);
        } catch (Throwable t) {
            return Json.obj("ok", false, "error", "内容解码失败");
        }
        try {
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(text), null);
            lastSeen = text;
        } catch (Throwable t) {
            return Json.obj("ok", false, "error", "写入剪贴板失败: " + t.getMessage());
        }
        addEntry(text, System.currentTimeMillis());
        return Json.obj("ok", true);
    }

    private Object doRemove(long time) {
        synchronized (LOCK) {
            Iterator<Entry> it = HISTORY.iterator();
            while (it.hasNext()) {
                if (it.next().time == time) { it.remove(); break; }
            }
            saveHistory();
        }
        broadcastReload();
        return Json.obj("ok", true);
    }

    private Object doClear() {
        synchronized (LOCK) {
            HISTORY.clear();
            saveHistory();
        }
        broadcastReload();
        return Json.obj("ok", true);
    }

    /* ==================================================================
     * 迷你 JSON 工具（写：正确转义；读：只解析本模块用到的扁平请求）
     * ================================================================== */
    private static class Json {

        static Map<String, Object> obj(Object... kv) {
            Map<String, Object> m = new LinkedHashMap<>();
            for (int i = 0; i + 1 < kv.length; i += 2) m.put(String.valueOf(kv[i]), kv[i + 1]);
            return m;
        }

        static String stringify(Object o) {
            StringBuilder sb = new StringBuilder();
            write(sb, o);
            return sb.toString();
        }

        private static void write(StringBuilder sb, Object o) {
            if (o == null) { sb.append("null"); return; }
            if (o instanceof Map) {
                sb.append('{');
                boolean first = true;
                for (Map.Entry<?, ?> e : ((Map<?, ?>) o).entrySet()) {
                    if (!first) sb.append(',');
                    first = false;
                    writeString(sb, String.valueOf(e.getKey()));
                    sb.append(':');
                    write(sb, e.getValue());
                }
                sb.append('}');
                return;
            }
            if (o instanceof Iterable) {
                sb.append('[');
                boolean first = true;
                for (Object it : (Iterable<?>) o) {
                    if (!first) sb.append(',');
                    first = false;
                    write(sb, it);
                }
                sb.append(']');
                return;
            }
            if (o instanceof Number || o instanceof Boolean) { sb.append(o); return; }
            writeString(sb, String.valueOf(o));
        }

        private static void writeString(StringBuilder sb, String s) {
            sb.append('"');
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                switch (c) {
                    case '"': sb.append("\\\""); break;
                    case '\\': sb.append("\\\\"); break;
                    case '\n': sb.append("\\n"); break;
                    case '\r': sb.append("\\r"); break;
                    case '\t': sb.append("\\t"); break;
                    default:
                        if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                        else sb.append(c);
                }
            }
            sb.append('"');
        }

        /** 只解析本模块用到的扁平对象 {"seq":1,"method":"copy","b64":"..."}。 */
        static Map<String, Object> parseObject(String s) {
            Map<String, Object> m = new LinkedHashMap<>();
            int i = s.indexOf('{');
            if (i < 0) return m;
            i++;
            while (i < s.length()) {
                int k = s.indexOf('"', i);
                if (k < 0) break;
                int kEnd = s.indexOf('"', k + 1);
                if (kEnd < 0) break;
                String key = s.substring(k + 1, kEnd);
                int colon = s.indexOf(':', kEnd);
                if (colon < 0) break;
                int v = colon + 1;
                while (v < s.length() && Character.isWhitespace(s.charAt(v))) v++;
                if (v < s.length() && s.charAt(v) == '"') {
                    int vEnd = s.indexOf('"', v + 1);
                    if (vEnd < 0) break;
                    m.put(key, s.substring(v + 1, vEnd));
                    i = vEnd + 1;
                } else {
                    int vEnd = v;
                    while (vEnd < s.length() && "},]".indexOf(s.charAt(vEnd)) < 0) vEnd++;
                    String raw = s.substring(v, vEnd).trim();
                    m.put(key, raw.matches("-?\\d+") ? (Object) Long.parseLong(raw) : raw);
                    i = vEnd;
                }
            }
            return m;
        }
    }
}
