package modules;

import app.Winllx;
import utils.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ExitAction {
    public ExitAction() {
        int result = JOptionPane.showConfirmDialog(null, 
            LangManager.getString("msg.confirm.exit"),
            LangManager.getString("dialog.confirm"),
            JOptionPane.YES_NO_OPTION);
        
        if (result == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }
}
