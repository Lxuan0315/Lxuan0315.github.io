package modules;

import ui.GlassBrowserPanel;
import utils.LangManager;

import javax.swing.*;
import java.awt.*;

/**
 * 时钟模块（JCEF + 网页版液态玻璃）。
 * 加载 web/clock/clock.html：时钟（模拟+数字+日期）、秒表、计时器、
 * 闹钟（localStorage 持久化 + 铃音）。
 */
public class ClockModule {

    private JFrame frame;
    private GlassBrowserPanel browserPanel;

    public ClockModule() {
        frame = utils.WinllxIcon.createFrame(LangManager.getString("module.clock"));
        frame.setSize(520, 700);
        frame.setMinimumSize(new Dimension(420, 560));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        browserPanel = new GlassBrowserPanel("clock/clock.html", true);
        frame.add(browserPanel, BorderLayout.CENTER);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                if (browserPanel != null) browserPanel.closeBrowser();
            }
        });
        frame.setVisible(true);
        System.out.println("[Winllx5] 时钟窗口已启动 (JCEF + clock.html)");
    }

    public GlassBrowserPanel getBrowserPanel() {
        return browserPanel;
    }
}
