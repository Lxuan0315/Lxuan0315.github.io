package modules;

import ui.GlassBrowserPanel;
import utils.LangManager;

import javax.swing.*;
import java.awt.*;

/**
 * 白板模块（JCEF + 网页版液态玻璃）。
 * 原 Swing 白板整体替换为 web/board/board.html：
 * 画笔/橡皮/形状、颜色与粗细、撤销重做、清空、换底色、保存(localStorage)、导出 PNG（下载）。
 */
public class BoardModule {

    private JFrame frame;
    private GlassBrowserPanel browserPanel;

    public BoardModule() {
        frame = utils.WinllxIcon.createFrame(LangManager.getString("module.board"));
        frame.setSize(1080, 700);
        frame.setMinimumSize(new Dimension(760, 480));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        browserPanel = new GlassBrowserPanel("board/board.html", true);
        // 浏览器创建完成后再注册下载处理器（JCEF 未就绪时会延后创建）
        browserPanel.onBrowserReady(browserPanel::enableDownloads); // 导出 PNG 自动保存到下载目录
        frame.add(browserPanel, BorderLayout.CENTER);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                if (browserPanel != null) browserPanel.closeBrowser();
            }
        });
        frame.setVisible(true);
        System.out.println("[Winllx7] 白板窗口已启动 (JCEF + board.html)");
    }

    public GlassBrowserPanel getBrowserPanel() {
        return browserPanel;
    }
}
