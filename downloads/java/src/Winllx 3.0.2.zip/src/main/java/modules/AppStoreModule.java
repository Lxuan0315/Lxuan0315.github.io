package modules;

import ui.GlassBrowserPanel;
import utils.GitHubAccel;
import utils.GithubPrefs;
import utils.HttpDownloader;
import utils.LangManager;

import javax.swing.*;
import org.cef.CefClient;
import org.cef.browser.CefBrowser;
import org.cef.handler.CefDisplayHandlerAdapter;

import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * 应用商店模块（JCEF + 网页版液态玻璃）。
 *
 * 应用索引固定从 GitHub 仓库的 apps.json 拉取（地址写死，界面不可改），
 * 拉取与下载统一在内部走 utils/GitHubAccel 的自动加速（镜像择优 + 断点续传 + sha256 校验），
 * 不向用户暴露任何加速设置。
 *
 * 通信协议与 FileManagerModule 一致（标题桥）：
 *   store.html 的 window.__storeBridge.call(method,args) →
 *   document.title = '__STOREBRIDGE__' + base64(JSON{seq,method,args}) →
 *   本类在后台线程处理后，经 executeJavaScript 回传 window.__storeBridge.onResult(seq, b64) / onProgress(b64)。
 */
public class AppStoreModule {

    private static final String REL = "store/store.html";

    /** 固定的应用索引地址（唯一来源，界面不提供修改入口）。 */
    private static final String INDEX_URL =
            "https://raw.githubusercontent.com/Lxuan0315/WinllxAssets/main/apps.json";

    /** 应用安装根目录：Winllx/apps/<id>/ */
    private static final String APPS_ROOT = System.getProperty("user.dir") + "/Winllx/apps";
    private static final String CACHE_DIR = APPS_ROOT + "/.cache";
    private static final String INDEX_CACHE = CACHE_DIR + "/apps.json";

    private static final long MEM_TTL_MS = 5 * 60 * 1000L;

    /** 最近一次成功拉取走的镜像（用于状态行展示） */
    private String lastMirror;

    /** 磁盘缓存键：索引地址唯一，固定值即可 */
    private static final String CACHE_KEY = "index:" + INDEX_URL;

    private JFrame frame;
    private GlassBrowserPanel browserPanel;

    /** 桥接请求（单线程，避免并发乱序） */
    private final ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "store-bridge");
        t.setDaemon(true);
        return t;
    });
    /** 安装任务（独立线程池，避免长时间下载把 list 请求堵死） */
    private final ExecutorService jobPool = Executors.newFixedThreadPool(2, r -> {
        Thread t = new Thread(r, "store-install");
        t.setDaemon(true);
        return t;
    });

    /** 内存索引缓存 */
    private volatile List<Map<String, Object>> appsCache;
    private volatile long appsCacheAt;

    private final Set<String> installing = ConcurrentHashMap.newKeySet();

    public AppStoreModule() {
        frame = utils.WinllxIcon.createFrame(LangManager.getString("module.store"));
        frame.setSize(980, 660);
        frame.setMinimumSize(new Dimension(640, 420));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        browserPanel = new GlassBrowserPanel(REL, true);
        frame.add(browserPanel, BorderLayout.CENTER);

        // JCEF 未就绪时浏览器会延后创建，桥接需等浏览器创建完成后再装
        browserPanel.onBrowserReady(this::installBridge);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                try { if (browserPanel != null) browserPanel.closeBrowser(); } catch (Throwable ignored) {}
                try { exec.shutdownNow(); } catch (Throwable ignored) {}
                try { jobPool.shutdownNow(); } catch (Throwable ignored) {}
            }
        });
        frame.setVisible(true);

        // 清理上次残留的下载分片（>7 天）
        sweepStaleParts();
        System.out.println("[Winllx8] 应用商店窗口已启动 (JCEF + store.html)，索引源=" + INDEX_URL);
    }

    public GlassBrowserPanel getBrowserPanel() {
        return browserPanel;
    }

    /* ==================================================================
     * 标题桥：store.html 的 window.__storeBridge.call() → 本方法
     * ================================================================== */
    private void installBridge() {
        try {
            CefClient client = browserPanel.getClient();
            if (client == null) return;
            client.addDisplayHandler(new CefDisplayHandlerAdapter() {
                @Override
                public void onTitleChange(CefBrowser browser, String title) {
                    if (browser == null || browser != browserPanel.getBrowser()) return;
                    if (title != null && title.startsWith("__STOREBRIDGE__")) {
                        final String payload = title.substring("__STOREBRIDGE__".length());
                        exec.execute(() -> handleRequest(payload));
                    }
                }
            });
        } catch (Throwable t) {
            System.err.println("[Winllx8] 标题桥安装失败: " + t.getMessage());
        }
    }

    private void handleRequest(String payload) {
        long seq = -1;
        try {
            String json = new String(Base64.getDecoder().decode(payload), StandardCharsets.UTF_8);
            Map<String, Object> req = Json.parseObject(json);
            seq = (req.get("seq") instanceof Number) ? ((Number) req.get("seq")).longValue() : -1L;
            String method = String.valueOf(req.get("method"));
            Object argsObj = req.get("args");
            @SuppressWarnings("unchecked")
            Map<String, Object> args = (argsObj instanceof Map) ? (Map<String, Object>) argsObj : new LinkedHashMap<>();
            Map<String, Object> result = dispatch(seq, method, args);
            if (result != null) sendResult(seq, result);   // null = 已异步自行回传
        } catch (Throwable t) {
            System.err.println("[Winllx8] 桥请求处理失败: " + t.getMessage());
            sendResult(seq, Json.obj("ok", false, "error", "内部错误: " + msg(t)));
        }
    }

    private void sendResult(long seq, Map<String, Object> result) {
        try {
            String resJson = Json.stringify(result);
            final String b64 = Base64.getEncoder().encodeToString(resJson.getBytes(StandardCharsets.UTF_8));
            final long fSeq = seq;
            SwingUtilities.invokeLater(() -> {
                try {
                    browserPanel.executeJavaScript("window.__storeBridge.onResult(" + fSeq + ",'" + b64 + "')");
                } catch (Throwable t) {
                    System.err.println("[Winllx8] 回传失败: " + t.getMessage());
                }
            });
        } catch (Throwable t) {
            System.err.println("[Winllx8] 结果编码失败: " + t.getMessage());
        }
    }

    /** 下载/安装进度推送（网页端 window.__storeBridge.onProgress(b64)） */
    private void pushProgress(String id, String stage, long done, long total, String mirror) {
        try {
            Map<String, Object> m = Json.obj("id", id, "stage", stage, "done", done, "total", total);
            m.put("mirror", mirror);
            final String b64 = Base64.getEncoder().encodeToString(
                    Json.stringify(m).getBytes(StandardCharsets.UTF_8));
            SwingUtilities.invokeLater(() -> {
                try {
                    browserPanel.executeJavaScript("window.__storeBridge.onProgress('" + b64 + "')");
                } catch (Throwable ignored) {}
            });
        } catch (Throwable ignored) {}
    }

    /* ==================================================================
     * 请求分发（返回 null 表示已异步回传）
     * ================================================================== */
    private Map<String, Object> dispatch(long seq, String method, Map<String, Object> args) {
        if (method == null) return Json.obj("ok", false, "error", "缺少方法名");
        switch (method) {
            case "list":
                return listResponse(false);
            case "refresh":
                return listResponse(true);
            case "install": {
                String id = s(args.get("id"));
                if (id.isEmpty()) return Json.obj("ok", false, "error", "缺少应用 id");
                if (!installing.add(id)) return Json.obj("ok", false, "error", "该应用正在安装中");
                final long fSeq = seq;
                jobPool.execute(() -> {
                    try {
                        sendResult(fSeq, install(id));
                    } catch (Throwable t) {
                        sendResult(fSeq, Json.obj("ok", false, "error", "安装失败: " + msg(t)));
                    } finally {
                        installing.remove(id);
                    }
                });
                return null;
            }
            case "open":
                return openApp(s(args.get("id")));
            case "open_dir":
                return openDir(s(args.get("id")));
            default:
                return Json.obj("ok", false, "error", "未知方法: " + method);
        }
    }

    /* ==================================================================
     * 应用列表
     * ================================================================== */

    /** 拉取应用列表（网络拉取 + 内存缓存 + 网络失败回退本地磁盘缓存）。 */
    private Map<String, Object> listResponse(boolean force) {
        long now = System.currentTimeMillis();
        List<Map<String, Object>> mem = appsCache;
        if (!force && mem != null && now - appsCacheAt < MEM_TTL_MS) {
            return Json.obj("ok", true, "apps", mem, "source", INDEX_URL, "cached", true);
        }

        try {
            List<Map<String, Object>> apps = normalizeApps(fetchText(INDEX_URL));
            appsCache = apps;
            appsCacheAt = now;
            writeDiskCache(apps);
            Map<String, Object> out = Json.obj("ok", true, "apps", apps, "source", INDEX_URL);
            if (lastMirror != null) out.put("mirror", lastMirror);
            return out;
        } catch (Throwable t) {
            List<Map<String, Object>> disk = readDiskCache();
            if (disk != null) {
                return Json.obj("ok", true, "apps", disk, "source", INDEX_URL, "stale", true,
                        "error", "连接 GitHub 失败，已显示缓存列表：" + msg(t));
            }
            Map<String, Object> out = Json.obj("ok", false, "error", "连接 GitHub 失败：" + msg(t), "source", INDEX_URL);
            out.put("apps", Collections.emptyList());
            return out;
        }
    }

    /** 按加速策略拉取文本；所有镜像与直连都失败时抛异常。 */
    private String fetchText(String url) throws Exception {
        List<GitHubAccel.Plan> plans = GitHubAccel.plan(url);
        Map<String, Object> res = HttpDownloader.text(plans, GithubPrefs.getTimeoutMs());
        if (!Boolean.TRUE.equals(res.get("ok"))) {
            throw new IOException(String.valueOf(res.get("error")));
        }
        lastMirror = s(res.get("mirror"));
        return String.valueOf(res.get("body"));
    }

    /** 把 apps.json 文本规范化为商店 UI 需要的字段，并按 id 去重。 */
    private List<Map<String, Object>> normalizeApps(String body) {
        Object root = Json.parse(body);
        List<?> raw;
        if (root instanceof List) {
            raw = (List<?>) root;
        } else if (root instanceof Map && ((Map<?, ?>) root).get("apps") instanceof List) {
            raw = (List<?>) ((Map<?, ?>) root).get("apps");
        } else {
            throw new IllegalArgumentException("apps.json 格式错误：需要一个应用对象数组");
        }
        List<Map<String, Object>> out = new ArrayList<>();
        Set<String> ids = new LinkedHashSet<>();
        for (Object o : raw) {
            if (!(o instanceof Map)) continue;
            Map<?, ?> m = (Map<?, ?>) o;
            String id = s(m.get("id"));
            if (id.isEmpty() || !ids.add(id)) continue;
            Map<String, Object> app = Json.obj(
                    "id", id,
                    "name", orElse(s(m.get("name")), id),
                    "description", s(m.get("description")),
                    "version", s(m.get("version")),
                    "asset", s(m.get("asset")),
                    "sha256", s(m.get("sha256")),
                    "homepage", s(m.get("homepage")));
            app.put("size", num(m.get("size")));
            app.put("installed", isInstalled(id));
            app.put("installedVersion", installedVersion(id));
            out.add(app);
        }
        return out;
    }

    /** 列表磁盘缓存：索引地址固定，写入时带上键以便日后识别格式。 */
    private void writeDiskCache(List<Map<String, Object>> apps) {
        try {
            File d = new File(CACHE_DIR);
            if (!d.exists()) d.mkdirs();
            Map<String, Object> root = Json.obj("key", CACHE_KEY, "apps", apps);
            try (Writer w = new OutputStreamWriter(new FileOutputStream(INDEX_CACHE), StandardCharsets.UTF_8)) {
                w.write(Json.stringify(root));
            }
        } catch (Throwable ignore) {}
    }

    private List<Map<String, Object>> readDiskCache() {
        try {
            File f = new File(INDEX_CACHE);
            if (!f.isFile()) return null;
            String text;
            try (InputStream in = new FileInputStream(f)) {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) baos.write(buf, 0, n);
                text = baos.toString(StandardCharsets.UTF_8.name());
            }
            Object root = Json.parse(text);
            if (!(root instanceof Map)) return null;
            Map<?, ?> m = (Map<?, ?>) root;
            if (!CACHE_KEY.equals(s(m.get("key")))) return null;
            Object list = m.get("apps");
            if (!(list instanceof List)) return null;
            List<Map<String, Object>> out = new ArrayList<>();
            for (Object o : (List<?>) list) {
                if (!(o instanceof Map)) continue;
                Map<?, ?> a = (Map<?, ?>) o;
                String id = s(a.get("id"));
                if (id.isEmpty()) continue;
                Map<String, Object> app = Json.obj("id", id, "name", orElse(s(a.get("name")), id),
                        "description", s(a.get("description")), "version", s(a.get("version")),
                        "asset", s(a.get("asset")), "sha256", s(a.get("sha256")),
                        "homepage", s(a.get("homepage")));
                app.put("size", num(a.get("size")));
                app.put("installed", isInstalled(id));
                app.put("installedVersion", installedVersion(id));
                out.add(app);
            }
            return out.isEmpty() ? null : out;
        } catch (Throwable t) {
            return null;
        }
    }

    /* ==================================================================
     * 安装 / 打开
     * ================================================================== */

    private Map<String, Object> install(String id) {
        Map<String, Object> app = findApp(id);
        if (app == null) {
            return Json.obj("ok", false, "error", "索引里没有该应用（或索引不可用）：" + id);
        }
        String asset = s(app.get("asset"));
        if (asset.isEmpty() || !asset.startsWith("http")) {
            return Json.obj("ok", false, "error", "该应用缺少可下载地址(asset)");
        }
        String sha = s(app.get("sha256"));
        long size = num(app.get("size"));
        String version = s(app.get("version"));

        File cacheDir = new File(CACHE_DIR);
        cacheDir.mkdirs();
        final File part = new File(cacheDir, id + ".part");

        List<GitHubAccel.Plan> plans = GitHubAccel.plan(asset);
        if (plans.isEmpty()) return Json.obj("ok", false, "error", "无法生成下载候选地址");
        final String mirror0 = plans.get(0).mirrorId;
        final String assetUrl = asset;

        try {
            pushProgress(id, "download", 0, size, mirror0);
            HttpDownloader.file(plans, part, sha.isEmpty() ? null : sha, size,
                    (stage, done, total) -> pushProgress(id, stage, done, total, mirror0),
                    Math.max(2, plans.size()));
        } catch (Throwable t) {
            return Json.obj("ok", false, "error", "下载失败：" + msg(t), "asset", assetUrl);
        }

        File root = new File(APPS_ROOT);
        File dir = new File(root, id);
        File newDir = new File(root, id + ".new");
        File oldDir = new File(root, id + ".old");
        try {
            deleteRecursively(newDir);
            pushProgress(id, "unzip", 0, 1, mirror0);
            unzip(part, newDir);
            pushProgress(id, "unzip", 1, 1, mirror0);

            deleteRecursively(oldDir);
            if (dir.exists() && !dir.renameTo(oldDir)) {
                throw new IOException("旧版本目录被占用，请先关闭该应用后重试");
            }
            if (!newDir.renameTo(dir)) {
                if (oldDir.exists()) oldDir.renameTo(dir);   // 回滚
                throw new IOException("安装目录改名失败");
            }
            deleteRecursively(oldDir);
            writeManifest(dir, app);
            part.delete();
        } catch (Throwable t) {
            deleteRecursively(newDir);
            return Json.obj("ok", false, "error", "安装失败：" + msg(t));
        }

        pushProgress(id, "done", size, size, mirror0);
        appsCache = null;   // 安装状态变了，作废列表缓存（下次 list 重算 installed）
        return Json.obj("ok", true, "id", id, "version", version, "path", dir.getAbsolutePath());
    }

    private Map<String, Object> openApp(String id) {
        File dir = new File(APPS_ROOT, id);
        if (id.isEmpty() || !dir.isDirectory()) {
            return Json.obj("ok", false, "error", "尚未安装该应用");
        }
        File entry = readManifestEntry(dir);
        if (entry == null || !entry.isFile()) entry = findEntry(dir);
        if (entry == null) {
            openDir(id);
            return Json.obj("ok", false, "error", "未找到可执行入口，已为你打开安装目录",
                    "path", dir.getAbsolutePath());
        }
        try {
            String lower = entry.getName().toLowerCase();
            if (lower.endsWith(".exe") || lower.endsWith(".bat") || lower.endsWith(".cmd") || lower.endsWith(".lnk")) {
                // 本地可执行文件统一交给 explorer 打开 = 双击的效果。
                // 不走 Desktop.open：本机实测它对 .bat 与 .exe 都会抛 "Unsupported URI content"；
                // 也不走 PowerShell -WindowStyle Hidden（会被安全软件判成“隐藏执行 PowerShell”并拦截）。
                new ProcessBuilder("explorer.exe", entry.getAbsolutePath()).start();
                return Json.obj("ok", true, "path", entry.getAbsolutePath());
            }
            if (!Desktop.isDesktopSupported() || !Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                return Json.obj("ok", false, "error", "当前系统不支持打开该文件", "path", entry.getAbsolutePath());
            }
            Desktop.getDesktop().open(entry);
            return Json.obj("ok", true, "path", entry.getAbsolutePath());
        } catch (Throwable t) {
            return Json.obj("ok", false, "error", "启动失败：" + msg(t), "path", entry.getAbsolutePath());
        }
    }

    private Map<String, Object> openDir(String id) {
        File dir = new File(APPS_ROOT, id);
        if (!dir.isDirectory()) return Json.obj("ok", false, "error", "安装目录不存在");
        try {
            Desktop.getDesktop().open(dir);
            return Json.obj("ok", true, "path", dir.getAbsolutePath());
        } catch (Throwable t) {
            return Json.obj("ok", false, "error", "打开目录失败：" + msg(t));
        }
    }

    private Map<String, Object> findApp(String id) {
        List<Map<String, Object>> apps = appsCache;
        if (apps == null) {
            Map<String, Object> res = listResponse(false);
            Object o = res.get("apps");
            if (o instanceof List) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> l = (List<Map<String, Object>>) o;
                apps = l;
            }
        }
        if (apps == null) return null;
        for (Map<String, Object> a : apps) {
            if (id.equals(s(a.get("id")))) return a;
        }
        return null;
    }

    /* ==================================================================
     * 本地文件工具
     * ================================================================== */

    private static void unzip(File zip, File targetDir) throws IOException {
        if (!targetDir.exists() && !targetDir.mkdirs()) throw new IOException("无法创建目录：" + targetDir);
        final String base = targetDir.getCanonicalPath();
        byte[] buf = new byte[64 * 1024];
        try (ZipInputStream zin = new ZipInputStream(
                new BufferedInputStream(new FileInputStream(zip)), StandardCharsets.UTF_8)) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                File out = new File(targetDir, e.getName());
                String canon = out.getCanonicalPath();
                // zip-slip 防护：解压路径必须落在目标目录内
                if (!canon.equals(base) && !canon.startsWith(base + File.separator)) {
                    throw new IOException("压缩包包含非法路径：" + e.getName());
                }
                if (e.isDirectory()) {
                    out.mkdirs();
                } else {
                    File parent = out.getParentFile();
                    if (parent != null) parent.mkdirs();
                    try (FileOutputStream fos = new FileOutputStream(out)) {
                        int n;
                        while ((n = zin.read(buf)) > 0) fos.write(buf, 0, n);
                    }
                }
                zin.closeEntry();
            }
        }
    }

    private static void deleteRecursively(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursively(k);
        }
        f.delete();
    }

    private static void writeManifest(File dir, Map<String, Object> app) {
        try {
            File entryFile = findEntry(dir);
            Map<String, Object> m = Json.obj(
                    "id", s(app.get("id")),
                    "name", s(app.get("name")),
                    "version", s(app.get("version")),
                    "installedAt", System.currentTimeMillis());
            m.put("entry", entryFile == null ? "" : entryFile.getAbsolutePath());
            File mf = new File(dir, "manifest.json");
            try (Writer w = new OutputStreamWriter(new FileOutputStream(mf), StandardCharsets.UTF_8)) {
                w.write(Json.stringify(m));
            }
        } catch (Throwable ignore) {}
    }

    /** 在安装目录里找一个可执行入口（exe → bat → lnk → jar）。 */
    private static File findEntry(File dir) {
        String[] exts = {".exe", ".bat", ".cmd", ".lnk", ".jar"};
        for (String ext : exts) {
            File found = findFirstWithExt(dir, ext, 0);
            if (found != null) return found;
        }
        return null;
    }

    private static File findFirstWithExt(File dir, String ext, int depth) {
        if (dir == null || depth > 3) return null;
        File[] kids = dir.listFiles();
        if (kids == null) return null;
        for (File f : kids) {
            if (f.isFile() && f.getName().toLowerCase().endsWith(ext)) return f;
        }
        for (File f : kids) {
            if (f.isDirectory()) {
                File r = findFirstWithExt(f, ext, depth + 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static File readManifestEntry(File dir) {
        try {
            File mf = new File(dir, "manifest.json");
            if (!mf.isFile()) return null;
            try (InputStream in = new FileInputStream(mf)) {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) baos.write(buf, 0, n);
                Map<String, Object> m = Json.parseObject(baos.toString(StandardCharsets.UTF_8.name()));
                String path = s(m.get("entry"));
                if (!path.isEmpty()) {
                    File f = new File(path);
                    if (f.isFile()) return f;
                }
            }
        } catch (Throwable ignore) {}
        return null;
    }

    private static boolean isInstalled(String id) {
        return new File(new File(APPS_ROOT, id), "manifest.json").isFile();
    }

    private static String installedVersion(String id) {
        try {
            File dir = new File(APPS_ROOT, id);
            File mf = new File(dir, "manifest.json");
            if (!mf.isFile()) return "";
            try (InputStream in = new FileInputStream(mf)) {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) baos.write(buf, 0, n);
                return s(Json.parseObject(baos.toString(StandardCharsets.UTF_8.name())).get("version"));
            }
        } catch (Throwable t) {
            return "";
        }
    }

    /** 清理超过 7 天的下载分片残留。 */
    private static void sweepStaleParts() {
        try {
            File d = new File(CACHE_DIR);
            File[] kids = d.listFiles();
            if (kids == null) return;
            long cut = System.currentTimeMillis() - 7L * 24 * 3600 * 1000;
            for (File f : kids) {
                if (f.getName().endsWith(".part") && f.lastModified() < cut) f.delete();
            }
        } catch (Throwable ignore) {}
    }

    /* ==================================================================
     * 小工具
     * ================================================================== */

    private static String s(Object o) {
        if (o == null) return "";
        if (o instanceof Number) return String.valueOf(((Number) o).longValue());
        return String.valueOf(o).trim();
    }

    private static String orElse(String v, String def) {
        return (v == null || v.isEmpty()) ? def : v;
    }

    private static long num(Object o) {
        if (o instanceof Number) return ((Number) o).longValue();
        try {
            String v = s(o);
            return v.isEmpty() ? 0L : Long.parseLong(v);
        } catch (Throwable t) {
            return 0L;
        }
    }

    private static String msg(Throwable t) {
        String m = t == null ? null : t.getMessage();
        return (m == null || m.isEmpty()) ? (t == null ? "未知错误" : t.getClass().getSimpleName()) : m;
    }

    /* ==================================================================
     * 极简 JSON 读写（与 FileManagerModule 内部实现同风格，含递归下降解析器）
     * ================================================================== */
    private static class Json {

        static Map<String, Object> obj(Object... kv) {
            Map<String, Object> m = new LinkedHashMap<>();
            for (int i = 0; i + 1 < kv.length; i += 2) {
                m.put(String.valueOf(kv[i]), kv[i + 1]);
            }
            return m;
        }

        static String stringify(Object o) {
            StringBuilder sb = new StringBuilder();
            write(sb, o);
            return sb.toString();
        }

        private static void write(StringBuilder sb, Object o) {
            if (o == null) { sb.append("null"); return; }
            if (o instanceof String) { writeString(sb, (String) o); return; }
            if (o instanceof Number || o instanceof Boolean) { sb.append(o); return; }
            if (o instanceof Map) {
                sb.append('{');
                boolean first = true;
                for (Map.Entry<?, ?> e : ((Map<?, ?>) o).entrySet()) {
                    if (!first) sb.append(',');
                    first = false;
                    writeString(sb, String.valueOf(e.getKey()));
                    sb.append(':');
                    write(sb, e.getValue());
                }
                sb.append('}');
                return;
            }
            if (o instanceof Iterable) {
                sb.append('[');
                boolean first = true;
                for (Object it : (Iterable<?>) o) {
                    if (!first) sb.append(',');
                    first = false;
                    write(sb, it);
                }
                sb.append(']');
                return;
            }
            writeString(sb, String.valueOf(o));
        }

        private static void writeString(StringBuilder sb, String s) {
            sb.append('"');
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                switch (c) {
                    case '"': sb.append("\\\""); break;
                    case '\\': sb.append("\\\\"); break;
                    case '\n': sb.append("\\n"); break;
                    case '\r': sb.append("\\r"); break;
                    case '\t': sb.append("\\t"); break;
                    default:
                        if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                        else sb.append(c);
                }
            }
            sb.append('"');
        }

        /** 解析任意 JSON 值（对象 / 数组 / 字符串 / 数字 / 布尔 / null）。 */
        static Object parse(String s) {
            // 容忍 UTF-8 BOM：用编辑器维护 apps.json 时可能被写入 BOM，否则会被当成非法 token
            if (s != null && !s.isEmpty() && s.charAt(0) == '\uFEFF') s = s.substring(1);
            return new Parser(s).parse();
        }

        static Map<String, Object> parseObject(String s) {
            Object v = parse(s);
            @SuppressWarnings("unchecked")
            Map<String, Object> m = (v instanceof Map) ? (Map<String, Object>) v : new LinkedHashMap<>();
            return m;
        }

        /** 极简递归下降 JSON 解析器 */
        static class Parser {
            final String s;
            int i = 0;

            Parser(String s) { this.s = s == null ? "" : s; }

            void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }

            Object parse() {
                ws();
                if (i >= s.length()) return null;
                char c = s.charAt(i);
                if (c == '{') return obj();
                if (c == '[') return arr();
                if (c == '"') return str();
                return lit();
            }

            Map<String, Object> obj() {
                Map<String, Object> m = new LinkedHashMap<>();
                i++; ws();
                if (i < s.length() && s.charAt(i) == '}') { i++; return m; }
                while (i < s.length()) {
                    // 必须先跳过空白：apps.json 常是换行排版，否则第二个键会从空白处开始解析而失败
                    ws();
                    String k = str(); ws();
                    if (i < s.length() && s.charAt(i) == ':') i++;
                    ws();
                    m.put(k, parse());
                    ws();
                    if (i < s.length() && s.charAt(i) == ',') { i++; continue; }
                    if (i < s.length() && s.charAt(i) == '}') { i++; break; }
                    break;
                }
                return m;
            }

            List<Object> arr() {
                List<Object> l = new ArrayList<>();
                i++; ws();
                if (i < s.length() && s.charAt(i) == ']') { i++; return l; }
                while (i < s.length()) {
                    l.add(parse());
                    ws();
                    if (i < s.length() && s.charAt(i) == ',') { i++; continue; }
                    if (i < s.length() && s.charAt(i) == ']') { i++; break; }
                    break;
                }
                return l;
            }

            String str() {
                StringBuilder sb = new StringBuilder();
                if (i < s.length() && s.charAt(i) == '"') i++;
                while (i < s.length()) {
                    char c = s.charAt(i);
                    if (c == '"') { i++; break; }
                    if (c == '\\' && i + 1 < s.length()) {
                        char n = s.charAt(i + 1);
                        switch (n) {
                            case '"': sb.append('"'); break;
                            case '\\': sb.append('\\'); break;
                            case '/': sb.append('/'); break;
                            case 'n': sb.append('\n'); break;
                            case 'r': sb.append('\r'); break;
                            case 't': sb.append('\t'); break;
                            case 'b': sb.append('\b'); break;
                            case 'f': sb.append('\f'); break;
                            case 'u':
                                if (i + 5 < s.length()) {
                                    try { sb.append((char) Integer.parseInt(s.substring(i + 2, i + 6), 16)); i += 4; }
                                    catch (NumberFormatException ignored) { sb.append('u'); }
                                }
                                break;
                            default: sb.append(n);
                        }
                        i += 2;
                    } else {
                        sb.append(c);
                        i++;
                    }
                }
                return sb.toString();
            }

            Object lit() {
                StringBuilder sb = new StringBuilder();
                while (i < s.length()) {
                    char c = s.charAt(i);
                    if (c == ',' || c == '}' || c == ']' || Character.isWhitespace(c)) break;
                    sb.append(c);
                    i++;
                }
                String t = sb.toString();
                if (t.equals("true")) return Boolean.TRUE;
                if (t.equals("false")) return Boolean.FALSE;
                if (t.equals("null")) return null;
                try {
                    if (t.indexOf('.') >= 0 || t.indexOf('e') >= 0 || t.indexOf('E') >= 0) return Double.parseDouble(t);
                    return Long.parseLong(t);
                } catch (NumberFormatException e) {
                    return t;
                }
            }
        }
    }
}
