package modules;

import ui.GlassBrowserPanel;
import utils.LangManager;

import javax.swing.*;
import java.awt.*;

/**
 * 计算器模块（JCEF + 网页版液态玻璃）。
 * 原 Swing 计算器整体替换为 web/calc/calc.html：
 * 标准/科学/百分比/历史四种模式、表达式求值、键盘输入、历史记录(localStorage)。
 */
public class CalculatorModule {

    private JFrame frame;
    private GlassBrowserPanel browserPanel;

    public CalculatorModule() {
        frame = utils.WinllxIcon.createFrame(LangManager.getString("module.calc"));
        frame.setSize(430, 660);
        frame.setMinimumSize(new Dimension(360, 560));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        browserPanel = new GlassBrowserPanel("calc/calc.html", true);
        frame.add(browserPanel, BorderLayout.CENTER);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                if (browserPanel != null) browserPanel.closeBrowser();
            }
        });
        frame.setVisible(true);
        System.out.println("[Winllx3] 计算器窗口已启动 (JCEF + calc.html)");
    }

    public GlassBrowserPanel getBrowserPanel() {
        return browserPanel;
    }
}
