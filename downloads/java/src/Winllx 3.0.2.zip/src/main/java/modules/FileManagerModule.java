package modules;

import ui.GlassBrowserPanel;
import utils.LangManager;

import javax.swing.*;
import org.cef.CefClient;
import org.cef.browser.CefBrowser;
import org.cef.handler.CefDisplayHandlerAdapter;

import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 文件管理模块（JCEF + 网页版液态玻璃）。
 *
 * 原 Swing 文件管理器整体替换为 files.html；文件系统操作通过"标题桥"协议
 * （document.title = '__FILEBRIDGE__' + base64(JSON{seq,method,args})）发到本类，
 * 在后台线程执行后经 executeJavaScript 回传 window.__fileBridge.onResult(seq, b64)。
 *
 * 使用 local 模式（独立 CefClient）：可安全挂 title 桥 display handler、
 * 屏蔽 Chromium 默认右键菜单，关闭时彻底清理 native 资源。
 */
public class FileManagerModule {

    private static final String REL = "files/files.html";

    private JFrame frame;
    private GlassBrowserPanel browserPanel;
    private final ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "file-bridge");
        t.setDaemon(true);
        return t;
    });

    public FileManagerModule() {
        frame = utils.WinllxIcon.createFrame(LangManager.getString("module.file"));
        frame.setSize(1080, 680);
        frame.setMinimumSize(new Dimension(700, 440));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        browserPanel = new GlassBrowserPanel(REL, true);
        frame.add(browserPanel, BorderLayout.CENTER);

        // JCEF 未就绪时浏览器会延后创建，桥接/右键菜单需等浏览器创建完成后再装
        browserPanel.onBrowserReady(() -> {
            installBridge();
            suppressContextMenu();
        });

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                try { if (browserPanel != null) browserPanel.closeBrowser(); } catch (Throwable ignored) {}
                try { exec.shutdownNow(); } catch (Throwable ignored) {}
            }
        });
        frame.setVisible(true);
        System.out.println("[Winllx4] 文件管理窗口已启动 (JCEF + files.html)");
    }

    public GlassBrowserPanel getBrowserPanel() {
        return browserPanel;
    }

    /* ==================================================================
     * 标题桥：files.html 的 window.__fileBridge.call() → 本方法
     * ================================================================== */
    private void installBridge() {
        try {
            CefClient client = browserPanel.getClient();
            if (client == null) return;
            client.addDisplayHandler(new CefDisplayHandlerAdapter() {
                @Override
                public void onTitleChange(CefBrowser browser, String title) {
                    if (browser == null || browser != browserPanel.getBrowser()) return;
                    if (title != null && title.startsWith("__FILEBRIDGE__")) {
                        final String payload = title.substring("__FILEBRIDGE__".length());
                        exec.execute(() -> handleRequest(payload));
                    }
                }
            });
        } catch (Throwable t) {
            System.err.println("[Winllx4] 标题桥安装失败: " + t.getMessage());
        }
    }

    /** 屏蔽 Chromium 默认右键菜单（网页内部已实现自定义右键菜单） */
    private void suppressContextMenu() {
        try {
            CefClient client = browserPanel.getClient();
            if (client == null) return;
            client.addContextMenuHandler(new org.cef.handler.CefContextMenuHandlerAdapter() {
                @Override
                public void onBeforeContextMenu(CefBrowser browser, org.cef.browser.CefFrame frame,
                                                org.cef.callback.CefContextMenuParams params,
                                                org.cef.callback.CefMenuModel model) {
                    // 不添加任何菜单项 → 不弹出
                }
            });
        } catch (Throwable t) {
            System.err.println("[Winllx4] 右键菜单屏蔽失败: " + t.getMessage());
        }
    }

    private void handleRequest(String payload) {
        try {
            String json = new String(Base64.getDecoder().decode(payload), StandardCharsets.UTF_8);
            Map<String, Object> req = Json.parseObject(json);
            long seq = (req.get("seq") instanceof Number) ? ((Number) req.get("seq")).longValue() : 0L;
            String method = String.valueOf(req.get("method"));
            Object args = req.get("args");
            @SuppressWarnings("unchecked")
            Map<String, Object> argMap = (args instanceof Map) ? (Map<String, Object>) args : new HashMap<>();
            Object result = dispatch(method, argMap);
            sendResult(seq, result);
        } catch (Throwable t) {
            System.err.println("[Winllx4] 桥请求处理失败: " + t.getMessage());
            t.printStackTrace();
            sendResult(-1, Json.obj("ok", false, "error", "内部错误: " + t.getMessage()));
        }
    }

    private void sendResult(long seq, Object result) {
        try {
            String resJson = Json.stringify(result);
            final String b64 = Base64.getEncoder().encodeToString(resJson.getBytes(StandardCharsets.UTF_8));
            final long fSeq = seq;
            SwingUtilities.invokeLater(() -> {
                try {
                    browserPanel.executeJavaScript("window.__fileBridge.onResult(" + fSeq + ",'" + b64 + "')");
                } catch (Throwable t) {
                    System.err.println("[Winllx4] 回传失败: " + t.getMessage());
                }
            });
        } catch (Throwable t) {
            System.err.println("[Winllx4] 结果编码失败: " + t.getMessage());
        }
    }

    /* ==================================================================
     * 文件操作分发
     * ================================================================== */
    private Object dispatch(String m, Map<String, Object> a) throws Exception {
        switch (m) {
            case "home": return pathOk(System.getProperty("user.home"));
            case "desktop": return pathOk(homeSub("Desktop"));
            case "downloads": return pathOk(homeSub("Downloads"));
            case "documents": return pathOk(homeSub("Documents"));
            case "roots": return doRoots();
            case "list": return doList(str(a, "path"));
            case "parent": return doParent(str(a, "path"));
            case "mkdir": return doMkdir(str(a, "parent"), str(a, "name"));
            case "createFile": return doCreateFile(str(a, "parent"), str(a, "name"));
            case "rename": return doRename(str(a, "path"), str(a, "newName"));
            case "delete": return doDelete(str(a, "path"));
            case "copy": return doCopy(str(a, "src"), str(a, "dstParent"));
            case "move": return doMove(str(a, "src"), str(a, "dstParent"));
            case "readText": return doReadText(str(a, "path"));
            case "readImage": return doReadImage(str(a, "path"));
            case "open": return doOpen(str(a, "path"));
            case "properties": return doProperties(str(a, "path"));
            case "search": return doSearch(str(a, "dir"), str(a, "keyword"));
            default: return Json.obj("ok", false, "error", "未知方法: " + m);
        }
    }

    private static String str(Map<String, Object> a, String key) {
        Object v = a.get(key);
        return v == null ? "" : String.valueOf(v);
    }

    private static String homeSub(String name) {
        String base = System.getProperty("user.home");
        if (base == null) base = ".";
        return new File(base, name).getAbsolutePath();
    }

    private static Object pathOk(String path) {
        return Json.obj("ok", true, "path", path);
    }

    private Object doRoots() {
        List<Object> rs = new ArrayList<>();
        for (File r : File.listRoots()) {
            rs.add(Json.obj("path", r.getAbsolutePath(), "label", r.getPath()));
        }
        return Json.obj("ok", true, "roots", rs);
    }

    private Object doList(String path) {
        File d = new File(path);
        if (!d.isDirectory()) return Json.obj("ok", false, "error", "无法打开文件夹: " + path);
        File[] fs = d.listFiles();
        List<Object> items = new ArrayList<>();
        if (fs != null) {
            List<File> sorted = new ArrayList<>(Arrays.asList(fs));
            sorted.sort((x, y) -> {
                if (x.isDirectory() != y.isDirectory()) return x.isDirectory() ? -1 : 1;
                return x.getName().toLowerCase().compareTo(y.getName().toLowerCase());
            });
            for (File f : sorted) items.add(fileItem(f));
        }
        return Json.obj("ok", true, "path", d.getAbsolutePath(), "items", items);
    }

    private static Object fileItem(File f) {
        return Json.obj(
                "name", f.getName(),
                "path", f.getAbsolutePath(),
                "isDir", f.isDirectory(),
                "size", f.isDirectory() ? 0L : f.length(),
                "modified", f.lastModified());
    }

    private Object doParent(String path) {
        File p = new File(path).getParentFile();
        return Json.obj("ok", true, "parent", p != null ? p.getAbsolutePath() : null);
    }

    private static boolean invalidName(String name) {
        return name == null || name.trim().isEmpty()
                || name.contains("/") || name.contains("\\")
                || name.equals(".") || name.equals("..")
                || name.indexOf(':') >= 0;
    }

    private static File uniqueChild(File parent, String name) {
        File f = new File(parent, name);
        if (!f.exists()) return f;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; i < 10000; i++) {
            File nf = new File(parent, base + "(" + i + ")" + ext);
            if (!nf.exists()) return nf;
        }
        return new File(parent, name + "_" + System.currentTimeMillis());
    }

    private Object doMkdir(String parent, String name) {
        if (invalidName(name)) return Json.obj("ok", false, "error", "名称不合法");
        File base = new File(parent);
        if (!base.isDirectory()) return Json.obj("ok", false, "error", "目标目录无效");
        File target = uniqueChild(base, name);
        return target.mkdirs()
                ? Json.obj("ok", true, "path", target.getAbsolutePath())
                : Json.obj("ok", false, "error", "创建失败（名称可能被占用）");
    }

    private Object doCreateFile(String parent, String name) {
        if (invalidName(name)) return Json.obj("ok", false, "error", "名称不合法");
        File base = new File(parent);
        if (!base.isDirectory()) return Json.obj("ok", false, "error", "目标目录无效");
        File target = uniqueChild(base, name);
        try {
            if (target.createNewFile()) return Json.obj("ok", true, "path", target.getAbsolutePath());
        } catch (IOException e) {
            return Json.obj("ok", false, "error", "创建失败: " + e.getMessage());
        }
        return Json.obj("ok", false, "error", "创建失败（名称可能被占用）");
    }

    private Object doRename(String path, String newName) {
        if (invalidName(newName)) return Json.obj("ok", false, "error", "名称不合法");
        File f = new File(path);
        if (!f.exists()) return Json.obj("ok", false, "error", "文件不存在");
        File target = new File(f.getParentFile(), newName);
        if (target.exists()) return Json.obj("ok", false, "error", "目标名称已存在");
        return f.renameTo(target)
                ? Json.obj("ok", true)
                : Json.obj("ok", false, "error", "重命名失败");
    }

    private Object doDelete(String path) {
        File f = new File(path);
        if (!f.exists()) return Json.obj("ok", false, "error", "文件不存在");
        return deleteRec(f)
                ? Json.obj("ok", true)
                : Json.obj("ok", false, "error", "删除失败（文件可能被占用）");
    }

    private static boolean deleteRec(File f) {
        if (f.isDirectory()) {
            File[] cs = f.listFiles();
            if (cs != null) for (File c : cs) deleteRec(c);
        }
        return f.delete();
    }

    private Object doCopy(String srcPath, String dstParentPath) {
        File src = new File(srcPath);
        File dstParent = new File(dstParentPath);
        if (!src.exists()) return Json.obj("ok", false, "error", "源不存在");
        if (!dstParent.isDirectory()) return Json.obj("ok", false, "error", "目标目录无效");
        File target = uniqueChild(dstParent, src.getName());
        try {
            copyRec(src, target);
            return Json.obj("ok", true, "path", target.getAbsolutePath());
        } catch (IOException e) {
            return Json.obj("ok", false, "error", "复制失败: " + e.getMessage());
        }
    }

    private static void copyRec(File src, File dst) throws IOException {
        if (src.isDirectory()) {
            if (!dst.mkdirs() && !dst.isDirectory()) throw new IOException("创建目录失败: " + dst);
            File[] cs = src.listFiles();
            if (cs != null) for (File c : cs) copyRec(c, new File(dst, c.getName()));
        } else {
            try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
        }
    }

    private Object doMove(String srcPath, String dstParentPath) {
        File src = new File(srcPath);
        File dstParent = new File(dstParentPath);
        if (!src.exists()) return Json.obj("ok", false, "error", "源不存在");
        if (!dstParent.isDirectory()) return Json.obj("ok", false, "error", "目标目录无效");
        File target = uniqueChild(dstParent, src.getName());
        try {
            Files.move(src.toPath(), target.toPath());
        } catch (IOException e) {
            try {
                copyRec(src, target);
                deleteRec(src);
            } catch (IOException e2) {
                deleteRec(target);
                return Json.obj("ok", false, "error", "移动失败: " + e2.getMessage());
            }
        }
        return Json.obj("ok", true, "path", target.getAbsolutePath());
    }

    private Object doReadText(String path) {
        File f = new File(path);
        if (!f.isFile()) return Json.obj("ok", false, "error", "不是文件");
        try {
            byte[] bytes = Files.readAllBytes(f.toPath());
            String text = new String(bytes, StandardCharsets.UTF_8);
            if (text.indexOf('\uFFFD') >= 0) {
                String gbk = new String(bytes, Charset.forName("GBK"));
                if (gbk.indexOf('\uFFFD') < text.indexOf('\uFFFD')) text = gbk;
            }
            return Json.obj("ok", true, "text", text, "size", bytes.length);
        } catch (IOException e) {
            return Json.obj("ok", false, "error", "读取失败: " + e.getMessage());
        }
    }

    private Object doReadImage(String path) {
        File f = new File(path);
        if (!f.isFile()) return Json.obj("ok", false, "error", "不是文件");
        try {
            byte[] bytes = Files.readAllBytes(f.toPath());
            String b64 = Base64.getEncoder().encodeToString(bytes);
            String mime = mimeByExt(f.getName());
            return Json.obj("ok", true, "dataUrl", "data:" + mime + ";base64," + b64, "size", bytes.length);
        } catch (IOException e) {
            return Json.obj("ok", false, "error", "读取失败: " + e.getMessage());
        }
    }

    private static String mimeByExt(String name) {
        int i = name.lastIndexOf('.');
        String e = i > 0 ? name.substring(i + 1).toLowerCase() : "";
        switch (e) {
            case "png": return "image/png";
            case "jpg": case "jpeg": return "image/jpeg";
            case "gif": return "image/gif";
            case "webp": return "image/webp";
            case "bmp": return "image/bmp";
            case "svg": return "image/svg+xml";
            case "ico": return "image/x-icon";
            default: return "application/octet-stream";
        }
    }

    private Object doOpen(String path) {
        File f = new File(path);
        if (!f.exists()) return Json.obj("ok", false, "error", "文件不存在");
        try {
            if (!Desktop.isDesktopSupported() || !Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                return Json.obj("ok", false, "error", "系统不支持打开操作");
            }
            Desktop.getDesktop().open(f);
            return Json.obj("ok", true);
        } catch (Throwable t) {
            return Json.obj("ok", false, "error", "打开失败: " + t.getMessage());
        }
    }

    private Object doProperties(String path) {
        File f = new File(path);
        if (!f.exists()) return Json.obj("ok", false, "error", "文件不存在");
        int childCount = 0;
        if (f.isDirectory()) {
            File[] cs = f.listFiles();
            if (cs != null) childCount = cs.length;
        }
        return Json.obj("ok", true,
                "name", f.getName(),
                "path", f.getAbsolutePath(),
                "isDir", f.isDirectory(),
                "size", f.isDirectory() ? 0L : f.length(),
                "modified", f.lastModified(),
                "readable", f.canRead(),
                "writable", f.canWrite(),
                "hidden", f.isHidden(),
                "childCount", childCount);
    }

    private Object doSearch(String dir, String keyword) {
        File root = new File(dir);
        if (!root.isDirectory() || keyword == null || keyword.trim().isEmpty()) {
            return Json.obj("ok", true, "items", new ArrayList<>());
        }
        List<Object> results = new ArrayList<>();
        searchRec(root, keyword.trim().toLowerCase(), results, 0);
        return Json.obj("ok", true, "items", results);
    }

    private static void searchRec(File dir, String kw, List<Object> out, int depth) {
        if (depth > 3 || out.size() >= 300) return;
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (out.size() >= 300) return;
            if (f.getName().toLowerCase().contains(kw)) {
                @SuppressWarnings("unchecked")
                Map<String, Object> it = new LinkedHashMap<>((Map<String, Object>) fileItem(f));
                it.put("parentDir", dir.getAbsolutePath());
                out.add(it);
            }
            if (f.isDirectory()) searchRec(f, kw, out, depth + 1);
        }
    }

    /* ==================================================================
     * 迷你 JSON 工具（对象/数组/字符串/数字/布尔/null）
     * ================================================================== */
    private static class Json {
        static Map<String, Object> obj(Object... kv) {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            for (int i = 0; i + 1 < kv.length; i += 2) m.put(String.valueOf(kv[i]), kv[i + 1]);
            return m;
        }

        static String esc(String s) {
            if (s == null) return "null";
            StringBuilder sb = new StringBuilder(s.length() + 16);
            sb.append('"');
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                switch (c) {
                    case '"': sb.append("\\\""); break;
                    case '\\': sb.append("\\\\"); break;
                    case '\n': sb.append("\\n"); break;
                    case '\r': sb.append("\\r"); break;
                    case '\t': sb.append("\\t"); break;
                    case '\b': sb.append("\\b"); break;
                    case '\f': sb.append("\\f"); break;
                    default:
                        if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                        else sb.append(c);
                }
            }
            sb.append('"');
            return sb.toString();
        }

        static String stringify(Object o) {
            if (o == null) return "null";
            if (o instanceof String) return esc((String) o);
            if (o instanceof Number || o instanceof Boolean) return String.valueOf(o);
            if (o instanceof Map) {
                StringBuilder sb = new StringBuilder("{");
                boolean first = true;
                for (Map.Entry<?, ?> e : ((Map<?, ?>) o).entrySet()) {
                    if (!first) sb.append(',');
                    first = false;
                    sb.append(esc(String.valueOf(e.getKey()))).append(':').append(stringify(e.getValue()));
                }
                return sb.append('}').toString();
            }
            if (o instanceof Iterable) {
                StringBuilder sb = new StringBuilder("[");
                boolean first = true;
                for (Object v : (Iterable<?>) o) {
                    if (!first) sb.append(',');
                    first = false;
                    sb.append(stringify(v));
                }
                return sb.append(']').toString();
            }
            return esc(String.valueOf(o));
        }

        static Map<String, Object> parseObject(String s) {
            Parser p = new Parser(s);
            Object v = p.parse();
            return v instanceof Map ? (Map<String, Object>) v : new LinkedHashMap<>();
        }

        /** 极简递归下降 JSON 解析器（只服务本模块的简单请求） */
        static class Parser {
            final String s;
            int i = 0;

            Parser(String s) { this.s = s == null ? "" : s; }

            void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }

            Object parse() {
                ws();
                if (i >= s.length()) return null;
                char c = s.charAt(i);
                if (c == '{') return obj();
                if (c == '[') return arr();
                if (c == '"') return str();
                return lit();
            }

            Map<String, Object> obj() {
                Map<String, Object> m = new LinkedHashMap<>();
                i++; ws();
                if (i < s.length() && s.charAt(i) == '}') { i++; return m; }
                while (i < s.length()) {
                    String k = str(); ws();
                    if (i < s.length() && s.charAt(i) == ':') i++;
                    ws();
                    m.put(k, parse());
                    ws();
                    if (i < s.length() && s.charAt(i) == ',') { i++; continue; }
                    if (i < s.length() && s.charAt(i) == '}') { i++; break; }
                    break;
                }
                return m;
            }

            List<Object> arr() {
                List<Object> l = new ArrayList<>();
                i++; ws();
                if (i < s.length() && s.charAt(i) == ']') { i++; return l; }
                while (i < s.length()) {
                    l.add(parse());
                    ws();
                    if (i < s.length() && s.charAt(i) == ',') { i++; continue; }
                    if (i < s.length() && s.charAt(i) == ']') { i++; break; }
                    break;
                }
                return l;
            }

            String str() {
                StringBuilder sb = new StringBuilder();
                if (i < s.length() && s.charAt(i) == '"') i++;
                while (i < s.length()) {
                    char c = s.charAt(i);
                    if (c == '"') { i++; break; }
                    if (c == '\\' && i + 1 < s.length()) {
                        char n = s.charAt(i + 1);
                        switch (n) {
                            case '"': sb.append('"'); break;
                            case '\\': sb.append('\\'); break;
                            case '/': sb.append('/'); break;
                            case 'n': sb.append('\n'); break;
                            case 'r': sb.append('\r'); break;
                            case 't': sb.append('\t'); break;
                            case 'b': sb.append('\b'); break;
                            case 'f': sb.append('\f'); break;
                            case 'u':
                                if (i + 5 < s.length()) {
                                    try { sb.append((char) Integer.parseInt(s.substring(i + 2, i + 6), 16)); i += 4; }
                                    catch (NumberFormatException ignored) { sb.append('u'); }
                                }
                                break;
                            default: sb.append(n);
                        }
                        i += 2;
                    } else {
                        sb.append(c);
                        i++;
                    }
                }
                return sb.toString();
            }

            Object lit() {
                StringBuilder sb = new StringBuilder();
                while (i < s.length()) {
                    char c = s.charAt(i);
                    if (c == ',' || c == '}' || c == ']' || Character.isWhitespace(c)) break;
                    sb.append(c);
                    i++;
                }
                String t = sb.toString();
                if (t.equals("true")) return Boolean.TRUE;
                if (t.equals("false")) return Boolean.FALSE;
                if (t.equals("null")) return null;
                try {
                    if (t.indexOf('.') >= 0 || t.indexOf('e') >= 0 || t.indexOf('E') >= 0) return Double.parseDouble(t);
                    return Long.parseLong(t);
                } catch (NumberFormatException e) {
                    return t;
                }
            }
        }
    }
}
