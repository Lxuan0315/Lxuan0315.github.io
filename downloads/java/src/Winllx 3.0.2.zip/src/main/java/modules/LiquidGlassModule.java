package modules;

import ui.GlassBrowserPanel;
import utils.GlassAssetServer;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * 液态玻璃模块入口：
 * 1. 启动本地 HTTP 服务器伺服 Next.js 静态导出资源（解决 file:// 协议限制）
 * 2. 创建 GlassFrame 窗口并嵌入 JCEF 浏览器面板
 * 3. 浏览器加载网页版液态玻璃，效果与 GitHub 项目完全一致
 *
 * 若本地静态资源不存在，回退到开发服务器 http://localhost:3000/
 */
public class LiquidGlassModule {
    private static GlassAssetServer assetServer;
    private static String baseUrl;

    /**
     * 确保基础 URL 可用：优先本地静态资源服务器，否则回退到开发服务器
     */
    private static synchronized String ensureBaseUrl() {
        if (baseUrl != null) {
            return baseUrl;
        }
        // 静态导出资源目录（相对程序工作目录）
        String docRoot = System.getProperty("user.dir") + "/web/glass";
        if (!Files.isDirectory(Paths.get(docRoot))) {
            // 静态资源不存在，回退到开发服务器
            baseUrl = "http://localhost:3000/";
            return baseUrl;
        }
        try {
            // port=0 让系统自动分配可用端口
            assetServer = new GlassAssetServer(docRoot, 0);
            baseUrl = assetServer.start();
        } catch (IOException e) {
            baseUrl = "http://localhost:3000/";
        }
        return baseUrl;
    }

    public LiquidGlassModule() {
        SwingUtilities.invokeLater(() -> {
            String url = ensureBaseUrl();
            JFrame frame = utils.WinllxIcon.createFrame("液态玻璃");
            frame.setSize(960, 680);
            frame.setMinimumSize(new Dimension(640, 480));
            frame.setLocationRelativeTo(null);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            GlassBrowserPanel panel = new GlassBrowserPanel(url);
            frame.setContentPane(panel);
            frame.setVisible(true);
        });
    }

    /** 模块卸载时清理资源（可由外部调用） */
    public static synchronized void shutdown() {
        if (assetServer != null) {
            assetServer.stop();
            assetServer = null;
        }
        baseUrl = null;
    }
}
