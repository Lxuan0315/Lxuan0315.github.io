package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

/**
 * 浏览器设置持久化（Winllx/browser.properties）。
 * 未写入过时全部返回默认值，保证首次运行开箱即用。
 */
public class BrowserPrefs {

    private static final String DIR = System.getProperty("user.dir") + "/Winllx";
    private static final String FILE = DIR + "/browser.properties";

    /** 搜索引擎可选值（与 search.html 下拉顺序一致） */
    public static final String[] SEARCH_IDS = {"bing", "google", "baidu", "duckduckgo"};
    private static final String[] SEARCH_URLS = {
            "https://www.bing.com/search?q=",
            "https://www.google.com/search?q=",
            "https://www.baidu.com/s?wd=",
            "https://duckduckgo.com/?q="
    };

    private static final Properties P = new Properties();

    static {
        load();
    }

    private static void load() {
        try {
            File f = new File(FILE);
            if (f.exists()) {
                try (FileInputStream in = new FileInputStream(f)) {
                    P.load(in);
                }
            }
        } catch (Throwable t) {
            System.err.println("[BrowserPrefs] 读取失败: " + t.getMessage());
        }
    }

    public static synchronized void save() {
        try {
            File d = new File(DIR);
            if (!d.exists()) d.mkdirs();
            try (FileOutputStream out = new FileOutputStream(FILE)) {
                P.store(out, "Winllx Browser Settings");
            }
        } catch (Throwable t) {
            System.err.println("[BrowserPrefs] 保存失败: " + t.getMessage());
        }
    }

    // ===== 主页 =====

    public static String getHomeUrl() {
        return P.getProperty("homeUrl", "https://www.bing.com");
    }

    public static void setHomeUrl(String url) {
        P.setProperty("homeUrl", url == null || url.trim().isEmpty() ? "https://www.bing.com" : url.trim());
        save();
    }

    // ===== 搜索引擎 =====

    public static String getSearchEngine() {
        String id = P.getProperty("searchEngine", "bing");
        for (String s : SEARCH_IDS) if (s.equals(id)) return id;
        return "bing";
    }

    public static void setSearchEngine(String id) {
        for (String s : SEARCH_IDS) {
            if (s.equals(id)) { P.setProperty("searchEngine", s); save(); return; }
        }
    }

    /** 当前搜索引擎的前缀，如 https://www.bing.com/search?q= */
    public static String getSearchUrlPrefix() {
        String id = getSearchEngine();
        for (int i = 0; i < SEARCH_IDS.length; i++) {
            if (SEARCH_IDS[i].equals(id)) return SEARCH_URLS[i];
        }
        return SEARCH_URLS[0];
    }

    // ===== 标签页行为 =====

    public static boolean isRestoreSession() {
        return "true".equalsIgnoreCase(P.getProperty("restoreSession", "false"));
    }

    public static void setRestoreSession(boolean on) {
        P.setProperty("restoreSession", String.valueOf(on));
        save();
    }

    /** 新标签页内容：home=主页，blank=空白页 */
    public static String getNewTabContent() {
        String v = P.getProperty("newTabContent", "home");
        return "blank".equals(v) ? "blank" : "home";
    }

    public static void setNewTabContent(String v) {
        P.setProperty("newTabContent", "blank".equals(v) ? "blank" : "home");
        save();
    }

    public static boolean isShowCloseButton() {
        return "true".equalsIgnoreCase(P.getProperty("showCloseButton", "true"));
    }

    public static void setShowCloseButton(boolean on) {
        P.setProperty("showCloseButton", String.valueOf(on));
        save();
    }

    public static boolean isCloseOnDblClick() {
        return "true".equalsIgnoreCase(P.getProperty("closeOnDblClick", "true"));
    }

    public static void setCloseOnDblClick(boolean on) {
        P.setProperty("closeOnDblClick", String.valueOf(on));
        save();
    }

    // ===== 下载 =====

    public static String getDownloadDir() {
        String v = P.getProperty("downloadDir", "");
        if (v != null && !v.trim().isEmpty()) return v;
        File d = new File(System.getProperty("user.home"), "Downloads");
        return d.getAbsolutePath();
    }

    public static void setDownloadDir(String dir) {
        P.setProperty("downloadDir", dir == null ? "" : dir.trim());
        save();
    }

    // ===== 会话（上次打开的标签地址，\n 分隔） =====

    public static String getSession() {
        return P.getProperty("session", "");
    }

    public static void setSession(String urls) {
        P.setProperty("session", urls == null ? "" : urls);
        save();
    }

    // ===== 重置 =====

    public static synchronized void resetDefaults() {
        P.clear();
        save();
    }
}
