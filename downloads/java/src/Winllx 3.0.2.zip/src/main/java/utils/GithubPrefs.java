package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

/**
 * GitHub 加速设置持久化（Winllx/github_accel.properties）。
 * 与 BrowserPrefs 同范式：静态 Properties + 写后即存，未写入过时全部返回默认值。
 */
public class GithubPrefs {

    private static final String DIR = System.getProperty("user.dir") + "/Winllx";
    private static final String FILE = DIR + "/github_accel.properties";

    /** 加速模式：auto=自动测速择优，off=直连，custom=自定义前缀，manual=手动指定镜像 */
    public static final String MODE_AUTO = "auto";
    public static final String MODE_OFF = "off";
    public static final String MODE_CUSTOM = "custom";
    public static final String MODE_MANUAL = "manual";

    private static final Properties P = new Properties();

    static {
        load();
    }

    private static void load() {
        try {
            File f = new File(FILE);
            if (f.exists()) {
                try (FileInputStream in = new FileInputStream(f)) {
                    P.load(in);
                }
            }
        } catch (Throwable t) {
            System.err.println("[GithubPrefs] 读取失败: " + t.getMessage());
        }
    }

    public static synchronized void save() {
        try {
            File d = new File(DIR);
            if (!d.exists()) d.mkdirs();
            try (FileOutputStream out = new FileOutputStream(FILE)) {
                P.store(out, "Winllx GitHub Accelerator Settings");
            }
        } catch (Throwable t) {
            System.err.println("[GithubPrefs] 保存失败: " + t.getMessage());
        }
    }

    // ===== 加速模式 =====

    public static String getMode() {
        String v = P.getProperty("mode", MODE_AUTO);
        if (MODE_OFF.equals(v) || MODE_CUSTOM.equals(v) || MODE_MANUAL.equals(v)) return v;
        return MODE_AUTO;
    }

    public static void setMode(String mode) {
        String v = MODE_AUTO;
        if (MODE_OFF.equals(mode) || MODE_CUSTOM.equals(mode) || MODE_MANUAL.equals(mode)) v = mode;
        P.setProperty("mode", v);
        save();
    }

    // ===== 应用索引地址 =====

    public static String getIndexUrl() {
        return P.getProperty("indexUrl", "").trim();
    }

    public static void setIndexUrl(String url) {
        P.setProperty("indexUrl", url == null ? "" : url.trim());
        save();
    }

    // ===== 自定义镜像前缀 =====

    public static String getCustomPrefix() {
        return P.getProperty("customPrefix", "").trim();
    }

    public static void setCustomPrefix(String prefix) {
        P.setProperty("customPrefix", prefix == null ? "" : prefix.trim());
        save();
    }

    // ===== 手动指定镜像 id =====

    public static String getManualId() {
        return P.getProperty("manualId", "").trim();
    }

    public static void setManualId(String id) {
        P.setProperty("manualId", id == null ? "" : id.trim());
        save();
    }

    // ===== 网络超时（毫秒） =====

    public static int getTimeoutMs() {
        try {
            int v = Integer.parseInt(P.getProperty("timeoutMs", "15000").trim());
            if (v < 2000) v = 2000;
            if (v > 120000) v = 120000;
            return v;
        } catch (Throwable t) {
            return 15000;
        }
    }

    public static void setTimeoutMs(int ms) {
        int v = Math.max(2000, Math.min(120000, ms));
        P.setProperty("timeoutMs", String.valueOf(v));
        save();
    }

    // ===== 择优结果缓存（由 GitHubAccel 写入）=====

    public static String getChosenCache() {
        return P.getProperty("chosenCache", "");
    }

    public static void setChosenCache(String ids) {
        P.setProperty("chosenCache", ids == null ? "" : ids);
        save();
    }

    public static long getProbeAt() {
        try {
            return Long.parseLong(P.getProperty("probeAt", "0").trim());
        } catch (Throwable t) {
            return 0L;
        }
    }

    public static void setProbeAt(long at) {
        P.setProperty("probeAt", String.valueOf(at));
        save();
    }

    /** 重置全部加速设置（用户点「恢复默认」时用）。 */
    public static synchronized void resetDefaults() {
        P.clear();
        save();
    }
}
