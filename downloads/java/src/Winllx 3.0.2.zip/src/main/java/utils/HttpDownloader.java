package utils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 通用 HTTP 下载工具。
 *
 * 特性：
 *  - 手动跟随 301/302/303/307/308 重定向（最多 6 跳，含 http↔https 跨协议，系统默认不跟随跨协议）
 *  - Range 断点续传：206 追加、200 忽略 Range 时截断重写、416 视为已完成
 *  - sha256 校验：不符则抛错，由调用方换镜像重试
 *  - 多候选（镜像）依次回退，带进度回调
 */
public class HttpDownloader {

    public static final String UA = "Winllx/1.0";

    /** 进度回调：stage 为 download / verify */
    public interface Progress {
        void onStage(String stage, long done, long total);
    }

    /** 已打开的连接（含最终地址与状态码） */
    public static final class Conn {
        public final HttpURLConnection conn;
        public final int code;
        public final String finalUrl;

        Conn(HttpURLConnection conn, int code, String finalUrl) {
            this.conn = conn;
            this.code = code;
            this.finalUrl = finalUrl;
        }
    }

    /** 打开连接并手动跟随重定向；range 为 null 表示不请求分片。 */
    public static Conn open(String urlStr, int connectMs, int readMs, String range) throws IOException {
        String current = urlStr;
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = (HttpURLConnection) URI.create(current).toURL().openConnection();
            c.setRequestMethod("GET");
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(connectMs);
            c.setReadTimeout(readMs);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept", "*/*");
            if (range != null) c.setRequestProperty("Range", range);
            int code;
            try {
                code = c.getResponseCode();
            } catch (IOException e) {
                c.disconnect();
                throw e;
            }
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null || loc.isEmpty()) throw new IOException("重定向缺少 Location");
                current = URI.create(current).resolve(loc).toURL().toString();
                continue;
            }
            return new Conn(c, code, current);
        }
        throw new IOException("重定向次数过多");
    }

    /** 文本拉取：依次尝试候选地址，返回首个成功结果 {ok,body,url,error}。 */
    public static Map<String, Object> text(List<GitHubAccel.Plan> plans, int timeoutMs) {
        StringBuilder errs = new StringBuilder();
        for (GitHubAccel.Plan p : plans) {
            Conn c = null;
            try {
                c = open(p.url, Math.min(timeoutMs, 10000), timeoutMs, null);
                if (c.code >= 400) {
                    errs.append(p.mirrorId).append(" HTTP ").append(c.code).append("; ");
                    continue;
                }
                if (isHtmlResponse(c.conn)) {
                    errs.append(p.mirrorId).append(" 返回网页(被拦截); ");
                    continue;
                }
                String body;
                try (InputStream in = c.conn.getInputStream()) {
                    body = readAll(in);
                }
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("ok", true);
                m.put("body", body);
                m.put("url", c.finalUrl);
                m.put("mirror", p.mirrorId);
                return m;
            } catch (Throwable t) {
                errs.append(p.mirrorId).append(" ").append(msg(t)).append("; ");
            } finally {
                if (c != null) try { c.conn.disconnect(); } catch (Throwable ignore) {}
            }
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("ok", false);
        m.put("error", "全部候选失败: " + errs);
        return m;
    }

    /**
     * 下载文件到 dest（dest 即分片临时文件路径），成功后返回 dest。
     * 依次尝试 plans 中最多 maxMirrors 个候选，全部失败抛 IOException。
     */
    public static File file(List<GitHubAccel.Plan> plans, File dest, String sha256Hex,
                            long expectSize, Progress p, int maxMirrors) throws IOException {
        StringBuilder errs = new StringBuilder();
        int tried = 0;
        for (GitHubAccel.Plan plan : plans) {
            if (tried >= maxMirrors) break;
            tried++;
            try {
                downloadOnce(plan, dest, sha256Hex, expectSize, p);
                return dest;
            } catch (Throwable t) {
                errs.append(plan.mirrorId).append(": ").append(msg(t)).append("; ");
            }
        }
        throw new IOException("下载失败(" + tried + " 个候选): " + errs);
    }

    private static void downloadOnce(GitHubAccel.Plan plan, File dest, String sha256Hex,
                                     long expectSize, Progress p) throws IOException {
        File parent = dest.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new IOException("无法创建目录: " + parent);
        }

        long already = dest.exists() ? dest.length() : 0;
        if (expectSize > 0 && already == expectSize && sha256Hex != null) {
            if (sha256Hex.equalsIgnoreCase(sha256(dest))) return;   // 上次已下载完成
        }
        if (expectSize > 0 && already > expectSize) {
            dest.delete();
            already = 0;
        }

        String range = already > 0 ? ("bytes=" + already + "-") : null;
        Conn c = open(plan.url, 15000, 60000, range);
        int code = c.code;

        // 镜像可能返回拦截/验证网页而不报错，二进制下载必须拒绝
        if (code < 400 && isHtmlResponse(c.conn)) {
            c.conn.disconnect();
            throw new IOException("镜像返回的是网页而非文件（可能被拦截）");
        }

        boolean append;
        long total;
        if (code == 416) {
            // 请求范围超出文件（通常是本地分片已完整）：校验后直接用
            c.conn.disconnect();
            if (sha256Hex != null && sha256Hex.equalsIgnoreCase(sha256(dest))) return;
            dest.delete();
            already = 0;
            c = open(plan.url, 15000, 60000, null);
            code = c.code;
            if (code >= 400) {
                c.conn.disconnect();
                throw new IOException("HTTP " + code);
            }
            append = false;
            total = expectSize > 0 ? expectSize : c.conn.getContentLengthLong();
        } else if (code == 206) {
            append = already > 0;
            total = expectSize > 0 ? expectSize : already + c.conn.getContentLengthLong();
        } else if (code == 200) {
            append = false;          // 服务器忽略了 Range → 必须从头写
            already = 0;
            total = expectSize > 0 ? expectSize : c.conn.getContentLengthLong();
        } else {
            c.conn.disconnect();
            throw new IOException("HTTP " + code);
        }

        long done = already;
        if (p != null) p.onStage("download", done, total);
        byte[] buf = new byte[64 * 1024];
        long lastTick = 0;
        try (InputStream in = c.conn.getInputStream();
             FileOutputStream fos = new FileOutputStream(dest, append)) {
            int n;
            while ((n = in.read(buf)) > 0) {
                fos.write(buf, 0, n);
                done += n;
                long now = System.currentTimeMillis();
                if (p != null && now - lastTick >= 200) {
                    lastTick = now;
                    p.onStage("download", done, total);
                }
            }
            fos.flush();
        } finally {
            try { c.conn.disconnect(); } catch (Throwable ignore) {}
        }

        if (expectSize > 0 && dest.length() != expectSize) {
            throw new IOException("大小不符 " + dest.length() + "/" + expectSize);
        }
        if (sha256Hex != null) {
            if (p != null) p.onStage("verify", done, total);
            String h = sha256(dest);
            if (!h.equalsIgnoreCase(sha256Hex)) {
                throw new IOException("sha256 校验失败，实际=" + h);
            }
        }
        if (p != null) p.onStage("download", total, total);
    }

    /** 响应是否为 HTML（拦截/验证网页），二进制下载与测速都应据此判失败。 */
    public static boolean isHtmlResponse(HttpURLConnection c) {
        try {
            String ct = c.getHeaderField("Content-Type");
            return ct != null && ct.toLowerCase().contains("text/html");
        } catch (Throwable t) {
            return false;
        }
    }

    /** 计算文件 sha256（十六进制小写） */
    public static String sha256(File f) throws IOException {
        try (InputStream in = new BufferedInputStream(new FileInputStream(f))) {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            StringBuilder sb = new StringBuilder(64);
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException(e);
        }
    }

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buf = new byte[16 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) baos.write(buf, 0, n);
        return baos.toString(StandardCharsets.UTF_8.name());
    }

    private static String msg(Throwable t) {
        String m = t.getMessage();
        return (m == null || m.isEmpty()) ? t.getClass().getSimpleName() : m;
    }
}
