package utils;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

/**
 * 极简本地 HTTP 服务器
 * 用于伺服 Next.js / notes 静态资源，解决 file:// 协议下路径与 localStorage 同源问题。
 * 健壮性增强：
 *   1) URL 解码后再解析路径
 *   2) 严格 containment 检查（normalize + startsWith(realRoot)）
 *   3) 目录请求 → 按序查找 index.html / index.htm / 同目录名的 notes.html（不存在则 403，不再 500）
 *   4) 任何异常打印完整堆栈 + 响应体返回文字错误，便于排查"换电脑 500"
 *   5) 端口冲突时自动尝试下一个端口
 */
public class GlassAssetServer {
    private HttpServer server;
    private Path realRoot;
    private final String docRoot;
    private int resolvedPort;
    private final int requestedPort;

    /* ===================== /api 通道 ===================== */

    /** /api/* 请求的响应体：状态码 + 内容类型 + 字节。 */
    public static final class ApiResponse {
        public final int code;
        public final String contentType;
        public final byte[] body;

        public ApiResponse(int code, String contentType, byte[] body) {
            this.code = code;
            this.contentType = contentType;
            this.body = body == null ? new byte[0] : body;
        }

        public static ApiResponse json(String s) {
            return new ApiResponse(200, "application/json; charset=utf-8",
                    (s == null ? "{}" : s).getBytes(StandardCharsets.UTF_8));
        }

        public static ApiResponse bytes(byte[] b, String contentType) {
            return new ApiResponse(200, contentType, b);
        }

        public static ApiResponse notFound(String s) {
            return new ApiResponse(404, "text/plain; charset=utf-8",
                    (s == null ? "Not Found" : s).getBytes(StandardCharsets.UTF_8));
        }

        public static ApiResponse error(String s) {
            return new ApiResponse(500, "text/plain; charset=utf-8",
                    (s == null ? "Error" : s).getBytes(StandardCharsets.UTF_8));
        }
    }

    /** 宿主实现的 API 回调（path 已去掉 "/api" 前缀，如 "/state"）。 */
    public interface ApiHandler {
        ApiResponse handle(String path, Map<String, String> query, String method, String body) throws Exception;
    }

    private static volatile ApiHandler apiHandler;

    /** 注册 API 回调；应在任何页面加载之前调用。 */
    public static void setApiHandler(ApiHandler handler) {
        apiHandler = handler;
    }

    public GlassAssetServer(String docRoot, int port) {
        this.docRoot = docRoot;
        this.requestedPort = port;
        this.resolvedPort = port;
    }

    /** 启动服务器，返回可访问的根 URL；遇到端口冲突自动尝试下一端口 */
    public String start() throws IOException {
        realRoot = Paths.get(docRoot).toAbsolutePath().normalize();
        if (!Files.isDirectory(realRoot)) {
            throw new IOException("[GlassAssetServer] 资源目录不存在: " + realRoot);
        }
        int p = requestedPort;
        boolean allowFallback = false; // 指定端口被占用时，是否允许退化为随机端口
        int tries = 0;
        while (true) {
            try {
                server = HttpServer.create(new InetSocketAddress("127.0.0.1", p), 0);
                break;
            } catch (IOException bind) {
                if (requestedPort == 0) {
                    if (++tries > 64) throw bind;
                    p = 0; // 让 OS 分配
                    continue;
                }
                if (!allowFallback) {
                    // 固定端口被占用：本次退化为随机端口，保证程序仍能启动
                    // （注意：该次会话的 origin 会变化，网页 localStorage 无法延续，仅属兜底）
                    System.err.println("[GlassAssetServer] 端口 " + requestedPort
                            + " 被占用，改用随机端口: " + bind.getMessage());
                    allowFallback = true;
                    p = 0;
                    continue;
                }
                throw bind;
            }
        }
        server.createContext("/", new Handler(realRoot));
        // /api 走独立 context：HttpServer 按最长前缀匹配，/api/* 不会被 "/" 抢走
        server.createContext("/api", new ApiServlet());
        // 使用一个固定的线程池（避免单线程 executor 出现 Windows 下 keep-alive 中途崩溃）
        try {
            server.setExecutor(java.util.concurrent.Executors.newFixedThreadPool(4));
        } catch (Throwable ignore) {
            server.setExecutor(null);
        }
        server.start();
        resolvedPort = server.getAddress().getPort();
        String url = "http://127.0.0.1:" + resolvedPort + "/";
        System.out.println("[GlassAssetServer] 启动 OK: " + url + "  root=" + realRoot);
        return url;
    }

    /** 停止服务器 */
    public void stop() {
        if (server != null) {
            try { server.stop(0); } catch (Throwable ignored) {}
            server = null;
        }
    }

    public int getPort() {
        return resolvedPort;
    }

    public Path getRealRoot() {
        return realRoot;
    }

    /** /api/* 的处理器：把请求交给宿主注册的 ApiHandler（同源，无需 CORS）。 */
    private static class ApiServlet implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            try {
                String rawPath = ex.getRequestURI().getRawPath();
                String path = rawPath.startsWith("/api") ? rawPath.substring(4) : rawPath;
                if (path.isEmpty()) path = "/";
                Map<String, String> query = parseQuery(ex.getRequestURI().getRawQuery());

                String body = "";
                try (java.io.InputStream is = ex.getRequestBody()) {
                    byte[] buf = new byte[8192];
                    java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                    int n;
                    while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
                    body = new String(bos.toByteArray(), StandardCharsets.UTF_8);
                }

                ApiHandler h = apiHandler;
                if (h == null) {
                    write(ex, ApiResponse.error("api handler not registered"));
                    return;
                }
                write(ex, h.handle(path, query, ex.getRequestMethod(), body));
            } catch (Throwable t) {
                System.err.println("[GlassAssetServer] /api 处理失败: " + t);
                t.printStackTrace();
                try { write(ex, ApiResponse.error(t.getClass().getSimpleName() + ": " + t.getMessage())); }
                catch (Throwable ignore) {}
            }
        }

        private static void write(HttpExchange ex, ApiResponse r) throws IOException {
            ex.getResponseHeaders().set("Content-Type", r.contentType);
            ex.getResponseHeaders().set("Cache-Control", "no-store");
            ex.sendResponseHeaders(r.code, r.body.length);
            try (OutputStream os = ex.getResponseBody()) {
                os.write(r.body);
            }
        }

        private static Map<String, String> parseQuery(String raw) {
            Map<String, String> map = new HashMap<>();
            if (raw == null || raw.isEmpty()) return map;
            for (String pair : raw.split("&")) {
                if (pair.isEmpty()) continue;
                int eq = pair.indexOf('=');
                String k = eq < 0 ? pair : pair.substring(0, eq);
                String v = eq < 0 ? "" : pair.substring(eq + 1);
                try {
                    map.put(URLDecoder.decode(k, StandardCharsets.UTF_8.name()),
                            URLDecoder.decode(v, StandardCharsets.UTF_8.name()));
                } catch (Throwable ignore) {}
            }
            return map;
        }
    }

    private static class Handler implements HttpHandler {
        private final Path root;
        private final String rootStr;

        Handler(Path root) {
            this.root = root;
            this.rootStr = root.toString();
        }

        private static String decode(String raw) {
            if (raw == null) return "";
            try {
                return URLDecoder.decode(raw, StandardCharsets.UTF_8.name());
            } catch (UnsupportedEncodingException ue) {
                return raw;
            } catch (IllegalArgumentException ia) {
                // 错误的 % 编码，按原样返回
                return raw;
            }
        }

        private static void writeText(HttpExchange ex, int code, String text) throws IOException {
            byte[] body = (text == null ? "" : text).getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().set("Content-Type", "text/plain; charset=utf-8");
            ex.sendResponseHeaders(code, body.length);
            try (OutputStream os = ex.getResponseBody()) {
                os.write(body);
            }
        }

        @Override
        public void handle(HttpExchange ex) throws IOException {
            try {
                String raw = ex.getRequestURI().getRawPath();
                String decoded = decode(raw);
                if (decoded == null || decoded.isEmpty()) decoded = "/";

                // 防御：NUL / 换行符 / 控制字符直接 400
                if (decoded.indexOf('\u0000') >= 0 || decoded.indexOf('\n') >= 0 || decoded.indexOf('\r') >= 0) {
                    writeText(ex, 400, "Bad Request");
                    return;
                }

                // 相对路径 + 规范化
                String rel = decoded.startsWith("/") ? decoded.substring(1) : decoded;
                if (rel.isEmpty()) rel = "index.html";

                Path candidate = root.resolve(rel).normalize();
                // 严格 containment：必须位于 realRoot 之下
                String cStr = candidate.toString();
                if (!(cStr.equals(rootStr) || cStr.startsWith(rootStr + java.io.File.separator))) {
                    writeText(ex, 403, "Forbidden");
                    return;
                }

                if (Files.isDirectory(candidate)) {
                    // 依次尝试 index.html / index.htm / notes.html（子目录里常见）
                    Path f1 = candidate.resolve("index.html");
                    Path f2 = candidate.resolve("index.htm");
                    Path f3 = candidate.resolve("notes.html");
                    if (Files.exists(f1) && Files.isRegularFile(f1)) candidate = f1;
                    else if (Files.exists(f2) && Files.isRegularFile(f2)) candidate = f2;
                    else if (Files.exists(f3) && Files.isRegularFile(f3)) candidate = f3;
                    else {
                        // 没有 index：列目录会 403（避免暴露文件系统）
                        writeText(ex, 403, "Forbidden (no index)");
                        return;
                    }
                }

                if (!Files.exists(candidate) || !Files.isRegularFile(candidate)) {
                    // SPA 回退：当文件不存在，尝试根目录下 index.html（仅当请求不是明显的资源文件）
                    String name = candidate.getFileName() == null ? "" : candidate.getFileName().toString().toLowerCase();
                    boolean isAsset = name.endsWith(".js") || name.endsWith(".css") || name.endsWith(".png")
                        || name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".svg")
                        || name.endsWith(".woff") || name.endsWith(".woff2") || name.endsWith(".ttf")
                        || name.endsWith(".ico") || name.endsWith(".map") || name.endsWith(".wasm");
                    Path fall = root.resolve("index.html");
                    if (!isAsset && Files.exists(fall) && Files.isRegularFile(fall)) {
                        serveFile(ex, fall);
                        return;
                    }
                    writeText(ex, 404, "Not Found: " + decoded);
                    return;
                }

                serveFile(ex, candidate);
            } catch (Throwable t) {
                // 任何未处理异常：先打印到控制台（换电脑出 500 时能看到原因），再返回 500 带文字
                System.err.println("[GlassAssetServer] 500: " + (ex != null ? ex.getRequestURI() : "?"));
                t.printStackTrace();
                try {
                    StringBuilder sb = new StringBuilder();
                    sb.append("HTTP ERROR 500\n");
                    sb.append("Request: ").append(ex != null ? ex.getRequestURI().toString() : "?").append("\n");
                    sb.append("Reason: ").append(t.getClass().getSimpleName());
                    if (t.getMessage() != null) sb.append(" - ").append(t.getMessage());
                    sb.append("\n\nRoot: ").append(root.toString());
                    writeText(ex, 500, sb.toString());
                } catch (Throwable ignore) {
                    try { ex.sendResponseHeaders(500, -1); } catch (Throwable ignore2) {}
                }
            }
        }

        private void serveFile(HttpExchange ex, Path file) throws IOException {
            String name = file.getFileName() == null ? "" : file.getFileName().toString();
            long len;
            long mtime;
            try {
                len = Files.size(file);
                mtime = file.toFile().lastModified();
            } catch (IOException ioe) {
                writeText(ex, 500, "Size failed: " + ioe.getMessage());
                return;
            }

            // ===== 协商缓存：ETag / Last-Modified → 304 =====
            String etag = "\"" + len + "-" + mtime + "\"";
            String inm = ex.getRequestHeaders().getFirst("If-None-Match");
            String ims = ex.getRequestHeaders().getFirst("If-Modified-Since");
            boolean notModified = false;
            if (inm != null && inm.equals(etag)) {
                notModified = true;
            } else if (ims != null) {
                try {
                    long since = parseHttpDate(ims);
                    if (since > 0 && mtime / 1000 <= since / 1000) notModified = true;
                } catch (Throwable ignored) {}
            }
            ex.getResponseHeaders().set("ETag", etag);
            ex.getResponseHeaders().set("Last-Modified", formatHttpDate(mtime));
            if (notModified) {
                ex.sendResponseHeaders(304, -1);
                ex.close();
                return;
            }

            String lower = name.toLowerCase();
            // 本地资源文件会随开发/更新随时变化：此前对 js/css 用 "max-age=604800,
            // immutable" 强缓存，导致改了文件、程序重启后仍读旧内容（表现为"改了没生效、
            // 各窗口样式还不一致、按钮没有按下效果"）。统一改为协商缓存：靠 ETag 走 304，
            // 内容没变几乎零开销，内容一变立即生效。
            // 文本资源优先 gzip（首次加载显著提速；缓存命中后不再请求）
            boolean compressible = isCompressible(lower) && len >= 512;
            String ae = ex.getRequestHeaders().getFirst("Accept-Encoding");
            boolean wantGzip = compressible && ae != null && ae.toLowerCase().contains("gzip");

            ex.getResponseHeaders().set("Content-Type", mimeFor(name));
            ex.getResponseHeaders().set("Cache-Control", "no-cache");
            if (compressible) ex.getResponseHeaders().set("Vary", "Accept-Encoding");

            // 超大文件走 chunked，不做 gzip
            if (len > Integer.MAX_VALUE) {
                ex.sendResponseHeaders(200, 0);
                streamFile(ex, file);
                return;
            }

            if (wantGzip) {
                byte[] gz;
                try (java.io.InputStream is = new java.io.FileInputStream(file.toFile())) {
                    java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream((int) Math.min(len, 2 * 1024 * 1024));
                    try (java.util.zip.GZIPOutputStream gos = new java.util.zip.GZIPOutputStream(bos)) {
                        byte[] buf = new byte[64 * 1024];
                        int n;
                        while ((n = is.read(buf)) > 0) gos.write(buf, 0, n);
                    }
                    gz = bos.toByteArray();
                }
                ex.getResponseHeaders().set("Content-Encoding", "gzip");
                ex.sendResponseHeaders(200, gz.length);
                try (OutputStream os = ex.getResponseBody()) {
                    os.write(gz);
                }
                return;
            }

            ex.sendResponseHeaders(200, len);
            streamFile(ex, file);
        }

        private void streamFile(HttpExchange ex, Path file) throws IOException {
            try (OutputStream os = ex.getResponseBody();
                 java.io.InputStream is = new java.io.BufferedInputStream(new java.io.FileInputStream(file.toFile()), 64 * 1024)) {
                byte[] buf = new byte[64 * 1024];
                long sent = 0;
                int n;
                while ((n = is.read(buf)) > 0) {
                    os.write(buf, 0, n);
                    sent += n;
                }
                os.flush();
            } catch (IOException io) {
                // 浏览器中途断开连接（很常见），仅 debug 级别
                String msg = io.getMessage() == null ? "" : io.getMessage();
                if (!msg.contains("pipe") && !msg.contains("reset") && !msg.contains("closed")) {
                    System.err.println("[GlassAssetServer] serveFile 错误: " + io.getClass().getSimpleName() + " " + msg + " file=" + file);
                }
            }
        }

        /** 文本类资源适合 gzip */
        private static boolean isCompressible(String lower) {
            return lower.endsWith(".js") || lower.endsWith(".mjs") || lower.endsWith(".css")
                    || lower.endsWith(".html") || lower.endsWith(".htm") || lower.endsWith(".json")
                    || lower.endsWith(".svg") || lower.endsWith(".txt") || lower.endsWith(".md")
                    || lower.endsWith(".csv") || lower.endsWith(".map");
        }

        private static final java.text.SimpleDateFormat HTTP_DATE =
                new java.text.SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'", java.util.Locale.US);
        static { HTTP_DATE.setTimeZone(java.util.TimeZone.getTimeZone("GMT")); }

        private static String formatHttpDate(long millis) {
            synchronized (HTTP_DATE) { return HTTP_DATE.format(new java.util.Date(millis)); }
        }

        private static long parseHttpDate(String s) {
            synchronized (HTTP_DATE) {
                try { return HTTP_DATE.parse(s).getTime(); } catch (java.text.ParseException e) { return 0L; }
            }
        }
    }

    /** 简单的 MIME 类型推断（不可变 Map 优化）*/
    private static final Map<String, String> MIME = new HashMap<>();
    static {
        MIME.put(".html", "text/html; charset=utf-8");
        MIME.put(".htm",  "text/html; charset=utf-8");
        MIME.put(".js",   "application/javascript; charset=utf-8");
        MIME.put(".mjs",  "application/javascript; charset=utf-8");
        MIME.put(".css",  "text/css; charset=utf-8");
        MIME.put(".json", "application/json; charset=utf-8");
        MIME.put(".png",  "image/png");
        MIME.put(".jpg",  "image/jpeg");
        MIME.put(".jpeg", "image/jpeg");
        MIME.put(".gif",  "image/gif");
        MIME.put(".svg",  "image/svg+xml");
        MIME.put(".ico",  "image/x-icon");
        MIME.put(".webp", "image/webp");
        MIME.put(".woff", "font/woff");
        MIME.put(".woff2","font/woff2");
        MIME.put(".ttf",  "font/ttf");
        MIME.put(".otf",  "font/otf");
        MIME.put(".wasm", "application/wasm");
        MIME.put(".map",  "application/json; charset=utf-8");
        MIME.put(".txt",  "text/plain; charset=utf-8");
        MIME.put(".md",   "text/markdown; charset=utf-8");
        MIME.put(".csv",  "text/csv; charset=utf-8");
    }
    private static String mimeFor(String name) {
        if (name == null) return "application/octet-stream";
        String lower = name.toLowerCase();
        for (Map.Entry<String, String> e : MIME.entrySet()) {
            if (lower.endsWith(e.getKey())) return e.getValue();
        }
        return "application/octet-stream";
    }
}
