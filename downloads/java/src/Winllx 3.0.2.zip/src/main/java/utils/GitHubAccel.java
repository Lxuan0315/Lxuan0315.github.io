package utils;

import java.io.InputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * GitHub 自动加速。
 *
 * 内置一批公共 GitHub 代理/镜像候选，按模式把 GitHub 地址改写为镜像地址：
 *  - auto   ：自动测速择优（测速结果缓存 10 分钟，持久化兜底 30 分钟）
 *  - off    ：直连 GitHub
 *  - custom ：使用用户自定义前缀（base + 原 URL）
 *  - manual ：使用用户手动指定的内置镜像
 *
 * 改写覆盖 github.com / raw.githubusercontent.com / codeload.github.com。
 * objects.githubusercontent.com（release 真实 302 目标）不在此改写，交由下载器跟随。
 */
public class GitHubAccel {

    /** 镜像改写类型 */
    public enum Kind {
        PREFIX,     // base + 原始完整 URL
        RAW_HOST,   // 仅替换 raw.githubusercontent.com 主机
        JSDELIVR,   // raw 文件 → cdn.jsdelivr.net/gh/<owner>/<repo>@<ref>/<path>
        IDENTITY    // 直连
    }

    public static final class Mirror {
        public final String id;
        public final String label;
        public final String base;
        public final Kind kind;

        Mirror(String id, String label, String base, Kind kind) {
            this.id = id;
            this.label = label;
            this.base = base;
            this.kind = kind;
        }
    }

    /** 一次改写产生的候选下载地址 */
    public static final class Plan {
        public final String mirrorId;
        public final String label;
        public final String url;

        public Plan(String mirrorId, String label, String url) {
            this.mirrorId = mirrorId;
            this.label = label;
            this.url = url;
        }
    }

    /** 单个镜像的测速结果 */
    public static final class ProbeResult {
        public final String id;
        public final String label;
        public final String base;
        public final boolean ok;
        public final long ttfbMs;
        public final long score;
        public final boolean assetCapable;

        ProbeResult(String id, String label, String base, boolean ok, long ttfbMs, long score, boolean assetCapable) {
            this.id = id;
            this.label = label;
            this.base = base;
            this.ok = ok;
            this.ttfbMs = ttfbMs;
            this.score = score;
            this.assetCapable = assetCapable;
        }
    }

    private static final long MAX_MS = 999_999L;
    private static final long MEM_TTL_MS = 10 * 60 * 1000L;
    private static final long DISK_TTL_MS = 30 * 60 * 1000L;

    /** 测速探针：一个稳定的小文本文件（验证文本代理能力） */
    private static final String PROBE_TEXT_URL =
            "https://raw.githubusercontent.com/github/gitignore/main/Java.gitignore";
    /** 测速探针：一个小体积 release 资源（验证 release 资源转发能力，只用 Range 取 8KB） */
    private static final String PROBE_ASSET_URL =
            "https://github.com/cli/cli/releases/download/v2.62.0/gh_2.62.0_windows_amd64.zip";

    private static final List<Mirror> BUILTIN = new ArrayList<>();

    static {
        // 前缀型代理：base + 原始完整 URL
        BUILTIN.add(new Mirror("gh_proxy_com", "gh-proxy.com", "https://gh-proxy.com/", Kind.PREFIX));
        BUILTIN.add(new Mirror("ghproxy_net", "ghproxy.net", "https://ghproxy.net/", Kind.PREFIX));
        BUILTIN.add(new Mirror("ghfast_top", "ghfast.top", "https://ghfast.top/", Kind.PREFIX));
        BUILTIN.add(new Mirror("llkk", "gh.llkk.cc", "https://gh.llkk.cc/", Kind.PREFIX));
        BUILTIN.add(new Mirror("moeyy", "github.moeyy.xyz", "https://github.moeyy.xyz/", Kind.PREFIX));
        BUILTIN.add(new Mirror("gitproxy_click", "gitproxy.click", "https://gitproxy.click/", Kind.PREFIX));
        BUILTIN.add(new Mirror("gitfast_run", "gitfast.run", "https://gitfast.run/", Kind.PREFIX));
        // 裸文件镜像
        BUILTIN.add(new Mirror("gitmirror_raw", "raw.gitmirror.com", "https://raw.gitmirror.com/", Kind.RAW_HOST));
        BUILTIN.add(new Mirror("jsdelivr", "cdn.jsdelivr.net", "https://cdn.jsdelivr.net/gh/", Kind.JSDELIVR));
        // 直连（始终作为最后兜底）
        BUILTIN.add(new Mirror("direct", "直连 GitHub", "", Kind.IDENTITY));
    }

    private static final Object PROBE_LOCK = new Object();
    private static final java.util.concurrent.atomic.AtomicBoolean PROBING =
            new java.util.concurrent.atomic.AtomicBoolean(false);
    private static volatile List<String> cachedOrder;
    private static volatile long cachedAt;
    private static volatile List<ProbeResult> lastResults;

    static {
        loadCacheFromPrefs();
    }

    // ==================================================================
    // 镜像表 / 改写
    // ==================================================================

    public static List<Mirror> mirrors() {
        return Collections.unmodifiableList(BUILTIN);
    }

    public static Mirror mirrorById(String id) {
        if (id == null) return null;
        for (Mirror m : BUILTIN) if (m.id.equals(id)) return m;
        return null;
    }

    private static String labelOf(String id) {
        Mirror m = mirrorById(id);
        return m != null ? m.label : id;
    }

    /** 把 URL 按指定镜像改写；该镜像不适用时返回 null。 */
    public static String rewrite(String url, String mirrorId) {
        Mirror m = mirrorById(mirrorId);
        if (url == null || url.isEmpty() || m == null) return null;
        if (m.kind == Kind.IDENTITY) return url;

        URI u;
        try {
            u = new URI(url.trim());
        } catch (Exception e) {
            return null;
        }
        String host = u.getHost() == null ? "" : u.getHost().toLowerCase();

        if (m.kind == Kind.PREFIX) {
            if (!isGitHubHost(host)) return null;
            return m.base + url.trim();
        }

        // 裸文件镜像只服务 raw.githubusercontent.com
        if (!"raw.githubusercontent.com".equals(host)) return null;
        String path = u.getPath();
        if (path == null || path.isEmpty()) return null;

        if (m.kind == Kind.RAW_HOST) {
            return trimSlash(m.base) + path;
        }
        if (m.kind == Kind.JSDELIVR) {
            String[] parts = path.split("/");
            if (parts.length < 4) return null;
            String owner = parts[1];
            String repo = parts[2];
            String rest = path.substring(owner.length() + repo.length() + 3);   // 去掉 "/owner/repo/"
            int slash = rest.indexOf('/');
            String ref = slash < 0 ? rest : rest.substring(0, slash);
            String file = slash < 0 ? "" : rest.substring(slash);
            if (ref.startsWith("refs/heads/")) ref = ref.substring("refs/heads/".length());
            if (ref.isEmpty()) return null;
            return m.base + owner + "/" + repo + "@" + ref + file;
        }
        return null;
    }

    private static boolean isGitHubHost(String host) {
        return "github.com".equals(host) || "raw.githubusercontent.com".equals(host)
                || "codeload.github.com".equals(host) || "gist.githubusercontent.com".equals(host)
                || "api.github.com".equals(host) || "gist.github.com".equals(host);
    }

    private static boolean isGitHubUrl(String url) {
        try {
            String h = new URI(url.trim()).getHost();
            return h != null && isGitHubHost(h.toLowerCase());
        } catch (Exception e) {
            return false;
        }
    }

    private static String trimSlash(String s) {
        String v = s == null ? "" : s.trim();
        while (v.endsWith("/")) v = v.substring(0, v.length() - 1);
        return v;
    }

    private static String normalizePrefix(String s) {
        String v = trimSlash(s);
        return v.isEmpty() ? "" : v + "/";
    }

    // ==================================================================
    // 候选计划
    // ==================================================================

    /** 按当前模式生成有序候选地址列表（末尾一定是直连兜底）。 */
    public static List<Plan> plan(String url) {
        Map<String, Plan> seen = new LinkedHashMap<>();
        if (url == null || url.trim().isEmpty()) return new ArrayList<>();
        String u = url.trim();
        String mode = GithubPrefs.getMode();

        if (GithubPrefs.MODE_OFF.equals(mode)) {
            seen.put(u, new Plan("direct", labelOf("direct"), u));
            return new ArrayList<>(seen.values());
        }

        if (GithubPrefs.MODE_CUSTOM.equals(mode)) {
            String cp = normalizePrefix(GithubPrefs.getCustomPrefix());
            if (!cp.isEmpty() && isGitHubUrl(u)) {
                String w = cp + u;
                seen.put(w, new Plan("custom", "自定义镜像", w));
            }
        } else if (GithubPrefs.MODE_MANUAL.equals(mode)) {
            String mid = GithubPrefs.getManualId();
            String w = rewrite(u, mid);
            if (w != null) seen.put(w, new Plan(mid, labelOf(mid), w));
        }

        for (String id : rankedIds()) {
            String w = rewrite(u, id);
            if (w != null) seen.put(w, new Plan(id, labelOf(id), w));
        }
        seen.put(u, new Plan("direct", labelOf("direct"), u));
        return new ArrayList<>(seen.values());
    }

    /** 当前择优顺序（可能来自缓存；缓存过期时返回内置默认序并触发后台测速）。 */
    public static List<String> rankedIds() {
        List<String> c = cachedOrder;
        if (c != null && System.currentTimeMillis() - cachedAt < MEM_TTL_MS) return c;
        ensureProbeAsync();
        return defaultOrder();
    }

    /** 内置默认顺序：前缀型 → 裸文件镜像 → 直连由 plan() 追加 */
    private static List<String> defaultOrder() {
        List<String> ids = new ArrayList<>();
        for (Mirror m : BUILTIN) if (m.kind == Kind.PREFIX) ids.add(m.id);
        for (Mirror m : BUILTIN) if (m.kind == Kind.RAW_HOST || m.kind == Kind.JSDELIVR) ids.add(m.id);
        return ids;
    }

    private static void ensureProbeAsync() {
        if (!PROBING.compareAndSet(false, true)) return;
        Thread t = new Thread(() -> {
            try { probe(false); } catch (Throwable ignore) {} finally { PROBING.set(false); }
        }, "gh-accel-probe");
        t.setDaemon(true);
        t.start();
    }

    // ==================================================================
    // 测速择优
    // ==================================================================

    /** 对全部内置镜像测速并按分数排序；force=true 时忽略缓存强制重测。 */
    public static List<ProbeResult> probe(boolean force) {
        List<ProbeResult> r = lastResults;
        if (!force && r != null && System.currentTimeMillis() - cachedAt < MEM_TTL_MS) return r;
        return runProbe();
    }

    /** 单飞：同一时刻只跑一轮测速。 */
    private static synchronized List<ProbeResult> runProbe() {
        List<ProbeResult> r = lastResults;
        if (r != null && System.currentTimeMillis() - cachedAt < MEM_TTL_MS) return r;

        List<ProbeResult> results = Collections.synchronizedList(new ArrayList<>());
        ExecutorService pool = Executors.newFixedThreadPool(4, run -> {
            Thread t = new Thread(run, "gh-accel-speed");
            t.setDaemon(true);
            return t;
        });
        List<Future<?>> futures = new ArrayList<>();
        for (Mirror m : BUILTIN) {
            if (m.kind == Kind.IDENTITY) continue;   // 直连不参与择优，只作兜底
            futures.add(pool.submit(() -> results.add(probeOne(m))));
        }
        pool.shutdown();
        try {
            pool.awaitTermination(25, TimeUnit.SECONDS);
        } catch (InterruptedException ignore) {
            Thread.currentThread().interrupt();
        }

        List<ProbeResult> list = new ArrayList<>(results);
        list.sort((a, b) -> Long.compare(a.score, b.score));

        List<String> order = new ArrayList<>();
        for (ProbeResult pr : list) if (pr.ok) order.add(pr.id);
        if (order.isEmpty()) order.addAll(defaultOrder());
        else for (String id : defaultOrder()) if (!order.contains(id)) order.add(id);

        synchronized (PROBE_LOCK) {
            lastResults = list;
            cachedOrder = order;
            cachedAt = System.currentTimeMillis();
        }
        try {
            GithubPrefs.setChosenCache(String.join(",", order));
            GithubPrefs.setProbeAt(cachedAt);
        } catch (Throwable ignore) {}
        return list;
    }

    private static ProbeResult probeOne(Mirror m) {
        String textUrl = rewrite(PROBE_TEXT_URL, m.id);
        long[] r = textUrl == null ? new long[]{0, MAX_MS} : measure(textUrl, 5000);
        boolean ok = r[0] == 1;
        boolean assetCapable = rewrite(PROBE_ASSET_URL, m.id) != null;
        long score = ok ? (r[1] + (assetCapable ? 0 : 4000)) : MAX_MS;
        long ttfb = ok && r.length > 2 ? r[2] : -1;
        return new ProbeResult(m.id, m.label, m.base, ok, ttfb, score, assetCapable);
    }

    /** 返回 {ok(1/0), score, ttfb, bytes} */
    private static long[] measure(String url, int timeoutMs) {
        long t0 = System.nanoTime();
        HttpDownloader.Conn c = null;
        try {
            c = HttpDownloader.open(url, 3000, timeoutMs, "bytes=0-1023");
            if (c.code >= 400) return new long[]{0, MAX_MS};
            // 有些镜像对不支持的请求会返回拦截/验证网页，这种要判为不可用
            if (HttpDownloader.isHtmlResponse(c.conn)) return new long[]{0, MAX_MS};
            long total = 0;
            long ttfb;
            try (InputStream in = c.conn.getInputStream()) {
                byte[] buf = new byte[1024];
                int n;
                ttfb = (System.nanoTime() - t0) / 1_000_000L;
                while ((n = in.read(buf)) > 0) {
                    total += n;
                    if (total >= 8192) break;
                }
            }
            long span = Math.max(1L, (System.nanoTime() - t0) / 1_000_000L);
            long kbps = Math.max(1L, (total / 1024L) * 1000L / span);
            return new long[]{1, ttfb + 8000 / kbps, ttfb, total};
        } catch (Throwable t) {
            return new long[]{0, MAX_MS};
        } finally {
            if (c != null) try { c.conn.disconnect(); } catch (Throwable ignore) {}
        }
    }

    private static void loadCacheFromPrefs() {
        try {
            long at = GithubPrefs.getProbeAt();
            String cache = GithubPrefs.getChosenCache();
            if (at > 0 && System.currentTimeMillis() - at < DISK_TTL_MS && cache != null && !cache.isEmpty()) {
                List<String> ids = new ArrayList<>();
                for (String s : cache.split(",")) {
                    String id = s.trim();
                    if (!id.isEmpty() && mirrorById(id) != null) ids.add(id);
                }
                if (!ids.isEmpty()) {
                    cachedOrder = ids;
                    cachedAt = at;
                }
            }
        } catch (Throwable ignore) {}
    }

    // ==================================================================
    // 状态（供 UI 展示）
    // ==================================================================

    /** 加速状态快照，供设置面板渲染。 */
    public static Map<String, Object> statusMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("mode", GithubPrefs.getMode());
        m.put("custom", GithubPrefs.getCustomPrefix());
        m.put("manualId", GithubPrefs.getManualId());
        m.put("indexUrl", GithubPrefs.getIndexUrl());
        m.put("timeoutMs", GithubPrefs.getTimeoutMs());

        List<ProbeResult> r = lastResults;
        List<Map<String, Object>> candidates = new ArrayList<>();
        if (r != null) {
            for (ProbeResult pr : r) {
                Map<String, Object> c = new LinkedHashMap<>();
                c.put("id", pr.id);
                c.put("label", pr.label);
                c.put("base", pr.base);
                c.put("ok", pr.ok);
                c.put("ms", pr.ttfbMs);
                c.put("asset", pr.assetCapable);
                candidates.add(c);
            }
        }
        m.put("candidates", candidates);

        List<String> order = cachedOrder;
        Map<String, Object> chosen = null;
        if (order != null) {
            for (String id : order) {
                Mirror mm = mirrorById(id);
                if (mm != null) {
                    chosen = new LinkedHashMap<>();
                    chosen.put("id", mm.id);
                    chosen.put("label", mm.label);
                    chosen.put("base", mm.base);
                    break;
                }
            }
        }
        m.put("chosen", chosen);
        m.put("probed", r != null);
        return m;
    }

    /** 应用设置面板提交的模式/自定义/手动/索引地址。 */
    public static void apply(String mode, String custom, String manualId, String indexUrl) {
        if (mode != null && !mode.trim().isEmpty()) GithubPrefs.setMode(mode.trim());
        if (custom != null) GithubPrefs.setCustomPrefix(custom);
        if (manualId != null) GithubPrefs.setManualId(manualId);
        if (indexUrl != null) GithubPrefs.setIndexUrl(indexUrl);
    }
}
