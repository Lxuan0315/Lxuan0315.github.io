package ui;

import org.cef.browser.CefBrowser;
import org.cef.handler.CefDisplayHandlerAdapter;
import utils.BrowserPrefs;
import utils.LangManager;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * 浏览器设置窗口。
 *
 * 结构与便笺/设置窗口一致：GlassFrame（毛玻璃 + 三色按钮 + 可拖动/缩放）+ 共享 JCEF 内核加载
 * web/browser/settings.html。页面排版与动画参考便笺的设置卡片（左导航 + 右面板 + 分段入场）。
 *
 * 页面 ↔ Java 用 title 桥通信：
 *   JS → Java：document.title = "__BRIDGE__" + base64([{action, value}])
 *   Java → JS：window.__applyState(jsonString)
 */
public class BrowserSettingsFrame {

    private static final String SETTINGS_HTML = "browser/settings.html";
    private static final String BRIDGE_PREFIX = "__BRIDGE__";

    private final JFrame frame;
    private final GlassBrowserPanel browserPanel;

    public BrowserSettingsFrame() {
        String title = LangManager.getString("module.browser") + " · " + LangManager.getString("app.settings.title");
        frame = new GlassFrame(title);
        frame.setSize(820, 580);
        frame.setMinimumSize(new Dimension(620, 460));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        // local 模式：独立 CefClient，关闭时整体 dispose，避免 native 残留
        browserPanel = new GlassBrowserPanel(SETTINGS_HTML, true);
        frame.add(browserPanel, BorderLayout.CENTER);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                if (browserPanel != null) browserPanel.closeBrowser();
            }
        });

        frame.setVisible(true);

        // JCEF 未就绪时浏览器会延后创建，title 桥与状态推送需等创建完成后再执行
        browserPanel.onBrowserReady(() -> {
            installTitleBridge();
            // 兜底：页面加载慢时也推一次状态
            new Timer(700, ev -> { pushState(); ((Timer) ev.getSource()).stop(); }).start();
        });
        System.out.println("[BrowserSettingsFrame] 已启动");
    }

    // ========================================================================
    // title 桥
    // ========================================================================
    private void installTitleBridge() {
        try {
            org.cef.CefClient client = browserPanel.getClient();
            if (client == null) return;
            client.addDisplayHandler(new CefDisplayHandlerAdapter() {
                @Override
                public void onTitleChange(CefBrowser browser, String title) {
                    if (title == null || !title.startsWith(BRIDGE_PREFIX)) return;
                    String payload = title.substring(BRIDGE_PREFIX.length());
                    try {
                        String json = new String(Base64.getDecoder().decode(payload), StandardCharsets.UTF_8);
                        SwingUtilities.invokeLater(() -> handleEvent(json));
                    } catch (Throwable t) {
                        System.err.println("[BrowserSettings] 桥解码失败: " + t.getMessage());
                    }
                    try {
                        browser.executeJavaScript("(function(){try{document.title='Winllx 浏览器设置';}catch(e){}})();",
                                "restore-title", 0);
                    } catch (Throwable ignore) {}
                }
            });
        } catch (Throwable t) {
            System.err.println("[BrowserSettings] 安装 title 桥失败: " + t.getMessage());
        }
    }

    private void handleEvent(String json) {
        String action = _jsonStr(json, "action");
        String value = _jsonStr(json, "value");
        if (action == null) return;
        if ("null".equals(value)) value = null;

        switch (action) {
            case "pageReady":
                pushState();
                return;
            case "setHomeUrl":
                BrowserPrefs.setHomeUrl(value);
                return;
            case "setSearchEngine":
                BrowserPrefs.setSearchEngine(value);
                return;
            case "setRestoreSession":
                BrowserPrefs.setRestoreSession("true".equalsIgnoreCase(value));
                return;
            case "setNewTabContent":
                BrowserPrefs.setNewTabContent(value);
                return;
            case "setShowCloseButton":
                BrowserPrefs.setShowCloseButton("true".equalsIgnoreCase(value));
                return;
            case "setCloseOnDblClick":
                BrowserPrefs.setCloseOnDblClick("true".equalsIgnoreCase(value));
                return;
            case "pickDownloadDir": {
                JFileChooser chooser = new JFileChooser(BrowserPrefs.getDownloadDir());
                chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                chooser.setDialogTitle(LangManager.getString("module.browser"));
                if (chooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
                    File dir = chooser.getSelectedFile();
                    if (dir != null) BrowserPrefs.setDownloadDir(dir.getAbsolutePath());
                }
                pushState();
                return;
            }
            case "clearCache":
                clearCache();
                return;
            case "resetDefaults":
                BrowserPrefs.resetDefaults();
                pushState();
                return;
            case "closeWindow":
                frame.dispose();
                return;
            default:
                System.out.println("[BrowserSettings] 未处理 action: " + action);
        }
    }

    /** 清空 JCEF 缓存目录（尽力而为，占用中的文件跳过） */
    private static void clearCache() {
        File dir = new File(System.getProperty("user.dir") + "/Winllx/jcef_cache");
        int[] n = {0};
        deleteRecursive(dir, n);
        System.out.println("[BrowserSettings] 已清除缓存文件数: " + n[0]);
    }

    private static void deleteRecursive(File f, int[] counter) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursive(k, counter);
        }
        if (f.delete()) counter[0]++;
    }

    // ========================================================================
    // Java → JS：推送当前设置
    // ========================================================================
    private void pushState() {
        String json = "{"
                + "\"lang\":" + toJsonStr(LangManager.getCurrentLang()) + ","
                + "\"homeUrl\":" + toJsonStr(BrowserPrefs.getHomeUrl()) + ","
                + "\"searchEngine\":" + toJsonStr(BrowserPrefs.getSearchEngine()) + ","
                + "\"restoreSession\":" + BrowserPrefs.isRestoreSession() + ","
                + "\"newTabContent\":" + toJsonStr(BrowserPrefs.getNewTabContent()) + ","
                + "\"showCloseButton\":" + BrowserPrefs.isShowCloseButton() + ","
                + "\"closeOnDblClick\":" + BrowserPrefs.isCloseOnDblClick() + ","
                + "\"downloadDir\":" + toJsonStr(BrowserPrefs.getDownloadDir())
                + "}";
        execJS("(function(){try{if(window.__applyState)window.__applyState(" + toJsString(json) + ");}catch(e){}})();");
    }

    private void execJS(String js) {
        if (browserPanel != null) browserPanel.executeJavaScript(js);
    }

    // ========================================================================
    // 小工具
    // ========================================================================
    private static String toJsString(String s) {
        if (s == null) return "''";
        StringBuilder sb = new StringBuilder(s.length() + 16);
        sb.append('\'');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '\'': sb.append("\\'"); break;
                case '\r': sb.append("\\r"); break;
                case '\n': sb.append("\\n"); break;
                case '\t': sb.append("\\t"); break;
                case '"':  sb.append("\\\""); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\x%02X", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('\'');
        return sb.toString();
    }

    private static String toJsonStr(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder(s.length() + 16);
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '"':  sb.append("\\\""); break;
                case '\r': sb.append("\\r"); break;
                case '\n': sb.append("\\n"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04X", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('"');
        return sb.toString();
    }

    private static String _jsonStr(String json, String key) {
        if (json == null || json.isEmpty()) return null;
        String pat = "\"" + key + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(pat).matcher(json);
        if (m.find()) return _unescape(m.group(1));
        String pat2 = "\"" + key + "\"\\s*:\\s*(true|false|null|-?\\d+(?:\\.\\d+)?)";
        java.util.regex.Matcher m2 = java.util.regex.Pattern.compile(pat2).matcher(json);
        return m2.find() ? m2.group(1) : null;
    }

    private static String _unescape(String s) {
        if (s == null) return null;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                switch (n) {
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case '/': sb.append('/'); break;
                    case 'u':
                        if (i + 4 < s.length()) {
                            try { sb.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16)); i += 4; }
                            catch (Exception ignore) { sb.append("\\u"); }
                        } else sb.append("\\u");
                        break;
                    default: sb.append(n);
                }
            } else sb.append(c);
        }
        return sb.toString();
    }
}
