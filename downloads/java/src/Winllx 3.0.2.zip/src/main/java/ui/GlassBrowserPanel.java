package ui;

import org.cef.CefApp;
import org.cef.CefClient;
import org.cef.CefSettings;
import org.cef.browser.CefBrowser;
import org.cef.browser.CefFrame;
import org.cef.handler.CefAppHandlerAdapter;
import org.cef.handler.CefLoadHandler;
import org.cef.handler.CefLoadHandlerAdapter;
import utils.GlassAssetServer;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * JCEF 浏览器面板：将 Chromium 内核嵌入 Swing 容器，
 * 用于加载并渲染网页版液态玻璃（WebGL/SVG filter 效果与浏览器完全一致）。
 *
 * 优化：
 *  - JCEF 初始化顺序：setIsRemoteEnabled(false) → startup → addAppHandler → getInstance
 *  - 不 block 等待 stateHasChanged.INITIALIZED（getInstance 返回就能用，INITIALIZED 在后台异步过来）
 *  - getUIComponent 非阻塞：设置短轮询 + Swing 定时器贴组件，避免卡主线程
 *  - 主程序可以后台调用 ensureJcef() 预热，用户点便笺时就秒开
 */
public class GlassBrowserPanel extends JPanel {
    private static CefApp cefApp;
    private static CefClient sharedClient;
    private static volatile boolean jcefAvailable = false;
    private static final AtomicBoolean jcefInited = new AtomicBoolean(false);
    /**
     * 本地静态资源服务的固定端口。
     * 端口参与网页的 origin（同源）判定，若每次启动都变化，各页面基于 localStorage 的
     * 数据（便笺/待办/日历/计算器历史等）就会因 origin 变化而读不到，表现为"关了就没"。
     * 故固定端口；若被占用则由 GlassAssetServer 兜底退化为随机端口。
     */
    private static final int ASSET_PORT = 18520;
    private static GlassAssetServer assetServer;
    private static String baseUrl;
    /** HTTP 模式下并行保留的 file:// 根 URL，用于页面加载失败时 JS 端 fallback 跳转 */
    private static volatile String fileFallbackBaseUrl;

    private CefBrowser browser;
    /** 当前浏览器使用的 CefClient（local 模式为独立 client，共享模式为 sharedClient） */
    private CefClient client;
    /** local 模式：独立 CefClient 及其归属 CefApp。
     *  注意：CefApp 是进程级单例，同一 JVM 只能有一个，故 localApp 实际复用共享 cefApp，
     *  关闭时只 dispose 独立 client，绝不 dispose CefApp（否则共享的便笺窗口会崩溃）。 */
    private CefApp localApp;
    private CefClient localClient;
    private boolean isLocal = false;

    /** JCEF 就绪前显示的占位组件；就绪后移除并挂载真正的浏览器组件。 */
    private JComponent placeholderComp;

    /** 浏览器创建完成后的回调（用于注册需要 client/browser 的处理器）。 */
    private Runnable browserReadyCallback;
    private volatile boolean browserCreated = false;

    public GlassBrowserPanel(String relativeUrl) {
        this(relativeUrl, false);
    }

    public GlassBrowserPanel(String relativeUrl, boolean local) {
        super(new BorderLayout());
        setOpaque(false);
        this.isLocal = local;

        // JCEF 尚未就绪时不要阻塞 EDT：ensureJcef()/initLocalJcef() 都是 static synchronized，
        // 后台预热线程在初始化期间（1~3s）一直持锁，若在此直接调用会把整个界面卡住，
        // 表现为"点了子应用半天不弹窗"。这里先显示占位，等就绪后再回 EDT 创建浏览器。
        if (!isJcefReady()) {
            showPlaceholder();
            whenJcefReady(() -> {
                removePlaceholder();
                initBrowser(relativeUrl, local);
            });
            return;
        }

        initBrowser(relativeUrl, local);
    }

    /** 真正创建浏览器并绑定事件（需在 EDT 上、且 JCEF 已就绪时调用）。 */
    private void initBrowser(String relativeUrl, boolean local) {
        if (local) {
            // local 模式：复用共享 CefApp，创建独立 CefClient
            if (!initLocalJcef()) {
                showFallback(relativeUrl);
                return;
            }
        } else {
            // 共享模式：全部复用 sharedClient
            if (!ensureJcef()) {
                showFallback(relativeUrl);
                return;
            }
        }

        try {
            // 绝对地址（http/https/file/...）：作为独立浏览器使用时直接加载，
            // 不拼接本地资源服务器前缀，也不做 file:// 兜底跳转
            final boolean external = isAbsoluteUrl(relativeUrl);
            String fullUrl;
            if (external) {
                fullUrl = relativeUrl;
            } else {
                fullUrl = baseUrl;
                if (relativeUrl != null && !relativeUrl.isEmpty()) {
                    if (!relativeUrl.startsWith("/")) {
                        if (!fullUrl.endsWith("/")) fullUrl += "/";
                        fullUrl += relativeUrl;
                    } else {
                        fullUrl += relativeUrl;
                    }
                }
                // 把 file:// 兜底地址塞进 hash，页面的 JS 能拿到并在加载失败时跳过去
                if (baseUrl.startsWith("http:") && fileFallbackBaseUrl != null) {
                    String fileFull = fileFallbackBaseUrl;
                    if (relativeUrl != null && !relativeUrl.isEmpty()) {
                        if (!relativeUrl.startsWith("/")) {
                            if (!fileFull.endsWith("/")) fileFull += "/";
                            fileFull += relativeUrl;
                        } else {
                            fileFull += relativeUrl;
                        }
                    }
                    try {
                        String frag = "fallback=" + URLEncoder.encode(fileFull, StandardCharsets.UTF_8.name());
                        // 保留原有 hash
                        if (fullUrl.contains("#")) {
                            fullUrl = fullUrl + "&" + frag;
                        } else {
                            fullUrl = fullUrl + "#" + frag;
                        }
                    } catch (Throwable ignore) {}
                }
            }
            System.out.println("[GlassBrowserPanel] 加载: " + fullUrl);

            final String fallbackFileUrl = (!external && baseUrl.startsWith("http:") && fileFallbackBaseUrl != null && relativeUrl != null)
                    ? buildFileUrl(fileFallbackBaseUrl, relativeUrl)
                    : null;

            // DEFAULT 模式（非 OSR），透明关闭
            // local 模式用独立 client（关闭时可整体 dispose 掉 native 资源）；共享模式用 sharedClient
            client = isLocal ? localClient : sharedClient;
            browser = client.createBrowser(fullUrl, false, false);
            browser.createImmediately();
            System.out.println("[GlassBrowserPanel] browser 创建: " + (browser != null)
                    + " client=" + client + " local=" + isLocal);

            // 弹窗必须从创建起就拦掉：CEF 自己建窗口会开出一整套 Chrome 界面的原生窗口
            //（带标签栏 + 三条信息栏 + “恢复页面”气泡），详见 installPopupInterceptor 注释
            installPopupInterceptor();

            // 页面加载完成后强制刷新布局：有些显卡/native 窗口要等加载完才诞生，
            // addNotify 的定时刷新可能已结束，这里在加载完再补几下，杜绝"全灰需挪动"。
            try {
                client.addLoadHandler(new CefLoadHandlerAdapter() {
                    private final java.util.concurrent.atomic.AtomicInteger n = new java.util.concurrent.atomic.AtomicInteger(0);
                    @Override
                    public void onLoadingStateChange(CefBrowser b, boolean isLoading, boolean canBack, boolean canForward) {
                        if (isLoading) return;
                        int p = n.incrementAndGet();
                        if (p > 3) return; // 只补 3 次
                        SwingUtilities.invokeLater(GlassBrowserPanel.this::forceLayoutRefresh);
                    }
                });
            } catch (Throwable ignore) {}

            // Java 侧兜底：HTTP 加载失败（404/500/拒绝连接等）自动跳到 file://
            if (fallbackFileUrl != null) {
                final CefBrowser cur = browser;
                browser.getClient().addLoadHandler(new CefLoadHandlerAdapter() {
                    private final java.util.concurrent.atomic.AtomicBoolean jumped = new java.util.concurrent.atomic.AtomicBoolean(false);
                    @Override
                    public void onLoadError(CefBrowser b, CefFrame f, CefLoadHandler.ErrorCode ec, String err, String u) {
                        if (jumped.get()) return;
                        if (b != cur) return;
                        if (f != null && !f.isMain()) return;
                        System.err.println("[LOAD-HTTP-FALLBACK] ec=" + ec + " err=" + err + " url=" + u + " → redirect=" + fallbackFileUrl);
                        if (jumped.compareAndSet(false, true)) {
                            try {
                                // 安全：用 JS 执行 window.location.replace 跨 file:// 兼容
                                cur.executeJavaScript("(function(){try{window.location.replace("
                                        + toJsString(fallbackFileUrl)
                                        + ");}catch(e){document.documentElement.innerHTML='跳转失败 ' + e.message;}})();",
                                        "fallback", 0);
                            } catch (Throwable t2) {
                                // 再回退：重新创建 browser 太重；直接打印
                                System.err.println("[LOAD-HTTP-FALLBACK] JS 跳转失败: " + t2.getMessage());
                            }
                        }
                    }
                });
            }

            // 先尝试一次拿 UI 组件，拿不到就用 Swing Timer 非阻塞等待
            Component ui = null;
            try { ui = browser.getUIComponent(); } catch (Throwable ignored) {}
            if (ui != null) {
                installBrowserFocusRestore(ui);
                add(ui, BorderLayout.CENTER);
                revalidate();
                repaint();
                System.out.println("[GlassBrowserPanel] UI 组件立即可用: " + ui.getClass().getName());
            } else {
                System.out.println("[GlassBrowserPanel] UI 组件稍后就绪，Timer 等待...");
                final int[] attempts = {0};
                Timer waitUi = new Timer(50, null);
                waitUi.addActionListener(e -> {
                    if (browser == null) { waitUi.stop(); return; }
                    Component c = null;
                    try { c = browser.getUIComponent(); } catch (Throwable ignored) {}
                    if (c != null) {
                        installBrowserFocusRestore(c);
                        add(c, BorderLayout.CENTER);
                        revalidate();
                        repaint();
                        waitUi.stop();
                        System.out.println("[GlassBrowserPanel] UI 组件就绪(异步): " + c.getClass().getName() + " 尝试次数=" + attempts[0]);
                    } else if (attempts[0]++ > 80) { // 最多 ~4 秒
                        waitUi.stop();
                        System.err.println("[GlassBrowserPanel] UI 组件仍不可用，显示回退");
                        showFallback(relativeUrl);
                        revalidate();
                        repaint();
                    }
                });
                waitUi.setRepeats(true);
                waitUi.start();
            }

            // 浏览器已创建：通知外部注册依赖 client/browser 的处理器
            browserCreated = true;
            Runnable cb = browserReadyCallback;
            browserReadyCallback = null;
            if (cb != null) {
                try { cb.run(); } catch (Throwable t) {
                    System.err.println("[GlassBrowserPanel] onBrowserReady 回调失败: " + t.getMessage());
                }
            }
        } catch (Throwable t) {
            System.err.println("[GlassBrowserPanel] 创建浏览器失败: " + t.getMessage());
            t.printStackTrace();
            showFallback(relativeUrl);
        }
    }

    /** local 模式初始化：复用共享 CefApp，但创建独立 CefClient。
     *  关闭时 dispose 该独立 client，即可连带清理本窗口的全部 native 资源（消除灰框）。
     *  注意：CefApp 是进程级单例，同一 JVM 只有一个，因此这里绝不重新 startup / dispose CefApp。 */
    private boolean initLocalJcef() {
        try {
            if (!ensureJcef()) return false;
            localApp = cefApp;                       // 复用共享 CefApp（进程级单例）
            localClient = cefApp.createClient();     // 独立 client
            return localClient != null;
        } catch (Throwable t) {
            System.err.println("[GlassBrowserPanel] local 模式初始化失败: " + t.getMessage());
            return false;
        }
    }

    /** 初始化 JCEF 单例与本地资源服务器，仅执行一次。
     *  可在主程序启动时后台线程调用，用户点便笺时就跳过初始化秒开。*/
    public static synchronized boolean ensureJcef() {
        if (jcefInited.get()) {
            return jcefAvailable;
        }

        String javaHome = System.getProperty("java.home");
        File jbrBin = new File(javaHome, "bin");
        File jcefHelper = new File(jbrBin, "jcef_helper.exe");
        File locales = new File(jbrBin, "locales");

        System.out.println("[GlassBrowserPanel] java.home = " + javaHome);
        System.out.println("[GlassBrowserPanel] jcef_helper = " + jcefHelper.getAbsolutePath() + ", exists=" + jcefHelper.exists());
        System.out.println("[GlassBrowserPanel] locales = " + locales.getAbsolutePath() + ", exists=" + locales.exists());

        if (!jcefHelper.exists()) {
            System.err.println("[GlassBrowserPanel] jcef_helper.exe 不存在，JCEF 不可用");
            jcefInited.set(true);
            return false;
        }

        try {
            // 1) 本地资源 HTTP 服务器：多候选目录探测（user.dir 最常见；也支持 jar/class 所在目录 + 父目录）
            //    换电脑时如果 user.dir 没 cd 到项目目录，会出现 web 不存在导致 500，此处做健壮 fallback
            String webRoot = findWebRoot();
            File webRootFile = new File(webRoot);
            if (!webRootFile.exists()) {
                if (!webRootFile.mkdirs()) {
                    System.err.println("[GlassBrowserPanel] web 目录创建失败: " + webRoot);
                }
            }
            // 确保 notes/notes.html（核心资源）存在，否则打印警告
            File notesAnchor = new File(webRootFile, "notes/notes.html");
            System.out.println("[GlassBrowserPanel] web 根目录: " + webRootFile.getAbsolutePath()
                    + " (notes.html 存在=" + notesAnchor.exists() + ")");

            // 先拼好 fileFallbackBaseUrl，无论 HTTP 是否启用都会保留
            String fileRootUri = webRootFile.getAbsoluteFile().toURI().toString();
            if (fileRootUri.endsWith("/")) fileRootUri = fileRootUri.substring(0, fileRootUri.length() - 1);
            fileFallbackBaseUrl = fileRootUri;

            try {
                assetServer = new GlassAssetServer(webRoot, ASSET_PORT);
                baseUrl = assetServer.start();
                System.out.println("[GlassBrowserPanel] 静态资源服务: " + baseUrl + " (root=" + webRoot + ")");
            } catch (Throwable tAsset) {
                System.err.println("[GlassBrowserPanel] HTTP 资源服务启动失败，改用 file:// 加载：" + tAsset.getMessage());
                tAsset.printStackTrace();
                assetServer = null;
                baseUrl = fileFallbackBaseUrl;
                System.out.println("[GlassBrowserPanel] file:// 兜底 baseUrl: " + baseUrl);
            }

            // 2) JCEF 初始化（顺序严格）
            CompletableFuture<Void> initDone = new CompletableFuture<>();
            // 2a) 禁用 Remote 模式
            CefApp.setIsRemoteEnabled(false);
            System.out.println("[GlassBrowserPanel] setIsRemoteEnabled(false)");

            // 2b) AppHandler（注册 state 变化）
            CefApp.addAppHandler(new CefAppHandlerAdapter(null) {
                @Override
                public void stateHasChanged(CefApp.CefAppState state) {
                    System.out.println("[CEF] stateHasChanged: " + state);
                    if (state == CefApp.CefAppState.INITIALIZED) {
                        initDone.complete(null);
                    }
                }
            });
            System.out.println("[GlassBrowserPanel] addAppHandler");

            // 2c) Settings
            CefSettings settings = new CefSettings();
            settings.no_sandbox = true;
            settings.windowless_rendering_enabled = false;
            settings.resources_dir_path = jbrBin.getAbsolutePath();
            settings.locales_dir_path = locales.getAbsolutePath();
            settings.browser_subprocess_path = jcefHelper.getAbsolutePath();

            String cachePath = System.getProperty("user.dir") + "/Winllx/jcef_cache";
            new File(cachePath).mkdirs();
            settings.cache_path = cachePath;
            System.out.println("[GlassBrowserPanel] cache_path = " + cachePath);

            // 2d) startup
            // GPU 回退方案（复刻独立 Chrome 的成功路径）：
            // 独立浏览器用"真实 GPU(D3D11) + 不用 DirectComposition"能正常渲染 backdrop-filter；
            // 之前的强制 SwiftShader 软件合成反而让 backdrop-filter 静默失效。
            // 因此改为：ANGLE D3D11 真实 GPU 光栅化 + --disable-direct-composition 绕开
            // AMD DirectComposition 0x80004005 的坏路。
            String[] cefArgs = {
                    "--use-gl=angle",
                    "--use-angle=d3d11",
                    "--ignore-gpu-blocklist",
                    "--disable-direct-composition",   // 绕开 AMD DirectComposition 失败(0x80004005)，走 D3D11 swapchain 合成
                    "--no-sandbox",
                    "--test-type",                       // 抑制 Chrome 界面信息栏：--no-sandbox 警告、"不是默认浏览器"、"缺少 Google API keys"
                    "--disable-session-crashed-bubble",  // 禁止恢复弹窗
                    "--disable-infobars",                // 禁止信息栏
                    "--no-first-run",                    // 禁止首次运行向导
                    "--disable-features=IsolateOrigins,site-per-process",  // 简化进程模型
                    "--disable-background-networking",   // 静音后台网络请求（消除 SSL 握手报错噪音）
                    "--disable-component-update",
                    "--disable-domain-reliability",
                    "--no-pings"
            };
            CefApp.startup(cefArgs);
            System.out.println("[GlassBrowserPanel] CefApp.startup");

            // 2e) getInstance
            cefApp = CefApp.getInstance(cefArgs, settings, new File("."));
            System.out.println("[GlassBrowserPanel] CefApp.getInstance");

            // 不等 INITIALIZED，标记已初始化（INITIALIZED 异步会稍后到，不影响 createBrowser）
            sharedClient = cefApp.createClient();
            System.out.println("[GlassBrowserPanel] sharedClient = " + sharedClient);
            jcefAvailable = true;
            jcefInited.set(true);

            // 加载日志
            sharedClient.addLoadHandler(new CefLoadHandlerAdapter() {
                @Override
                public void onLoadingStateChange(CefBrowser b, boolean isLoading, boolean canBack, boolean canForward) {
                    System.out.println("[LOAD] loading=" + isLoading);
                }
                @Override
                public void onLoadEnd(CefBrowser b, CefFrame f, int rc) {
                    System.out.println("[LOAD] end rc=" + rc + " url=" + f.getURL());
                }
                @Override
                public void onLoadError(CefBrowser b, CefFrame f, CefLoadHandler.ErrorCode ec, String err, String u) {
                    System.err.println("[LOAD] ERROR: ec=" + ec + " err=" + err + " url=" + u);
                }
            });

            // 页面 JS 控制台输出（排查渲染问题用）
            sharedClient.addDisplayHandler(new org.cef.handler.CefDisplayHandlerAdapter() {
                @Override
                public boolean onConsoleMessage(CefBrowser browser, CefSettings.LogSeverity level,
                                                String message, String source, int line) {
                    System.out.println("[JS-" + level + "] " + message + " @" + source + ":" + line);
                    return false;
                }
            });

            Runtime.getRuntime().addShutdownHook(new Thread(GlassBrowserPanel::shutdownJcef));

            // 顺便后台等 INITIALIZED（只用于日志，不阻塞）
            new Thread(() -> {
                try {
                    initDone.get(30, TimeUnit.SECONDS);
                    System.out.println("[GlassBrowserPanel] CEF INITIALIZED");
                } catch (Exception ex) {
                    System.err.println("[GlassBrowserPanel] INITIALIZED 超时或异常: " + ex.getMessage());
                }
            }, "jcef-init-wait").start();

            return true;
        } catch (Throwable t) {
            System.err.println("[GlassBrowserPanel] JCEF 初始化失败: " + t.getMessage());
            t.printStackTrace();
            jcefAvailable = false;
            jcefInited.set(true);
            return false;
        }
    }

    /** JCEF 是否已就绪（初始化已结束且可用）。非阻塞，可安全在 EDT 上调用。 */
    public static boolean isJcefReady() {
        return jcefInited.get() && jcefAvailable;
    }

    /**
     * 在 JCEF 就绪后于 EDT 回调（始终延后一个 EDT 周期执行）。
     * 用于让子应用窗口「先秒开」——窗口与占位先 setVisible，浏览器等 JCEF 就绪后再挂载。
     * 关键点：绝不在 EDT 上直接调 ensureJcef()，否则会被预热线程持有的 synchronized 锁阻塞整个界面。
     */
    public static void whenJcefReady(Runnable onReady) {
        if (onReady == null) return;
        if (isJcefReady()) {
            // 已就绪：仍延后一个周期，保证窗口/占位先完成绘制
            SwingUtilities.invokeLater(onReady);
            return;
        }
        Thread t = new Thread(() -> {
            // 轮询等待初始化结束（不阻塞 EDT）；ensureJcef 成功或失败都会置 jcefInited
            while (!jcefInited.get()) {
                try {
                    Thread.sleep(30);
                } catch (InterruptedException ie) {
                    return;
                }
            }
            SwingUtilities.invokeLater(onReady);
        }, "jcef-wait");
        t.setDaemon(true);
        t.start();
    }

    /** 关闭并释放 JCEF 资源 */
    public static synchronized void shutdownJcef() {
        try {
            if (assetServer != null) {
                assetServer.stop();
                assetServer = null;
            }
        } catch (Throwable ignored) {}

        // 先 dispose 所有 client 的 browser
        try {
            if (sharedClient != null) {
                sharedClient.dispose();
                sharedClient = null;
            }
        } catch (Throwable ignored) {}

        // 再 dispose CefApp
        try {
            if (cefApp != null) {
                cefApp.dispose();
                cefApp = null;
            }
        } catch (Throwable ignored) {}

        // 强制清理静态引用
        jcefAvailable = false;
        jcefInited.set(false);
    }

    /** JCEF 就绪前的占位内容（保证窗口/面板先于浏览器创建即可见）。 */
    private void showPlaceholder() {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        JLabel label = new JLabel("正在加载…", SwingConstants.CENTER);
        label.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        label.setForeground(new Color(255, 255, 255, 180));
        p.add(label, BorderLayout.CENTER);
        placeholderComp = p;
        add(p, BorderLayout.CENTER);
    }

    private void removePlaceholder() {
        if (placeholderComp != null) {
            remove(placeholderComp);
            placeholderComp = null;
            revalidate();
            repaint();
        }
    }

    /** JCEF 不可用时的回退：提示并尝试用系统浏览器打开 */
    private void showFallback(String relativeUrl) {
        JPanel fallback = new JPanel(new BorderLayout());
        fallback.setOpaque(false);
        String url = isAbsoluteUrl(relativeUrl)
                ? relativeUrl
                : (baseUrl != null ? baseUrl : "") + (relativeUrl == null ? "" : relativeUrl);
        JLabel label = new JLabel("<html><div style='text-align:center;color:white;padding:20px;'>"
                + "Chromium 内核(JCEF)加载失败<br/>"
                + "请确保 lib/jbr 已正确解压并包含 jcef_helper.exe<br/>"
                + "资源 URL：<br/>"
                + "<b>" + url + "</b>"
                + "</div></html>", SwingConstants.CENTER);
        fallback.add(label, BorderLayout.CENTER);
        add(fallback, BorderLayout.CENTER);
        try {
            if (url.startsWith("http") || url.startsWith("file:")) {
                Desktop.getDesktop().browse(new URI(url));
            }
        } catch (Exception ignored) {
        }
    }

    /**
     * 探测 web 资源根目录：优先选择包含 `notes/notes.html` 或 `notes/` 子目录的候选。
     * 候选列表（优先级从高到低）：
     *   1) user.dir/web（run.bat 启动时的项目根/web）
     *   2) GlassBrowserPanel.class 所在目录的 ../web（从编译出来的 class 反推根）
     *   3) java.home 的 ../../web（以防 jbr 里运行）
     *   4) 所有子目录扫一遍，找到首个名为 web 且存在 notes/notes.html 的目录（兜底深度搜索 2 层）
     * 全部失败则返回 user.dir/web，保证创建目录不报错。
     */
    private static String findWebRoot() {
        java.util.List<String> candidates = new java.util.ArrayList<>();
        String userDir = System.getProperty("user.dir");
        if (userDir != null && !userDir.isEmpty()) {
            candidates.add(userDir + File.separator + "web");
            candidates.add(userDir);                 // 有时用户把 web 放在项目目录下父级外面，已兜底；这里留 userDir 自身再试 notes
        }
        // class 所在路径：ui/GlassBrowserPanel.class → 根 = getResource("").getPath 的 ../../
        try {
            java.net.URL loc = GlassBrowserPanel.class.getProtectionDomain().getCodeSource().getLocation();
            if (loc != null) {
                File codeDir = new File(java.net.URLDecoder.decode(loc.getPath(), StandardCharsets.UTF_8.name()));
                if (codeDir.isFile()) codeDir = codeDir.getParentFile();
                if (codeDir != null) {
                    candidates.add(codeDir.getAbsolutePath() + File.separator + "web");
                    if (codeDir.getParentFile() != null) {
                        candidates.add(codeDir.getParentFile().getAbsolutePath() + File.separator + "web");
                        if (codeDir.getParentFile().getParentFile() != null) {
                            candidates.add(codeDir.getParentFile().getParentFile().getAbsolutePath() + File.separator + "web");
                        }
                    }
                }
            }
        } catch (Throwable ignore) {}
        String javaHome = System.getProperty("java.home");
        if (javaHome != null) {
            File jh = new File(javaHome);
            if (jh.getParentFile() != null) {
                candidates.add(jh.getParentFile().getAbsolutePath() + File.separator + "web");
                if (jh.getParentFile().getParentFile() != null) {
                    candidates.add(jh.getParentFile().getParentFile().getAbsolutePath() + File.separator + "web");
                }
            }
        }

        // 评分：存在 notes/notes.html 最优先，次之存在 notes/ 目录，再次存在 web/ 目录
        String best = null; int bestScore = -1;
        for (String raw : candidates) {
            if (raw == null) continue;
            File d = new File(raw);
            int score = 0;
            if (new File(d, "notes" + File.separator + "notes.html").isFile()) score = 100;
            else if (new File(d, "notes").isDirectory()) score = 60;
            else if (d.isDirectory()) {
                // 仅当 d 就是 web 目录本身，给 20；否则 0
                score = "web".equalsIgnoreCase(d.getName()) ? 20 : 1;
            } else continue;
            if (score > bestScore) { bestScore = score; best = d.getAbsolutePath(); }
        }

        // 深度 2 兜底搜索（项目路径常见，不会耗时）
        if (bestScore < 100 && userDir != null) {
            File ud = new File(userDir);
            File r = searchWebShallow(ud, 2);
            if (r != null) best = r.getAbsolutePath();
        }

        if (best == null) {
            best = (userDir != null ? userDir : ".") + File.separator + "web";
        }
        return best;
    }

    private static File searchWebShallow(File root, int maxDepth) {
        if (root == null || maxDepth < 0) return null;
        File[] subs = root.listFiles();
        if (subs == null) return null;
        for (File f : subs) {
            if (f.isDirectory() && "web".equalsIgnoreCase(f.getName())) {
                if (new File(f, "notes" + File.separator + "notes.html").isFile()) return f;
            }
        }
        if (maxDepth == 0) return null;
        for (File f : subs) {
            if (f.isDirectory() && !f.getName().startsWith(".")) {
                File r = searchWebShallow(f, maxDepth - 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    /** 关闭当前浏览器实例；local 模式额外销毁独立 client（连带清理 native 资源，避免灰框残留） */
    public void closeBrowser() {
        try {
            if (browser != null) {
                browser.stopLoad();
                browser.close(true);
                browser = null;
            }
        } catch (Throwable ignored) {
        }
        if (isLocal) {
            // 关键：销毁独立 client，彻底清理 native 资源
            try {
                if (localClient != null) {
                    localClient.dispose();
                    localClient = null;
                }
            } catch (Throwable ignored) {
            }
            client = null;
            // 注意：localApp 复用共享 CefApp（进程级单例），绝不能 dispose，
            // 否则便笺等共享窗口的 Chromium 进程会被一起杀掉。
        }
    }

    /**
     * 注册「浏览器创建完成」回调，用于注册需要 client/browser 的处理器（下载、弹窗、右键菜单、桥接等）。
     * 若浏览器已创建则立即执行，否则延后到创建完成时执行（均在 EDT 上下文，与构造时的线程一致）。
     */
    public void onBrowserReady(Runnable r) {
        if (r == null) return;
        if (browserCreated) {
            r.run();
            return;
        }
        browserReadyCallback = r;
    }

    /** 获取本面板持有的 CefClient（供外部挂 handler，如 title 桥） */
    public CefClient getClient() {
        return client;
    }

    /** 获取当前浏览器实例（供外部按 browser 过滤 handler 回调） */
    public CefBrowser getBrowser() {
        return browser;
    }

    /** 可配置的下载目录（由浏览器设置写入；未配置时回退到系统下载目录） */
    private static volatile String downloadDir;

    /** 设置下载目录；传空则回退到默认（系统下载目录 / Winllx/downloads） */
    public static void setDownloadDir(String dir) {
        downloadDir = dir;
    }

    /** 启用下载：网页触发下载（如白板导出 PNG）时自动保存到系统下载目录。
     *  JCEF 的 CefClient 上挂 CefDownloadHandler 即可拦截下载事件。 */
    public void enableDownloads() {
        if (client == null) return;
        try {
            client.addDownloadHandler(new org.cef.handler.CefDownloadHandlerAdapter() {
                @Override
                public boolean onBeforeDownload(CefBrowser b, org.cef.callback.CefDownloadItem item,
                                                String suggestedName, org.cef.callback.CefBeforeDownloadCallback callback) {
                    File dir;
                    String cfg = downloadDir;
                    if (cfg != null && !cfg.trim().isEmpty()) {
                        dir = new File(cfg.trim());
                    } else {
                        dir = new File(System.getProperty("user.home"), "Downloads");
                        if (!dir.isDirectory()) dir = new File(System.getProperty("user.dir"), "Winllx/downloads");
                    }
                    try { dir.mkdirs(); } catch (Throwable ignored) {}
                    String name = (suggestedName != null && !suggestedName.isEmpty()) ? suggestedName : "download";
                    name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
                    File dest = new File(dir, name);
                    int i = 1;
                    while (dest.exists()) {
                        int dot = name.lastIndexOf('.');
                        String base = dot > 0 ? name.substring(0, dot) : name;
                        String ext = dot > 0 ? name.substring(dot) : "";
                        dest = new File(dir, base + "(" + (i++) + ")" + ext);
                    }
                    try { callback.Continue(dest.getAbsolutePath(), false); } catch (Throwable ignored) {}
                    return true;
                }
            });
        } catch (Throwable t) {
            System.err.println("[GlassBrowserPanel] 下载处理器挂载失败: " + t.getMessage());
        }
    }

    /**
     * 强制浏览器组件重新布局 + 派发 ComponentResized。
     * JCEF DEFAULT 模式下 CefBrowser 内部 Canvas/Native 窗口只有收到
     * ComponentResized 事件才会真正开始渲染。若 add 进父容器时父容器
     * 还没 validate 完，就会出现"全灰一片、必须手动 resize 才显示"的问题。
     */
    public void forceLayoutRefresh() {
        revalidate();
        repaint();
        Dimension d = getSize();
        if (d == null || d.width <= 0 || d.height <= 0) {
            Container parent = getParent();
            if (parent != null) {
                parent.revalidate();
                parent.repaint();
                Dimension pd = parent.getSize();
                if (pd != null && pd.width > 0 && pd.height > 0) d = pd;
            }
        }
        if (d == null || d.width <= 0 || d.height <= 0) return;
        Component[] kids = getComponents();
        for (Component k : kids) {
            if (k == null) continue;
            k.setSize(d);
            k.setPreferredSize(d);
            k.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
            k.revalidate();
            k.repaint();
            try {
                k.dispatchEvent(new java.awt.event.ComponentEvent(
                        k, java.awt.event.ComponentEvent.COMPONENT_RESIZED));
            } catch (Throwable ignored) {}
        }
        // 给 CEF 一个小延时再刷一次（它内部可能异步创建 native 窗口）
        SwingUtilities.invokeLater(() -> {
            revalidate();
            repaint();
            for (Component k : getComponents()) {
                if (k == null) continue;
                k.revalidate();
                k.repaint();
                try {
                    k.dispatchEvent(new java.awt.event.ComponentEvent(
                            k, java.awt.event.ComponentEvent.COMPONENT_RESIZED));
                } catch (Throwable ignored) {}
            }
        });
    }

    /**
     * 当本 Panel 挂到 JFrame 上（addNotify）后，在 ~800ms 内定时重复触发布局刷新生效。
     * JCEF DEFAULT 模式下 browser 的 native 窗口是异步创建的（createImmediately 之后才出现），
     * 只刷一次容易在 native 窗口诞生前就发 COMPONENT_RESIZED，导致"全灰、必须手动挪动窗口才显示"。
     * 这里用 Swing Timer 连续多刷几次，覆盖 native 窗口异步创建的过程，任何时机窗口都能自动显示。
     */
    @Override
    public void addNotify() {
        super.addNotify();
        final int[] pass = {0};
        Timer t = new Timer(55, e -> {
            forceLayoutRefresh();
            if (++pass[0] >= 14) ((Timer) e.getSource()).stop();   // ~770ms，足够覆盖 native 窗口创建
        });
        t.setRepeats(true);
        t.start();
    }

    public boolean isBrowserActive() {
        return browser != null;
    }

    /** 在浏览器中执行 JS（供外部调用，例如触发保存） */
    public void executeJavaScript(String js) {
        try {
            if (browser != null) {
                browser.executeJavaScript(js, "winllx-bridge", 0);
            }
        } catch (Throwable ignored) {
        }
    }

    // ===== 独立浏览器导航 API（供 BrowserModule 调用）=====

    /** 判断是否为可直接加载的绝对地址（外部网页/本地文件），而非本地资源库内的相对路径。 */
    public static boolean isAbsoluteUrl(String url) {
        if (url == null) return false;
        String s = url.trim().toLowerCase();
        return s.startsWith("http://") || s.startsWith("https://") || s.startsWith("file://")
                || s.startsWith("about:") || s.startsWith("data:") || s.startsWith("blob:")
                || s.startsWith("chrome:") || s.startsWith("view-source:");
    }

    /** 加载指定地址（绝对地址直接跳转） */
    public void loadUrl(String url) {
        try {
            if (browser != null && url != null && !url.isEmpty()) {
                browser.loadURL(url);
            }
        } catch (Throwable ignored) {
        }
    }

    public void goBack() {
        try { if (browser != null) browser.goBack(); } catch (Throwable ignored) {}
    }

    public void goForward() {
        try { if (browser != null) browser.goForward(); } catch (Throwable ignored) {}
    }

    public void reloadPage() {
        try { if (browser != null) browser.reload(); } catch (Throwable ignored) {}
    }

    /** 当前加载的地址（失败返回 null） */
    public String getCurrentUrl() {
        try { return browser != null ? browser.getURL() : null; } catch (Throwable t) { return null; }
    }

    /** 交出/收回浏览器焦点。地址栏等 Swing 输入控件聚焦时需置为 false，
     *  否则 Chromium 原生窗口会抢占键盘输入，导致地址栏无法编辑。 */
    public void setBrowserFocus(boolean enable) {
        try { if (browser != null) browser.setFocus(enable); } catch (Throwable ignored) {}
    }

    /** 弹窗（target=_blank / window.open）回调；由浏览器模块设置为「新建标签」。 */
    private java.util.function.Consumer<String> popupHandler;
    /** 弹窗拦截器是否已挂到当前 client 上（每个面板只挂一次）。 */
    private boolean popupInterceptorOn;

    /**
     * 拦截网页弹出的新窗口，**一律不让 CEF 自己建窗口**。
     *
     * 为什么要一律拦掉：这套 libcef 编译进了 Chrome runtime，只要 CEF 自己创建顶层窗口
     * （onBeforePopup 返回 false 时走的就是这条路），就会开出一个**整套 Chrome 界面**的原生窗口 ——
     * 带标签栏与 omnibox，并且必定弹出三条信息栏（"--no-sandbox 不受支持"、"缺少 Google API keys"、
     * "Chromium 不是默认浏览器"）以及"Chromium 未正常关闭 / 恢复页面"气泡；启动时它会连带恢复
     * 上一次残留的标签。这些都不是 Winllx 的界面，必须从源头掐掉。
     *
     * 拦截后由我们决定去向：
     *   · 浏览器模块（已 setPopupHandler）→ 回调出去，在顶部标签栏新建标签；
     *   · 其它模块（主界面 / 便笺 / 设置 / 天气 / 商店 …没设回调）→ 外部 http(s) 链接交给系统浏览器，
     *     其余（file: / about: 等内部地址）直接丢弃并打日志。
     */
    private void installPopupInterceptor() {
        if (client == null || popupInterceptorOn) return;
        popupInterceptorOn = true;
        try {
            client.addLifeSpanHandler(new org.cef.handler.CefLifeSpanHandlerAdapter() {
                @Override
                public boolean onBeforePopup(CefBrowser b, CefFrame f, String targetUrl, String targetFrameName) {
                    java.util.function.Consumer<String> h = popupHandler;
                    if (h != null && targetUrl != null && !targetUrl.isEmpty()) {
                        SwingUtilities.invokeLater(() -> h.accept(targetUrl));
                    } else if (targetUrl != null
                            && (targetUrl.startsWith("http://") || targetUrl.startsWith("https://"))) {
                        try {
                            Desktop.getDesktop().browse(new java.net.URI(targetUrl));
                        } catch (Throwable ignored) {}
                    } else {
                        System.out.println("[GlassBrowserPanel] 已拦截弹窗（内部地址，忽略）: " + targetUrl);
                    }
                    return true;   // 关键：永远不让 CEF 自己建窗口
                }
            });
        } catch (Throwable t) {
            System.err.println("[GlassBrowserPanel] 弹窗拦截挂载失败: " + t.getMessage());
        }
    }

    /**
     * 登记弹窗回调（浏览器模块用：把新页面并进顶部标签栏而不是弹窗）。
     * 拦截器本身在创建浏览器时已挂好，这里只是登记回调。
     */
    public void setPopupHandler(java.util.function.Consumer<String> handler) {
        this.popupHandler = handler;
        installPopupInterceptor();   // 兜底：若创建路径没挂上，这里补挂
    }

    /** 点击网页区域时收回 Chromium 焦点，保证网页内输入框仍可正常输入。 */
    private void installBrowserFocusRestore(Component ui) {
        if (ui == null) return;
        ui.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                try { if (browser != null) browser.setFocus(true); } catch (Throwable ignored) {}
            }
        });
    }

    /** 拼接 file:// 版完整 URL */
    private static String buildFileUrl(String fileBase, String relativeUrl) {
        String s = fileBase;
        if (relativeUrl == null || relativeUrl.isEmpty()) return s;
        if (relativeUrl.startsWith("/")) return s + relativeUrl;
        if (!s.endsWith("/")) s += "/";
        return s + relativeUrl;
    }

    /** 把字符串转成 JS 单引号字面量（兜底使用，避免 fallback URL 里含 Windows 全角字符 / 反斜杠导致 JS 语法错误） */
    private static String toJsString(String s) {
        if (s == null) return "''";
        StringBuilder sb = new StringBuilder(s.length() + 16);
        sb.append('\'');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\'': sb.append("\\'"); break;
                case '\\': sb.append("\\\\"); break;
                case '\r': sb.append("\\r"); break;
                case '\n': sb.append("\\n"); break;
                case '\t': sb.append("\\t"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\x%02X", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('\'');
        return sb.toString();
    }

    /** 触发 JS 端的保存（关闭前调用） */
    public void triggerSaveBeforeClose() {
        executeJavaScript("try{if(typeof window.saveNotes==='function')window.saveNotes();}catch(e){};");
    }
}
