using System;
using System.Runtime.InteropServices;
using System.Threading;

// IMMDeviceEnumerator - 不显式声明 IUnknown，让 marshaler 自动偏移到 vtable 3+
[ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDeviceEnumerator {
    [PreserveSig] int EnumAudioEndpoints(int dataFlow, int stateMask, out object ppCollection);
    [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice ppDevice);
    [PreserveSig] int GetDevice(string pwstrId, out IMMDevice ppDevice);
}

[ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDevice {
    [PreserveSig] int Activate(ref Guid iid, int clsCtx, IntPtr pParams, out IntPtr ppInterface);
    [PreserveSig] int OpenPropertyStore(int stgmAccess, out object ppStore);
    [PreserveSig] int GetId([MarshalAs(UnmanagedType.LPWStr)] out string ppstrId);
    [PreserveSig] int GetState(out int pdwState);
}

// IAudioEndpointVolume 完整 vtable（marshaler 自动偏移）
[ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IAudioEndpointVolume {
    [PreserveSig] int RegisterControlChangeNotify(IntPtr pNotify);           // vtable 3
    [PreserveSig] int UnregisterControlChangeNotify(IntPtr pNotify);         // vtable 4
    [PreserveSig] int GetChannelCount(out int pnChannelCount);               // vtable 5
    [PreserveSig] int SetMasterVolumeLevel(float fLevelDB, ref Guid pguid);  // vtable 6
    [PreserveSig] int SetMasterVolumeLevelScalar(float fLevel, ref Guid pguid); // vtable 7
    [PreserveSig] int GetMasterVolumeLevel(out float pfLevelDB);             // vtable 8 (漏了它就全错！)
    [PreserveSig] int GetMasterVolumeLevelScalar(out float pfLevel);         // vtable 9
    [PreserveSig] int SetChannelVolumeLevel(uint nChannel, float fLevelDB, ref Guid pguid);
    [PreserveSig] int SetChannelVolumeLevelScalar(uint nChannel, float fLevel, ref Guid pguid);
    [PreserveSig] int GetChannelVolumeLevel(uint nChannel, out float pfLevelDB);
    [PreserveSig] int GetChannelVolumeLevelScalar(uint nChannel, out float pfLevel);
    [PreserveSig] int SetAllMute([MarshalAs(UnmanagedType.Bool)] bool bMute, ref Guid pguid);
    [PreserveSig] int IsMuted([MarshalAs(UnmanagedType.Bool)] out bool bMuted);
}

class Program {
    static int retCode = 0;
    static string output = "";

    static void Main(string[] args) {
        Thread t = new Thread(() => RunCom(args));
        t.SetApartmentState(ApartmentState.STA);
        t.Start();
        t.Join();
        if (!string.IsNullOrEmpty(output)) Console.WriteLine(output);
        Environment.Exit(retCode);
    }

    static void RunCom(string[] args) {
        try {
            if (args.Length < 1) { Console.Error.WriteLine("volctl.exe get | set <0-100> | mute | unmute"); retCode = 2; return; }

            Guid clsid = new Guid("BCDE0395-E52F-467C-8E3D-C4579291692E");
            object unk = Activator.CreateInstance(Type.GetTypeFromCLSID(clsid));
            IMMDeviceEnumerator enumerator = (IMMDeviceEnumerator)unk;
            IMMDevice device;
            enumerator.GetDefaultAudioEndpoint(0, 0, out device);
            Guid iid = typeof(IAudioEndpointVolume).GUID;
            IntPtr pInterface;
            device.Activate(ref iid, 1, IntPtr.Zero, out pInterface);
            IAudioEndpointVolume epVol = (IAudioEndpointVolume)Marshal.GetObjectForIUnknown(pInterface);

            if (args[0].Equals("get", StringComparison.OrdinalIgnoreCase)) {
                float level;
                epVol.GetMasterVolumeLevelScalar(out level);
                bool muted;
                epVol.IsMuted(out muted);
                int pct = (int)Math.Round(level * 100f);
                output = muted ? "MUTED::" + pct : "VOL::" + pct;
            } else if (args[0].Equals("set", StringComparison.OrdinalIgnoreCase) && args.Length >= 2) {
                int pct;
                if (!int.TryParse(args[1], out pct)) { Console.Error.WriteLine("invalid value"); retCode = 6; return; }
                pct = Math.Max(0, Math.Min(100, pct));
                Guid empty = Guid.Empty;
                // 值 > 0 时自动解除静音（与 Windows 混音器行为一致），避免静音标志让调节"看起来无效"
                if (pct > 0) epVol.SetAllMute(false, ref empty);
                epVol.SetMasterVolumeLevelScalar(pct / 100f, ref empty);
                output = "SET_OK";
            } else if (args[0].Equals("mute", StringComparison.OrdinalIgnoreCase)) {
                Guid empty = Guid.Empty;
                epVol.SetAllMute(true, ref empty);
                output = "MUTE_OK";
            } else if (args[0].Equals("unmute", StringComparison.OrdinalIgnoreCase)) {
                Guid empty = Guid.Empty;
                epVol.SetAllMute(false, ref empty);
                output = "UNMUTE_OK";
            } else {
                Console.Error.WriteLine("volctl.exe get | set <0-100> | mute | unmute");
                retCode = 2;
            }

            Marshal.ReleaseComObject(epVol);
            Marshal.ReleaseComObject(device);
            Marshal.ReleaseComObject(enumerator);
        } catch (Exception ex) {
            Console.Error.WriteLine("ERR::" + ex.Message);
            retCode = 1;
        }
    }
}
