@echo off
cd /d "%~dp0"

echo ========================================
echo        Winllx Build and Run
echo ========================================

set "JAVA_HOME=%~dp0lib\jbr"
call "%~dp0gradlew.bat" run
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Program exited abnormally.
    pause
)