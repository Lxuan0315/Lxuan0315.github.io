import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

/**
 * Winllx 主程序入口
 */
public class Winllx {

    // ==================== 常量定义区 ====================
    private static final String APP_TITLE = "Winllx";
    private static final Color DEFAULT_BG = Color.WHITE;
    private static final String TRAY_ICON_PATH = "C:/Users/86132/Desktop/java.png";

    private static final int COL_LEFT = 300;
    private static final int COL_RIGHT = 800;
    private static final int ROW_TOP = 70;
    private static final int ROW_MIDDLE = 200;
    private static final int ROW_BOTTOM = 330;

    private static final int APP_BTN_SIZE = 80;
    private static final int WIDE_BTN_WIDTH = 200;
    private static final int SHORT_BTN_HEIGHT = 50;

    private static final int[][] MIND_GROUPS = {
        {1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31},
        {2, 3, 6, 7, 10, 11, 14, 15, 18, 19, 22, 23, 26, 27, 30, 31},
        {4, 5, 6, 7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31},
        {8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29, 30, 31},
        {16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31}
    };
    private static final int[] MIND_WEIGHTS = {1, 2, 4, 8, 16};

    // ==================== 状态变量 ====================
    private static boolean trayEnabled = true;
    private static TrayIcon trayIcon;

    private static JFrame mainFrame;

    // ==================== 主入口 ====================
    public static void main(String[] args) {
        Loading loading = new Loading();
        loading.show();

        initMainWindow();
        buildDesktopUI();
        initSystemTray();

        loading.close();
    }

    public static void setMainVisible(boolean visible) {
        if (mainFrame != null) {
            mainFrame.setVisible(visible);
        }
    }

    private static void initMainWindow() {
        mainFrame = new JFrame(APP_TITLE);
        mainFrame.getContentPane().setBackground(DEFAULT_BG);
        mainFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        mainFrame.setLayout(null);
        mainFrame.setSize(300, 200);
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setVisible(true);
    }

    private static void buildDesktopUI() {
        addDesktopLabels();
        addDesktopButtons();
    }

    private static void addDesktopLabels() {
        JLabel title = createLabel(APP_TITLE, 600, 20, 100, 50, 20f);
        JLabel noteLabel = createLabel("便笺", COL_LEFT + 20, ROW_TOP + 60, 80, 80, 0);
        JLabel calcLabel = createLabel("计算器", COL_RIGHT + 20, ROW_TOP + 60, 80, 80, 0);
        JLabel fileLabel = createLabel("文件管理", COL_LEFT + 10, ROW_MIDDLE + 60, 80, 80, 0);
        JLabel boardLabel = createLabel("白板", COL_LEFT + 20, ROW_BOTTOM + 60, 80, 80, 0);

        addToMain(title, noteLabel, calcLabel, fileLabel, boardLabel);
    }

    private static void addDesktopButtons() {
        JButton noteBtn = createAppButton("便笺", COL_LEFT, ROW_TOP, e -> new Winllx2());
        JButton calcBtn = createAppButton("计算器", COL_RIGHT, ROW_TOP, e -> new Winllx3());
        JButton fileBtn = createAppButton("文件管理", COL_LEFT, ROW_MIDDLE, e -> new Winllx4());
        JButton mindBtn = createStyledButton("读心术", COL_RIGHT, ROW_MIDDLE, WIDE_BTN_WIDTH, SHORT_BTN_HEIGHT, e -> launchMindReading());
        JButton boardBtn = createAppButton("白板", COL_LEFT, ROW_BOTTOM, e -> new Winllx7(null));
        JLabel clockLabel = createLabel("时钟", COL_RIGHT + 20, ROW_BOTTOM + 60, 80, 80, 0);
        JButton clockBtn = createAppButton("时钟", COL_RIGHT, ROW_BOTTOM, e -> {
            SwingUtilities.invokeLater(() -> new Winllx5().setVisible(true));
        });

        JButton minimizeBtn = createStyledButton("缩小到任务栏", 900, 550, 150, SHORT_BTN_HEIGHT, e -> setMainVisible(false));
        JButton settingsBtn = createAppButton("设置", 1100, 550, e -> openSettings());
        JButton exitBtn = createAppButton("退出", 1200, 550, e -> new Winllx0());

        addToMain(noteBtn, calcBtn, fileBtn, mindBtn, boardBtn, clockBtn, clockLabel, minimizeBtn, settingsBtn, exitBtn);
    }

    private static JLabel createLabel(String text, int x, int y, int w, int h, float fontSize) {
        JLabel label = new JLabel(text);
        label.setBounds(x, y, w, h);
        if (fontSize > 0) {
            label.setFont(label.getFont().deriveFont(fontSize));
        }
        return label;
    }

    private static JButton createAppButton(String text, int x, int y, ActionListener action) {
        return createStyledButton(text, x, y, APP_BTN_SIZE, APP_BTN_SIZE, action);
    }

    private static JButton createStyledButton(String text, int x, int y, int w, int h, ActionListener action) {
        JButton btn = GlassButtonDemo.createButton(text);
        btn.setBounds(x, y, w, h);
        btn.setBorderPainted(false);
        btn.setBackground(DEFAULT_BG);
        if (action != null) {
            btn.addActionListener(action);
        }
        return btn;
    }

    private static void addToMain(JComponent... components) {
        for (JComponent c : components) {
            mainFrame.add(c);
        }
    }

    private static void launchMindReading() {
        setMainVisible(false);
        JOptionPane.showMessageDialog(null, "启动成功，请返回cmd进行操作");

        System.out.println("欢迎来到读心术(二进制)");
        System.out.println("在1-31中选择一个数字");
        System.out.println("注：如果玩不起(更改所想数字)，请不要按下Enter，并退出游戏");
        System.out.println("按下Enter开始游戏");

        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();

        int result = 0;
        for (int i = 0; i < MIND_GROUPS.length; i++) {
            System.out.println("你心中所想数字在这一组吗？");
            if (askGroup(scanner, MIND_GROUPS[i])) {
                result += MIND_WEIGHTS[i];
            }
        }

        JOptionPane.showMessageDialog(null, "你心中所想的数字是：" + result + "\n游戏结束");
        setMainVisible(true);
    }

    private static boolean askGroup(Scanner scanner, int[] group) {
        System.out.print("组：");
        for (int num : group) {
            System.out.print(num + " ");
        }
        System.out.println("\n你的数字在这个组中吗？ (0: 没有, 1: 有): ");
        try {
            return scanner.nextInt() == 1;
        } catch (InputMismatchException e) {
            scanner.next();
            System.out.println("输入无效，默认为 0");
            return false;
        }
    }

    private static void openSettings() {
        JFrame dialog = new JFrame("Winllx设置");
        dialog.setSize(350, 350);
        dialog.setLocation(200, 200);
        dialog.setLayout(null);

        JLabel themeLabel = new JLabel("主题色");
        themeLabel.setBounds(10, 0, 80, 30);
        dialog.add(themeLabel);

        String[] themes = {"默认", "黑色", "蓝色"};
        GlassSegmentedControl themeSelector = new GlassSegmentedControl(themes);
        themeSelector.setBounds(10, 30, 300, 60);
        themeSelector.addSelectionListener((index, opt) -> applyTheme(index));
        themeSelector.setSelectedIndex(0);
        dialog.add(themeSelector);

        JLabel volumeLabel = new JLabel("音量(需系统权限)");
        volumeLabel.setBounds(10, 100, 120, 30);
        dialog.add(volumeLabel);

        GlassSlider[] sliderRef = new GlassSlider[1];
        sliderRef[0] = GlassSlider.create(dialog, 0, 260, 200, 50, 50, evt -> {
            int volume = sliderRef[0].getValue();
            setSystemVolume(volume);
        });
        sliderRef[0].setBounds(10, 130, 200, 50);
        dialog.add(sliderRef[0]);

        dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialog.setVisible(true);
    }

    private static void applyTheme(int index) {
        Color color = switch (index) {
            case 1 ->
                Color.BLACK;
            case 2 ->
                Color.BLUE;
            default ->
                Color.WHITE;
        };
        mainFrame.getContentPane().setBackground(color);
        mainFrame.repaint();
    }

    private static void initSystemTray() {
        if (!trayEnabled || !SystemTray.isSupported()) {
            return;
        }

        SystemTray tray = SystemTray.getSystemTray();
        Image image = Toolkit.getDefaultToolkit().getImage(TRAY_ICON_PATH);

        PopupMenu popup = new PopupMenu();
        MenuItem openItem = new MenuItem("打开");
        MenuItem settingsItem = new MenuItem("设置");
        MenuItem exitItem = new MenuItem("退出");

        popup.add(openItem);
        popup.addSeparator();
        popup.add(settingsItem);
        popup.addSeparator();
        popup.add(exitItem);

        trayIcon = new TrayIcon(image, APP_TITLE, popup);
        trayIcon.setImageAutoSize(true);

        openItem.addActionListener(e -> setMainVisible(true));
        settingsItem.addActionListener(e -> openSettings());
        exitItem.addActionListener(e -> {
            tray.remove(trayIcon);
            System.exit(0);
        });
        trayIcon.addActionListener(e -> setMainVisible(true));

        try {
            tray.add(trayIcon);
        } catch (AWTException ex) {
            System.err.println("无法添加到系统托盘\n请检查是否给予权限");
        }
    }

    private static void setSystemVolume(int volume) {
        try {
            int vol = Math.max(0, Math.min(100, volume));
            String script = buildVolumeScript(vol);

            ProcessBuilder pb = new ProcessBuilder("powershell.exe", "-Command", script);
            pb.redirectErrorStream(true);
            Process process = pb.start();
            process.waitFor(2, java.util.concurrent.TimeUnit.SECONDS);

            System.out.println("音量已设置为: " + vol + "%");
        } catch (Exception e) {
            System.err.println("PowerShell 控制音量失败: " + e.getMessage());
            setSystemVolumeRobot(volume);
        }

    }

    private static String buildVolumeScript(int volume) {
        return "Add-Type -TypeDefinition @\" \n"
                + "using System; \n"
                + "using System.Runtime.InteropServices; \n"
                + "public class VolumeControl { \n"
                + "    [DllImport(\\\"user32.dll\\\")] \n"
                + "    public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, uint dwExtraInfo); \n"
                + "} \n"
                + "\"@; \n"
                + "$vol = " + volume + "; \n"
                + "for ($i = 0; $i < 50; $i++) { \n"
                + "    [VolumeControl]::keybd_event(0xAE, 0, 0, 0); \n"
                + "    Start-Sleep -Milliseconds 10; \n"
                + "} \n"
                + "for ($i = 0; i < $vol; $i++) { \n"
                + "    [VolumeControl]::keybd_event(0xAF, 0, 0, 0); \n"
                + "    Start-Sleep -Milliseconds 10; \n"
                + "}";
    }

    private static void setSystemVolumeRobot(int volume) {
        try {
            Robot robot = new Robot();
            int vol = Math.max(0, Math.min(100, volume));

            for (int i = 0; i < 50; i++) {
                robot.keyPress(0xAE);
                robot.keyRelease(0xAE);
                Thread.sleep(5);
            }
            for (int i = 0; i < vol / 2; i++) {
                robot.keyPress(0xAF);
                robot.keyRelease(0xAF);
                Thread.sleep(5);
            }
            System.out.println("Robot 方式设置音量为: " + vol + "%");
        } catch (Exception e) {
            System.err.println("Robot 控制音量失败: " + e.getMessage());
        }    
    }
    public static void showNotification(String caption, String text) {
        if (trayIcon != null) {
            trayIcon.displayMessage(caption, text, TrayIcon.MessageType.INFO);
        }
    }

}




// ==================== 子模块：关机 ====================
class Winllx0 {

    Winllx0() {
        try {
            Runtime.getRuntime().exec("shutdown -s -t 0");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "关机失败！请检查是否给予权限");
        }
    }
}

// ==================== 子模块：便笺 ====================
class Winllx2 {

    // 修改：统一使用 winllx 目录，便笺内容和配置文件同目录不同文件
    private static final String WINLLX_DIR = System.getProperty("user.dir") + "/Winllx";
    private static final String NOTES_FILE = WINLLX_DIR + "/notes.txt";
    private static final String CONFIG_FILE = WINLLX_DIR + "/config.properties";
    private static final int MAX_TABS = 50;
        // 新增：设置窗口单例引用
    private JFrame settingsFrameRef = null;


    private JFrame frame;
    private JTabbedPane tabbedPane;
    private java.util.List<String> loadedTitles = new java.util.ArrayList<>();
    private java.util.List<String> loadedContents = new java.util.ArrayList<>();
    private java.util.List<Boolean> loadedWraps = new java.util.ArrayList<>();
    
    // 新增：保存每个标签页 JTextArea 的引用，避免用 getComponentAt 坐标查找
    private java.util.List<JTextArea> textAreas = new java.util.ArrayList<>();
    
    // 新增：全局默认自动换行设置，从 config.properties 读取
    private boolean defaultLineWrap = true;

    Winllx2() {
        loadConfig();   // 先读全局配置
        loadNotes();
        initUI();
    }

    private void initUI() {
        frame = new JFrame("Winllx便签");
        frame.setSize(500, 400);
        frame.setLocation(200, 200);
        frame.setLayout(new BorderLayout());

        tabbedPane = new JTabbedPane();

        if (loadedTitles.isEmpty()) {
            addNewTab("便签 1", "", defaultLineWrap);
        } else {
            for (int i = 0; i < loadedTitles.size(); i++) {
                boolean wrap = i < loadedWraps.size() ? loadedWraps.get(i) : defaultLineWrap;
                addNewTab(loadedTitles.get(i), loadedContents.get(i), wrap);
            }
        }

        // 鼠标监听：右键菜单 + 双击重命名
        tabbedPane.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && SwingUtilities.isLeftMouseButton(e)) {
                    int idx = tabbedPane.indexAtLocation(e.getX(), e.getY());
                    if (idx >= 0) renameTab(idx);
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    int idx = tabbedPane.indexAtLocation(e.getX(), e.getY());
                    if (idx >= 0) showTabContextMenu(idx, e.getX(), e.getY());
                }
            }
        });

        // 关闭窗口时自动保存
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                saveNotes();
            }
        });

        // 底部面板
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        bottomPanel.setOpaque(false);

        JButton addBtn = GlassButtonDemo.createButton("+");
        addBtn.setPreferredSize(new Dimension(45, 40));
        addBtn.addActionListener(e -> {
            int count = tabbedPane.getTabCount();
            if (count >= MAX_TABS) {
                JOptionPane.showMessageDialog(frame, "标签数量已达上限 (" + MAX_TABS + ")", "提示", JOptionPane.WARNING_MESSAGE);
                return;
            }
            // 修改：新建标签页使用全局默认值
            addNewTab("便签 " + (count + 1), "", defaultLineWrap);
            tabbedPane.setSelectedIndex(count);
        });

        JButton settingsBtn = GlassButtonDemo.createButton("设置");
        settingsBtn.setPreferredSize(new Dimension(80, 40));
        settingsBtn.addActionListener(e -> openSettings());

        bottomPanel.add(addBtn);
        bottomPanel.add(settingsBtn);

        frame.add(tabbedPane, BorderLayout.CENTER);
        frame.add(bottomPanel, BorderLayout.SOUTH);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }

    private void addNewTab(String title, String content, boolean lineWrap) {
        JTextArea textArea = new JTextArea(content);
        textArea.setLineWrap(lineWrap);
        textArea.setWrapStyleWord(true);
        textAreas.add(textArea); // 保存引用，方便后续读写

        JScrollPane scrollPane = new JScrollPane(textArea);
        tabbedPane.addTab(title, scrollPane);
    }

    private void renameTab(int idx) {
        String current = tabbedPane.getTitleAt(idx);
        String newName = JOptionPane.showInputDialog(frame, "新名称:", current);
        if (newName != null && !newName.trim().isEmpty()) {
            tabbedPane.setTitleAt(idx, newName.trim());
        }
    }

    private void showTabContextMenu(int idx, int x, int y) {
        JPopupMenu menu = new JPopupMenu();

        JMenuItem renameItem = new JMenuItem("重命名");
        renameItem.addActionListener(ev -> renameTab(idx));

        JMenuItem closeItem = new JMenuItem("关闭");
        closeItem.addActionListener(ev -> {
            if (tabbedPane.getTabCount() > 1) {
                textAreas.remove(idx); // 同步移除引用
                tabbedPane.remove(idx);
            } else {
                JOptionPane.showMessageDialog(frame, "至少保留一个标签页", "提示", JOptionPane.WARNING_MESSAGE);
            }
        });

        menu.add(renameItem);
        menu.add(closeItem);
        menu.show(tabbedPane, x, y);
    }

    private void saveNotes() {
        try {
            java.io.File dir = new java.io.File(WINLLX_DIR);
            if (!dir.exists()) dir.mkdirs();

            Properties props = new Properties();
            int count = 0;
            for (int i = 0; i < tabbedPane.getTabCount(); i++) {
                String title = tabbedPane.getTitleAt(i);
                // 修改：直接从 textAreas 列表获取，不再使用 getComponentAt(i) 坐标查找
                JTextArea textArea = textAreas.get(i);
                props.setProperty("title." + count, title);
                props.setProperty("content." + count, textArea.getText());
                props.setProperty("wrap." + count, String.valueOf(textArea.getLineWrap()));
                count++;
            }
            props.setProperty("count", String.valueOf(count));

            try (java.io.FileOutputStream fos = new java.io.FileOutputStream(NOTES_FILE)) {
                props.store(fos, "Winllx Notes");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "保存失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void loadNotes() {
        java.io.File file = new java.io.File(NOTES_FILE);
        if (!file.exists()) return;

        try (java.io.FileInputStream fis = new java.io.FileInputStream(NOTES_FILE)) {
            Properties props = new Properties();
            props.load(fis);

            int count = Integer.parseInt(props.getProperty("count", "0"));
            if (count > 100) {
                System.err.println("便签数据损坏（标签数=" + count + "），已重置");
                return;
            }

            for (int i = 0; i < count; i++) {
                String title = props.getProperty("title." + i, "便签 " + (i + 1));
                String content = props.getProperty("content." + i, "");
                boolean wrap = Boolean.parseBoolean(props.getProperty("wrap." + i, "true"));
                loadedTitles.add(title);
                loadedContents.add(content);
                loadedWraps.add(wrap);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 新增：读取全局配置文件 config.properties
    private void loadConfig() {
        java.io.File file = new java.io.File(CONFIG_FILE);
        if (!file.exists()) return;
        try (java.io.FileInputStream fis = new java.io.FileInputStream(CONFIG_FILE)) {
            Properties props = new Properties();
            props.load(fis);
            defaultLineWrap = Boolean.parseBoolean(props.getProperty("note.wrap.default", "true"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 新增：保存全局配置文件 config.properties
    private void saveConfig() {
        try {
            java.io.File dir = new java.io.File(WINLLX_DIR);
            if (!dir.exists()) dir.mkdirs();

            Properties props = new Properties();
            props.setProperty("note.wrap.default", String.valueOf(defaultLineWrap));

            try (java.io.FileOutputStream fos = new java.io.FileOutputStream(CONFIG_FILE)) {
                props.store(fos, "Winllx Configuration");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

void openSettings() {
    // 如果设置窗口已存在且可见，直接置顶，不再新建
    if (settingsFrameRef != null && settingsFrameRef.isVisible()) {
        settingsFrameRef.toFront();
        settingsFrameRef.requestFocus();
        return;
    }

    int idx = tabbedPane.getSelectedIndex();
    if (idx < 0) return;

    JTextArea textArea = textAreas.get(idx);

    settingsFrameRef = new JFrame("Winllx便签设置");
    settingsFrameRef.setSize(350, 280);
    settingsFrameRef.setLocation(200, 200);
    settingsFrameRef.setLayout(null);
    settingsFrameRef.getContentPane().setBackground(new Color(20, 20, 40));

    JLabel label = new JLabel("自动换行");
    label.setForeground(Color.WHITE);
    label.setBounds(20, 10, 80, 30);
    settingsFrameRef.add(label);

    String[] wrapOptions = {"启用", "禁用"};
    GlassSegmentedControl wrapSelector = new GlassSegmentedControl(wrapOptions);
    wrapSelector.setBounds(20, 50, 200, 72);

    int initialIndex = defaultLineWrap ? 0 : 1;
    wrapSelector.setSelectedIndex(initialIndex);

    wrapSelector.addSelectionListener((selectedIdx, opt) -> {
        boolean newWrap = selectedIdx == 0;
        textArea.setLineWrap(newWrap);
        defaultLineWrap = newWrap;
        saveConfig();
    });

    settingsFrameRef.add(wrapSelector);

    JButton clearBtn = GlassButtonDemo.createButton("清空所有便笺");
    clearBtn.setBounds(20, 140, 200, 40);
    clearBtn.addActionListener(e -> {
        int confirm = JOptionPane.showConfirmDialog(
            settingsFrameRef,
            "确定要清空所有便笺吗？此操作不可恢复！",
            "确认清空",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );
        if (confirm == JOptionPane.YES_OPTION) {
            clearAllNotes();
        }
    });
    settingsFrameRef.add(clearBtn);

    settingsFrameRef.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    settingsFrameRef.setVisible(true);
}
    // 新增：清空所有便笺数据
    private void clearAllNotes() {
        try {
            // 删除配置文件
            java.io.File notesFile = new java.io.File(NOTES_FILE);
            java.io.File configFile = new java.io.File(CONFIG_FILE);
            if (notesFile.exists()) notesFile.delete();
            if (configFile.exists()) configFile.delete();

            // 清空内存中的数据
            loadedTitles.clear();
            loadedContents.clear();
            loadedWraps.clear();
            textAreas.clear();
            tabbedPane.removeAll();

            // 重置默认值并新建一个空白标签页
            defaultLineWrap = true;
            addNewTab("便签 1", "", defaultLineWrap);

            JOptionPane.showMessageDialog(frame, "所有便笺已清空", "提示", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "清空失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}

// ==================== 子模块：文件管理 ====================
class Winllx4 {

    private static final String[] BTN_NAMES = {"新建", "打开", "预览文件"};
    private static final int[] BTN_X = {10, 100, 200};
    private static final int[] BTN_W = {80, 80, 100};

    Winllx4() {
        JFrame frame = new JFrame("文件管理");
        frame.setSize(350, 80);
        frame.setResizable(false);
        frame.setLayout(null);

        for (int i = 0; i < BTN_NAMES.length; i++) {
            JButton btn = new JButton(BTN_NAMES[i]);
            btn.setBounds(BTN_X[i], 10, BTN_W[i], 30);
            btn.addActionListener(e -> showUnsupported());
            frame.add(btn);
        }

        frame.setVisible(true);
    }

    private static void showUnsupported() {
        JOptionPane.showMessageDialog(null, "您的电脑不支持此功能", "该功能不会做", JOptionPane.ERROR_MESSAGE);
    }
}

// ==================== 子模块：加载动画 ====================
class Loading {

    private JFrame frame;
    private javax.swing.Timer timer;
    private int angle = 0;

    public Loading() {
        initUI();
    }

    private void initUI() {
        frame = new JFrame("加载中");
        frame.setSize(200, 200);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setAlwaysOnTop(true);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int cx = getWidth() / 2;
                int cy = getHeight() / 2;
                int r = 50;

                g2d.setColor(Color.LIGHT_GRAY);
                g2d.setStroke(new BasicStroke(2));
                g2d.drawOval(cx - r, cy - r, r * 2, r * 2);

                g2d.setColor(Color.BLUE);
                g2d.setStroke(new BasicStroke(5));
                g2d.drawArc(cx - r, cy - r, r * 2, r * 2, angle, 270);
            }
        };
        panel.setBackground(Color.WHITE);
        frame.add(panel);

        timer = new javax.swing.Timer(50, e -> {
            angle = (angle + 10) % 360;
            panel.repaint();
        });
        timer.start();
    }

    public void show() {
        frame.setVisible(true);
    }

    public void close() {
        if (timer != null) {
            timer.stop();
        }
        if (frame != null) {
            frame.dispose();
        }
    }
}

// ==================== 子模块：时钟 ====================
class Winllx5 extends JFrame {

    private JTabbedPane tabbedPane;
    private ClockPanel clockPanel;
    private AlarmPanel alarmPanel;
    private CountdownPanel countdownPanel;
    private StopwatchPanel stopwatchPanel;

    public Winllx5() {
        setTitle("时钟");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        tabbedPane = new JTabbedPane();
        clockPanel = new ClockPanel();
        alarmPanel = new AlarmPanel();
        countdownPanel = new CountdownPanel();
        stopwatchPanel = new StopwatchPanel();

        tabbedPane.addTab("时间", clockPanel);
        tabbedPane.addTab("闹钟", alarmPanel);
        tabbedPane.addTab("倒计时", countdownPanel);
        tabbedPane.addTab("计时器", stopwatchPanel);

        add(tabbedPane);

        java.util.Timer timer = new java.util.Timer();
        timer.scheduleAtFixedRate(new java.util.TimerTask() {
            @Override
            public void run() {
                clockPanel.repaint();
            }
        }, 0, 1000);
    }

    class ClockPanel extends JPanel {

        private java.text.SimpleDateFormat timeFormat = new java.text.SimpleDateFormat("HH:mm:ss");
        private java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyy年MM月dd日 EEEE");

        public ClockPanel() {
            setLayout(new BorderLayout());
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR);
            int minute = calendar.get(Calendar.MINUTE);
            int second = calendar.get(Calendar.SECOND);

            String time = timeFormat.format(calendar.getTime());
            String date = dateFormat.format(calendar.getTime());

            g.setFont(new Font("Arial", Font.BOLD, 24));
            FontMetrics fm = g.getFontMetrics();
            int timeWidth = fm.stringWidth(time);
            g.drawString(time, (getWidth() - timeWidth) / 2, 50);

            g.setFont(new Font("Arial", Font.PLAIN, 16));
            fm = g.getFontMetrics();
            int dateWidth = fm.stringWidth(date);
            g.drawString(date, (getWidth() - dateWidth) / 2, 80);

            int centerX = getWidth() / 2;
            int centerY = getHeight() / 2 + 30;
            int radius = Math.min(getWidth(), getHeight()) / 3;

            g.setColor(Color.BLACK);
            g.drawOval(centerX - radius, centerY - radius, 2 * radius, 2 * radius);

            for (int i = 0; i < 60; i++) {
                double angle = Math.toRadians(6 * i);
                int x1 = centerX + (int) (0.9 * radius * Math.sin(angle));
                int y1 = centerY - (int) (0.9 * radius * Math.cos(angle));
                int x2 = centerX + (int) (radius * Math.sin(angle));
                int y2 = centerY - (int) (radius * Math.cos(angle));

                if (i % 5 == 0) {
                    g.setColor(Color.BLACK);
                    g.drawLine(x1, y1, x2, y2);
                } else {
                    g.setColor(Color.GRAY);
                    g.drawLine(x1, y1, x2, y2);
                }
            }

            double hourAngle = Math.toRadians(30 * hour + 0.5 * minute);
            int hourHandLength = radius / 2;
            int hourX = centerX + (int) (hourHandLength * Math.sin(hourAngle));
            int hourY = centerY - (int) (hourHandLength * Math.cos(hourAngle));
            g.setColor(Color.BLACK);
            g.drawLine(centerX, centerY, hourX, hourY);

            double minuteAngle = Math.toRadians(6 * minute + 0.1 * second);
            int minuteHandLength = 3 * radius / 4;
            int minuteX = centerX + (int) (minuteHandLength * Math.sin(minuteAngle));
            int minuteY = centerY - (int) (minuteHandLength * Math.cos(minuteAngle));
            g.setColor(Color.BLUE);
            g.drawLine(centerX, centerY, minuteX, minuteY);

            double secondAngle = Math.toRadians(6 * second);
            int secondHandLength = 4 * radius / 5;
            int secondX = centerX + (int) (secondHandLength * Math.sin(secondAngle));
            int secondY = centerY - (int) (secondHandLength * Math.cos(secondAngle));
            g.setColor(Color.RED);
            g.drawLine(centerX, centerY, secondX, secondY);

            g.setColor(Color.RED);
            g.fillOval(centerX - 5, centerY - 5, 10, 10);
        }
    }

    class AlarmPanel extends JPanel {

        private DefaultListModel<String> alarmListModel;
        private JList<String> alarmList;
        private JButton addButton;
        private JButton deleteButton;

        public AlarmPanel() {
            setLayout(new BorderLayout());

            alarmListModel = new DefaultListModel<>();
            alarmList = new JList<>(alarmListModel);
            add(new JScrollPane(alarmList), BorderLayout.CENTER);

            JPanel buttonPanel = new JPanel();
            addButton = new JButton("添加闹钟");
            deleteButton = new JButton("删除闹钟");

            addButton.addActionListener(e -> addAlarm());
            deleteButton.addActionListener(e -> deleteAlarm());

            buttonPanel.add(addButton);
            buttonPanel.add(deleteButton);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        private void addAlarm() {
            JSpinner hourSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 23, 1));
            JSpinner minuteSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));

            JPanel panel = new JPanel(new GridLayout(2, 2));
            panel.add(new JLabel("小时:"));
            panel.add(hourSpinner);
            panel.add(new JLabel("分钟:"));
            panel.add(minuteSpinner);

            int result = JOptionPane.showConfirmDialog(null, panel, "设置闹钟",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                int hour = (Integer) hourSpinner.getValue();
                int minute = (Integer) minuteSpinner.getValue();
                alarmListModel.addElement(String.format("%02d:%02d", hour, minute));
            }
        }

        private void deleteAlarm() {
            int selectedIndex = alarmList.getSelectedIndex();
            if (selectedIndex != -1) {
                alarmListModel.remove(selectedIndex);
            }
        }
    }

    class CountdownPanel extends JPanel {

        private JSpinner hourSpinner;
        private JSpinner minuteSpinner;
        private JSpinner secondSpinner;
        private JButton startButton;
        private JButton stopButton;
        private JLabel countdownLabel;
        private java.util.Timer countdownTimer;
        private int remainingSeconds;

        public CountdownPanel() {
            setLayout(new BorderLayout());

            JPanel inputPanel = new JPanel(new GridLayout(3, 2));
            hourSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 23, 1));
            minuteSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));
            secondSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));

            inputPanel.add(new JLabel("小时:"));
            inputPanel.add(hourSpinner);
            inputPanel.add(new JLabel("分钟:"));
            inputPanel.add(minuteSpinner);
            inputPanel.add(new JLabel("秒:"));
            inputPanel.add(secondSpinner);

            JPanel buttonPanel = new JPanel();
            startButton = new JButton("开始");
            stopButton = new JButton("停止");
            stopButton.setEnabled(false);

            startButton.addActionListener(e -> startCountdown());
            stopButton.addActionListener(e -> stopCountdown());

            buttonPanel.add(startButton);
            buttonPanel.add(stopButton);

            countdownLabel = new JLabel("00:00:00", SwingConstants.CENTER);
            countdownLabel.setFont(new Font("Arial", Font.BOLD, 24));

            add(inputPanel, BorderLayout.NORTH);
            add(countdownLabel, BorderLayout.CENTER);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        private void startCountdown() {
            int hours = (Integer) hourSpinner.getValue();
            int minutes = (Integer) minuteSpinner.getValue();
            int seconds = (Integer) secondSpinner.getValue();

            remainingSeconds = hours * 3600 + minutes * 60 + seconds;
            updateCountdownLabel();

            startButton.setEnabled(false);
            stopButton.setEnabled(true);

            countdownTimer = new java.util.Timer();
            countdownTimer.scheduleAtFixedRate(new java.util.TimerTask() {
                @Override
                public void run() {
                    if (remainingSeconds > 0) {
                        remainingSeconds--;
                        SwingUtilities.invokeLater(() -> updateCountdownLabel());
                    } else {
                        stopCountdown();
                        Winllx.showNotification("倒计时结束", "时间到了");
                    }
                }
            }, 1000, 1000);
        }

        private void stopCountdown() {
            if (countdownTimer != null) {
                countdownTimer.cancel();
                countdownTimer = null;
            }
            startButton.setEnabled(true);
            stopButton.setEnabled(false);
        }

        private void updateCountdownLabel() {
            int hours = remainingSeconds / 3600;
            int minutes = (remainingSeconds % 3600) / 60;
            int seconds = remainingSeconds % 60;
            countdownLabel.setText(String.format("%02d:%02d:%02d", hours, minutes, seconds));
        }
    }

    class StopwatchPanel extends JPanel {

        private JLabel timeLabel;
        private JButton startButton;
        private JButton stopButton;
        private JButton resetButton;
        private javax.swing.Timer stopwatchTimer;
        private long startTime;
        private boolean isRunning;

        public StopwatchPanel() {
            setLayout(new BorderLayout());

            timeLabel = new JLabel("00:00:00.000", SwingConstants.CENTER);
            timeLabel.setFont(new Font("Arial", Font.BOLD, 24));
            add(timeLabel, BorderLayout.CENTER);

            JPanel buttonPanel = new JPanel();
            startButton = new JButton("开始");
            stopButton = new JButton("停止");
            resetButton = new JButton("重置");
            stopButton.setEnabled(false);

            startButton.addActionListener(e -> startStopwatch());
            stopButton.addActionListener(e -> stopStopwatch());
            resetButton.addActionListener(e -> resetStopwatch());

            buttonPanel.add(startButton);
            buttonPanel.add(stopButton);
            buttonPanel.add(resetButton);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        private void startStopwatch() {
            if (!isRunning) {
                startTime = System.currentTimeMillis() - startTime;
                isRunning = true;
                startButton.setEnabled(false);
                stopButton.setEnabled(true);

                stopwatchTimer = new javax.swing.Timer(10, e -> {
                    long elapsed = System.currentTimeMillis() - startTime;
                    updateStopwatchLabel(elapsed);
                });
                stopwatchTimer.start();
            }
        }

        private void stopStopwatch() {
            if (isRunning) {
                if (stopwatchTimer != null) {
                    stopwatchTimer.stop();
                }
                isRunning = false;
                startButton.setEnabled(true);
                stopButton.setEnabled(false);
            }
        }

        private void resetStopwatch() {
            if (stopwatchTimer != null) {
                stopwatchTimer.stop();
            }
            isRunning = false;
            startTime = 0;
            startButton.setEnabled(true);
            stopButton.setEnabled(false);
            timeLabel.setText("00:00:00.000");
        }

        private void updateStopwatchLabel(long elapsed) {
            long hours = elapsed / 3600000;
            long minutes = (elapsed % 3600000) / 60000;
            long seconds = (elapsed % 60000) / 1000;
            long millis = elapsed % 1000;
            timeLabel.setText(String.format("%02d:%02d:%02d.%03d", hours, minutes, seconds, millis));
        }
    }
}
